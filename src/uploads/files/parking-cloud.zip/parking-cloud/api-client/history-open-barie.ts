import axiosClient from '@/api/axios-client';

export const historyOpenBarie = {
    getVehicleTypes(data: {
        ID: string;
        Current: number;
        Limit: number;
        TextSearch: string;
        StartDate: string;
        EndDate: string;
    }) {
        return axiosClient.post('/history-open-barie/find-by-paginate', data);
    },
};
