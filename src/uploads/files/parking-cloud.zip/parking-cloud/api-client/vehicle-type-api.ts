import axiosClient from '@/api/axios-client';

export const vehicleTypeApi = {
    getVehicleTypes() {
        return axiosClient.get('/vehicle-type');
    },
    getVehicleTypeById(id: string) {
        return axiosClient.get(`/vehicle-type/${id}`);
    },
    getVehiclTypeByIdParking(data: {
        ID: string;
        Current: number;
        Limit: number;
        TextSearch?: string;
    }) {
        return axiosClient.post(`/vehicle-type/find-by-parking`, data);
    },
    updateVehicleType(payload: {
        Description?: string;
        IsDelete?: true;
        Name?: string;
        ParkingId?: string;
        ID: string;
        IsPlateNumber?: boolean;
    }) {
        return axiosClient.put(`/vehicle-type`, payload);
    },
    createVehicleType(payload: {
        Name: string;
        Description: string;
        IsPlateNumber: boolean;
        ParkingId: string;
    }) {
        return axiosClient.post('/vehicle-type', payload);
    },
    importVehicleType(payload: FormData) {
        return axiosClient.post('/vehicle-type/create-by-excel', payload, {
            headers: {
                'Content-Type': 'multipart/form-data',
            },
        });
    },
};
