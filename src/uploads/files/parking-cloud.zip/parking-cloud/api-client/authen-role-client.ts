import axiosClient from '@/api/axios-client';
export const AuthenKeyApi = {
    getKeyClient(payload: any) {
        return axiosClient.post('/authen-role-client/find-by-paginate', payload);
    },
    createKeyClient(payload: any) {
        return axiosClient.post('/authen-role-client', payload);
    },
    updateKeyClient(payload: any) {
        return axiosClient.put('/authen-role-client', payload);
    },
    deleteKeyClient(id: String) {
        return axiosClient.delete(`/authen-role-client/${id}`);
    },
};
