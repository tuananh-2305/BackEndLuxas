import { AccountCreatePayload, LoginPayload, RegisterPayload } from '@/models/index';
import axiosClient from '@/api/axios-client';

export const authApi = {
    login(payload: LoginPayload) {
        return axiosClient.post('/login', payload);
    },

    checkLoginCloud(payload: LoginPayload) {
        return axiosClient.post('/user/check-login', payload);
    },

    logout(token: string) {
        return axiosClient.delete(`/logout/${token}`);
    },
    forceLogout(token: string) {
        return axiosClient.delete(`/force-logout/${token}`);
    },
    getProfile() {
        return axiosClient.get('/profile');
    },

    getListUser(data: { Current: number; Limit: number; TextSearch: string }) {
        return axiosClient.post('/user/find-list-user', data);
    },
    getHistoryLogin(data: { Current: number; Limit: number; TextSearch: string }) {
        return axiosClient.post('/user/get-history-login', data);
    },
    getHistoryDevice(data: { Current: number; Limit: number; TextSearch: string }) {
        return axiosClient.post('/user/get-device-login', data);
    },
    register(payload: AccountCreatePayload) {
        return axiosClient.post('/register', payload);
    },

    update(payload: AccountCreatePayload) {
        return axiosClient.put('/user/update-user-by-web', payload);
    },

    updateByAdmin(payload: AccountCreatePayload) {
        return axiosClient.put('/user/admin/update-user-by-admin', payload);
    },

    delete(id: string) {
        return axiosClient.delete(`/user/${id}`);
    },

    sendOtp(phone: string) {
        return axiosClient.get(`/user/send-otp/${phone}`);
    },
    checkOtp(phone: string, otp: string) {
        return axiosClient.get(`/user/check-otp/${phone}/${otp}`);
    },
    resetOtp(phone: string) {
        return axiosClient.get(`/user/reset-otp/${phone}`);
    },
    changePassword(data: { ID: string; NewPassword: string }) {
        return axiosClient.post('/change-password', data);
    },
    updateUserData(data: FormData) {
        return axiosClient.put('/user/update-user-by-web', data, {
            headers: {
                'Content-Type': 'multipart/form-data',
            },
        });
    },
};
