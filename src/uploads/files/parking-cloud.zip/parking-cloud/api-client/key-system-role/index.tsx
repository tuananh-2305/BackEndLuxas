import axiosClient from '@/api/axios-client';

export interface ISystemRole {
    Name: string;
    KeyWord: string;
    IsValue: boolean;
}

export const systemRoleApi = {
    allRole() {
        return axiosClient.get('/key-setting-cloud');
    },
    roleById(id: string) {
        return axiosClient.get(`/key-setting-cloud/${id}`);
    },
    groupRoleByParkingId(ParkingId: string) {
        return axiosClient.get(`/system-setting-cloud/find-by-parking/${ParkingId}`);
    },
    createRole(payload: ISystemRole) {
        return axiosClient.post('/key-setting-cloud', payload);
    },
    createGroupRole(
        ParkingId: string,
        DataCreate: {
            KeySettingId: string;
            IsUse: boolean;
            Value: string;
        }[]
    ) {
        return axiosClient.post(`/system-setting-cloud`, { ParkingId, DataCreate });
    },
    updateRole(ID: string, payload: ISystemRole) {
        return axiosClient.put('/key-setting-cloud', { ...payload, ID });
    },
    updateGroupRole(
        DataUpdate: {
            ID: string;
            IsUse: boolean;
            Value: string;
        }[]
    ) {
        return axiosClient.put('/system-setting-cloud', { DataUpdate });
    },
    deleteRole(id: string) {
        return axiosClient.delete(`/key-setting-cloud/${id}`);
    },
    deleteRoleByUserAndParking(userId: string, parkingId: string) {
        return axiosClient.delete(`/system-setting-cloud/${userId}/${parkingId}`);
    },
};
