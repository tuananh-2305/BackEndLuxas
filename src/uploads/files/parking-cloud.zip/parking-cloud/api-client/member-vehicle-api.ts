import axiosClient from '@/api/axios-client';
import { PaginationIDPayload } from '@/models/config.model';
import {
    CreateVehicleAndAuthen,
    MemberVehicleCreatePayload,
    MemberVehicleUpdatePayload,
} from '@/models/member.vehicle.model';

export const memberVehicleApi = {
    getMemberVehicleByIdMember(payload: PaginationIDPayload) {
        return axiosClient.post(`/member-vehicle/find-by-member`, payload);
    },
    createMemberVehicle(payload: MemberVehicleCreatePayload) {
        return axiosClient.post('/member-vehicle', payload);
    },
    updateMemberVehicle(payload: MemberVehicleUpdatePayload) {
        return axiosClient.put('/member-vehicle', payload);
    },

    getMemberVehicleByIdMemberAndParking(idParking: string, payload: PaginationIDPayload) {
        return axiosClient.post(`/member-vehicle/find-by-member-and-parking-with-paginate`, {
            ...payload,
            ParkingId: idParking,
        });
    },
    makeResportLostVehicle(data: { PlateNumber: string; Description?: string; ParkingId: string }) {
        return axiosClient.post('/lost-vehicle', data);
    },
    makeResportLostVehicleV2(data: {
        ParkingId: string;
        PlateNumber?: string;
        Description: string;
        VehicleType?: string;
        VehicleBrand?: string;
        VehicleColor?: string;
        Address?: string;
    }) {
        return axiosClient.post('/lost-vehicle', data);
    },
    updateResportLostVehicle(data: {
        ParkingId: string;
        Status?: string;
        PlateNumber?: string;
        ID: string;
        IsCancelVehicle?: boolean;
        Description?: string;
    }) {
        return axiosClient.put('/lost-vehicle', data);
    },
    getAllReportLostVehicle(payload: {
        ID: string;
        Current: number;
        Limit: number;
        Name: string;
        Phone: string;
        Address: string;
        PlateNumber: string;
        StartDate: string;
        EndDate: string;
    }) {
        return axiosClient.post('/lost-vehicle/find-by-paginate', payload);
    },
    removeLostVehicle(id: string) {
        return axiosClient.delete(`/lost-vehicle/${id}`);
    },
    getAllVehicelByParking(payload: {
        ID: string;
        Current: number;
        Limit: number;
        Option: string;
        Address: string;
        PlateNumber: string;
        Name: string;
        Phone: string;
    }) {
        return axiosClient.post('/member-vehicle/find-by-parking-with-paginate', payload);
    },

    createVehicleAndAuthen(payload: CreateVehicleAndAuthen) {
        return axiosClient.post('/member-vehicle/create-list-vehicle-and-authen', payload);
    },
    downloadMemberVehicle(id: string) {
        return axiosClient.get(`/member-vehicle/export-excel/${id}`);
    },
    checkPlaceNo(placeNo: string, parkingId: string) {
        return axiosClient.get(`/member-vehicle/check-exist-plate-number/${placeNo}/${parkingId}`);
    },
    getCountCategory(parkingId: string) {
        return axiosClient.get(`/member-vehicle/count-category-by-parking-id/${parkingId}`);
    },
    deleteMultiple(payload: any) {
        return axiosClient.post(`/member-vehicle/delete-list-member-vehicle`, payload);
    },
};
