import axiosClient from '@/api/axios-client';
export const addressApi = {
    getProvinces() {
        return axiosClient.get('/address/provinces');
    },
    getDistricts(idProvice: string) {
        return axiosClient.get(`/address/districts/${idProvice}`);
    },
    getWards(idProvince: string, idDistrict: string) {
        return axiosClient.get(`/address/wards/${idProvince}/${idDistrict}`);
    },
};
