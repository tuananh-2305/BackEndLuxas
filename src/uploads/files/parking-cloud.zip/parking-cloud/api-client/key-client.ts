import axiosClient from '@/api/axios-client';
export const KeyClientApi = {
    getKeyClient() {
        return axiosClient.get('/key-role-client');
    },
    createKeyClient(payload: any) {
        return axiosClient.post('/key-role-client', payload);
    },
    updateKeyClient(payload: any) {
        return axiosClient.put('/key-role-client', payload);
    },
    deleteKeyClient(id: string) {
        return axiosClient.delete(`/key-role-client/${id}`);
    },
};
