import axiosClient from '@/api/axios-client';

export const keyRoleApi = {
    getKeyRole() {
        return axiosClient.get('/key-role');
    },
    getKeyRoleById(id: string) {
        return axiosClient.get(`/key-role/${id}`);
    },
};
