import axiosClient from '@/api/axios-client';
import { PaginationIDPayload } from '@/models/config.model';

export const groupRoleApi = {
    // getGroupRole() {
    //     return axiosClient.get('/group-role');
    // },
    getGroupRoleById(id: string) {
        return axiosClient.get(`/group-role/${id}`);
    },
    getGroupRoleByParkingId(id: string) {
        return axiosClient.get(`/group-role/find-by-parking/${id}`);
    },
    createGroupRole(data: any) {
        return axiosClient.post('/group-role', data);
    },
    updateGroupRole(data: any) {
        return axiosClient.put('/group-role', data);
    },
    getGroupRoleByCustomerId(id: string) {
        return axiosClient.get(`/group-role/find-by-customer/${id}`);
    },
    deleteGroupRole(id: string) {
        return axiosClient.delete(`/group-role/${id}`);
    },
    getGroupRolePaginate(payload: PaginationIDPayload) {
        return axiosClient.post(`/group-role/find-by-customer`, payload);
    },
};
