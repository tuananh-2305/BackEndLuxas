import axiosClient from '@/api/axios-client';
import { PaginationPayload } from '@/models/config.model';
import { ParkingCreatePayload, ParkingUpdatePayload } from '@/models/parking.model';

export const parkingApi = {
    getAllParking() {
        return axiosClient.get('/parking');
    },
    syncData(idParking: string) {
        return axiosClient.get(`/request-synchronized-data/${idParking}`);
    },
    getParkingById(id: string) {
        return axiosClient.get(`/parking/${id}`);
    },
    createParking(payload: ParkingCreatePayload) {
        return axiosClient.post('/parking', payload);
    },
    updateParking(payload: ParkingUpdatePayload) {
        return axiosClient.put(`/parking`, payload);
    },
    getAllParkingPaging(payload: PaginationPayload) {
        return axiosClient.post('/parking/find-all-by-paginate', payload);
    },
    deleteParking(id: string) {
        return axiosClient.delete(`/parking/${id}`);
    },
    getAllCameraByParkingId(id: string) {
        return axiosClient.get(`/camera/find-by-parking/${id}`);
    },
};
