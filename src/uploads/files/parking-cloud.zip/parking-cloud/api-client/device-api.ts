import axiosClient from '@/api/axios-client';
import { DeviceCreatePayload } from '../models';

export const deviceApi = {
    createDevice(payload: DeviceCreatePayload) {
        return axiosClient.post('/device', payload);
    },
    getAllDevice() {
        return axiosClient.get('/device');
    },
    getAllDeviceInParking(parkingId: string) {
        return axiosClient.get(`/device/find-by-parking/${parkingId}`);
    },
    updateDevice(payload: { ID: string; Name?: string; Port?: string }) {
        return axiosClient.put('/device', payload);
    },
    updateSeverDevice(payload: { ID: string; ParkingId: string }) {
        return axiosClient.put('/update-server', payload);
    },
    unlink(id: string) {
        return axiosClient.delete(`/device/${id}`);
    },
};
