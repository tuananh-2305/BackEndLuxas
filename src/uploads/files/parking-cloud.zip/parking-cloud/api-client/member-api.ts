import axiosClient from '@/api/axios-client';
import {
    MemberCreatePayload,
    MemberLinkParkingCreatePayload,
    MemberUpdatePayload,
} from '@/models/member.model';
import { GenericAbortSignal } from 'axios';

export const memberApi = {
    getMember() {
        return axiosClient.get('/member');
    },
    getMemberLog(data: {
        ID?: string;
        ParkingId: string;
        Current: number;
        Limit: number;
        TextSearch?: string;
        Action: 'ALL' | 'UPDATE' | 'DELETE' | 'CREATE';
        TableName: 'ALL' | 'MemberVehicles' | 'Authentications' | 'Members' | 'CardGuest';
        Option: 'TODAY' | 'YESTERDAY' | 'ALL';
    }) {
        return axiosClient.post('/history-log/find-history-log-by-member-and-paginate', data);
    },
    getMemberById(id: string) {
        return axiosClient.get(`/member/${id}`);
    },
    getMemberParkingById(id: string, parkingId: string) {
        return axiosClient.get(`/member/find-by-id-with-parking/${id}/${parkingId}`);
    },
    // /member/find-by-id-with-parking/{id}/{parkingId}

    getMemberByParkingId(id: string) {
        return axiosClient.get(`/member/find-by-parking/${id}`);
    },
    searchMemberByPhone(phone: string, parking: string) {
        return axiosClient.get(`/member/find-by-phone/${phone}/${parking}`);
    },
    getMemberByParkingIdPaginate(payload: {
        ID: string;
        Current: number;
        Limit: number;
        TextSearch: string;
    }) {
        return axiosClient.post(`/member/find-by-parking`, payload);
    },
    getMemberByParkingIdPaginateSearch(
        payload: {
            ID: string;
            Current: number;
            Limit: number;
            Address: string;
            PlateNumber: string;
            CardNumber: string;
            IdCard: string;
            Name: string;
            Phone: string;
        },
        signal?: GenericAbortSignal | undefined
    ) {
        return axiosClient.post('/member/find-by-parking-with-member-search', payload, { signal });
    },
    coutMemberByMemberTypeAndParking(parkingId: string) {
        return axiosClient.get(`/member/count-member-for-member-type/${parkingId}`);
    },
    getMemberByParkingIdPaginateSearchV2(
        payload: {
            ID: string;
            Current: number;
            Limit: number;
            Address: string;
            PlateNumber: string;
            CardNumber: string;
            IdCard: string;
            Name: string;
            Phone: string;
            UserCreate: string;
            MemberTypeId: string;
        },
        signal?: GenericAbortSignal | undefined
    ) {
        return axiosClient.post('/member/find-by-parking-with-member-search-v2', payload, {
            signal,
        });
    },
    createPayment(payload: {
        MemberId: string;
        PlateNumber: string;
        PaymentMethods: 'MONEY' | 'MOMO' | 'NAPAS';
        TotalMoney: number;
        Description: string;
    }) {
        return axiosClient.post('/payment-history', payload);
    },
    getPaymentHistory(paylopad: {
        ParkingId: string;
        Current: number;
        StartDate: Date;
        EndDate: Date;
        Limit: number;
        TextSearch: string;
        PaymentMethods: 'ALL' | 'MONEY' | 'MOMO' | 'NAPAS';
    }) {
        return axiosClient.post('/payment-history/find-by-paginate', paylopad);
    },
    getFuturesTradesByParking(paylopad: {
        ID: string;
        Current: number;
        Limit: number;
        TextSearch: string;
        // StartDate: Date;
        // EndDate: Date;
    }) {
        return axiosClient.post('/member/find-futures-trades-by-parking', paylopad);
    },
    // MemberCreatePayload
    createMember(data: FormData) {
        return axiosClient.post('/member', data, {
            headers: {
                'Content-Type': 'multipart/form-data',
            },
        });
    },
    removeMoreMember(payload: { ListMemberParkingId: string[]; ParkingId: string }) {
        return axiosClient.post('/member/delete-by-list-member', payload);
    },
    linkMemberParking(data: MemberLinkParkingCreatePayload) {
        return axiosClient.post('/member/create-member-parking', data);
    },
    updateMember(data: FormData) {
        return axiosClient.put('/member', data, {
            headers: {
                'Content-Type': 'multipart/form-data',
            },
        });
    },
    deleteMember(idMemberParking: string, idParking: string) {
        return axiosClient.delete(`/member/${idMemberParking}/${idParking}`);
    },
    updateMemberPayload(data: MemberUpdatePayload) {
        return axiosClient.put('/member', data);
    },
    downloadParkingMember(id: string) {
        return axiosClient.get(`/member/download/${id}`);
    },
    exportParkingMember(id: string) {
        return axiosClient.get(`/member/export-excel/${id}`);
    },
    exportDataForTargetMember(payload: {
        ParkingId: string;
        ListMember: string[];
        Option: 'ALL' | 'ELEVATOR' | 'CARDMONTH';
    }) {
        return axiosClient.post(`/authentication/export-excel-by-list-member`, payload);
    },
    importParkingMember(data: FormData) {
        return axiosClient.post('/member/create-by-excel', data, {
            headers: {
                'Content-Type': 'multipart/form-data',
            },
        });
    },
};
