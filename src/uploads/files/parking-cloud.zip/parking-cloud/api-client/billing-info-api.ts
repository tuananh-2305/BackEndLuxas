import { BillingInfoCreatePayload, BillingInfoUpdatePayload } from './../models/billing.info.model';
import axiosClient from '@/api/axios-client';
import { DeviceImeiCreatePayload, DeviceImeiUpdate } from '@/models/device.imei.model';

export const billingInfoApi = {
    findByParkingId(parkingId: string) {
        return axiosClient.get(`/billing-info/find-by-parking/${parkingId}`);
    },
    create(payload: BillingInfoCreatePayload) {
        return axiosClient.post('/billing-info', payload);
    },
    update(payload: BillingInfoUpdatePayload) {
        return axiosClient.put('/billing-info', payload);
    },
    delete(id: string) {
        return axiosClient.delete(`/billing-info/${id}`);
    },
};
