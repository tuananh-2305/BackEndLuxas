import axiosClient from '@/api/axios-client';
import { PaginationIDPayload } from '@/models/config.model';

export const userParkingApi = {
    getListUserCanCreateParking(idParking: string) {
        return axiosClient.get(`/user-parking/find-user-out-parking/${idParking}`);
    },
    createUserParking(payload: any) {
        return axiosClient.post('/user-parking', payload);
    },
    getListUserParkingByParkingId(idParking: string) {
        return axiosClient.get(`/user-parking/find-staff-by-parking/${idParking}`);
    },
    deleteUserParking(idUserParking: string) {
        return axiosClient.delete(`/user-parking/${idUserParking}`);
    },
    getListUserParking(idParking: string) {
        return axiosClient.get(`/user-parking/find-by-parking/${idParking}`);
    },
    updateUserParking(payload: any) {
        return axiosClient.put(`/user-parking`, payload);
    },
    getListUserParkingPaginate(payload: PaginationIDPayload) {
        return axiosClient.post(`/user-parking/find-by-parking`, payload);
    },
};
