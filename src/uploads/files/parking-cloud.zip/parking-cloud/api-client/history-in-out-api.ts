import { data } from './../components/product-langing/footer/data.mock';
import axiosClient from '@/api/axios-client';
import { HistoryExportPayload, HistoryRevenueExportPayl, PaginationIDPayload } from '../models';

export const historyInOutApi = {
    memberInParking(data: {
        ParkingId: string;
        CodeCardIn: string;
        PlateNumberIn: string;
        IdVehicleType: string;
    }) {
        return axiosClient.post('/history-in-out/create-by-web', { ...data, TYPE_AUTH: 'CARD' });
    },
    checkByCardNumberAndParkingId(payload: { ParkingId: string; Data: string[] }) {
        return axiosClient.post(`/history-in-out/find-by-card-number`, payload);
    },
    checkByPlateNumberAndParking(payload: { ParkingId: string; Data: string[] }) {
        return axiosClient.post(`/history-in-out/find-list-plate-number-in-parking`, payload);
    },
    updateHistoryInOut(id: string) {
        return axiosClient.put('/history-in-out', { ID: id });
    },
    memberOutParking(id: string, cardId: string) {
        return axiosClient.put('/history-in-out/update-by-web', { ID: id, CodeCardOut: cardId });
    },
    findManyHistoryByVehicelId(ParkingId: string, vehicelIds: string[]) {
        return axiosClient.post(`/history-in-out/find-history-by-member-vehicle`, {
            ParkingId,
            Data: vehicelIds,
        });
    },
    findMemberInParking(cardNumber: string, parkingId: string) {
        return axiosClient.get(`/history-in-out/find-by-card-number/${cardNumber}/${parkingId}`);
    },
    findByPlateNumberInParking(plateNumber: string) {
        return axiosClient.get(`/history-in-out/find-by-plate-number-in-parking/${plateNumber}`);
    },
    dashboard(payload: { ParkingId: string; StartDate: Date; EndDate: Date }) {
        return axiosClient.post('/history-in-out/dashboard', payload);
    },
    dashboardToday(idParking: string) {
        return axiosClient.get('/history-in-out/dashboard/' + idParking);
    },
    getHistoryPaginate(payload: any) {
        return axiosClient.post('/history-in-out/find-by-parking-id-with-paginate', payload);
    },
    exportHistory(payload: HistoryExportPayload) {
        return axiosClient.post('/history-in-out/report-history-by-excel', payload);
    },
    exportHistoryRevenueByExcel(payload: HistoryRevenueExportPayl) {
        return axiosClient.post('/history-in-out/report-revenue-by-excel', payload);
    },
    getRevenueByVehicleType(payload: HistoryRevenueExportPayl) {
        return axiosClient.post('/history-in-out/revenue-by-vehicle-type', payload);
    },
    exportExcelReport(data: { ParkingId: string; StartDate: string; EndDate: string }) {
        return axiosClient.post('/history-in-out/report-revenue-by-excel', data);
    },
    checkPrice(data: {
        ParkingId: string;
        VehicleTypeId: string;
        TimeOut: string;
        TimeIn: string;
    }) {
        return axiosClient.post('/history-in-out/check-price', data);
    },
    updatePriceOrVehicleType(data: {
        IdVehicleType: string;
        Price: string;
        ID: string;
        Description: string;
    }) {
        return axiosClient.put('/history-in-out/update-price-or-vehicle-type', data);
    },
    getLogHistoryEdit(data: PaginationIDPayload) {
        return axiosClient.post('/history-edit-price/find-by-history-in-out/', data);
    },
};
