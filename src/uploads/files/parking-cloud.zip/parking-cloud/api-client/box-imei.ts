import axiosClient from '@/api/axios-client';
import { DeviceImeiCreatePayload, DeviceImeiUpdate } from '@/models/device.imei.model';

export const boxImeiApi = {
    getBoxImeis(data: { Current: number; Limit: number; TextSearch: string }) {
        return axiosClient.post('/box-imei/find-by-paginate', data);
    },
    getBoxImeiById(id: string) {
        return axiosClient.get(`/box-imei/${id}`);
    },
    createBoxImei(payload: DeviceImeiCreatePayload) {
        return axiosClient.post('/box-imei', payload);
    },
    findAllBoxImageNotLink() {
        return axiosClient.get('/box-imei/find-all-not-link');
    },
    updateDataImei(data: DeviceImeiUpdate) {
        return axiosClient.put('/box-imei', data);
    },
    deleteBoxImei(id: string) {
        return axiosClient.delete(`/box-imei/${id}`);
    },
};
