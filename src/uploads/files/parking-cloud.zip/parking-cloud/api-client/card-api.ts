import axiosClient from '@/api/axios-client';
import { CardCreatePayload, CardUpdatePayload } from '@/models/card.model';

export const cardApi = {
    getCard() {
        return axiosClient.get('/authentication');
    },
    getCardById(id: string) {
        return axiosClient.get(`/authentication/${id}`);
    },
    getCardByParkingId(id: string) {
        return axiosClient.get(`/authentication/find-by-parking/${id}`);
    },
    getCheckCard(cardNumber: string, parkingId: string) {
        return axiosClient.get(`/authentication/find-by-card-number/${cardNumber}/${parkingId}`);
    },
    getMemberByParkingIdPaginate(paload: any) {
        return axiosClient.post(`/authentication/find-by-parking`, paload);
    },
    createCard(data: FormData) {
        return axiosClient.post('/authentication', data, {
            headers: {
                'Content-Type': 'multipart/form-data',
            },
        });
    },
    updateCard(data: FormData) {
        return axiosClient.put('/authentication', data, {
            headers: {
                'Content-Type': 'multipart/form-data',
            },
        });
    },
    downloadCard(id: string) {
        return axiosClient.get(`/authentication/download/${id}`);
    },
    exportCard(parkingId: string, option: string) {
        return axiosClient.get(`/authentication/export-excel/${parkingId}/${option}`);
    },
    importCard(data: FormData) {
        return axiosClient.post('/authentication/create-by-excel', data, {
            headers: {
                'Content-Type': 'multipart/form-data',
            },
        });
    },
    makeResportLostCard(data: { CardNumber: string; Description: string; ParkingId: string }) {
        return axiosClient.post('/lost-card', data);
    },
    updateResportLostCard(data: {
        ParkingId: string;
        Status?: string;
        CardNumber?: string;
        ID: string;
        IsCancelCard?: boolean;
        Description?: string;
    }) {
        return axiosClient.put('/lost-card', data);
    },
    getAllReportLostCard(payload: {
        ID: string;
        Current: number;
        Limit: number;
        CardNumber: string;
        IdCard: string;
        Name: string;
        Phone: string;
        Address: string;
        StartDate: string;
        EndDate: string;
    }) {
        return axiosClient.post('/lost-card/find-by-paginate', payload);
    },
    dashboardLostHistory(parkingId: string) {
        return axiosClient.get(`/lost-card/dashboard/${parkingId}`);
    },
    getCardByParkingIdAndMemberIdAndPagination(payload: {
        ID: string;
        ParkingId: string;
        Current: number;
        Limit: number;
        TextSearch: string;
    }) {
        return axiosClient.post('/authentication/find-bymember-and-parking-with-paginate', payload);
    },
    removeLostCard(id: string) {
        return axiosClient.delete(`/lost-card/${id}`);
    },

    // card guest
    getCardGuestPagination(paload: any) {
        return axiosClient.post(`/card-guest/find-by-paginate`, paload);
    },
    createCardGuest(paload: any) {
        return axiosClient.post('/card-guest', paload);
    },
    updateCardGuest(paload: any) {
        return axiosClient.put('/card-guest', paload);
    },
    deleteCardGuest(id: any) {
        return axiosClient.delete(`/card-guest/${id}`);
    },
    remodeCard(id: string) {
        const item = {
            ID: id,
            IsLostCard: false,
        };
        return axiosClient.post('/authentication/delete', item);
    },
    remodeWhenLostCard(
        data: { ID: string; CardNumberNew: string; IdCardNew: string },
        cb: (state: number | 'done') => void
    ) {
        const item = {
            ...data,
            IsLostCard: true,
        };
        return axiosClient.post('/authentication/delete', item, {
            onUploadProgress: function (progressEvent) {
                const percentCompleted = Math.round(
                    (progressEvent.loaded * 100) / (progressEvent.total ? progressEvent.total : 1)
                );
                if (percentCompleted !== 100) {
                    cb(percentCompleted);
                } else {
                    cb('done');
                }
            },
        });
    },
    removeMutipleCard(ParkingId: string, ListID: string[]) {
        const item = {
            ParkingId: ParkingId,
            ListID: ListID,
        };
        return axiosClient.post('/authentication/delete-list-authentication', item);
    },
    removeMutipleCardGuest(ParkingId: string, ListID: string[]) {
        const item = {
            ParkingId: ParkingId,
            ListID: ListID,
        };
        return axiosClient.post('/card-guest/delete-list-card-guest', item);
    },
    downloadCardGuest(id: string) {
        return axiosClient.get(`card-guest/export-excel//${id}`);
    },

    getCountCategory(parkingId: string, option: 'CARDMONTH' | 'ELEVATOR') {
        return axiosClient.get(
            `/authentication/count-category-authentication/${parkingId}/${option}`
        );
    },
    getCountCardGuestCategory(parkingId: string) {
        return axiosClient.get(`/card-guest/count-category-by-parking-id/${parkingId}`);
    },
};
