import axiosClient from '@/api/axios-client';
import { CustomerUpdatePayload } from '@/models/customer.model';

export const customerApi = {
    getCustomers(data: { Current: number; Limit: number; TextSearch: string }) {
        return axiosClient.post('/customer/find-all-by-paginate', data);
    },
    getCustomerById(id: string) {
        return axiosClient.get(`/customer/${id}`);
    },
    createCustomer(payload: any) {
        return axiosClient.post('/customer', payload, {
            headers: { 'Content-Type': 'multipart/form-data' },
        });
    },
    updateCustomer(payload: FormData) {
        return axiosClient.put('/customer', payload, {
            headers: { 'Content-Type': 'multipart/form-data' },
        });
    },
    deleteCustomer(id: string) {
        return axiosClient.delete(`/customer/${id}`);
    },
};
