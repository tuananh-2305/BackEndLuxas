import axiosClient from '@/api/axios-client';

export const vehicelBranchApi = {
    pagination(payload: { Current: number; Limit: number; TextSearch: string }) {
        return axiosClient.post('/vehicle-brand/find-by-paginate', payload);
    },
    byId(id: string) {},
    create(name: string) {
        return axiosClient.post('/vehicle-brand', { Name: name });
    },
    update(payload: { Name: string; ID: string }) {
        return axiosClient.put('/vehicle-brand', payload);
    },
    remove(id: string) {
        return axiosClient.delete(`/vehicle-brand/${id}`);
    },
};
