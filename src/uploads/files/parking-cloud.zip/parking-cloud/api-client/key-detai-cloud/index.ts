import axiosClient from '@/api/axios-client';

export const keyDetailCloudApi = {
    all() {
        return axiosClient.get('/key-role-detail-cloud');
    },
    create(data: { Name: string; KeyWord: string }) {
        return axiosClient.post('/key-role-detail-cloud', data);
    },
    update(data: { ID: string; Name: string; KeyWord: string }) {
        return axiosClient.put('/key-role-detail-cloud', data);
    },
    delete(id: string) {
        return axiosClient.delete(`/key-role-detail-cloud/${id}`);
    },
};
