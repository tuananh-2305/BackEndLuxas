import axiosClient from '@/api/axios-client';
export const AuthenVipApi = {
    getKeyClient(payload: any) {
        //authentication-vip/find-by-paginate
        return axiosClient.post('/authentication-vip/find-by-paginate', payload);
    },
    createKeyClient(payload: any) {
        return axiosClient.post('/authentication-vip', payload);
    },
    updateKeyClient(payload: any) {
        return axiosClient.put('/authentication-vip', payload);
    },
    deleteKeyClient(id: String) {
        return axiosClient.delete(`/authentication-vip/${id}`);
    },
};
