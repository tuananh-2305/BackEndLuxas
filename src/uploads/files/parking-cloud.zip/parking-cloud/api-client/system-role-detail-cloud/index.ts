import axiosClient from '@/api/axios-client';

export const systemRoleDetailRoleApi = {
    byUser(userID: string) {
        return axiosClient.get(`/system-role-detail-cloud/find-by-user/${userID}`);
    },
    byUserAndParking(userID: string, parkingID: string) {
        return axiosClient.get(
            `/system-role-detail-cloud/find-by-user-and-parking/${userID}/${parkingID}`
        );
    },
    create(payload: {
        UserId: string;
        ParkingId: string;
        DataCreate: { KeyRoleDetailId: string; IsUse: boolean }[];
    }) {
        return axiosClient.post('/system-role-detail-cloud', payload);
    },
    update(payload: {
        DataUpdate: {
            ID: string;
            IsUse: boolean;
        }[];
    }) {
        return axiosClient.put('/system-role-detail-cloud', payload);
    },
    delete(userId: string, parkingId: string) {
        return axiosClient.delete(`/system-role-detail-cloud/${userId}/${parkingId}`);
    },
};
