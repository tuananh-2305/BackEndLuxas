import axiosClient from '@/api/axios-client';
import { SearchData } from '../models';

export const searchApi = {
    search(payload: SearchData) {
        return axiosClient.post('/search-data', payload);
    },
};
