import axios, {
    AxiosError,
    AxiosRequestConfig,
    AxiosResponse,
    InternalAxiosRequestConfig,
} from 'axios';
import { CookieStoreControl } from '@/hooks/cookie-storage';
const LOGIN_URL = '/login';

const axiosClient = axios.create({
    baseURL: '/service',
    // timeout: 5000,
    headers: {
        'Content-Type': 'application/json',
    },
});

const cookieInstance = CookieStoreControl.getInstance();
axiosClient.interceptors.request.use(
    (config: InternalAxiosRequestConfig) => {
        const accessToken = cookieInstance.token.get_access_token();
        if (accessToken) {
            config.headers.Authorization = 'Bearer ' + accessToken;
        }

        return config;
    },
    (err: AxiosError) => {
        console.log('error request');
        return Promise.reject(err);
    }
);

axiosClient.interceptors.response.use(
    async (response: AxiosResponse) => {
        return response;
    },

    async (err) => {
        console.log(err.response);

        if (err.response && err.response?.data) {
        } else {
            return Promise.reject(err);
        }
        const { statusCode, message } = err.response?.data as any;
        const rf_token = cookieInstance.token.get_refesh_token();
        if (statusCode === 401) {
            switch (message) {
                case 'R_TOKEN_NOT_EXIST':
                case 'R_TOKEN_EXPIRED':
                    cookieInstance.token.remove_refesh_token();
                    cookieInstance.token.remove_access_token();
                    window.location.replace(LOGIN_URL);
                    return Promise.reject(err);

                case 'DATA_NOT_VALIDATE':
                    return Promise.reject(err);
                case 'A_TOKEN_EXPIRED':
                case 'USER_NOT_VALIDATE':
                case 'Unauthorized':
                    if (rf_token) {
                        axiosClient.get(`/renew-token/${rf_token}`).then(async (res) => {
                            const { message, accessToken, expired } = res.data;
                            if (message === 'RENEW_SUCCESS') {
                                cookieInstance.token.set_access_token(accessToken, expired);
                                return await axiosClient(err.config);
                            } else {
                                cookieInstance.token.remove_access_token();
                                cookieInstance.token.remove_refesh_token();

                                if (window) {
                                    window.location.replace(LOGIN_URL);
                                }
                            }
                        });
                    } else {
                        cookieInstance.token.remove_access_token();
                        window.location.replace(LOGIN_URL);
                        return Promise.reject(err);
                    }
                    break;

                default:
                    return Promise.reject(err);
            }
        } else {
            return Promise.reject(err);
        }
    }
);

export default axiosClient;
