import axiosClient from '@/api/axios-client';
import { MemberTypeCreatePayload, MemberTypeUpdatePayload } from '@/models/member.type.model';

export const memberTypeApi = {
    getMemberType() {
        return axiosClient.get('/member-type');
    },
    getMemberTypeById(id: string) {
        return axiosClient.get(`/member-type/${id}`);
    },
    getMemberTypeByParkingId(data: {
        ID: string;
        Current: number;
        Limit: number;
        TextSearch?: string;
    }) {
        return axiosClient.post(`/member-type/find-by-parking`, {
            ID: data.ID,
            Current: data.Current,
            Limit: data.Limit,
            TextSearch: data.TextSearch,
        });
    },
    createMemberType(data: MemberTypeCreatePayload) {
        return axiosClient.post('/member-type', data);
    },
    updateMemberType(data: MemberTypeUpdatePayload) {
        return axiosClient.put('/member-type', data);
    },
    importMemberType(data: FormData) {
        return axiosClient.post('/member-type/create-by-excel', data, {
            headers: {
                'Content-Type': 'multipart/form-data',
            },
        });
    },
};
