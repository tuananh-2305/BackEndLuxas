import axiosClient from '@/api/axios-client';
import { PaginationIDPayload } from '../models';

export const staffApi = {
    getAllParking(payload: PaginationIDPayload) {
        return axiosClient.post(`/user-parking/find-staff-by-parking`, payload);
    },
};
