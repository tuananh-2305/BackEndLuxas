import axiosClient from '../axios-client';
import { PostFormula, PutFormula, TestFomula } from './interface';
export const formulaApi = {
    formulasByVehicle(data: { ParkingId: string; VehicleTypeId: string; TextSearch: string }) {
        return axiosClient.post(`/formula/find-by-vehicle-and-parking`, data);
    },
    updateFomular(data: PutFormula) {
        return axiosClient.put('/formula', data);
    },
    createFumular(data: PostFormula) {
        return axiosClient.post('/formula', data);
    },
    testFomular(data: TestFomula) {
        return axiosClient.post('/formula/test-formula', data);
    },
    getTotalPrice(parkingId: string, vehicleTypeId: string) {
        return axiosClient.get(`/formula/get-total-price-card-month/${parkingId}/${vehicleTypeId}`);
    },
};
