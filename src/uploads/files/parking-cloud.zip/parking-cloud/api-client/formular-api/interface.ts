export interface PostFormula {
    Description?: string;
    HourPrice?: string;
    Type?: 'HOUR' | 'MONTH' | 'SURCHARGE';
    Price?: string;
    Cycle?: string;
    Optional?: string;
    CycleDate?: string;
    TimeIn?: string;
    TimeOut?: string;
    Day?: string[];
    FreeTime?: string;
    IsFree?: boolean;
    Name?: string;
    VehicleTypeId?: string;
    ParkingId?: string;
}

export interface PutFormula extends PostFormula {
    ID: string;
    IsDelete?: boolean;
}

export interface TestFomula {
    ListIdFormula: string[];
    ParkingId: string;
    VehicleTypeId: string;
    TimeIn: Date;
    TimeOut: Date;
}
