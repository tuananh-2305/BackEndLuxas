import axiosClient from '@/api/axios-client';
import { CompanyCreatePayload, CompanyModel, CompanyUpdatePayload } from '../models';

export const companyApi = {
    createCompany(payload: CompanyCreatePayload) {
        return axiosClient.post('/company', payload);
    },
    getAllCompany(data: { Current: number; Limit: number; TextSearch: string }) {
        return axiosClient.post('/company/find-by-paginate', data);
    },
    updateCompanyPayload(payload: CompanyUpdatePayload) {
        return axiosClient.put('/company', payload);
    },
    updateCompany(payload: FormData) {
        return axiosClient.put('/company', payload, {
            headers: { 'Content-Type': 'multipart/form-data' },
        });
    },
    deleteCompany(id: string) {
        return axiosClient.delete(`/company/${id}`);
    },
};
