import HeaderTable from '@/components/table/header-table';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import ArrowForwardIcon from '@mui/icons-material/ArrowForward';
import {
    Pagination,
    PaginationItem,
    Table,
    TableBody,
    TableContainer,
    useTheme,
} from '@mui/material';
import RowTableRole from './row-table-role';
import { SettingEmptyComponent } from '@/components/settings/empty';
import { RoleModel } from '@/models/group.role.model';
import { columnsRoleGroup } from '@/mocks/index';
import { useState } from 'react';
import DialogUpdateGroupRole from '@/components/dialog/dialog-update/dialog-update-group-role';
import { useRouter } from 'next/router';
export interface ITableRoleProps {
    data: RoleModel[];
    fetchData: () => void;
    maxPage: number;
}

export default function TableRole(props: ITableRoleProps) {
    const { data, fetchData, maxPage } = props;
    const [openDialogUpdate, setOpenDialogUpdate] = useState(false);
    const [itemHandle, setItemHandle] = useState<RoleModel>();
    const theme = useTheme();
    const router = useRouter();
    const { page } = router.query;
    return (
        <TableContainer
            sx={{
                flex: 1,
                display: 'flex',
                flexDirection: 'column',
                justifyContent: 'space-between',
                alignItems: 'center',
                p: 2,
            }}
        >
            <Table
                sx={{
                    borderCollapse: 'separate',
                    borderSpacing: '0 10px',
                    marginTop: '-10px',
                }}
            >
                <HeaderTable headerData={columnsRoleGroup} />
                <TableBody
                    sx={{
                        '& td': {
                            background: 'rgba(217, 217, 217, 0.2)',
                        },
                        'td:first-of-type': {
                            borderTopLeftRadius: '10px',
                            borderBottomLeftRadius: '10px',
                        },
                        'td:last-of-type': {
                            borderTopRightRadius: '10px',
                            borderBottomRightRadius: '10px',
                        },
                    }}
                >
                    {itemHandle && (
                        <DialogUpdateGroupRole
                            open={openDialogUpdate}
                            handleClose={() => {
                                setOpenDialogUpdate(false);
                            }}
                            role={itemHandle}
                            handleReload={fetchData}
                        />
                    )}
                    {data?.map((c: RoleModel, index) => (
                        <RowTableRole
                            data={c}
                            setOpen={undefined}
                            setDataUpdate={(data) => {
                                setItemHandle(data);
                                setOpenDialogUpdate(true);
                            }}
                            key={index}
                            reloadData={fetchData}
                        />
                    ))}
                </TableBody>
            </Table>
            {(!data || data?.length === 0) && <SettingEmptyComponent />}
            <Pagination
                count={maxPage}
                page={
                    page?.toString() && page?.toString() !== 'undefined'
                        ? parseInt(page?.toString())
                        : 1
                }
                onChange={(event, page) => {
                    router.push({
                        pathname: router.pathname,
                        query: { page: page },
                    });
                }}
                renderItem={(item) => (
                    <PaginationItem
                        components={{ previous: ArrowBackIcon, next: ArrowForwardIcon }}
                        {...item}
                        shape="rounded"
                        sx={{
                            borderRadius: '4px',
                            border: '1px solid #DFE3E8',
                            '&.Mui-selected': {
                                background: '#fff',
                                border: '1px solid #067DC0',
                                color: '#067DC0',
                            },

                            color: theme.palette.text.primary,
                        }}
                    />
                )}
                sx={{
                    py: 2,
                }}
            />
        </TableContainer>
    );
}
