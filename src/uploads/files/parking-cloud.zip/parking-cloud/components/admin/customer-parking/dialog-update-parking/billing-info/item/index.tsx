import { DeviceModel } from '@/models/device.model';
import { Checkbox, Stack, Switch, Typography, IconButton, Tooltip, TextField } from '@mui/material';
import Image from 'next/image';
import RadioButtonUncheckedIcon from '@mui/icons-material/RadioButtonUnchecked';
import RadioButtonCheckedIcon from '@mui/icons-material/RadioButtonChecked';
import DialogWarningServer from '../../dialog-warning-server';
import { useState } from 'react';
import { deviceApi } from '@/api/device-api';
import { ParkingModel } from '@/models/index';
import { useAppDispatch } from '@/hooks/index';
import { showSnackbarWithClose } from '@/hooks/useSnackbarWithClose';
import { deleteDevice } from '@/redux/parking';
import DialogWarning from '@/components/dialog/dialog-warning';
import { BillingInfoModel } from '@/models/billing.info.model';
import ActionTable from '@/components/common/action-table/action-table';
import DialogUpdateBillingInfo from '@/components/dialog/dialog-billing-info/update';
import { billingInfoApi } from '@/api/billing-info-api';
export interface IBillingInfoItemComponentProps {
    data: BillingInfoModel;
    handleReload: () => void;
}
export const BillingInfoItemComponent = (props: IBillingInfoItemComponentProps) => {
    const { data, handleReload } = props;
    const [openUpdate, setOpenUpdate] = useState(false);
    const [dataUpdate, setDataUpdate] = useState<BillingInfoModel | null>(null);

    const handleDelete = () => {
        billingInfoApi
            .delete(data.ID)
            .then((res) => {
                console.log(res.data);
                if (res.data) {
                    handleReload();
                    showSnackbarWithClose('Xóa thành công', { variant: 'success' });
                }
            })
            .catch((error) => {
                if (Array.isArray(error?.response?.data?.message)) {
                    error?.response?.data?.message.forEach((item: any) => {
                        showSnackbarWithClose(item, {
                            variant: 'error',
                        });
                    });
                } else {
                    showSnackbarWithClose(
                        error?.response ? error.response.data?.message : error.message,
                        {
                            variant: 'error',
                        }
                    );
                }
            });
    };

    return (
        <Stack
            direction="row"
            sx={{
                padding: '15px',
                boxShadow: '0px 4px 4px rgba(0, 0, 0, 0.25)',
                backgroundColor: 'rgba(217, 217, 217, 0.2)',
                borderRadius: '15px',
            }}
            alignItems="flex-start"
            spacing={'10px'}
        >
            <Stack sx={{ flex: 1 }}>
                <Stack direction="row" alignItems="center" sx={{ gap: '10px' }}>
                    <Typography
                        sx={{
                            color: '#55595D',
                            fontWeight: 700,
                            fontSize: '24px',
                        }}
                    >
                        {data.Name}
                    </Typography>
                </Stack>

                <Stack>
                    <Stack
                        sx={{ color: '#55595D', fontSize: '14px', gap: '5px' }}
                        direction="row"
                        alignItems="center"
                    >
                        <Typography
                            sx={{
                                color: '#55595D',
                                fontSize: '14px',
                                fontWeight: 600,
                                userSelect: 'none',
                            }}
                        >
                            Code :
                        </Typography>
                        <Typography
                            component="span"
                            sx={{
                                fontSize: '14px',
                                outline: 'none',
                                border: 'none',
                                backgroundColor: 'transparent',
                                maxWidth: '400px',
                                overflow: 'hidden',
                                textOverflow: 'ellipsis',
                            }}
                        >
                            {data.Code}
                        </Typography>
                    </Stack>
                    <Stack sx={{ flexDirection: 'row', justifyContent: 'space-between' }}>
                        <Stack
                            sx={{ color: '#55595D', fontSize: '14px', gap: '5px' }}
                            direction="row"
                            alignItems="center"
                        >
                            <Typography
                                sx={{
                                    color: '#55595D',
                                    fontSize: '14px',
                                    fontWeight: 600,
                                    userSelect: 'none',
                                }}
                            >
                                Phương thức :
                            </Typography>
                            <Typography
                                component="span"
                                sx={{
                                    fontSize: '14px',
                                    outline: 'none',
                                    border: 'none',
                                    backgroundColor: 'transparent',
                                    maxWidth: '400px',
                                    overflow: 'hidden',
                                    textOverflow: 'ellipsis',
                                }}
                            >
                                {data.PaymentMethods}
                            </Typography>
                        </Stack>
                        <Stack>
                            <Stack
                                sx={{
                                    display: 'flex',
                                    flexDirection: 'row',
                                    alignItems: 'center',
                                    justifyContent: 'center',
                                    gap: '7px',
                                    height: '100%',
                                }}
                            >
                                <ActionTable
                                    size={'small'}
                                    onEdit={() => {
                                        setDataUpdate(data);
                                        setOpenUpdate(true);
                                    }}
                                    onDelete={handleDelete}
                                    onSync={data.IsUpdate || data.IsInsert ? () => {} : undefined}
                                ></ActionTable>
                            </Stack>
                        </Stack>
                    </Stack>
                </Stack>
            </Stack>
            <DialogUpdateBillingInfo
                open={openUpdate}
                handleClose={() => {
                    setOpenUpdate(false);
                    setDataUpdate(null);
                }}
                dataUpdate={dataUpdate}
                handleReload={handleReload}
            />
        </Stack>
    );
};
