import {
    Pagination,
    PaginationItem,
    Paper,
    Stack,
    Table,
    TableBody,
    TableContainer,
    useTheme,
} from '@mui/material';
import React, { useEffect, useRef, useState } from 'react';
import HeaderTableCustomer from './table/header-table-customer';
import { ParkingModel } from '@/models/parking.model';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import ArrowForwardIcon from '@mui/icons-material/ArrowForward';
import { headerData } from '@/mocks/header-mock';
import { DialogUpdateTableParking } from './dialog-update-parking';
import HeaderTable from '@/components/table/header-table';
import RowTableCustomerParking from './table/row-table-customer-parking';
import { useRouter } from 'next/router';
import { SettingEmptyComponent } from '@/components/settings/empty';
import { useAppSelector } from '@/hooks/index';
import { formatTextPagination } from '@/ultis/index';

export interface ITableCustomerParkingProps {
    data: ParkingModel[];
    reloadTable: () => void;
    maxPage: number;
    total: number;
    currentSize: number;
}

export default function TableCustomerParking(props: ITableCustomerParkingProps) {
    const { data, reloadTable, maxPage, total, currentSize } = props;

    const tableBodyRef = useRef<any>(null);
    const [tableBodyHeight, setTableBodyHeight] = useState(0);
    const [dataUpdate, setDataUpdate] = useState<ParkingModel | null>(null);
    const router = useRouter();
    const { page } = router.query;
    useEffect(() => {
        if (tableBodyRef.current) {
            if (tableBodyRef.current.offsetHeight <= 0) return;
            let tdHeight = tableBodyRef.current.offsetHeight / 11; // tính thêm header
            setTableBodyHeight(tdHeight);
        }
    }, [tableBodyRef.current]);
    const profile = useAppSelector((state) => state.common.profile);

    return (
        <TableContainer
            sx={{
                flex: 1,
                display: 'flex',
                flexDirection: 'column',
                justifyContent: 'space-between',
                alignItems: 'center',
                padding: '10px',
            }}
        >
            <Table
                sx={{
                    borderCollapse: 'separate',
                    borderSpacing: '0 10px',
                    marginTop: '-10px',
                }}
            >
                <HeaderTable headerData={headerData} isHideAction={!profile?.IsSupperAdmin} />

                <TableBody
                    sx={{
                        '& td': {
                            background: 'rgba(217, 217, 217, 0.2)',
                        },
                        'td:first-of-type': {
                            borderTopLeftRadius: '10px',
                            borderBottomLeftRadius: '10px',
                        },
                        'td:last-of-type': {
                            borderTopRightRadius: '10px',
                            borderBottomRightRadius: '10px',
                        },
                    }}
                >
                    {data?.map((c: ParkingModel, index) => (
                        <RowTableCustomerParking
                            data={c}
                            setDataUpdate={setDataUpdate}
                            key={index}
                            reloadData={reloadTable}
                        />
                    ))}
                </TableBody>
            </Table>
            {(!data || data?.length === 0) && <SettingEmptyComponent />}
        </TableContainer>
    );
}
