import { parkingApi } from '@/api/index';
import InputAddress from '@/components/common/input/input-address';
import { StyledOutlinedInput } from '@/components/common/style-component';
import { useAppDispatch } from '@/hooks/index';
import { showSnackbarWithClose } from '@/hooks/useSnackbarWithClose';
import { ParkingModel, ParkingUpdatePayload } from '@/models/index';
import { editParkingInfo } from '@/redux/index';
import { getDateTime } from '@/ultis/index';
import { InputLabel, Stack, Typography } from '@mui/material';
import { useEffect, useState } from 'react';

export interface BaseInfoUpdateParkingComponentProps {
    data: ParkingModel;
    handleReload?: () => void;
    handleClose: () => void;
}

export const BaseInfoUpdateParkingComponent = (props: BaseInfoUpdateParkingComponentProps) => {
    const { data, handleReload, handleClose } = props;
    const [province, setProvince] = useState<string>(data.Province || '');
    const [district, setDistrict] = useState<string>(data.District || '');
    const [ward, setWard] = useState<string>(data.Ward || '');
    const [name, setName] = useState<string>(data.Name || '');
    const [capacity, setCapacity] = useState<number>(data.Capacity);
    const [address, setAddress] = useState<string>(data.Address || '');
    const dispatch = useAppDispatch();

    const handleUpdateParking = async () => {
        if (!name) {
            showSnackbarWithClose('Vui lòng nhập tên bãi xe', { variant: 'error' });
            return;
        }
        const payload: any = {
            ID: data.ID,
            Name: name,
            Province: province,
            District: district,
            Ward: ward,
            Capacity: capacity,
            Address: address,
        };
        try {
            const { data } = await parkingApi.updateParking(payload);
            const action = editParkingInfo({
                parking: data,
            });
            dispatch(action);
            // console.log(data);
            showSnackbarWithClose('Cập nhật bãi xe thành công', { variant: 'success' });
            handleReload && handleReload();
            handleClose();
        } catch (error: any) {
            if (Array.isArray(error?.response?.data?.message)) {
                error?.response?.data?.message.forEach((item: any) => {
                    showSnackbarWithClose(item, {
                        variant: 'error',
                    });
                });
            } else {
                showSnackbarWithClose(
                    error?.response ? error.response.data?.message : error.message,
                    {
                        variant: 'error',
                    }
                );
            }
        }
    };

    return (
        <Stack sx={{ flex: 1 }} spacing={'10px'} justifyContent={'space-between'}>
            <Stack spacing={'10px'}>
                <Stack>
                    <Typography sx={{ color: '#55595D', fontSize: '16px' }}>Tên bãi xe</Typography>
                    <input
                        style={{
                            outline: 'none',
                            border: '1px solid #D9D9D9',
                            borderRadius: '10px',
                            fontSize: '16px',
                            padding: '10px 20px',
                            color: '#55595D',
                        }}
                        autoComplete="off"
                        placeholder={data.Name}
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                    />
                </Stack>
                <Stack>
                    <InputLabel>Công suất tối đa</InputLabel>
                    <StyledOutlinedInput
                        autoComplete="off"
                        value={capacity}
                        onChange={(e) => {
                            setCapacity(parseInt(e.target.value));
                        }}
                        size="small"
                        fullWidth
                        type="number"
                    />
                </Stack>
                <Stack py={2}>
                    <InputAddress
                        selectedProvince={province}
                        selectedDistrict={district}
                        selectedWard={ward}
                        setSelectedProvince={setProvince}
                        setSelectedDistrict={setDistrict}
                        setSelectedWard={setWard}
                        isFetchAddressFirst
                    />
                </Stack>
                <Stack>
                    <InputLabel>Địa chỉ</InputLabel>
                    <StyledOutlinedInput
                        autoComplete="off"
                        value={address}
                        onChange={(e) => {
                            setAddress(e.target.value);
                        }}
                        size="small"
                        fullWidth
                    />
                </Stack>
                {/* <Stack sx={{ gap: '20px', flex: 1 }}>
                <Typography sx={{ color: '#55595D', fontSize: '16px' }}>Vị trí</Typography>

                <Stack direction="row" sx={{ gap: '20px' }}>
                    <SelectBoxComponent />
                    <SelectBoxComponent />
                </Stack>

                <Stack>
                    <SelectBoxComponent />
                </Stack>

                <input
                    style={{
                        outline: 'none',
                        border: '1px solid rgba(85, 89, 93, 0.5)',
                        borderRadius: '10px',
                        fontSize: '16px',
                        padding: '15px 20px 15px 30px',
                        color: '#55595D',
                    }}
                    placeholder="Địa chỉ cụ thể..."
                />
            </Stack> */}
            </Stack>

            <Stack direction="row" alignItems="flex-end" justifyContent="space-between" mt={'auto'}>
                <Typography
                    sx={{
                        fontWeight: 300,
                        fontStyle: 'italic',
                        color: '#55595D',
                        fontSize: '13px',
                    }}
                >
                    Ngày khởi tạo: {getDateTime(data.CreatedAt)}
                </Typography>
                <Stack
                    sx={{
                        backgroundColor: '#FFB862',
                        borderRadius: '10px',
                        padding: '10px 50px',
                        filter: 'drop-shadow(0px 2px 2px rgba(0, 0, 0, 0.25))',
                        cursor: 'pointer',
                    }}
                    onClick={handleUpdateParking}
                >
                    <Typography sx={{ textTransform: 'uppercase', fontWeight: 700, color: '#fff' }}>
                        Cập nhật
                    </Typography>
                </Stack>
            </Stack>
        </Stack>
    );
};
