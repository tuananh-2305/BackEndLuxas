import { DeviceModel } from '@/models/device.model';
import { Checkbox, Stack, Switch, Typography, IconButton, Tooltip, TextField } from '@mui/material';
import Image from 'next/image';
import RadioButtonUncheckedIcon from '@mui/icons-material/RadioButtonUnchecked';
import RadioButtonCheckedIcon from '@mui/icons-material/RadioButtonChecked';
import DialogWarningServer from '../../dialog-warning-server';
import { useState } from 'react';
import { deviceApi } from '@/api/device-api';
import { ParkingModel } from '@/models/index';
import { useAppDispatch } from '@/hooks/index';
import { showSnackbarWithClose } from '@/hooks/useSnackbarWithClose';
import { deleteDevice } from '@/redux/parking';
import EditNoteIcon from '@mui/icons-material/EditNote';
import { UpdateComponent } from './update-component';
import DialogWarning from '@/components/dialog/dialog-warning';
export interface IBoxDeviceItemComponentProps {
    device: DeviceModel;
    parking: ParkingModel;
    handleReload: () => void;
}
export const BoxDeviceItemComponent = (props: IBoxDeviceItemComponentProps) => {
    const { device, parking, handleReload } = props;
    const [openAlert, setOpenAlert] = useState(false);
    const dispatch = useAppDispatch();
    const [openWarning, setOpenWarning] = useState(false);

    const handleDelete = () => {
        deviceApi
            .unlink(device.ID)
            .then((res) => {
                if (res.data) {
                    handleReload();
                    const action = deleteDevice({ data: device });
                    dispatch(action);
                    showSnackbarWithClose('Xóa thành công', { variant: 'success' });
                }
            })
            .catch((error) => {
                if (Array.isArray(error?.response?.data?.message)) {
                    error?.response?.data?.message.forEach((item: any) => {
                        showSnackbarWithClose(item, {
                            variant: 'error',
                        });
                    });
                } else {
                    showSnackbarWithClose(
                        error?.response ? error.response.data?.message : error.message,
                        {
                            variant: 'error',
                        }
                    );
                }
                // showSnackbarWithClose('Xóa thất bại', { variant: 'error' });
            });
    };

    return (
        <Stack
            direction="row"
            sx={{
                padding: '15px',
                boxShadow: '0px 4px 4px rgba(0, 0, 0, 0.25)',
                backgroundColor: device.IsOnline
                    ? 'rgba(217, 217, 217, 0.2)'
                    : 'rgba(233, 79, 79, 0.1)',
                borderRadius: '15px',
            }}
            alignItems="flex-start"
            spacing={'10px'}
        >
            <Stack
                sx={{
                    backgroundColor: device.IsOnline ? '#5EB14a' : '#E94F4F',
                    boxShadow: '0px 2px 2px rgba(0, 0, 0, 0.25)',
                    width: '15px',
                    height: '15px',
                    borderRadius: '8px',
                    transform: 'translateY(10px)',
                }}
            />

            <Stack sx={{ flex: 1 }}>
                <Stack direction="row" alignItems="center" sx={{ gap: '10px' }}>
                    <Typography
                        sx={{
                            color: device.IsOnline ? '#55595D' : '#E94F4F',
                            fontWeight: 700,
                            fontSize: '24px',
                        }}
                    >
                        {device.Name}
                    </Typography>
                    {!device.IsOnline ? (
                        <UpdateComponent
                            handleUpdate={(value: string) => {
                                deviceApi
                                    .updateDevice({ ID: device.ID, Name: value })
                                    .then(() => {
                                        handleReload();
                                    })
                                    .catch((error) => {
                                        if (Array.isArray(error?.response?.data?.message)) {
                                            error?.response?.data?.message.forEach((item: any) => {
                                                showSnackbarWithClose(item, {
                                                    variant: 'error',
                                                });
                                            });
                                        } else {
                                            showSnackbarWithClose(
                                                error?.response
                                                    ? error.response.data?.message
                                                    : error.message,
                                                {
                                                    variant: 'error',
                                                }
                                            );
                                        }
                                    });
                            }}
                            defaultValue={device.Name}
                            name="tên thiết bị"
                        />
                    ) : (
                        <></>
                    )}
                </Stack>

                <Stack>
                    <Stack
                        sx={{ color: '#55595D', fontSize: '14px', gap: '5px' }}
                        direction="row"
                        alignItems="center"
                    >
                        <Typography
                            sx={{
                                color: '#55595D',
                                fontSize: '14px',
                                fontWeight: 600,
                                userSelect: 'none',
                            }}
                        >
                            ID :
                        </Typography>
                        <Typography
                            component="span"
                            sx={{
                                fontSize: '14px',
                                outline: 'none',
                                border: 'none',
                                backgroundColor: 'transparent',
                                width: 'fit-content',
                            }}
                        >
                            {device.ID}
                        </Typography>
                    </Stack>
                    <Stack
                        sx={{ color: '#55595D', fontSize: '14px', gap: '5px' }}
                        direction="row"
                        alignItems="center"
                    >
                        <Typography
                            sx={{
                                color: '#55595D',
                                fontSize: '14px',
                                fontWeight: 600,
                                userSelect: 'none',
                            }}
                        >
                            IMEI :
                        </Typography>
                        <Typography
                            component="span"
                            sx={{
                                fontSize: '14px',
                                outline: 'none',
                                border: 'none',
                                backgroundColor: 'transparent',
                                width: 'fit-content',
                            }}
                        >
                            {device?.ImeiId?.Imei}
                        </Typography>
                    </Stack>

                    <Stack
                        sx={{ color: '#55595D', fontSize: '14px', gap: '5px' }}
                        direction="row"
                        alignItems="center"
                    >
                        <Typography
                            sx={{
                                color: '#55595D',
                                fontSize: '14px',
                                fontWeight: 600,
                                userSelect: 'none',
                            }}
                        >
                            Port :
                        </Typography>
                        <Typography
                            component="span"
                            sx={{
                                fontSize: '14px',
                                outline: 'none',
                                border: 'none',
                                backgroundColor: 'transparent',
                                width: 'fit-content',
                            }}
                        >
                            {device.Port}
                        </Typography>
                        {!device.IsOnline ? (
                            <UpdateComponent
                                handleUpdate={(value: string) => {
                                    deviceApi
                                        .updateDevice({ ID: device.ID, Port: value })
                                        .then(() => {
                                            handleReload();
                                        })
                                        .catch((error) => {
                                            if (Array.isArray(error?.response?.data?.message)) {
                                                error?.response?.data?.message.forEach(
                                                    (item: any) => {
                                                        showSnackbarWithClose(item, {
                                                            variant: 'error',
                                                        });
                                                    }
                                                );
                                            } else {
                                                showSnackbarWithClose(
                                                    error?.response
                                                        ? error.response.data?.message
                                                        : error.message,
                                                    {
                                                        variant: 'error',
                                                    }
                                                );
                                            }
                                        });
                                }}
                                defaultValue={device.Port}
                                name="port"
                            />
                        ) : (
                            <></>
                        )}
                    </Stack>
                </Stack>
            </Stack>

            {/* <Switch value={device.IsServer} /> */}
            <Stack sx={{ height: '100%' }} justifyContent={'space-between'}>
                <Checkbox
                    icon={<RadioButtonUncheckedIcon />}
                    checkedIcon={<RadioButtonCheckedIcon />}
                    color="success"
                    checked={device.IsServer}
                    onChange={() => {
                        if (!device.IsServer) {
                            setOpenAlert(true);
                        }
                    }}
                />

                {device.IsServer ? (
                    <></>
                ) : (
                    <Tooltip title="Ngắt kết nối với thiết bị!.">
                        <IconButton onClick={() => setOpenWarning(true)}>
                            <Image
                                src="/icons/link-broken.svg"
                                width={24}
                                height={24}
                                alt="link-broken"
                            />
                        </IconButton>
                    </Tooltip>
                )}
            </Stack>
            <DialogWarning
                open={openWarning}
                handleClose={() => setOpenWarning(false)}
                title="Bạn đang thực hiện ngắt kết nối thiết bị với bãi xe, nhập "
                handleConfirm={handleDelete}
            />
            <DialogWarningServer
                open={openAlert}
                handleClose={() => setOpenAlert(false)}
                device={device}
                handleReload={handleReload}
                isSeverOnline={parking.Device.find((item) => item.IsServer)?.IsOnline}
            ></DialogWarningServer>
        </Stack>
    );
};
