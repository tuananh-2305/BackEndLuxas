import TextFieldForm from '@/components/common/input/text-field-form/text-field-form';
import { useAppSelector } from '@/hooks/index';
import { showSnackbarWithClose } from '@/hooks/useSnackbarWithClose';
import { DeviceModel, ParkingModel } from '@/models/index';
import { Autocomplete, InputLabel, Stack, TextField } from '@mui/material';
import Button from '@mui/material/Button';
import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import DialogTitle from '@mui/material/DialogTitle';
import React from 'react';
import { useState } from 'react';
import { io } from 'socket.io-client';
const BACKEND_DOMAIN = process.env.NEXT_PUBLIC_SERVER_PARKING_DOMAIN || '';
export interface IDialogSendImeiProps {
    open: boolean;
    handleClose: () => void;
    item: ParkingModel;
    device: DeviceModel[];
}

export default function DialogSendImei(props: IDialogSendImeiProps) {
    const { handleClose, item, open, device } = props;
    const parkingChoose = useAppSelector((state) => state.parking.chooseDashboard);
    const profile = useAppSelector((state) => state.common.profile);
    const [imei, setImei] = useState<DeviceModel | null>(null);

    const submit = () => {
        if (!profile?.ID) return;
        if (!imei?.ImeiId?.Imei) {
            showSnackbarWithClose('Imei không được để trống', { variant: 'error' });
            return;
        }

        const socket = io(BACKEND_DOMAIN, {
            withCredentials: true,
        });
        socket.on('connect', () => {
            socket.emit('join-web', {
                UserId: profile.ID,
            });
            socket.emit(
                'accept-role-by-web',
                {
                    Imei: imei?.ImeiId?.Imei,
                    ParkingId: item.ID,
                },
                (data: boolean) => {
                    if (data) {
                        showSnackbarWithClose('Yêu cầu đã được gửi đi', { variant: 'success' });
                    } else {
                        showSnackbarWithClose('Yêu cầu thất bại', { variant: 'error' });
                    }
                }
            );
        });
    };
    return (
        <Dialog
            open={open}
            onClose={() => {
                handleClose();
                setImei(null);
            }}
            aria-labelledby="alert-dialog-title"
            aria-describedby="alert-dialog-description"
            maxWidth={'sm'}
            fullWidth
        >
            <DialogTitle id="alert-dialog-title">{'Kiểm tra imei'}</DialogTitle>
            <DialogContent>
                {/* <TextFliedForm
                    lable={'Imei'}
                    value={imei}
                    onChange={(e) => {
                        const { value } = e.target;
                        setImei(value);
                    }}
                /> */}
                <Stack>
                    <InputLabel required>Imei</InputLabel>
                    <Autocomplete
                        size="small"
                        onChange={(event: any, newValue: DeviceModel | null) => {
                            setImei(newValue);
                        }}
                        isOptionEqualToValue={(option: any, value) => option.ID === value?.ID}
                        getOptionLabel={(option: DeviceModel) =>
                            `${option.Name} (${option.ImeiId?.Imei})`
                        }
                        options={device}
                        renderInput={(params) => (
                            <TextField
                                {...params}
                                InputProps={{
                                    ...params.InputProps,
                                    endAdornment: (
                                        <React.Fragment>
                                            {params.InputProps.endAdornment}
                                        </React.Fragment>
                                    ),
                                }}
                                sx={{
                                    '& .MuiInputBase-root': {
                                        borderRadius: '10px',
                                    },
                                }}
                            />
                        )}
                    />
                </Stack>
                <Stack sx={{ py: '5px' }} />
            </DialogContent>
            <DialogActions sx={{ gap: '10px', mr: '20px', mb: '10px' }}>
                <Button
                    onClick={() => {
                        handleClose();
                        setImei(null);
                    }}
                    variant="contained"
                    sx={{
                        background: '#CDD2D1',
                        ':hover': {
                            background: '#DBE8E1',
                        },
                        fontSize: '14px',
                        fontWeight: '500',
                        borderRadius: '6px',
                        textTransform: 'revert-layer',
                    }}
                >
                    Hủy
                </Button>
                <Button
                    onClick={submit}
                    variant="contained"
                    sx={{
                        background: '#007DC0',
                        ':hover': {
                            background: '#009FD0',
                        },
                        fontSize: '14px',
                        fontWeight: '500',
                        textTransform: 'revert-layer',
                        borderRadius: '6px',
                    }}
                    autoFocus
                >
                    Xác nhận
                </Button>
            </DialogActions>
        </Dialog>
    );
}
