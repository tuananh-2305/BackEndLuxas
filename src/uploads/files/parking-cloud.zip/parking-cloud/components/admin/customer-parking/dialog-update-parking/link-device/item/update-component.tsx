import { Button, Popover, Stack, TextField, Typography } from '@mui/material';
import { useRef, useState } from 'react';
import EditNoteIcon from '@mui/icons-material/EditNote';

interface UpdateComponentProps {
    handleUpdate: (value: string) => void;
    defaultValue: string;
    name: string;
}

export const UpdateComponent = (props: UpdateComponentProps) => {
    const { defaultValue, handleUpdate, name } = props;

    const [open, setOpen] = useState(false);
    const ref = useRef<any>(null);

    const [value, setValue] = useState(defaultValue);
    return (
        <>
            <EditNoteIcon sx={{ cursor: 'pointer' }} ref={ref} onClick={() => setOpen(true)} />

            <Popover
                open={open}
                anchorEl={ref.current}
                onClose={() => setOpen(false)}
                anchorOrigin={{
                    vertical: 'bottom',
                    horizontal: 'left',
                }}
            >
                <Stack sx={{ padding: '10px', gap: '10px' }}>
                    <Typography
                        sx={{ fontSize: '14px', fontWeight: 600 }}
                    >{`Cập nhật ${name}`}</Typography>
                    <TextField
                        size="small"
                        value={value}
                        onChange={(e) => {
                            const { value: item } = e.target;
                            setValue(item);
                        }}
                    />
                    <Button
                        size="small"
                        variant="contained"
                        color="info"
                        onClick={() => handleUpdate(value)}
                    >
                        Cập nhật
                    </Button>
                </Stack>
            </Popover>
        </>
    );
};
