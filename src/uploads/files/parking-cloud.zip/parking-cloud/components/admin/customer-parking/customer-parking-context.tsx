import { createContext } from 'react';

const ContextCustomerParking = createContext({});
const CustomerParkingProvider = ({ children }: any) => {
    const context = {};
    return (
        <ContextCustomerParking.Provider value={context}>
            {children}
        </ContextCustomerParking.Provider>
    );
};
export { ContextCustomerParking, CustomerParkingProvider };
