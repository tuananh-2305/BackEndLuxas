import { IconButton, Stack, Typography } from '@mui/material';
import AddBoxIcon from '@mui/icons-material/AddBox';
import DialogCreateDevice from '@/components/dialog/dialog-create-device';
import { useEffect, useState } from 'react';
import { ParkingModel } from '@/models/parking.model';
import { DeviceModel, PaginationPayload } from '@/models/index';
import DialogCreateBillingInfo from '@/components/dialog/dialog-billing-info/create';
import { billingInfoApi } from '@/api/billing-info-api';
import { showSnackbarWithClose } from '@/hooks/useSnackbarWithClose';
import { BillingInfoModel } from '@/models/billing.info.model';
import { BillingInfoItemComponent } from './item';
export interface IBillingInfoUpdateParkingComponentProps {
    data: ParkingModel;
    fecthData: () => void;
}
export const BillingInfoUpdateParkingComponent = (
    props: IBillingInfoUpdateParkingComponentProps
) => {
    const { data, fecthData } = props;
    const [open, setOpen] = useState(false);
    const [loading, setLoading] = useState(false);
    const [dataBillInfo, setDataBillInfo] = useState<BillingInfoModel[]>([]);
    const fetchDataPayment = async () => {
        setLoading(true);
        try {
            billingInfoApi.findByParkingId(data.ID).then((res) => {
                if (res.data) {
                    setDataBillInfo(res.data);
                }
            });
        } catch (err: any) {
            if (Array.isArray(err?.response?.data?.message)) {
                err?.response?.data?.message.forEach((item: any) => {
                    showSnackbarWithClose(item, {
                        variant: 'error',
                    });
                });
            } else {
                showSnackbarWithClose(err?.response ? err.response.data?.message : err.message, {
                    variant: 'error',
                });
            }
        } finally {
            setLoading(false);
        }
    };
    useEffect(() => {
        fetchDataPayment();
    }, []);
    return (
        <Stack sx={{ overflow: 'auto' }} spacing={'30px'}>
            <Stack
                justifyContent="center"
                alignItems="center"
                sx={{
                    padding: '25px',
                    border: '1px dashed #000000',
                    borderRadius: '15px',
                    cursor: 'pointer',
                    position: 'sticky',
                    top: 0,
                    backgroundColor: '#fff',
                    zIndex: 1,
                }}
                onClick={() => setOpen(true)}
            >
                <IconButton>
                    <AddBoxIcon />
                </IconButton>
                <Typography
                    sx={{ fontWeight: 700, sx: '16px', color: '#55595D', userSelect: 'none' }}
                >
                    Thêm phương thức thanh toán mới
                </Typography>
            </Stack>
            <DialogCreateBillingInfo
                open={open}
                handleClose={() => setOpen(false)}
                parkingId={data.ID}
                handleReload={() => {
                    fetchDataPayment();
                }}
            />
            {loading ? (
                <></>
            ) : (
                <Stack sx={{ pb: '10px', maxHeight: '500px', overflow: 'auto' }} spacing={'25px'}>
                    {dataBillInfo.map((item, index) => (
                        <BillingInfoItemComponent
                            key={index}
                            data={item}
                            handleReload={() => {
                                fetchDataPayment();
                            }}
                        />
                    ))}
                </Stack>
            )}
        </Stack>
    );
};
