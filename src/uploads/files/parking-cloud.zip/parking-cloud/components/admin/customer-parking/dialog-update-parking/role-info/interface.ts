export interface KeySetting {
    ID: string;
    CreatedAt: string;
    UpdatedAt: string;
    DeletedAt: string | null;
    Name: string;
    KeyWord: string;
    IsValue: boolean;
}

export interface Parking {
    ID: string;
    CreatedAt: string;
    UpdatedAt: string;
    IsDelete: boolean;
    IsInsert: boolean;
    IsUpdate: boolean;
    Name: string;
    Address: string;
    Description: string;
    Province: string;
    Capacity: number;
    District: string;
    Ward: string;
    TimeResetReport: string | null;
    ExpectedRevenue: number;
}

export interface RoleItem {
    ID: string;
    CreatedAt: string;
    UpdatedAt: string;
    DeletedAt: string | null;
    IsUse: boolean;
    Value: any;
    KeySettingId: KeySetting;
    ParkingId: Parking;
}
