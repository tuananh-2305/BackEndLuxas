import { deviceMock } from '@/mocks/index';
import { DeviceModel } from '@/models/index';
import { createContext, useState } from 'react';

const ContextBoxParking = createContext({
    reload: () => {},
    boxs: deviceMock,
});
export interface IBoxParkingProviderProps {
    children: React.ReactNode;
    idParking: string;
}
const BoxParkingProvider = ({ children, idParking }: IBoxParkingProviderProps) => {
    const [boxs, setBoxs] = useState<DeviceModel[]>([]);

    const reload = () => {};
    const context = {
        reload,
        boxs: boxs,
    };
    return <ContextBoxParking.Provider value={context}>{children}</ContextBoxParking.Provider>;
};
export { ContextBoxParking, BoxParkingProvider };
