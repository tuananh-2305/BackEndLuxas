import { IconButton, Stack, Typography } from '@mui/material';
import AddBoxIcon from '@mui/icons-material/AddBox';
import { BoxDeviceItemComponent } from './item';
import DialogCreateDevice from '@/components/dialog/dialog-create-device';
import { useState } from 'react';
import { ParkingModel } from '@/models/parking.model';
import { DeviceModel } from '@/models/index';
export interface ILinkDeviceUpdateParkingComponentProps {
    data: ParkingModel;
    fecthData: () => void;
}
export const LinkDeviceUpdateParkingComponent = (props: ILinkDeviceUpdateParkingComponentProps) => {
    const { data, fecthData } = props;
    const [open, setOpen] = useState(false);
    return (
        <Stack sx={{ overflow: 'auto' }} spacing={'30px'}>
            <Stack
                justifyContent="center"
                alignItems="center"
                sx={{
                    padding: '25px',
                    border: '1px dashed #000000',
                    borderRadius: '15px',
                    cursor: 'pointer',
                    position: 'sticky',
                    top: 0,
                    backgroundColor: '#fff',
                    zIndex: 1,
                }}
                onClick={() => setOpen(true)}
            >
                <IconButton>
                    <AddBoxIcon />
                </IconButton>
                <Typography
                    sx={{ fontWeight: 700, sx: '16px', color: '#55595D', userSelect: 'none' }}
                >
                    Thêm thiết bị trung tâm mới
                </Typography>
            </Stack>
            <DialogCreateDevice
                open={open}
                handleClose={() => setOpen(false)}
                parkingId={data.ID}
                handleReload={props.fecthData}
            />
            <Stack sx={{ pb: '10px' }} spacing={'25px'}>
                {data.Device.map((item, index) => (
                    <BoxDeviceItemComponent
                        key={index}
                        device={item}
                        parking={data}
                        handleReload={fecthData}
                    />
                ))}
            </Stack>
        </Stack>
    );
};
