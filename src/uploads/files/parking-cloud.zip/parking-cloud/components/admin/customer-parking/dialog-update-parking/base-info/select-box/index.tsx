import { Popover, Stack, Typography } from '@mui/material';
import Image from 'next/image';
import { useRef, useState } from 'react';
export const SelectBoxComponent = () => {
    const [openSelect, setOpenSelect] = useState<boolean>(false);
    const anchorRef = useRef<HTMLDivElement | null>(null);
    return (
        <>
            <Stack
                ref={anchorRef}
                onClick={() => setOpenSelect(true)}
                direction="row"
                sx={{
                    padding: '10px 20px 10px 30px',
                    flex: 1,
                    border: '1px solid rgba(85, 89, 93, 0.5)',
                    borderRadius: '10px',
                    cursor: 'pointer',
                    position: 'relative',
                }}
            >
                <Typography sx={{ fontWeight: 300, fontStyle: 'italic', flex: 1 }}>
                    Chọn tỉnh...
                </Typography>
                <Image src="/icons/chevron-down-sliver.svg" width={24} height={24} alt="photo" />{' '}
            </Stack>
            <Popover
                open={openSelect}
                anchorEl={anchorRef.current}
                onClose={() => setOpenSelect(false)}
                anchorOrigin={{
                    vertical: 'bottom',
                    horizontal: 'left',
                }}
            >
                <Stack sx={{ width: anchorRef?.current?.clientWidth }}>
                    <Stack>
                        <Typography>asdasd</Typography>
                    </Stack>
                    <Stack>
                        <Typography>asdasd</Typography>
                    </Stack>
                    <Stack>
                        <Typography>asdasd</Typography>
                    </Stack>
                </Stack>
            </Popover>
        </>
    );
};
