import { deviceApi } from '@/api/device-api';
import { showSnackbarWithClose } from '@/hooks/useSnackbarWithClose';
import { DeviceModel } from '@/models/index';
import WarningIcon from '@mui/icons-material/Warning';
import { LoadingButton } from '@mui/lab';
import {
    Button,
    Checkbox,
    Dialog,
    DialogActions,
    DialogContent,
    FormControlLabel,
    InputBase,
    Stack,
    Typography,
} from '@mui/material';
import { delay } from '@reduxjs/toolkit/dist/utils';
import { useEffect, useState } from 'react';
export interface IDialogWarningServerProps {
    open: boolean;
    handleClose: () => void;
    device: DeviceModel;
    handleReload?: () => void;
    isSeverOnline?: boolean;
}

export default function DialogWarningServer(props: IDialogWarningServerProps) {
    const { open, handleClose, device, handleReload, isSeverOnline } = props;
    const [checked, setChecked] = useState(false);
    const [textRequired, setTextRequired] = useState('');
    const [loading, setLoading] = useState(false);
    useEffect(() => {
        if (open) {
            setChecked(false);
            setTextRequired('');
        }
    }, [open]);
    const handleChangeServer = async () => {
        setLoading(true);

        if (!device.ParkingId?.ID) {
            showSnackbarWithClose('Thiết bị chưa được gán bãi xe', {
                variant: 'error',
            });
            handleClose();
            setLoading(false);
            return;
        }

        const payload = {
            ID: device.ID,
            ParkingId: device.ParkingId?.ID,
        };
        deviceApi
            .updateSeverDevice(payload)
            .then(async (res) => {
                showSnackbarWithClose('Thay đổi sever thành công', { variant: 'success' });
                if (handleReload) {
                    handleReload();
                }
                handleClose();
            })
            .catch(async (error) => {
                if (Array.isArray(error?.response?.data?.message)) {
                    error?.response?.data?.message.forEach((item: any) => {
                        showSnackbarWithClose(item, {
                            variant: 'error',
                        });
                    });
                } else {
                    showSnackbarWithClose(
                        error?.response ? error.response.data?.message : error.message,
                        {
                            variant: 'error',
                        }
                    );
                }
            })
            .finally(async () => {
                setLoading(false);
            });
    };

    return (
        <Dialog
            open={open}
            onClose={handleClose}
            aria-labelledby="alert-dialog-title"
            aria-describedby="alert-dialog-description"
            sx={{
                '& .MuiDialog-paper': {
                    backgroundColor: '#FFF5E8',
                    borderRadius: '16px',
                },
            }}
        >
            <DialogContent>
                <Stack alignItems={'center'} spacing={3}>
                    <WarningIcon fontSize="large" color="error" />
                    <Stack alignItems={'center'}>
                        <Typography
                            sx={{
                                color: 'rgba(255, 184, 98, 1)',
                                textAlign: 'center',
                                fontWeight: 'bold',
                            }}
                        >
                            Bạn đang thực hiện hành động thay đổi máy chủ bãi xe
                            {!isSeverOnline && (
                                <Typography fontWeight="inherit" variant="body1" component={'span'}>
                                    . Máy chủ đang offline, hành động này có thể dẫn đến thất thoát
                                    dữ liệu của máy chủ. Vui lòng kiểm tra lại kết nối của máy chủ
                                    trước khi thực hiện hành động này
                                </Typography>
                            )}
                            , nhập{' “'}
                            <Typography
                                fontWeight="inherit"
                                variant="body1"
                                component={'span'}
                                color={'error'}
                            >
                                {device.ParkingId?.Name}
                            </Typography>
                            {'” '}
                            và nhấn vào{'  “'}
                            <Typography
                                fontWeight="inherit"
                                variant="body1"
                                component={'span'}
                                color={'error'}
                            >
                                Tôi hiểu
                            </Typography>
                            {'” '}
                            để thực hiện hành động này
                        </Typography>
                    </Stack>
                    <Stack alignItems={'center'}>
                        <Typography color={'error'}>
                            Dữ liệu và cách hoạt động bãi xe sẽ thay đổi sau hành động này
                        </Typography>
                        <Typography>
                            Máy chủ mới: {device.Name} (IMEI: {device?.ImeiId?.Imei})
                        </Typography>
                    </Stack>
                    <InputBase
                        fullWidth
                        sx={{
                            backgroundColor: '#fff',
                            borderRadius: '10px',
                            px: '10px',
                            '& .MuiInputBase-input': {
                                textAlign: 'center',
                            },
                            boxShadow: '0px 2px 2px rgba(0, 0, 0, 0.25)',
                        }}
                        value={textRequired}
                        onChange={(e) => setTextRequired(e.target.value)}
                    />
                </Stack>
            </DialogContent>
            <DialogActions
                sx={{
                    justifyContent: 'space-between',
                    px: 4,
                    pb: 2,
                }}
            >
                <FormControlLabel
                    sx={{
                        '& .MuiFormControlLabel-label': {
                            fontSize: '14px',
                            fontWeight: 'bold',
                            color: '#55595D',
                        },
                        '& .MuiCheckbox-root': {
                            color: '#55595D',
                        },
                    }}
                    required
                    control={<Checkbox size="small" />}
                    label="Tôi hiểu"
                    value={checked}
                    onChange={(e: any) => setChecked(e.target.checked)}
                />
                {/* <Button
                    variant="contained"
                    color="error"
                    disabled={!checked || textRequired !== device.ParkingId?.Name}
                    onClick={handleChangeServer}
                > */}

                <LoadingButton
                    sx={{
                        color: '#fff',
                        padding: '10px 30px',
                        cursor: 'pointer',
                        backgroundColor:
                            Boolean(!checked) || textRequired !== device.ParkingId?.Name
                                ? '#59595940'
                                : '#E94F4F',
                        borderRadius: '10px',
                        '&:hover': {
                            backgroundColor: '#E94F4Faa',
                        },
                    }}
                    disabled={Boolean(!checked) || textRequired !== device.ParkingId?.Name}
                    loading={loading}
                    onClick={() => handleChangeServer()}
                >
                    Đồng ý
                </LoadingButton>

                {/* </Button> */}
            </DialogActions>
        </Dialog>
    );
}
