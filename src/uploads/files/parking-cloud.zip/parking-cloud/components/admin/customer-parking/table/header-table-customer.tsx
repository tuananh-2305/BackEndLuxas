import { Stack, styled, TableCell, TableHead, TableRow, Typography, useTheme } from '@mui/material';
interface data {
    id: any;
    label: string;
}
export interface IHeaderTableCustomerProps {
    headerData: data[];
}
export default function HeaderTableCustomer(props: IHeaderTableCustomerProps) {
    const { headerData } = props;
    return (
        <Stack>
            <Stack sx={{ height: '50px', flexDirection: 'row', pl: 1 }}>
                {headerData.map((card: any) => {
                    return (
                        <Stack
                            key={card.id}
                            sx={{
                                width: card.width,
                                borderBottom: `1px solid #fff`,
                                background: 'inherit',
                                justifyContent: 'center',
                                pl: 1,
                            }}
                        >
                            <Stack
                                direction={'row'}
                                alignItems={'center'}
                                spacing={1}
                                sx={{ cursor: 'pointer' }}
                            >
                                <Typography
                                    sx={{
                                        color: '#55595D',
                                        fontFamily: 'sans-serif',
                                        fontSize: { xs: '14px', lg: '15px' },
                                        fontWeight: 700,
                                        textTransform: 'capitalize',
                                        userSelect: 'none',
                                    }}
                                >
                                    {card.label}
                                </Typography>
                            </Stack>
                        </Stack>
                    );
                })}
            </Stack>
        </Stack>
    );
}
