import { ParkingModel } from '@/models/parking.model';
import { theme } from '@/ultis/index';
import InfoOutlinedIcon from '@mui/icons-material/InfoOutlined';
import LayersOutlinedIcon from '@mui/icons-material/LayersOutlined';
import {
    Dialog,
    DialogContent,
    DialogTitle,
    Divider,
    Stack,
    Typography,
    useMediaQuery,
} from '@mui/material';
import { useEffect, useMemo, useState } from 'react';
import { BaseInfoUpdateParkingComponent } from './base-info';
import { LinkDeviceUpdateParkingComponent } from './link-device';
import { DeviceModel } from '@/models/device.model';
import { deviceApi } from '@/api/index';
import { ComfirmCloseDialog } from '@/components/dialog/dialog-comfirm-close';
import { BillingInfoUpdateParkingComponent } from './billing-info';
import { ParkingRoleInfoComponent } from './role-info';
import { useAppSelector } from '@/hooks';

export interface IDialogUpdateTableParkingProps {
    data: ParkingModel;
    setDataUpdate: any;
    reloadTable: () => void;
    open: boolean;
    handleClose: () => void;
}

export const DialogUpdateTableParking = (props: IDialogUpdateTableParkingProps) => {
    const { handleClose, open, data, setDataUpdate, reloadTable } = props;

    const profile = useAppSelector((state) => state.common.profile);

    const IsSupperAdmin = useMemo(() => profile?.IsSupperAdmin, [profile]);

    const [caseView, setCaseView] = useState<
        'link-device' | 'base-info' | 'billing-info' | 'role-group'
    >(IsSupperAdmin ? 'base-info' : 'role-group');
    const fullScreen = useMediaQuery(theme.breakpoints.down('md'));
    const [openComfirm, setOpenComfirm] = useState(false);

    return (
        <Dialog
            fullScreen={fullScreen}
            open={open}
            onClose={() => setOpenComfirm(true)}
            aria-labelledby="responsive-dialog-title"
            sx={{
                '& .MuiPaper-root': {
                    md: { minWidth: '700px', minHeight: '800px', borderRadius: '16px' },
                },
            }}
        >
            <Stack sx={{ padding: '30px 30px 15px 30px' }}>
                <Typography
                    sx={{
                        fontSize: '20px',
                        lineHeight: '24px',
                        fontWeight: 700,
                        color: '#55595D',
                    }}
                >
                    {data.Name}
                </Typography>
            </Stack>
            <Divider />
            <Stack
                direction="row"
                sx={{
                    padding: '15px 30px',
                    maxWidth: '100%',
                    overflowX: 'scroll',
                    '::-webkit-scrollbar-thumb': {
                        background: '#78C6E7',
                        ':hover': {
                            background: '#78C6E7',
                        },
                    },
                    ' ::-webkit-scrollbar': {
                        width: '5px',
                        height: '5px',
                    },
                }}
                spacing={'50px'}
            >
                {IsSupperAdmin ? (
                    <>
                        {' '}
                        <Stack
                            direction="row"
                            sx={{
                                cursor: 'pointer',
                                position: 'relative',
                                gap: '8px',
                                '&:after ':
                                    caseView === 'base-info'
                                        ? {
                                              position: 'absolute',
                                              content: '""',
                                              width: '100%',
                                              top: '110%',
                                              backgroundColor: '#067DC0',
                                              height: '2px',
                                          }
                                        : {},
                            }}
                            onClick={() => setCaseView('base-info')}
                        >
                            <InfoOutlinedIcon
                                sx={{ color: caseView === 'base-info' ? '#067DC0' : '#55595D' }}
                            />
                            <Typography
                                sx={{
                                    color: caseView === 'base-info' ? '#067DC0' : '#55595D',
                                    fontWeight: 700,
                                    whiteSpace: 'nowrap',
                                }}
                            >
                                Thông tin cơ bản
                            </Typography>
                        </Stack>
                        <Stack
                            direction="row"
                            sx={{
                                cursor: 'pointer',
                                position: 'relative',
                                gap: '8px',
                                '&:after ':
                                    caseView === 'link-device'
                                        ? {
                                              position: 'absolute',
                                              content: '""',
                                              width: '100%',
                                              top: '110%',
                                              backgroundColor: '#067DC0',
                                              height: '2px',
                                          }
                                        : {},
                            }}
                            onClick={() => setCaseView('link-device')}
                        >
                            <LayersOutlinedIcon
                                sx={{
                                    color: caseView === 'link-device' ? '#067DC0' : '#55595D',
                                }}
                            />
                            <Typography
                                sx={{
                                    color: caseView === 'link-device' ? '#067DC0' : '#55595D',
                                    fontWeight: 700,
                                    whiteSpace: 'nowrap',
                                }}
                            >
                                Liên kết thiết bị{' '}
                                {data.Device.length > 0 ? `(${data.Device.length})` : ''}
                            </Typography>
                        </Stack>
                        <Stack
                            direction="row"
                            sx={{
                                cursor: 'pointer',
                                position: 'relative',
                                gap: '8px',
                                '&:after ':
                                    caseView === 'billing-info'
                                        ? {
                                              position: 'absolute',
                                              content: '""',
                                              width: '100%',
                                              top: '110%',
                                              backgroundColor: '#067DC0',
                                              height: '2px',
                                          }
                                        : {},
                            }}
                            onClick={() => setCaseView('billing-info')}
                        >
                            <LayersOutlinedIcon
                                sx={{
                                    color: caseView === 'billing-info' ? '#067DC0' : '#55595D',
                                }}
                            />
                            <Typography
                                sx={{
                                    color: caseView === 'billing-info' ? '#067DC0' : '#55595D',
                                    fontWeight: 700,
                                    whiteSpace: 'nowrap',
                                }}
                            >
                                Thông tin thanh toán
                            </Typography>
                        </Stack>
                    </>
                ) : (
                    <></>
                )}

                <Stack
                    direction="row"
                    sx={{
                        cursor: 'pointer',
                        position: 'relative',
                        gap: '8px',
                        '&:after ':
                            caseView === 'role-group'
                                ? {
                                      position: 'absolute',
                                      content: '""',
                                      width: '100%',
                                      top: '110%',
                                      backgroundColor: '#067DC0',
                                      height: '2px',
                                  }
                                : {},
                    }}
                    onClick={() => setCaseView('role-group')}
                >
                    <LayersOutlinedIcon
                        sx={{
                            color: caseView === 'role-group' ? '#067DC0' : '#55595D',
                        }}
                    />
                    <Typography
                        sx={{
                            color: caseView === 'role-group' ? '#067DC0' : '#55595D',
                            fontWeight: 700,
                            whiteSpace: 'nowrap',
                        }}
                    >
                        Quyền
                    </Typography>
                </Stack>
            </Stack>
            <Divider />
            <DialogContent
                sx={{
                    display: 'flex',
                    px: '30px',
                }}
            >
                <Stack
                    sx={{
                        flexGrow: 1,
                    }}
                >
                    {caseView === 'base-info' ? (
                        <BaseInfoUpdateParkingComponent
                            handleReload={reloadTable}
                            data={data}
                            handleClose={handleClose}
                        />
                    ) : caseView === 'link-device' ? (
                        <LinkDeviceUpdateParkingComponent
                            data={data}
                            fecthData={() => {
                                handleClose();
                                reloadTable();
                            }}
                        />
                    ) : caseView === 'billing-info' ? (
                        <BillingInfoUpdateParkingComponent
                            data={data}
                            fecthData={() => {
                                reloadTable();
                            }}
                        />
                    ) : caseView === 'role-group' ? (
                        <ParkingRoleInfoComponent
                            data={data}
                            fecthData={() => {
                                reloadTable();
                            }}
                        />
                    ) : (
                        <></>
                    )}
                </Stack>
            </DialogContent>
            {openComfirm ? (
                <ComfirmCloseDialog
                    close={() => setOpenComfirm(false)}
                    action={() => {
                        setOpenComfirm(false);
                        handleClose();
                    }}
                />
            ) : (
                <></>
            )}
        </Dialog>
    );
};
