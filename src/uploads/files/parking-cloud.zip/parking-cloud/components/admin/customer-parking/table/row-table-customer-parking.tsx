import { parkingApi } from '@/api/parking-api';
import { AvatarCustom } from '@/components/common';
import ActionTable from '@/components/common/action-table/action-table';
import { useAppDispatch, useAppSelector } from '@/hooks/index';
import { DeviceModel, ParkingModel } from '@/models/index';
import { deleteParking } from '@/redux/index';
import { getNameAddress, showAddress } from '@/ultis/index';
import { IconButton, Stack, TableCell, TableRow, Tooltip, Typography } from '@mui/material';
import { useRouter } from 'next/router';
import { useEffect, useState } from 'react';
import { DialogUpdateTableParking } from '../dialog-update-parking';
import { showSnackbarWithClose } from '@/hooks/useSnackbarWithClose';
import SendTimeExtensionIcon from '@mui/icons-material/SendTimeExtension';
import DialogSendImei from '../send-imei-dialog';
export interface IRowTableCustomerParkingProps {
    data: ParkingModel;
    setDataUpdate: any;
    reloadData: () => void;
}
const BACKEND_DOMAIN = process.env.NEXT_PUBLIC_SERVER_PARKING_DOMAIN;

export default function RowTableCustomerParking(props: IRowTableCustomerParkingProps) {
    const { data, setDataUpdate, reloadData } = props;
    const [open, setOpen] = useState(false);
    const [openImeiDialog, setOpenImeiDialog] = useState(false);
    const profile = useAppSelector((state) => state.common.profile);
    const router = useRouter();
    const [device, setDevice] = useState<DeviceModel[]>([]);
    const deviceOnline = useAppSelector((state) => state.socket.onlineDevice);
    const deviceOffline = useAppSelector((state) => state.socket.offlineDevice);
    const dispatch = useAppDispatch();

    useEffect(() => {
        if (data.Device) {
            setDevice(data.Device);
        }
    }, [data]);
    const handleDelete = () => {
        parkingApi
            .deleteParking(data.ID)
            .then((res) => {
                if (res.data) {
                    reloadData();
                    const action = deleteParking({ parking: data });
                    dispatch(action);
                    showSnackbarWithClose('Xóa thành công', { variant: 'success' });
                }
            })
            .catch((error) => {
                if (Array.isArray(error?.response?.data?.message)) {
                    error?.response?.data?.message.forEach((item: any) => {
                        showSnackbarWithClose(item, {
                            variant: 'error',
                        });
                    });
                } else {
                    showSnackbarWithClose(
                        error?.response ? error.response.data?.message : error.message,
                        {
                            variant: 'error',
                        }
                    );
                }
            });
    };
    useEffect(() => {
        if (!deviceOnline || data.ID !== deviceOnline?.ParkingId) return;
        const deviceIndex = device.findIndex((item) => item.ID === deviceOnline.ID);
        // console.log(deviceOnline, deviceIndex, device);
        if (deviceIndex !== -1) {
            setDevice((prev) => {
                // const clone = structuredClone(device);
                const clone = [...device];
                clone[deviceIndex].IsOnline = true;
                return clone;
            });
        }
    }, [deviceOnline]);
    useEffect(() => {
        if (!deviceOffline || data.ID !== deviceOffline?.ParkingId) return;
        const deviceIndex = device.findIndex((item) => item.ID === deviceOffline.ID);
        // console.log(deviceIndex, device);

        if (deviceIndex !== -1) {
            setDevice((prev) => {
                // const clone = structuredClone(device);
                const clone = [...device];
                clone[deviceIndex].IsOnline = false;
                return clone;
            });
        }
    }, [deviceOffline]);

    return (
        <TableRow
            sx={{
                '&:last-child td, &:last-child th': { border: 0 },
                '&:not(:last-child)': { marginBottom: '10px' },
            }}
        >
            {open ? (
                <DialogUpdateTableParking
                    handleClose={() => setOpen(false)}
                    data={{
                        ...data,
                        Device: device,
                    }}
                    setDataUpdate={setDataUpdate}
                    reloadTable={reloadData}
                    open={open}
                />
            ) : (
                <></>
            )}

            <TableCell
                onClick={(e) => {
                    router.push({
                        pathname: `${router.pathname}/${data.ID}`,
                    });
                }}
                sx={{
                    cursor: 'pointer',
                }}
            >
                {data.Name}
            </TableCell>
            <TableCell>
                <Tooltip
                    title={data?.CustomerId?.PhoneNumber || '' + '\n' + data?.CustomerId?.FullName}
                >
                    <Stack direction={'row'} spacing={1}>
                        <AvatarCustom
                            src={
                                data.CustomerId?.Avatar
                                    ? BACKEND_DOMAIN + data.CustomerId?.Avatar
                                    : ''
                            }
                            type="circle"
                            size={40}
                            alt={data?.CustomerId?.FullName}
                        />
                        <Stack justifyContent={'space-between'}>
                            <Typography variant="body2">{data.CustomerId?.FullName}</Typography>
                            <Typography variant="caption">
                                Công ty:{' '}
                                {data?.CustomerId?.CompanyId?.Name
                                    ? data?.CustomerId?.CompanyId?.Name
                                    : 'Chưa có'}
                            </Typography>
                        </Stack>
                    </Stack>
                </Tooltip>
            </TableCell>
            <TableCell
                sx={{
                    maxWidth: '400px',
                }}
            >
                {showAddress(
                    data?.Address || '',
                    getNameAddress(data?.Ward),
                    getNameAddress(data?.District),
                    getNameAddress(data?.Province)
                )}
            </TableCell>
            <TableCell>{data.Capacity}</TableCell>
            <TableCell>
                <Typography variant="body2">{device?.length + ' Box liên hết'}</Typography>
                <Typography variant="caption">
                    {device &&
                        device?.filter((item) => {
                            return item.IsOnline;
                        }).length + ' Đang hoạt động'}
                </Typography>
            </TableCell>
            {profile?.IsSupperAdmin || profile?.IsAdmin ? (
                <TableCell>
                    <Stack
                        sx={{
                            display: 'flex',
                            flexDirection: 'row',
                            alignItems: 'center',
                            justifyContent: 'center',
                            gap: '7px',
                            height: '100%',
                        }}
                    >
                        <ActionTable
                            size={'small'}
                            onEdit={() => {
                                setDataUpdate(data);
                                setOpen(true);
                            }}
                            onDelete={profile?.IsSupperAdmin ? handleDelete : undefined}
                        ></ActionTable>

                        {profile?.IsSupperAdmin ? (
                            <Tooltip title="imei">
                                <IconButton
                                    color="error"
                                    sx={{
                                        backgroundColor: '#fa6400',
                                        '&:hover': {
                                            backgroundColor: '#fb8332',
                                        },
                                        boxShadow: '0px 2px 2px rgba(0, 0, 0, 0.25)',
                                        color: '#fff',
                                    }}
                                    size={'small'}
                                    onClick={() => setOpenImeiDialog(true)}
                                >
                                    <SendTimeExtensionIcon fontSize="small" />
                                </IconButton>
                            </Tooltip>
                        ) : (
                            <></>
                        )}
                    </Stack>
                </TableCell>
            ) : (
                <></>
            )}

            <DialogSendImei
                open={openImeiDialog}
                handleClose={() => setOpenImeiDialog(false)}
                item={data}
                device={device}
            />
        </TableRow>
    );
}
