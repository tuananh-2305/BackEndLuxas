import { systemRoleApi } from '@/api/key-system-role';
import { ParkingModel } from '@/models';
import { Stack, Checkbox, Typography } from '@mui/material';
import { useCallback, useEffect, useState } from 'react';
import SaveOutlinedIcon from '@mui/icons-material/SaveOutlined';
import { KeySetting, Parking, RoleItem } from './interface';
import { showSnackbarWithClose } from '@/hooks/useSnackbarWithClose';

interface IParkingRoleInfoComponent {
    data: ParkingModel;
    fecthData: () => void;
}

export const ParkingRoleInfoComponent = (props: IParkingRoleInfoComponent) => {
    const { data: parking } = props;

    const [caseView, setCaseView] = useState<'boolean' | 'string'>('string');
    const [currentRole, setCurrentRole] = useState<RoleItem[]>([]);

    const fetchData = useCallback(async (parkingId: string) => {
        await systemRoleApi
            .groupRoleByParkingId(parkingId)
            .then((res) => {
                setCurrentRole(res.data);
            })
            .catch((error) => {
                if (Array.isArray(error?.response?.data?.message)) {
                    error?.response?.data?.message.forEach((item: any) => {
                        showSnackbarWithClose(item, {
                            variant: 'error',
                        });
                    });
                } else {
                    showSnackbarWithClose(
                        error?.response ? error.response.data?.message : error.message,
                        {
                            variant: 'error',
                        }
                    );
                }
            });
    }, []);

    useEffect(() => {
        fetchData(parking.ID);
    }, [fetchData, parking.ID]);

    return (
        <Stack sx={{ overflow: 'auto', gap: '20px', height: '100%' }} justifyContent="center">
            <Stack direction="row" mx="auto" sx={{ gap: '20px' }}>
                <Stack
                    sx={{
                        backgroundColor: caseView === 'string' ? '#55595D' : 'transparent',
                        borderRadius: '5px',
                        padding: '10px 20px',
                        border: '1px solid',
                        borderColor: '#55595D',
                        cursor: 'pointer',
                        transition: 'all ease .3s',
                    }}
                    onClick={() => setCaseView('string')}
                >
                    <Typography
                        sx={{
                            color: caseView === 'string' ? '#fff' : '#333',
                            fontSize: '14px',
                            fontStyle: 'normal',
                            fontWeight: 400,
                            lineHeight: '140%',
                            transition: 'all ease .3s',
                        }}
                    >
                        loại ký tự
                    </Typography>
                </Stack>
                <Stack
                    sx={{
                        backgroundColor: caseView === 'boolean' ? '#55595D' : 'transparent',
                        borderRadius: '5px',
                        padding: '10px 20px',
                        border: '1px solid',
                        borderColor: '#55595D',
                        cursor: 'pointer',
                        transition: 'all ease .3s',
                    }}
                    onClick={() => setCaseView('boolean')}
                >
                    <Typography
                        sx={{
                            color: caseView === 'boolean' ? '#fff' : '#333',
                            fontSize: '14px',
                            fontStyle: 'normal',
                            fontWeight: 400,
                            lineHeight: '140%',
                            transition: 'all ease .3s',
                        }}
                    >
                        loại trạng thái
                    </Typography>
                </Stack>
            </Stack>

            <Stack
                sx={{
                    gap: '4px',
                    flex: 1,
                    flexWrap: 'wrap',
                    flexDirection: caseView === 'string' ? 'column' : 'row',
                }}
            >
                {currentRole
                    .filter((role: RoleItem) => {
                        if (caseView === 'string') {
                            return role.KeySettingId.IsValue;
                        } else if (caseView === 'boolean') {
                            return !role.KeySettingId.IsValue;
                        } else {
                            return false;
                        }
                    })
                    .map((role: RoleItem) => {
                        if (caseView === 'boolean') {
                            return (
                                <Stack
                                    key={role.ID}
                                    sx={{
                                        backgroundColor: Boolean(role.IsUse) ? '#007DC0' : '#fff',
                                        border: '1px solid',
                                        borderColor: Boolean(role.IsUse) ? '#fff' : '#007DC0',
                                        height: 'fit-content',
                                        padding: '5px 10px',
                                        borderRadius: '5px',
                                        cursor: 'pointer',
                                    }}
                                    onClick={() => {
                                        systemRoleApi
                                            .updateGroupRole([
                                                {
                                                    ID: role.ID,
                                                    IsUse: !Boolean(role.IsUse),
                                                    Value: '',
                                                },
                                            ])
                                            .then(() => {
                                                fetchData(parking.ID);
                                            });
                                    }}
                                >
                                    <Typography
                                        sx={{
                                            color: Boolean(role.IsUse) ? '#FFF' : '#007DC0',
                                            fontSize: '14px',
                                            fontStyle: 'normal',
                                            fontWeight: 500,
                                            lineHeight: 'normal',
                                        }}
                                    >
                                        {role.KeySettingId.Name}
                                    </Typography>
                                </Stack>
                            );
                        }

                        if (caseView === 'string') {
                            return (
                                <Stack
                                    key={role.ID}
                                    sx={{
                                        gap: '8px',
                                    }}
                                    direction="row"
                                    alignItems="center"
                                >
                                    <Typography
                                        sx={{
                                            color: '#55595D',
                                            fontSize: '14px',
                                            fontStyle: 'normal',
                                            fontWeight: 400,
                                            lineHeight: '140%',
                                        }}
                                    >
                                        {role.KeySettingId.Name} :
                                    </Typography>

                                    <Typography
                                        component="input"
                                        id={`${role.ID}-input-string`}
                                        sx={{
                                            outline: 'none',
                                            flex: 1,
                                            border: '1px solid black',
                                            borderRadius: '5px',
                                            padding: '5px 10px',
                                        }}
                                        defaultValue={role.Value ? role.Value : ''}
                                    />

                                    <SaveOutlinedIcon
                                        onClick={async () => {
                                            const input = document.getElementById(
                                                `${role.ID}-input-string`
                                            ) as HTMLInputElement;

                                            if (!input) {
                                                return;
                                            }

                                            systemRoleApi
                                                .updateGroupRole([
                                                    {
                                                        ID: role.ID,
                                                        IsUse: true,
                                                        Value: input.value,
                                                    },
                                                ])
                                                .then(() => {
                                                    fetchData(parking.ID);
                                                });
                                        }}
                                        sx={{ cursor: 'pointer', color: '#007DC0' }}
                                    />
                                </Stack>
                            );
                        }

                        // return (
                        //     <Stack
                        //         key={item.ID}
                        //         sx={{ gap: '8px' }}
                        //         direction="row"
                        //         alignItems="center"
                        //     >
                        //         <Typography
                        //             sx={{
                        //                 color: '#55595D',
                        //                 fontSize: '14px',
                        //                 fontStyle: 'normal',
                        //                 fontWeight: 400,
                        //                 lineHeight: '140%',
                        //             }}
                        //         >
                        //             {item.KeySettingId.Name} :
                        //         </Typography>

                        //         {item.KeySettingId.IsValue ? (
                        //             <Typography
                        //                 component={'input'}
                        //                 sx={{ outline: 'none', flex: 1, padding: '5px 10px' }}
                        //                 value={item.Value ? item.Value : ''}
                        //             />
                        //         ) : (
                        //             <Checkbox size="medium" value={item.IsUse} />
                        //         )}
                        //     </Stack>
                        // );
                    })}
            </Stack>

            {/* <Stack direction="row" justifyContent="flex-end">
                <Stack
                    sx={{
                        backgroundColor: '#007DC0',
                        padding: '10px 20px',
                        borderRadius: '5px',
                        cursor: 'pointer',
                    }}
                >
                    <Typography sx={{ fontSize: '14px', color: '#fff' }}>Lưu</Typography>
                </Stack>
            </Stack> */}
        </Stack>
    );
};
