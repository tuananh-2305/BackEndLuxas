import { AuthenVipApi } from '@/api/authentication-vip';
import ActionTable from '@/components/common/action-table/action-table';
import DialogUpdateAuthenVip from '@/components/dialog/dialog-authen-vip/update';
import { showSnackbarWithClose } from '@/hooks/useSnackbarWithClose';
import { AuthenVipItem } from '@/models/authen-vip';
import { TableCell, TableRow } from '@mui/material';
import { useState } from 'react';

export interface RowTableProps {
    data: AuthenVipItem;
    reloadData: () => void;
}

export default function RowTableAuthenVipRole(props: RowTableProps) {
    const { data, reloadData } = props;
    const [openDialogUpdate, setOpenDialogUpdate] = useState(false);

    const handleDelete = () => {
        AuthenVipApi.deleteKeyClient(data.ID)
            .then((res) => {
                if (res.data) {
                    reloadData();
                    showSnackbarWithClose('Xóa thành công', { variant: 'success' });
                }
            })
            .catch((error) => {
                if (Array.isArray(error?.response?.data?.message)) {
                    error?.response?.data?.message.forEach((item: any) => {
                        showSnackbarWithClose(item, {
                            variant: 'error',
                        });
                    });
                } else {
                    showSnackbarWithClose(
                        error?.response ? error.response.data?.message : error.message,
                        {
                            variant: 'error',
                        }
                    );
                }
            });
        return 1;
    };
    return (
        <>
            {data && (
                <DialogUpdateAuthenVip
                    open={openDialogUpdate}
                    handleClose={() => {
                        setOpenDialogUpdate(false);
                    }}
                    item={data}
                    handleReload={reloadData}
                />
            )}
            <TableRow
                sx={{
                    '&:last-child td, &:last-child th': { border: 0 },
                    '&:not(:last-child)': { marginBottom: '10px' },
                }}
            >
                <TableCell>{data?.PlateNumber}</TableCell>
                <TableCell>{data?.CardNumber}</TableCell>
                <TableCell>{data?.ParkingId?.Name}</TableCell>
                <TableCell>
                    <ActionTable
                        onDelete={handleDelete}
                        size={'small'}
                        onEdit={() => {
                            setOpenDialogUpdate(true);
                        }}
                        onSync={data.IsUpdate || data.IsInsert ? () => {} : undefined}
                    ></ActionTable>
                </TableCell>
            </TableRow>
        </>
    );
}
