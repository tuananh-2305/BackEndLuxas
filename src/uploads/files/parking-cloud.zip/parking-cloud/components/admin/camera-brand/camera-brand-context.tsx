import { createContext } from 'react';

const Context = createContext({});
const CameraBrandProvider = ({ children }: any) => {
    const context = {};
    return <Context.Provider value={context}>{children}</Context.Provider>;
};
export { Context, CameraBrandProvider };
