import React, { useEffect, useState } from 'react';
import LeftNav from '../common/nav/left-nav';
import {
    Divider,
    ListItemIcon,
    ListItemText,
    MenuItem,
    MenuList,
    IconButton,
    Stack,
    Typography,
    Tooltip,
} from '@mui/material';
import { subItemsAdmin } from '@/mocks/config';
import { useRouter } from 'next/router';
import { useAppDispatch, useAppSelector } from '@/hooks/index';
import { Role, checkRole, checkRoleRouter, getRole } from '@/ultis/index';
import MenuOpenIcon from '@mui/icons-material/MenuOpen';
import { updateLeftbarOpen } from '@/redux/index';
export interface ILeftMenuAdminProps {}

export default function LeftMenuAdmin(props: ILeftMenuAdminProps) {
    const router = useRouter();
    const { pathname } = router;
    const [menu, setMenu] = useState('');
    const profile = useAppSelector((state) => state.common.profile);

    const dispatch = useAppDispatch();
    // useEffect(() => {
    //     if (!profile) {
    //         return;
    //     }
    //     setKeyRole(getRole(profile));
    // }, [profile]);
    useEffect(() => {
        // check role  and not role => redirect to home
        // setMenu(pathname);
        if (!profile || !pathname) return;
        const subItem = subItemsAdmin.find((item) => {
            return pathname === '/admin'
                ? pathname === item.path
                : item.path !== '/admin' && pathname.startsWith(item.path);
        });
        if (subItem && checkRole(profile, subItem?.roles)) {
            setMenu(subItem.path);
            return;
        } else {
            const pathRedirect = subItemsAdmin.find((item) => {
                return checkRole(profile, item.roles);
            });
            router.push(pathRedirect?.path || '/');
        }
    }, [pathname, profile]);

    return (
        <LeftNav>
            <Stack spacing={'10px'} sx={{ width: '100%', py: 2 }}>
                <Stack
                    direction="row"
                    alignItems="center"
                    justifyContent="center"
                    sx={{ width: '100%' }}
                >
                    <Typography sx={{ fontWeight: 700, fontSize: '20px', flex: 1 }}>
                        Quản trị hệ thống
                    </Typography>
                    <Tooltip title="Đóng thanh công cụ trái.">
                        <IconButton
                            onClick={() => {
                                const action = updateLeftbarOpen({ view: 'admin', open: false });
                                dispatch(action);
                            }}
                        >
                            <MenuOpenIcon />
                        </IconButton>
                    </Tooltip>
                </Stack>

                {subItemsAdmin.map((item, index) => {
                    const splitNum = [5, 7];
                    const isActived =
                        item.path === '/admin'
                            ? pathname === item.path
                            : pathname.includes(item.path);
                    const isShow = checkRoleRouter(profile, item.roles);
                    if (!isShow) return null;
                    return (
                        <Stack key={index} spacing={'10px'}>
                            <Stack
                                onClick={() => {
                                    router.replace(item.path);
                                }}
                                sx={{
                                    backgroundColor: isActived ? '#78C6E7' : 'unset',
                                    padding: '10px 20px',
                                    borderRadius: '10px',
                                    cursor: 'pointer',
                                    transition: 'all ease .3s',
                                    userSelect: 'none',
                                    '&:hover ': {
                                        boxShadow: ' rgba(149, 157, 165, 0.2) 0px 8px 24px;',
                                    },
                                }}
                                spacing={'10px'}
                                direction="row"
                            >
                                <Stack>
                                    <item.icon
                                        sx={{
                                            color: isActived ? '#fff' : '#55595D',
                                        }}
                                    />
                                </Stack>
                                <Typography
                                    sx={{
                                        fontSize: '14px',
                                        fontWeight: isActived ? 700 : 400,
                                        color: isActived ? '#fff' : '#55595D',
                                    }}
                                >
                                    {item.title}
                                </Typography>
                            </Stack>
                            {splitNum.includes(index) ? (
                                <Divider sx={{ borderTop: '1px dotted #9AA0A6' }} />
                            ) : (
                                <></>
                            )}
                        </Stack>
                    );
                })}
            </Stack>
        </LeftNav>
    );
}
