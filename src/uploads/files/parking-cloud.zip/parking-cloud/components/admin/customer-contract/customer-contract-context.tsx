import { createContext } from 'react';
const defaultValue = {}; // Giá trị mặc định cho context

const ContextCustomerContract = createContext(defaultValue);
const CustomerContractProvider = ({ children }: any) => {
    const contextValue = {}; // Giá trị của context
    return (
        <ContextCustomerContract.Provider value={contextValue}>
            {children}
        </ContextCustomerContract.Provider>
    );
};
export { ContextCustomerContract, CustomerContractProvider };
