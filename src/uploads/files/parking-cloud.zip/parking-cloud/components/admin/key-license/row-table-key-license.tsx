import { memberApi } from '@/api/member-api';
import { AvatarCustom } from '@/components/common';
import ActionTable from '@/components/common/action-table/action-table';
import DialogUpdateGroupKeyLicense from '@/components/dialog/dialog-update/dialog-update-group-role';
import { KeyLicenseModel } from '@/models/index';
import { MenuItem, Stack, TableCell, TableRow, Typography } from '@mui/material';
import { enqueueSnackbar } from 'notistack';
import { useState } from 'react';

const BACKEND_DOMAIN = process.env.NEXT_PUBLIC_SERVER_PARKING_DOMAIN;

export interface IRowTableKeyLicenseProps {
    data: KeyLicenseModel;
    setOpen: any;
    setDataUpdate: (data: KeyLicenseModel) => void;
    reloadData: () => void;
}

export default function RowTableKeyLicense(props: IRowTableKeyLicenseProps) {
    const { data, setOpen, setDataUpdate, reloadData } = props;
    const handleDelete = () => {
        // groupKeyLicenseApi
        //     .deleteGroupKeyLicense(data.ID)
        //     .then((res) => {
        //         if (res.data) {
        //             reloadData();
        //             showSnackbarWithClose('Xóa thành công', { variant: 'success' });
        //         }
        //     })
        //     .catch((err) => {
        //         showSnackbarWithClose('Xóa thất bại', { variant: 'error' });
        //     });
    };
    return (
        <TableRow
            sx={{
                '&:last-child td, &:last-child th': { border: 0 },
                '&:not(:last-child)': { marginBottom: '10px' },
            }}
        >
            {/* <TableCell>{data.Name}</TableCell>
            <TableCell>{data.Key}</TableCell>
            <TableCell>
                <Stack direction={'row'} spacing={1}>
                    <AvatarCustom
                        src={
                            data.CustomerId?.Avatar ? BACKEND_DOMAIN + data.CustomerId?.Avatar : ''
                        }
                        type="circle"
                        size={40}
                    />
                    <Stack justifyContent={'space-between'}>
                        <Typography variant="body2">{data.Name}</Typography>
                        <Typography variant="caption">{'Công ty oryza'}</Typography>
                    </Stack>
                </Stack>
            </TableCell>
            <TableCell>{data.Description}</TableCell>

            <TableCell>
                <ActionTable
                    onDelete={handleDelete}
                    size={'small'}
                    onEdit={() => {
                        setDataUpdate(data);
                    }}
                >
                    <MenuItem disableRipple>Demo</MenuItem>
                </ActionTable>
            </TableCell> */}
        </TableRow>
    );
}
