import DialogUpdateGroupKeyLicense from '@/components/dialog/dialog-update/dialog-update-group-role';
import { SettingEmptyComponent } from '@/components/settings/empty';
import HeaderTable from '@/components/table/header-table';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import ArrowForwardIcon from '@mui/icons-material/ArrowForward';
import {
    Pagination,
    PaginationItem,
    Stack,
    Table,
    TableBody,
    TableContainer,
    useTheme,
} from '@mui/material';
import { useRouter } from 'next/router';
import { useMemo, useState } from 'react';
import RowTableKeyLicense from './row-table-key-license';
import { columnsLicense } from '@/mocks/header-mock';
import { KeyLicenseModel } from '@/models/key.license.model';
import { SIZE_PAGE, formatTextPagination } from '@/ultis/index';
export interface ITableKeyLicenseProps {
    data: KeyLicenseModel[];
    fetchData: () => void;
    maxPage: number;
    total: number;
    currentSize: number;
}

export default function TableKeyLicense(props: ITableKeyLicenseProps) {
    const { data, fetchData, maxPage, total, currentSize } = props;
    const [openDialogUpdate, setOpenDialogUpdate] = useState(false);
    const [itemHandle, setItemHandle] = useState<KeyLicenseModel>();
    const theme = useTheme();
    const router = useRouter();
    const { page } = router.query;

    const currentPage = useMemo(() => {
        return page && !Number.isNaN(Number(page)) && Number.isInteger(Number(page))
            ? Number(page) - 1
            : 0;
    }, [page]);
    return (
        <TableContainer
            sx={{
                flex: 1,
                display: 'flex',
                flexDirection: 'column',
                justifyContent: 'space-between',
                p: 2,
            }}
        >
            <Table
                sx={{
                    borderCollapse: 'separate',
                    borderSpacing: '0 10px',
                    marginTop: '-10px',
                }}
            >
                <HeaderTable headerData={columnsLicense} />
                <TableBody
                    sx={{
                        '& td': {
                            background: 'rgba(217, 217, 217, 0.2)',
                        },
                        'td:first-of-type': {
                            borderTopLeftRadius: '10px',
                            borderBottomLeftRadius: '10px',
                        },
                        'td:last-of-type': {
                            borderTopRightRadius: '10px',
                            borderBottomRightRadius: '10px',
                        },
                    }}
                >
                    {itemHandle && <></>}
                    {data?.map((c: KeyLicenseModel, index) => (
                        <RowTableKeyLicense
                            data={c}
                            setOpen={undefined}
                            setDataUpdate={(data) => {
                                setItemHandle(data);
                                setOpenDialogUpdate(true);
                            }}
                            key={index}
                            reloadData={fetchData}
                        />
                    ))}
                </TableBody>
            </Table>
            {!data || data?.length === 0 ? (
                <SettingEmptyComponent />
            ) : (
                <Stack position={'relative'} alignItems={'center'}>
                    <Pagination
                        count={maxPage}
                        page={
                            page?.toString() && page?.toString() !== 'undefined'
                                ? parseInt(page?.toString())
                                : 1
                        }
                        onChange={(event, page) => {
                            router.push({
                                pathname: router.pathname,
                                query: { page: page },
                            });
                        }}
                        renderItem={(item) => (
                            <PaginationItem
                                components={{ previous: ArrowBackIcon, next: ArrowForwardIcon }}
                                {...item}
                                shape="rounded"
                                sx={{
                                    borderRadius: '4px',
                                    border: '1px solid #DFE3E8',
                                    '&.Mui-selected': {
                                        background: '#fff',
                                        border: '1px solid #067DC0',
                                        color: '#067DC0',
                                    },

                                    color: theme.palette.text.primary,
                                }}
                            />
                        )}
                        sx={{
                            py: 2,
                        }}
                    />
                    <Stack
                        position={'absolute'}
                        sx={{
                            right: '60px',
                            top: '0',
                            bottom: '0',
                        }}
                        alignItems={'center'}
                        justifyContent={'center'}
                    >
                        {`${currentPage * SIZE_PAGE + data.length}/${total} dữ liệu`}
                    </Stack>
                </Stack>
            )}
        </TableContainer>
    );
}
