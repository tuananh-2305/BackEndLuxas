import HeaderTable from '@/components/table/header-table';
import { headerImei } from '@/mocks/header-mock';
import { DeviceImeiModel } from '@/models/index';
import { Table, TableBody, TableContainer } from '@mui/material';
import RowTableImei from './row-table-imei';

export interface ITableUUIDParkingProps {
    fetchData: () => void;
    data: DeviceImeiModel[];
}

export default function TableUUIDParking(props: ITableUUIDParkingProps) {
    const { fetchData, data } = props;

    return (
        <TableContainer
            sx={{
                flex: 1,
                display: 'flex',
                flexDirection: 'column',
                justifyContent: 'space-between',
                alignItems: 'center',
            }}
        >
            <Table
                sx={{
                    borderCollapse: 'separate',
                    borderSpacing: '0 10px',
                }}
            >
                <HeaderTable headerData={headerImei} />
                <TableBody
                    sx={{
                        maxHeight: '200px',
                        overflow: 'auto',
                        '& td': {
                            background: 'rgba(217, 217, 217, 0.2)',
                        },
                        'td:first-of-type': {
                            borderTopLeftRadius: '10px',
                            borderBottomLeftRadius: '10px',
                        },
                        'td:last-of-type': {
                            borderTopRightRadius: '10px',
                            borderBottomRightRadius: '10px',
                        },
                    }}
                >
                    {data?.map((c: DeviceImeiModel) => (
                        <RowTableImei key={`card-type-${c?.ID}`} data={c} reload={fetchData} />
                    ))}
                </TableBody>
            </Table>
        </TableContainer>
    );
}
