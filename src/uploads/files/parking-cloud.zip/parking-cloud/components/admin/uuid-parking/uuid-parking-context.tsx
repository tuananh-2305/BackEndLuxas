import { createContext } from 'react';

const UUIDParkingContext = createContext({});
const UUIDParkingProvider = ({ children }: any) => {
    const context = {};
    return <UUIDParkingContext.Provider value={context}>{children}</UUIDParkingContext.Provider>;
};
export { UUIDParkingContext, UUIDParkingProvider };
