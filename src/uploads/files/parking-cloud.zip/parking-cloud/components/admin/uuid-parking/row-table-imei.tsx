import { boxImeiApi } from '@/api/box-imei';
import { DialogCreateImei } from '@/components/dialog/dialog-update-imei';
import DialogWarning from '@/components/dialog/dialog-warning';
import { showSnackbarWithClose } from '@/hooks/useSnackbarWithClose';
import { DeviceImeiModel } from '@/models/index';
import { getDateTime } from '@/ultis/index';
import BorderColorIcon from '@mui/icons-material/BorderColor';
import DeleteIcon from '@mui/icons-material/Delete';
import { Stack, TableCell, TableRow, Tooltip } from '@mui/material';
import { useState } from 'react';
const BACKEND_DOMAIN = process.env.NEXT_PUBLIC_SERVER_PARKING_DOMAIN;

export interface IRowTableImeiProps {
    data: DeviceImeiModel;
    reload: () => void;
}

export default function RowTableImei(props: IRowTableImeiProps) {
    const { data, reload } = props;

    const [openEditDialog, setOpenEditDialog] = useState(false);
    const [openDialogSuccess, setOpenDialogSuccess] = useState(false);

    const handleDelete = () => {
        boxImeiApi
            .deleteBoxImei(data.ID)
            .then((res) => {
                reload();
                showSnackbarWithClose('xoá thành công!', {
                    variant: 'success',
                });
            })
            .catch((error) => {
                if (Array.isArray(error?.response?.data?.message)) {
                    error?.response?.data?.message.forEach((item: any) => {
                        showSnackbarWithClose(item, {
                            variant: 'error',
                        });
                    });
                } else {
                    showSnackbarWithClose(
                        error?.response ? error.response.data?.message : error.message,
                        {
                            variant: 'error',
                        }
                    );
                }
            });
    };
    return (
        <TableRow
            sx={{
                '&:last-child td, &:last-child th': { border: 0 },
                '&:not(:last-child)': { marginBottom: '10px' },
            }}
        >
            <DialogWarning
                open={openDialogSuccess}
                handleClose={() => {
                    setOpenDialogSuccess(false);
                }}
                handleConfirm={() => {
                    handleDelete();
                    setOpenDialogSuccess(false);
                }}
                title="Bạn đang thực hiện hành động xóa dữ liệu khỏi hệ thống, "
            ></DialogWarning>
            <TableCell scope="row">{data.Imei}</TableCell>
            <TableCell>{data.Name}</TableCell>
            <TableCell>{getDateTime(data.ProductionDate)}</TableCell>
            <TableCell>{getDateTime(data.ActivationDate)}</TableCell>
            <TableCell>{getDateTime(data.WarrantyExpirationDate)}</TableCell>
            <TableCell sx={{ display: 'flex', flexDirection: 'row', gap: '10px' }}>
                <Tooltip title="Xóa.">
                    <Stack
                        onClick={() => {
                            setOpenDialogSuccess(true);
                        }}
                        color="error"
                        sx={{
                            backgroundColor: 'rgba(233, 79, 79, 0.3)',
                            boxShadow: '0px 2px 2px rgba(0, 0, 0, 0.25)',
                            padding: '10px',
                            borderRadius: '50%',
                            cursor: 'pointer',
                        }}
                    >
                        <DeleteIcon sx={{ color: '#E94F4F' }} />
                    </Stack>
                </Tooltip>

                <Tooltip title="Sửa.">
                    <Stack
                        onClick={() => setOpenEditDialog(true)}
                        sx={{
                            backgroundColor: '#067DC0',
                            boxShadow: '0px 2px 2px rgba(0, 0, 0, 0.25)',
                            padding: '10px',
                            borderRadius: '50%',
                            cursor: 'pointer',
                        }}
                    >
                        <BorderColorIcon sx={{ color: '#fff' }} />
                    </Stack>
                </Tooltip>

                {openEditDialog ? (
                    <DialogCreateImei
                        item={data}
                        open={openEditDialog}
                        handleClose={() => setOpenEditDialog(false)}
                        handleReload={reload}
                    />
                ) : (
                    <></>
                )}
            </TableCell>
        </TableRow>
    );
}
