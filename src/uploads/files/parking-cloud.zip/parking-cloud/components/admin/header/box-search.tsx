export interface IBoxSearchProps {}

export default function BoxSearch(props: IBoxSearchProps) {
    return <div></div>;
}
