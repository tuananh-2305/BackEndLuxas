import { MemberTypeContext } from '@/components/settings/member-type';
import { useAppDispatch, useAppSelector } from '@/hooks/useReudx';
import { updateLeftbarOpen } from '@/redux/common';
import { useDebouncedValue } from '@mantine/hooks';
import AddBoxIcon from '@mui/icons-material/AddBox';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import ClearIcon from '@mui/icons-material/Clear';
import SearchIcon from '@mui/icons-material/Search';
import { Button, IconButton, InputBase, Stack, Tooltip, Typography } from '@mui/material';
import Image from 'next/image';
import { useRouter } from 'next/router';
import React, { useContext, useEffect, useState } from 'react';
import MenuOpenIcon from '@mui/icons-material/MenuOpen';
export interface IHeaderTableAdminProps {
    fecthData?: () => void;
    setOpen: any;
    setTextSearch?: (text: string) => void;
    isHiddenCreate?: boolean;
    hiddenImport?: boolean;
    hiddenExport?: boolean;
    children?: React.ReactNode;
    isHiddenSearch?: boolean;
    backLink?: string;
    neoCase: 'setting' | 'admin';
    customText?: string;
}

export default function HeaderTableAdmin(props: IHeaderTableAdminProps) {
    const {
        fecthData,
        setOpen,
        setTextSearch,
        isHiddenCreate,
        hiddenImport,
        hiddenExport,
        children,
        isHiddenSearch,
        backLink,
        neoCase,
        customText,
    } = props;
    const [search, changeSearch] = useState('');
    const [debounced] = useDebouncedValue(search, 500);
    const { updateSearchText } = useContext(MemberTypeContext);
    const [isSearch, setIsSearch] = useState(false);
    const router = useRouter();
    const dispatch = useAppDispatch();
    const neocase = useAppSelector((state) => state.common.leftBarStateOpen[neoCase]);
    useEffect(() => {
        updateSearchText(debounced);
        setTextSearch && setTextSearch(debounced);
    }, [debounced, updateSearchText]);
    const handleSubmit = () => {
        setIsSearch(true);
        // if (!checkRouter('job', router)) return;
        if (search.length <= 0) {
            setIsSearch(!isSearch);
            return;
        } else {
            changeSearch('');
        }
    };
    return (
        <Stack
            sx={{ justifyContent: 'space-between', flexDirection: 'row', width: '100%', p: 2 }}
            alignItems="center"
        >
            <Stack sx={{ flexDirection: 'row', gap: 2 }} alignItems="center">
                <Stack
                    sx={{
                        // width: neocase ? '0px' : '40px',
                        // overflow: 'hidden',
                        // transition: 'all 0.5s',
                        display: neocase ? 'none' : '',
                    }}
                >
                    <Tooltip title="Mở thanh công cụ trái.">
                        <IconButton
                            sx={{
                                transform: 'rotate(180deg)',
                                // display: neocase ? 'none' : 'flex',
                            }}
                            onClick={() => {
                                const action = updateLeftbarOpen({ view: neoCase, open: true });
                                dispatch(action);
                            }}
                        >
                            <MenuOpenIcon />
                        </IconButton>
                    </Tooltip>
                </Stack>

                {children}
                {backLink && (
                    <Tooltip title="Quay lại">
                        <Stack
                            sx={{
                                width: '40px',
                                height: '40px',
                                backgroundColor: '#CDD2D1',
                                borderRadius: '10px',
                                cursor: 'pointer',
                            }}
                            justifyContent="center"
                            alignItems="center"
                            onClick={() => {
                                router.push(backLink);
                            }}
                        >
                            <ArrowBackIcon sx={{ color: '#fff' }} />
                        </Stack>
                    </Tooltip>
                )}
                <Typography sx={{ fontWeight: 700, fontSize: '14px' }}>
                    {customText ? customText : ''}{' '}
                </Typography>

                {!isHiddenCreate && (
                    <Button
                        sx={{
                            bgcolor: '#78C6E7',
                            borderRadius: '10px',
                            transition: 'all 0.3s',
                        }}
                        size="small"
                        variant={'contained'}
                        color="secondary"
                        onClick={() => setOpen(true)}
                    >
                        <AddBoxIcon />
                        <Typography
                            sx={{ fontFamily: 'Roboto', fontWeight: 700, fontSize: '14px', pl: 1 }}
                        >
                            Tạo mới
                        </Typography>
                    </Button>
                )}
                {!hiddenImport && (
                    <Tooltip title="Nhập Excel (Tính năng đang bảo trì.)">
                        <Stack
                            sx={{
                                width: '40px',
                                height: '40px',
                                backgroundColor: '#CDD2D1',
                                borderRadius: '10px',
                                cursor: 'pointer',
                            }}
                            justifyContent="center"
                            alignItems="center"
                        >
                            <Image
                                src="/icons/file-left-arrow.svg"
                                width={24}
                                height={24}
                                alt="file-arrow"
                            />
                        </Stack>
                    </Tooltip>
                )}
                {/* {!hiddenExport && (
                    <Tooltip title="Xuất Excel">
                        <Stack
                            sx={{
                                width: '40px',
                                height: '40px',
                                backgroundColor: '#CDD2D1',
                                borderRadius: '10px',
                                cursor: 'pointer',
                            }}
                            justifyContent="center"
                            alignItems="center"
                        >
                            <Image
                                src="/icons/file-right-arrow.svg"
                                width={24}
                                height={24}
                                alt="file-arrow"
                            />
                        </Stack>
                    </Tooltip>
                )} */}
            </Stack>
            {!isHiddenSearch && (
                <Stack direction="row">
                    <Stack
                        sx={{
                            width: isSearch ? '300px' : '0px',
                            height: isSearch ? '50px' : '5px',
                            overflow: 'hidden',
                            justifyContent: 'center',
                            transition: 'width 300ms linear, height 300ms linear 300ms',
                            maxHeight: '40px',
                        }}
                    >
                        <InputBase
                            value={search}
                            onChange={(e) => {
                                const { value } = e.target;
                                // console.log('searchText 1 : ', value);
                                changeSearch(value);
                            }}
                            sx={{
                                borderBottom: '1px solid  #000000',
                            }}
                            placeholder="Tìm kiếm..."
                        />
                    </Stack>
                    <Stack>
                        <IconButton
                            type="button"
                            sx={{}}
                            aria-label="search"
                            onClick={handleSubmit}
                        >
                            {search.length <= 0 ? <SearchIcon /> : <ClearIcon />}
                        </IconButton>
                    </Stack>
                </Stack>
            )}
        </Stack>
    );
}
