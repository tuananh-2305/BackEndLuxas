import DialogUpdatekeyKeySystemCloud from '@/components/dialog/dialog-update/dialog-update-key-system-role';
import HeaderTable from '@/components/table/header-table';
import { columnsKeyClient } from '@/mocks/index';
import { AuthenRoleClientInterface } from '@/models/authen-role-client';
import { Table, TableBody, TableContainer } from '@mui/material';
import { useState } from 'react';
import { RowTableRole } from './row';
export interface ITableKeyClientProps {
    data: AuthenRoleClientInterface[];
    fetchData: () => void;
}

export function TableKeyDetailSystemCloud(props: ITableKeyClientProps) {
    const { data, fetchData } = props;
    const [openDialogUpdate, setOpenDialogUpdate] = useState(false);
    const [itemHandle, setItemHandle] = useState<AuthenRoleClientInterface>();

    return (
        <TableContainer
            sx={{
                flex: 1,
                display: 'flex',
                flexDirection: 'column',
                justifyContent: 'space-between',
                alignItems: 'center',
                p: 2,
            }}
        >
            <Table
                sx={{
                    borderCollapse: 'separate',
                    borderSpacing: '0 10px',
                    marginTop: '-10px',
                }}
            >
                <HeaderTable headerData={columnsKeyClient} />
                <TableBody
                    sx={{
                        '& td': {
                            background: 'rgba(217, 217, 217, 0.2)',
                        },
                        'td:first-of-type': {
                            borderTopLeftRadius: '10px',
                            borderBottomLeftRadius: '10px',
                        },
                        'td:last-of-type': {
                            borderTopRightRadius: '10px',
                            borderBottomRightRadius: '10px',
                        },
                    }}
                >
                    {itemHandle && (
                        <DialogUpdatekeyKeySystemCloud
                            open={openDialogUpdate}
                            handleClose={() => {
                                setOpenDialogUpdate(false);
                            }}
                            item={itemHandle}
                            handleReload={fetchData}
                        />
                    )}
                    {data &&
                        data
                            .sort((a: any, b: any) => {
                                return (
                                    new Date(a.CreatedAt).getTime() -
                                    new Date(b.CreatedAt).getTime()
                                );
                            })
                            .map((c: AuthenRoleClientInterface, index) => (
                                <RowTableRole
                                    data={c}
                                    setOpen={undefined}
                                    setDataUpdate={(data: AuthenRoleClientInterface) => {
                                        setItemHandle(data);
                                        setOpenDialogUpdate(true);
                                    }}
                                    key={index}
                                    reloadData={fetchData}
                                />
                            ))}
                </TableBody>
            </Table>
        </TableContainer>
    );
}
