import { authApi } from '@/api/auth-api';
import ActionTable from '@/components/common/action-table/action-table';
import { useAppSelector } from '@/hooks/index';
import { showSnackbarWithClose } from '@/hooks/useSnackbarWithClose';
import { EmployeeModel } from '@/models/employee.model';
import { checkRoleEmployee } from '@/ultis/index';
import { Avatar, Stack, TableCell, TableRow, Typography } from '@mui/material';

const BACKEND_DOMAIN = process.env.NEXT_PUBLIC_SERVER_PARKING_DOMAIN;

export interface IRowTableManagerEmployeeProps {
    data: EmployeeModel;
    setOpen: any;
    setDataUpdate: (data: EmployeeModel) => void;
    reloadData: () => void;
}

export default function RowTableManagerEmployee(props: IRowTableManagerEmployeeProps) {
    const { data, setOpen, setDataUpdate, reloadData } = props;
    const handleDelete = () => {
        authApi
            .delete(data.ID)
            .then((res) => {
                if (res.data) {
                    reloadData();
                    showSnackbarWithClose('Xóa thành công', { variant: 'success' });
                }
            })
            .catch((error) => {
                if (Array.isArray(error?.response?.data?.message)) {
                    error?.response?.data?.message.forEach((item: any) => {
                        showSnackbarWithClose(item, {
                            variant: 'error',
                        });
                    });
                } else {
                    showSnackbarWithClose(
                        error?.response ? error.response.data?.message : error.message,
                        {
                            variant: 'error',
                        }
                    );
                }
            });
    };
    // console.log(data);
    const profile = useAppSelector((state) => state.common.profile);
    return (
        <TableRow
            sx={{
                '&:last-child td, &:last-child th': { border: 0 },
                '&:not(:last-child)': { marginBottom: '10px' },
            }}
        >
            <TableCell scope="row" sx={{ width: '25%' }}>
                <Stack direction={'row'} spacing={1}>
                    <Avatar
                        alt={data.Name}
                        src={data?.Avatar ? BACKEND_DOMAIN + data.Avatar : ''}
                    />
                    <Stack>
                        <Typography sx={{ fontWeight: 600, fontSize: '14px' }}>
                            {data.Name}
                        </Typography>
                        <Typography sx={{ fontWeight: 300, fontSize: '12px', fontStyle: 'italic' }}>
                            {data.Phone}
                        </Typography>
                    </Stack>
                </Stack>
            </TableCell>
            <TableCell sx={{ width: '20%' }}>
                {data.Gender ? data.Gender : 'Chưa xác định'}
            </TableCell>
            {/* <TableCell sx={{ width: '20%', fontWeight: 600 }}>{'Chưa được phân quyền'}</TableCell> */}
            <TableCell sx={{ color: data.IsActive ? '#5EB14A' : '#E94F4F', width: '20%' }}>
                {data.IsActive ? 'Đã kích hoạt' : 'Chưa kích hoạt'}
            </TableCell>
            <TableCell>
                {/* <Stack sx={{ flexDirection: 'row', justifyContent: 'flex-end', pr: 2 }} gap={1}>
                    <Tooltip title="Xóa">
                        <Button
                            sx={{
                                background:
                                    'linear-gradient(0deg, rgba(233, 79, 79, 0.3), rgba(233, 79, 79, 0.3)), #FFFFFF',
                                borderRadius: '50%',
                                transition: 'all 0.3s',
                                boxShadow: '0px 2px 2px rgba(0, 0, 0, 0.25)',
                                maxWidth: '40px',
                                maxHeight: '40px',
                                minHeight: '40px',
                                minWidth: '40px',
                            }}
                            variant={'contained'}
                            color="secondary"
                        >
                            <DeleteOutlinedIcon />
                        </Button>
                    </Tooltip>
                    <Tooltip title="Sửa">
                        <Button
                            sx={{
                                background: '#067DC0',
                                borderRadius: '40px',
                                transition: 'all 0.3s',
                                boxShadow: '0px 2px 2px rgba(0, 0, 0, 0.25)',
                                maxWidth: '40px',
                                maxHeight: '40px',
                                minHeight: '40px',
                                minWidth: '40px',
                            }}
                            variant={'contained'}
                            color="secondary"
                            onClick={() => {
                                setOpen(true);
                                setDataUpdate(data);
                            }}
                        >
                            <BorderColorOutlinedIcon />
                        </Button>
                    </Tooltip>
                </Stack> */}

                {/* {checkRoleEmployee(data, profile) ? (
                    <></>
                ) : (
                    <ActionTable
                        onDelete={handleDelete}
                        size={'small'}
                        onEdit={() => {
                            setOpen(true);
                            setDataUpdate(data);
                        }}
                    />
                )} */}

                <ActionTable
                    onDelete={handleDelete}
                    size={'small'}
                    onEdit={() => {
                        setOpen(true);
                        setDataUpdate(data);
                    }}
                />
            </TableCell>
        </TableRow>
    );
}
