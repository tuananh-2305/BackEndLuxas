import { SettingEmptyComponent } from '@/components/settings/empty';
import HeaderTable from '@/components/table/header-table';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import ArrowForwardIcon from '@mui/icons-material/ArrowForward';
import {
    Pagination,
    PaginationItem,
    Table,
    TableBody,
    TableContainer,
    useTheme,
} from '@mui/material';
import { EmployeeModel } from '@/models/employee.model';
import { headerEmployee } from '@/mocks/header-mock';
import { useState } from 'react';
import DialogCreateEmployee from '@/components/dialog/dialog-create-employee';
import RowTableManagerEmployee from './row-table-manager-employee';

export interface ITableManagerEmployeeProps {
    data: EmployeeModel[];
    fetchData: () => void;
    setDataUpdate: (data: EmployeeModel) => void;
}

export default function TableManagerEmployee(props: ITableManagerEmployeeProps) {
    const { data, fetchData, setDataUpdate } = props;
    const theme = useTheme();
    const [open, setOpen] = useState(false);
    return (
        // <TableContainer
        //     sx={{
        //         flex: 1,
        //         display: 'flex',
        //         flexDirection: 'column',
        //         justifyContent: 'space-between',
        //         alignItems: 'center',
        //         pl: 2,
        //         pr: 2,
        //     }}
        // >
        <Table
            sx={{
                borderCollapse: 'separate',
                borderSpacing: '0 10px',
                marginTop: '-10px',
            }}
        >
            <HeaderTable headerData={headerEmployee} />
            <TableBody
                sx={{
                    flex: 1,
                    '& td': {
                        background: 'rgba(217, 217, 217, 0.2)',
                    },
                    'td:first-of-type': {
                        borderTopLeftRadius: '10px',
                        borderBottomLeftRadius: '10px',
                    },
                    'td:last-of-type': {
                        borderTopRightRadius: '10px',
                        borderBottomRightRadius: '10px',
                    },
                }}
            >
                {data?.map((c: EmployeeModel) => (
                    <RowTableManagerEmployee
                        key={`card-type-${c?.ID}`}
                        data={c}
                        setOpen={setOpen}
                        setDataUpdate={setDataUpdate}
                        reloadData={fetchData}
                    />
                ))}
            </TableBody>
        </Table>
        //     {/* {data.length === 0 && <SettingEmptyComponent />}
        //     <Pagination
        //         count={6}
        //         onChange={(event, value) => setPage(value.toString())}
        //         renderItem={(item) => (
        //             <PaginationItem
        //                 components={{ previous: ArrowBackIcon, next: ArrowForwardIcon }}
        //                 {...item}
        //                 shape="rounded"
        //                 sx={{
        //                     borderRadius: '4px',
        //                     border: '1px solid #DFE3E8',
        //                     '&.Mui-selected': {
        //                         background: '#fff',
        //                         border: '1px solid #067DC0',
        //                         color: '#067DC0',
        //                     },

        //                     color: theme.palette.text.primary,
        //                 }}
        //             />
        //         )}
        //         sx={{
        //             py: 2,
        //             pt: 0,
        //         }}
        //     />
        //     <DialogCreateEmployee
        //         open={open}
        //         handleClose={() => {
        //             setOpen(false);
        //             setDataUpdate(null);
        //         }}
        //         handleReload={fetchData}
        //         dataUpdate={dataUpdate}
        //     />
        // </TableContainer> */}
    );
}
