import { createContext } from 'react';

const ContextCompany = createContext({});
const CompanyProvider = ({ children }: any) => {
    const context = {};
    return <ContextCompany.Provider value={context}>{children}</ContextCompany.Provider>;
};
export { ContextCompany, CompanyProvider };
