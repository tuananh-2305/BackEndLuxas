import { KeyClientApi } from '@/api/key-client';
import { keyDetailCloudApi } from '@/api/key-detai-cloud';
import ActionTable from '@/components/common/action-table/action-table';
import { showSnackbarWithClose } from '@/hooks/useSnackbarWithClose';
import { AuthenRoleClientInterface } from '@/models/authen-role-client';
import { TableCell, TableRow } from '@mui/material';

const BACKEND_DOMAIN = process.env.NEXT_PUBLIC_SERVER_PARKING_DOMAIN;

export interface RowTableProps {
    data: AuthenRoleClientInterface;
    setOpen: any;
    setDataUpdate: (data: AuthenRoleClientInterface) => void;
    reloadData: () => void;
}

export default function RowTableRole(props: RowTableProps) {
    const { data, setOpen, setDataUpdate, reloadData } = props;
    const handleDelete = () => {
        keyDetailCloudApi
            .delete(data.ID)
            .then((res) => {
                if (res.data) {
                    reloadData();
                    showSnackbarWithClose('Xóa thành công', { variant: 'success' });
                }
            })
            .catch((error) => {
                if (Array.isArray(error?.response?.data?.message)) {
                    error?.response?.data?.message.forEach((item: any) => {
                        showSnackbarWithClose(item, {
                            variant: 'error',
                        });
                    });
                } else {
                    showSnackbarWithClose(
                        error?.response ? error.response.data?.message : error.message,
                        {
                            variant: 'error',
                        }
                    );
                }
            });
    };
    return (
        <TableRow
            sx={{
                '&:last-child td, &:last-child th': { border: 0 },
                '&:not(:last-child)': { marginBottom: '10px' },
            }}
        >
            <TableCell>{data.Name}</TableCell>
            <TableCell>{data.KeyWord}</TableCell>
            <TableCell>
                <ActionTable
                    onDelete={handleDelete}
                    size={'small'}
                    onEdit={() => {
                        setDataUpdate(data);
                    }}
                >
                    {/* <MenuItem disableRipple>Demo</MenuItem> */}
                </ActionTable>
            </TableCell>
        </TableRow>
    );
}
