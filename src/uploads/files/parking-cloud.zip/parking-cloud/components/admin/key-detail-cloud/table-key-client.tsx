import DialogUpdatekeyClient from '@/components/dialog/dialog-key-client/update';
import HeaderTable from '@/components/table/header-table';
import { columnsKeyClient } from '@/mocks/index';
import { AuthenRoleClientInterface } from '@/models/authen-role-client';
import { Table, TableBody, TableContainer, useTheme } from '@mui/material';
import { useRouter } from 'next/router';
import { useState } from 'react';
import RowTableRole from './row-table';
import DialogUpdatekeyKeyDetailCloud from '@/components/dialog/dialog-update/dialog-update-key-detail-role-cloud';
export interface ITableKeyClientProps {
    data: AuthenRoleClientInterface[];
    fetchData: () => void;
}

export default function TableKeyDetailCloud(props: ITableKeyClientProps) {
    const { data, fetchData } = props;
    const [openDialogUpdate, setOpenDialogUpdate] = useState(false);
    const [itemHandle, setItemHandle] = useState<AuthenRoleClientInterface>();
    const theme = useTheme();
    const router = useRouter();
    const { page } = router.query;
    return (
        <TableContainer
            sx={{
                flex: 1,
                display: 'flex',
                flexDirection: 'column',
                justifyContent: 'space-between',
                alignItems: 'center',
                p: 2,
            }}
        >
            <Table
                sx={{
                    borderCollapse: 'separate',
                    borderSpacing: '0 10px',
                    marginTop: '-10px',
                }}
            >
                <HeaderTable headerData={columnsKeyClient} />
                <TableBody
                    sx={{
                        '& td': {
                            background: 'rgba(217, 217, 217, 0.2)',
                        },
                        'td:first-of-type': {
                            borderTopLeftRadius: '10px',
                            borderBottomLeftRadius: '10px',
                        },
                        'td:last-of-type': {
                            borderTopRightRadius: '10px',
                            borderBottomRightRadius: '10px',
                        },
                    }}
                >
                    {itemHandle && (
                        <DialogUpdatekeyKeyDetailCloud
                            open={openDialogUpdate}
                            handleClose={() => {
                                setOpenDialogUpdate(false);
                            }}
                            item={itemHandle}
                            handleReload={fetchData}
                        />
                    )}
                    {data &&
                        data.map((c: AuthenRoleClientInterface, index) => (
                            <RowTableRole
                                data={c}
                                setOpen={undefined}
                                setDataUpdate={(data: AuthenRoleClientInterface) => {
                                    setItemHandle(data);
                                    setOpenDialogUpdate(true);
                                }}
                                key={index}
                                reloadData={fetchData}
                            />
                        ))}
                </TableBody>
            </Table>
        </TableContainer>
    );
}
