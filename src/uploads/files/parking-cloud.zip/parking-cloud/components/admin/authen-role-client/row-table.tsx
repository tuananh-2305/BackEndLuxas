import { AuthenKeyApi } from '@/api/authen-role-client';
import { groupRoleApi } from '@/api/group-role-api';
import { AvatarCustom } from '@/components/common';
import ActionTable from '@/components/common/action-table/action-table';
import DialogUpdateAuthenRoleClient from '@/components/dialog/dialog-authen-role-client/update';
import { showSnackbarWithClose } from '@/hooks/useSnackbarWithClose';
import { AuthenRoleClientItem } from '@/models/authen-role-client';
import { RoleModel } from '@/models/group.role.model';
import { Box, Stack, TableCell, TableRow, Typography } from '@mui/material';
import { useState } from 'react';

const BACKEND_DOMAIN = process.env.NEXT_PUBLIC_SERVER_PARKING_DOMAIN;

export interface RowTableProps {
    data: AuthenRoleClientItem;
    reloadData: () => void;
}

export default function RowTableRole(props: RowTableProps) {
    const { data, reloadData } = props;
    const [openDialogUpdate, setOpenDialogUpdate] = useState(false);

    const handleDelete = () => {
        AuthenKeyApi.deleteKeyClient(data.ID)
            .then((res) => {
                if (res.data) {
                    reloadData();
                    showSnackbarWithClose('Xóa thành công', { variant: 'success' });
                }
            })
            .catch((error) => {
                if (Array.isArray(error?.response?.data?.message)) {
                    error?.response?.data?.message.forEach((item: any) => {
                        showSnackbarWithClose(item, {
                            variant: 'error',
                        });
                    });
                } else {
                    showSnackbarWithClose(
                        error?.response ? error.response.data?.message : error.message,
                        {
                            variant: 'error',
                        }
                    );
                }
            });
    };
    return (
        <>
            {data && (
                <DialogUpdateAuthenRoleClient
                    open={openDialogUpdate}
                    handleClose={() => {
                        setOpenDialogUpdate(false);
                    }}
                    item={data}
                    handleReload={reloadData}
                />
            )}
            <TableRow
                sx={{
                    '&:last-child td, &:last-child th': { border: 0 },
                    '&:not(:last-child)': { marginBottom: '10px' },
                }}
            >
                <TableCell>{data?.Name}</TableCell>
                <TableCell>{data?.CardNumber}</TableCell>
                <TableCell>{data?.ParkingId?.Name}</TableCell>
                <TableCell>
                    <ActionTable
                        onDelete={handleDelete}
                        size={'small'}
                        onEdit={() => {
                            setOpenDialogUpdate(true);
                        }}
                    ></ActionTable>
                </TableCell>
            </TableRow>
        </>
    );
}
