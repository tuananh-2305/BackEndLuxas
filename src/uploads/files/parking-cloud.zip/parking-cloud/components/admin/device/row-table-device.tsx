import {
    Avatar,
    Button,
    Fade,
    MenuItem,
    Stack,
    TableCell,
    TableRow,
    Tooltip,
    Typography,
    useTheme,
} from '@mui/material';
import { useRouter } from 'next/router';
import { ParkingModel } from '@/models/parking.model';
import DeleteOutlinedIcon from '@mui/icons-material/DeleteOutlined';
import BorderColorOutlinedIcon from '@mui/icons-material/BorderColorOutlined';
import { DeviceImeiModel, DeviceModel } from '@/models/index';
import CustomizedMenus from '@/components/common/menu/menu';

const BACKEND_DOMAIN = process.env.NEXT_PUBLIC_SERVER_PARKING_DOMAIN;

export interface IRowTableDeviceProps {
    data: DeviceModel;
    setOpen: any;
    setDataUpdate: any;
}

export default function RowTableDevice(props: IRowTableDeviceProps) {
    const { data, setOpen, setDataUpdate } = props;
    return (
        <TableRow
            sx={{
                '&:last-child td, &:last-child th': { border: 0 },
                '&:not(:last-child)': { marginBottom: '10px' },
            }}
        >
            <TableCell scope="row">{data.Name}</TableCell>
            <TableCell>{data.ParkingId?.Name}</TableCell>
            <TableCell>{data.Name}</TableCell>
            <TableCell>{data.IpAddress}</TableCell>
            <TableCell>{data.Port}</TableCell>
            <TableCell></TableCell>
            <TableCell>
                <CustomizedMenus>
                    <MenuItem sx={{ color: 'black' }}>Thêm thành viên</MenuItem>
                    <MenuItem sx={{ color: 'black' }}>Thêm thành viên</MenuItem>
                </CustomizedMenus>
            </TableCell>
        </TableRow>
    );
}
