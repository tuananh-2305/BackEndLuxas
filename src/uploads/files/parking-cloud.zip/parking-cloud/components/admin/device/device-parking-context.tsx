import { createContext } from 'react';

const DeviceParkingContext = createContext({});
const DeviceParkingProvider = ({ children }: any) => {
    const context = {};
    return (
        <DeviceParkingContext.Provider value={context}>{children}</DeviceParkingContext.Provider>
    );
};
export { DeviceParkingContext, DeviceParkingProvider };
