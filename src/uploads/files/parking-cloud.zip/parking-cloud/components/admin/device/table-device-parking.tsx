import {
    Pagination,
    PaginationItem,
    Paper,
    Stack,
    Table,
    TableBody,
    TableContainer,
    TableFooter,
    TableRow,
    useTheme,
} from '@mui/material';
import React, { useEffect, useRef, useState } from 'react';
import HeaderTableCustomer from '../customer-parking/table/header-table-customer';
import { ParkingModel } from '@/models/parking.model';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import ArrowForwardIcon from '@mui/icons-material/ArrowForward';
import { headerData, headerImei } from '@/mocks/header-mock';
import { DeviceImeiModel, DeviceModel } from '@/models/index';
import HeaderTable from '@/components/table/header-table';
import RowTableImei from './row-table-device';
import RowTableDevice from './row-table-device';

export interface ITableDeviceParkingProps {
    setPage: any;
    data: DeviceModel[];
}

export default function TableDeviceParking(props: ITableDeviceParkingProps) {
    const { setPage, data } = props;
    const theme = useTheme();

    return (
        <TableContainer
            sx={{
                flex: 1,
                display: 'flex',
                flexDirection: 'column',
                justifyContent: 'space-between',
                alignItems: 'center',
                p: 2,
            }}
        >
            <Table
                sx={{
                    borderCollapse: 'separate',
                    borderSpacing: '0 10px',
                    marginTop: '-10px',
                }}
            >
                <HeaderTable headerData={headerImei} />
                <TableBody
                    sx={{
                        '& td': {
                            background: 'rgba(217, 217, 217, 0.2)',
                        },
                        'td:first-of-type': {
                            borderTopLeftRadius: '10px',
                            borderBottomLeftRadius: '10px',
                        },
                        'td:last-of-type': {
                            borderTopRightRadius: '10px',
                            borderBottomRightRadius: '10px',
                        },
                    }}
                >
                    {data?.map((c: DeviceModel) => (
                        <RowTableDevice
                            key={`card-type-${c?.ID}`}
                            data={c}
                            setOpen={undefined}
                            setDataUpdate={undefined}
                        />
                    ))}
                </TableBody>
            </Table>
            <Pagination
                count={6}
                onChange={(event, value) => setPage(value.toString())}
                renderItem={(item) => (
                    <PaginationItem
                        components={{ previous: ArrowBackIcon, next: ArrowForwardIcon }}
                        {...item}
                        shape="rounded"
                        sx={{
                            borderRadius: '4px',
                            border: '1px solid #DFE3E8',
                            '&.Mui-selected': {
                                background: '#fff',
                                border: '1px solid #067DC0',
                                color: '#067DC0',
                            },

                            color: theme.palette.text.primary,
                        }}
                    />
                )}
                sx={{
                    py: 2,
                }}
            />
        </TableContainer>
    );
}
