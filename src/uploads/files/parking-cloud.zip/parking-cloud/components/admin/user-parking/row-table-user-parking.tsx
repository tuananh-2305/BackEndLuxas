import { memberApi } from '@/api/member-api';
import { systemRoleDetailRoleApi } from '@/api/system-role-detail-cloud';
import { userParkingApi } from '@/api/user-parking-api';
import { AvatarCustom } from '@/components/common';
import ActionTable from '@/components/common/action-table/action-table';
import { useAppSelector } from '@/hooks/index';
import { showSnackbarWithClose } from '@/hooks/useSnackbarWithClose';
import { UserParkingModel } from '@/models/index';
import { MenuItem, Stack, TableCell, TableRow, Typography } from '@mui/material';
import { enqueueSnackbar } from 'notistack';

const BACKEND_DOMAIN = process.env.NEXT_PUBLIC_SERVER_PARKING_DOMAIN;

export interface IRowTableUserParkingProps {
    data: UserParkingModel;
    setDataUpdate: (data: UserParkingModel) => void;
    reloadData: () => void;
    idParking: string;
}

export default function RowTableUserParking(props: IRowTableUserParkingProps) {
    const { data, setDataUpdate, idParking } = props;

    const handleDelete = () => {
        const userId = data.UserId.ID;

        if (userId && idParking) {
            userParkingApi
                .deleteUserParking(data.ID)
                .then(async (res) => {
                    await systemRoleDetailRoleApi.delete(userId, idParking);

                    if (res.data) {
                        props.reloadData();
                        showSnackbarWithClose('Xóa thành công', { variant: 'success' });
                    }
                })
                .catch((error) => {
                    if (Array.isArray(error?.response?.data?.message)) {
                        error?.response?.data?.message.forEach((item: any) => {
                            showSnackbarWithClose(item, {
                                variant: 'error',
                            });
                        });
                    } else {
                        showSnackbarWithClose(
                            error?.response ? error.response.data?.message : error.message,
                            {
                                variant: 'error',
                            }
                        );
                    }
                });
        }
    };
    // const idUser = useAppSelector((state) => state.common.profile?.ID);
    const profile = useAppSelector((state) => state.common.profile);

    return (
        <TableRow
            sx={{
                '&:last-child td, &:last-child th': { border: 0 },
                '&:not(:last-child)': { marginBottom: '10px' },
            }}
        >
            <TableCell scope="row" sx={{ width: '25%' }}>
                <Stack direction={'row'} spacing={1}>
                    <AvatarCustom
                        src={data?.UserId?.Avatar ? BACKEND_DOMAIN + data.UserId.Avatar : ''}
                        type="circle"
                        size={40}
                        alt={data?.UserId?.Name}
                    />
                    <Stack justifyContent={'space-between'}>
                        <Typography variant="body2">{data.UserId.Name}</Typography>
                        <Typography variant="caption">{data.UserId.Phone}</Typography>
                    </Stack>
                </Stack>
            </TableCell>
            <TableCell sx={{ width: '20%', fontWeight: 600 }}>{data.GroupRoleId?.Name}</TableCell>
            <TableCell sx={{ width: '20%', fontWeight: 600 }}>{data.GroupRoleId?.Key}</TableCell>
            <TableCell sx={{ color: data.UserId.IsActive ? '#5EB14A' : '#E94F4F', width: '20%' }}>
                {data?.UserId?.IsActive ? 'Đã kích hoạt' : 'Chưa kích hoạt'}
            </TableCell>
            <TableCell>
                {profile?.ID !== data.UserId.ID && !profile?.IsSupperAdmin ? (
                    <ActionTable
                        onDelete={handleDelete}
                        size={'small'}
                        onEdit={() => setDataUpdate(data)}
                        onSync={data.IsUpdate || data.IsInsert ? () => {} : undefined}
                    >
                        {/* <MenuItem disableRipple>Demo</MenuItem> */}
                    </ActionTable>
                ) : (
                    <></>
                )}
            </TableCell>
        </TableRow>
    );
}
