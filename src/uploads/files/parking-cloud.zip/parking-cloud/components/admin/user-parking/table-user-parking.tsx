import HeaderTable from '@/components/table/header-table';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import ArrowForwardIcon from '@mui/icons-material/ArrowForward';
import {
    Pagination,
    PaginationItem,
    Stack,
    Table,
    TableBody,
    TableContainer,
    useTheme,
} from '@mui/material';
import { useRouter } from 'next/router';
import { SettingEmptyComponent } from '@/components/settings/empty';
import { UserParkingModel } from '@/models/index';
import RowTableUserParking from './row-table-user-parking';
import { columnsUserParkings } from '@/mocks/index';
import { useState } from 'react';
import DialogUpdateUserRole from '@/components/dialog/dialog-update/dialog-update-user-role';
import { formatTextPagination } from '@/ultis/index';

export interface ITableUserParkingProps {
    data: UserParkingModel[];
    fetchData: () => void;
    maxPage: number;
    idParking: string;
    total: number;
    currentSize: number;
}

export default function TableUserParking(props: ITableUserParkingProps) {
    const { data, fetchData, maxPage, idParking, total, currentSize } = props;
    const theme = useTheme();
    const router = useRouter();
    const [openDialogUpdate, setOpenDialogUpdate] = useState(false);
    const [itemHandle, setItemHandle] = useState<UserParkingModel | null>(null);
    const { page } = router.query;

    return (
        <TableContainer
            sx={{
                flex: 1,
                display: 'flex',
                flexDirection: 'column',
                justifyContent: 'space-between',
                p: 2,
            }}
        >
            <Table
                sx={{
                    borderCollapse: 'separate',
                    borderSpacing: '0 10px',
                    marginTop: '-10px',
                }}
            >
                <HeaderTable headerData={columnsUserParkings} />
                {itemHandle && (
                    <DialogUpdateUserRole
                        open={openDialogUpdate}
                        handleClose={() => {
                            setOpenDialogUpdate(false);
                        }}
                        idParking={idParking}
                        handleReload={fetchData}
                        item={itemHandle}
                    />
                )}
                <TableBody
                    sx={{
                        '& td': {
                            background: 'rgba(217, 217, 217, 0.2)',
                        },
                        'td:first-of-type': {
                            borderTopLeftRadius: '10px',
                            borderBottomLeftRadius: '10px',
                        },
                        'td:last-of-type': {
                            borderTopRightRadius: '10px',
                            borderBottomRightRadius: '10px',
                        },
                    }}
                >
                    {data?.map((c: UserParkingModel, index) => (
                        <RowTableUserParking
                            idParking={idParking}
                            data={c}
                            setDataUpdate={(data) => {
                                setItemHandle(data);
                                setOpenDialogUpdate(true);
                            }}
                            key={index}
                            reloadData={fetchData}
                        />
                    ))}
                </TableBody>
            </Table>
            {(!data || data?.length === 0) && <SettingEmptyComponent />}
            <Stack position={'relative'} alignItems={'center'}>
                <Pagination
                    count={maxPage}
                    page={
                        page?.toString() && page?.toString() !== 'undefined'
                            ? parseInt(page?.toString())
                            : 1
                    }
                    onChange={(event, page) => {
                        router.push({
                            pathname: `/admin/customer-parking/${idParking}`,
                            query: { page: page },
                        });
                    }}
                    renderItem={(item) => (
                        <PaginationItem
                            components={{ previous: ArrowBackIcon, next: ArrowForwardIcon }}
                            {...item}
                            shape="rounded"
                            sx={{
                                borderRadius: '4px',
                                border: '1px solid #DFE3E8',
                                '&.Mui-selected': {
                                    background: '#fff',
                                    border: '1px solid #067DC0',
                                    color: '#067DC0',
                                },

                                color: theme.palette.text.primary,
                            }}
                        />
                    )}
                    sx={{
                        py: 2,
                    }}
                />
                <Stack
                    position={'absolute'}
                    sx={{
                        right: '60px',
                        top: '0',
                        bottom: '0',
                    }}
                    alignItems={'center'}
                    justifyContent={'center'}
                >
                    {formatTextPagination(currentSize, data?.length, total)}
                </Stack>
            </Stack>
        </TableContainer>
    );
}
