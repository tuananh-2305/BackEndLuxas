import * as React from 'react';

export interface IAppProps {}

export function App(props: IAppProps) {
    return <div>kakak</div>;
}
