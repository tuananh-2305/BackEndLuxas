import PersonPinIcon from '@mui/icons-material/PersonPin';
import SearchIcon from '@mui/icons-material/Search';
import HistoryIcon from '@mui/icons-material/History';
import DirectionsCarFilledIcon from '@mui/icons-material/DirectionsCarFilled';
import LinkIcon from '@mui/icons-material/Link';
import StayCurrentPortraitIcon from '@mui/icons-material/StayCurrentPortrait';
import PaymentIcon from '@mui/icons-material/Payment';
import { OverridableComponent } from '@mui/material/OverridableComponent';
import { SvgIconTypeMap } from '@mui/material';
import BarChartIcon from '@mui/icons-material/BarChart';
export interface ItemNavRight {
    // icon: OverridableComponent<SvgIconTypeMap>;
    icon: any;
    title: string;
    path?: string;
    key: string;
}
//setting_icon.svg
export const navigationMock: ItemNavRight[] = [
    {
        key: 'dashboard',
        icon: '/icons/setting_icon_active.svg',
        title: 'Bảng Điều Khiển',
        path: '/dashboard',
    },
    {
        key: 'search',
        icon: '/icons/search_icon.svg',
        title: 'Tìm Kiếm Nhanh',
        path: '/dashboard/search',
    },
    {
        key: 'history',
        icon: '/icons/history_icon.svg',
        title: 'Lịch Sử Ra Vào',
        path: '/dashboard/history',
    },
    {
        key: 'barie',
        icon: '/icons/history_icon.svg',
        title: 'Lịch sử mở barie',
        path: '/dashboard/barie',
    },
    {
        key: 'paymemt',
        icon: '/icons/order_history_icon.svg',
        title: 'Lịch Sử Giao Dịch',
        path: '/dashboard/paymemt-transaction',
    },
    { key: 'report', icon: '/icons/report_icon.svg', title: 'Báo cáo', path: '/dashboard/report' },

    // {
    //     key: 'vehicle',
    //     icon: '/icons/car_2_icon.svg',
    //     title: 'Thông báo mất xe',
    //     path: '/dashboard/loss-vehicle',
    // },
    // {
    //     key: 'loss-report',
    //     icon: '/icons/card_icon.svg',
    //     title: 'Thông báo mất thẻ',
    //     path: '/dashboard/loss-report',
    // },
    { key: 'phone', icon: '/icons/phone_icon.svg', title: 'Xem live (Chỉ di động)' },

    // { icon: PersonPinIcon, title: 'Bảng Điều Khiển', path: '/dashboard' },
    // { icon: SearchIcon, title: 'Tìm Kiếm Nhanh', path: '/dashboard/search' },
    // { icon: HistoryIcon, title: 'Lịch Sử Ra Vào', path: '/dashboard/history' },
    // { icon: PaymentIcon, title: 'Lịch sử thanh toán', path: '/dashboard/paymemt-transaction' },
    // { icon: BarChartIcon, title: 'Báo cáo', path: '/dashboard/report' },

    // // { icon: DirectionsCarFilledIcon, title: 'Xe trong bãi' },
    // { icon: LinkIcon, title: 'Thông báo mất xe', path: '/dashboard/loss-vehicle' },
    // { icon: LinkIcon, title: 'Thông báo mất thẻ', path: '/dashboard/loss-report' },
    // { icon: StayCurrentPortraitIcon, title: 'Xem live (Chỉ di động)' },
];
