import * as React from 'react';
import styles from '../../dashboard.module.css';
import MoreVertIcon from '@mui/icons-material/MoreVert';
import { Card, CardContent, CardHeader, IconButton, Typography } from '@mui/material';
import { useMemo } from 'react';
import { convertToDataChart } from '@/ultis/index';
import { ContextDashboard } from '@/components/dashboard';
import dynamic from 'next/dynamic';

const ReactApexChart = dynamic(() => import('react-apexcharts'), { ssr: false });
export interface IIncidentsProps {}

export default function Incidents(props: IIncidentsProps) {
    const { dashboard } = React.useContext(ContextDashboard);

    const dataChartType = useMemo(() => {
        return convertToDataChart(dashboard.ReportVehicleType, 'Xe khác');
    }, [dashboard.ReportVehicleType]);

    return (
        <Card className={styles.card}>
            <CardHeader
                title={<Typography className={styles.card_title}>Sự cố diễn ra</Typography>}
                action={
                    <IconButton aria-label="settings">
                        <MoreVertIcon />
                    </IconButton>
                }
            />
            <CardContent className={styles.card_content}>
                <ReactApexChart
                    options={{
                        dataLabels: {
                            enabled: false,
                        },

                        chart: { toolbar: { show: false }, stacked: false, type: 'area' },
                        // labels: ['Thứ 2', 'Thứ 3', 'Thứ 4', 'Thứ 5', 'Thứ 6', 'Thứ 7', 'Chủ nhật'],
                        legend: {
                            show: true,
                            showForSingleSeries: true,
                            position: 'bottom',
                            horizontalAlign: 'center',
                            fontSize: '14px',
                            fontWeight: 500,
                            markers: {
                                width: 12,
                                height: 12,
                                radius: 12,
                            },
                        },
                        yaxis: {
                            show: true,
                            showAlways: true,
                            axisBorder: {
                                show: true,
                                color: '#D0D0D0',
                                offsetX: 0,
                                offsetY: 0,
                            },
                        },
                        xaxis: {
                            categories: [
                                'Thứ 2',
                                'Thứ 3',
                                'Thứ 4',
                                'Thứ 5',
                                'Thứ 6',
                                'Thứ 7',
                                'Chủ nhật',
                            ],
                        },
                        grid: {
                            show: true,
                            borderColor: '#f2f2f2',
                        },
                    }}
                    type="area"
                    series={[
                        {
                            data: [12, 13, 12, 11, 14, 16, 18],
                            color: '#FFE26B',
                            name: 'Barrie',
                        },
                        {
                            data: [10, 11, 11, 12, 11, 15, 17],
                            color: '#FFBB63',
                            name: 'Camera',
                        },
                        {
                            data: [4, 6, 5, 6, 7, 11, 13],
                            color: '#FF4C40',
                            name: 'Cảm biến',
                        },
                    ]}
                    width={'100%'}
                    height={'100%'}
                />
            </CardContent>
        </Card>
    );
}
