import * as React from 'react';
import styles from '../../dashboard.module.css';
import MoreVertIcon from '@mui/icons-material/MoreVert';
import { Card, CardContent, CardHeader, IconButton, Typography } from '@mui/material';
import dynamic from 'next/dynamic';
const ReactApexChart = dynamic(() => import('react-apexcharts'), { ssr: false });
export interface IComplaintIssuesGraphProps {}

export default function ComplaintIssuesGraph(props: IComplaintIssuesGraphProps) {
    return (
        <Card className={styles.card}>
            <CardHeader
                action={
                    <IconButton aria-label="settings">
                        <MoreVertIcon />
                    </IconButton>
                }
                title={<Typography className={styles.card_title}>Vấn đề khiếu nại</Typography>}
            />
            <CardContent className={styles.card_content}>
                <ReactApexChart
                    options={{
                        legend: {
                            show: true,
                            showForSingleSeries: true,
                            position: 'bottom',
                            horizontalAlign: 'center',
                            fontSize: '14px',
                            fontWeight: 500,
                            markers: {
                                width: 12,
                                height: 12,
                                radius: 12,
                            },
                        },
                        chart: {
                            type: 'area',
                            toolbar: {
                                show: false, // Ẩn thanh công cụ biểu đồ
                            },
                        },

                        stroke: {
                            curve: 'smooth',
                        },
                        dataLabels: {
                            enabled: false,
                        },
                        xaxis: {
                            categories: [
                                'T1',
                                'T2',
                                'T3',
                                'T4',
                                'T5',
                                'T6',
                                'T7',
                                'T8',
                                'T9',
                                'T10',
                                'T11',
                                'T12',
                            ],
                        },
                        yaxis: {
                            show: true,
                            showAlways: true,
                            axisBorder: {
                                show: true,
                                color: '#D0D0D0',
                                offsetX: 0,
                                offsetY: 0,
                            },
                        },
                        grid: {
                            show: true,
                            borderColor: '#f2f2f2',
                        },
                    }}
                    series={[
                        {
                            name: 'Vấn đề khiếu nại',
                            data: [10, 13, 12, 13, 14, 15, 11, 15, 14, 13, 13, 11],
                            color: '#FFC700',
                        },
                    ]}
                    height={'100%'}
                />
            </CardContent>
        </Card>
    );
}
