import { ContextDashboard } from '@/components/dashboard';
import { Card, CardContent, CardHeader, Stack, Typography } from '@mui/material';
import * as React from 'react';
import styles from '../../dashboard.module.css';
import { LineChartComponent } from '../../item';
import dynamic from 'next/dynamic';
import SelectOption from './select';

const ReactApexChart = dynamic(() => import('react-apexcharts'), { ssr: false });
export interface ITimeBasedVehicleFlowChartProps {}

export default function TimeBasedVehicleFlowChart(props: ITimeBasedVehicleFlowChartProps) {
    const { dashboard } = React.useContext(ContextDashboard);

    return (
        <Card className={styles.card}>
            <CardHeader
                title={
                    <Typography className={styles.card_title}>Biểu đồ theo thời gian</Typography>
                }
                action={
                    <Stack direction="row" sx={{ gap: '20px' }} alignItems="center">
                        <Stack direction="row" sx={{ gap: '15px' }} alignItems="center">
                            <Stack
                                sx={{
                                    height: '5px',
                                    backgroundColor: '#1B4DFF',
                                    borderRadius: '5px',
                                    width: '50px',
                                }}
                            />
                            <Typography sx={{ fontSize: '12px', color: '#55595D' }}>
                                Xe vào
                            </Typography>
                        </Stack>
                        <Stack direction="row" sx={{ gap: '15px' }} alignItems="center">
                            <Stack
                                sx={{
                                    height: '5px',
                                    backgroundColor: '#0AC4FF',
                                    borderRadius: '5px',
                                    width: '50px',
                                }}
                            />
                            <Typography sx={{ fontSize: '12px', color: '#55595D' }}>
                                Xe ra
                            </Typography>
                        </Stack>
                        <SelectOption />
                    </Stack>
                }
            />
            <CardContent sx={{ minHeight: '290px' }}>
                <LineChartComponent
                    data1={
                        dashboard.ReportVehicleInParkingByHour?.dataCarInParkingByHour?.map(
                            (item: any) => item.Total
                        ) || []
                    }
                    data2={
                        dashboard.ReportVehicleInParkingByHour?.dataCarOutParkingByHour?.map(
                            (item: any) => item.Total
                        ) || []
                    }
                />
            </CardContent>
        </Card>
    );
}
