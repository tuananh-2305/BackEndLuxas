import { ListItemText, MenuItem, Popover, Stack, Typography } from '@mui/material';
import * as React from 'react';
import KeyboardArrowDownIcon from '@mui/icons-material/KeyboardArrowDown';
import { useState } from 'react';
import ImageNextjs from '@/components/common/image';

export interface ISelectOptionProps {}

export default function SelectOption(props: ISelectOptionProps) {
    const [anchorEl3, setAnchorEl3] = React.useState<HTMLButtonElement | null>(null);
    const open = Boolean(anchorEl3);
    const [option, setOption] = useState<'ALL' | 'AUTO' | 'HANDMADE'>('ALL');
    const id = open ? 'simple-popover' : undefined;
    return (
        <>
            <Stack
                aria-describedby={id}
                onClick={(event: any) => setAnchorEl3(event.currentTarget)}
                sx={{
                    height: '40px',
                    padding: { md: '0 10px', lg: '0 20px' },
                    background: '#FFFFFF',
                    alignItems: 'center',
                    justifyContent: 'center',
                    borderRadius: '6px',
                    cursor: 'pointer',
                    border: anchorEl3 == null ? '1px solid #F2F2F2' : '1px solid #007DC0',
                    transition: 'all 0.35s ease-in-out',
                }}
                direction={'row'}
            >
                <Typography
                    sx={{
                        fontSize: '14px',
                        fontWeight: 400,
                        minWidth: '80px',
                    }}
                >
                    {option == 'ALL' ? 'Tất cả' : option == 'AUTO' ? 'Tự động' : 'Thủ công'}
                </Typography>
                <KeyboardArrowDownIcon
                    sx={{
                        width: '24px',
                        height: '24px',
                        transform: anchorEl3 == null ? 'rotate(0deg)' : 'rotate(-180deg)',
                        transition: 'all 0.35s ease-in-out',
                    }}
                />
            </Stack>
            <Popover
                id={id}
                open={open}
                anchorEl={anchorEl3}
                onClose={() => setAnchorEl3(null)}
                anchorOrigin={{
                    vertical: 'bottom',
                    horizontal: 'left',
                }}
                sx={{ mt: '10px' }}
            >
                {renderOption('Tất cả', 'ALL')}
                {renderOption('Tự động', 'AUTO')}
                {renderOption('Thủ công', 'HANDMADE')}
            </Popover>
        </>
    );

    function renderOption(lable: string, value: 'ALL' | 'AUTO' | 'HANDMADE') {
        return (
            <MenuItem
                onClick={() => {
                    setOption(value), setAnchorEl3(null);
                }}
                selected={option == value}
                sx={{
                    '&.Mui-selected': {
                        backgroundColor: '#007DC0',
                        '&:hover': {
                            backgroundColor: '#007DC0',
                        },
                        color: '#fff',
                        transition: 'all .25s',
                    },
                    margin: '8px',
                    borderRadius: '6px',
                    minWidth: { md: '124px', lg: '174px' },
                    textTransform: 'capitalize',
                }}
            >
                <ListItemText>{lable}</ListItemText>
                {option == value && (
                    <ImageNextjs
                        path={'icons/check_icon.svg'}
                        sx={{
                            pt: '2px',
                        }}
                    />
                )}
            </MenuItem>
        );
    }
}
