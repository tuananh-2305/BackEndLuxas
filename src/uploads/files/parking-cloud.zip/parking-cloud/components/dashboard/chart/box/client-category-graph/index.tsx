import * as React from 'react';
import styles from '../../dashboard.module.css';
import MoreVertIcon from '@mui/icons-material/MoreVert';
import { Card, CardContent, CardHeader, IconButton, Typography } from '@mui/material';
import { useMemo } from 'react';
import { convertToDataChart } from '@/ultis/index';
import { ContextDashboard } from '@/components/dashboard';
import { ColumnChartComponent } from '../../item';
export interface IClientCategoryGraphProps {}

export default function ClientCategoryGraph(props: IClientCategoryGraphProps) {
    const { dashboard } = React.useContext(ContextDashboard);

    const dataChartTypeMember = useMemo(() => {
        return convertToDataChart(dashboard.ReportMemberInParking, 'Khác');
    }, [dashboard.ReportMemberInParking]);

    return (
        <Card className={styles.card}>
            <CardHeader
                title={<Typography className={styles.card_title}>Phân loại khách hàng</Typography>}
            />
            <CardContent sx={{ minHeight: '290px' }}>
                <ColumnChartComponent
                    colors={['#0E9FB5', '#6069CB', '#78C6E7', '#55595D']}
                    // data={[39, 25, 19, 30]}
                    data={dataChartTypeMember.map((item) => item.Total)}
                    labels={dataChartTypeMember.map((item) => item.Name)}
                    // title="Xe trong bãi"
                    width="100%"
                />
            </CardContent>
        </Card>
    );
}
