import * as React from 'react';
import styles from '../../dashboard.module.css';
import MoreVertIcon from '@mui/icons-material/MoreVert';
import { Card, CardContent, CardHeader, IconButton, Stack, Typography } from '@mui/material';
const ReactApexChart = dynamic(() => import('react-apexcharts'), { ssr: false });
import dynamic from 'next/dynamic';
import ImageNextjs from '@/components/common/image';
export interface IRatingsProps {}

export default function Ratings(props: IRatingsProps) {
    const gradientColors = ['#007DC050', '#007DC0'];

    return (
        <Card className={styles.card}>
            <CardHeader
                action={
                    <IconButton aria-label="settings">
                        <MoreVertIcon />
                    </IconButton>
                }
                title={
                    <Typography className={styles.card_title}>Đánh giá của khách hàng</Typography>
                }
            />
            <CardContent className={styles.card_content}>
                <Stack
                    sx={{
                        position: 'relative',
                        height: '100%',
                    }}
                >
                    <ReactApexChart
                        options={{
                            chart: {
                                type: 'radialBar',
                                offsetY: 0,
                                sparkline: {
                                    enabled: true,
                                },
                                parentHeightOffset: 0,
                            },
                            fill: {
                                type: 'gradient',
                                gradient: {
                                    shade: 'dark',
                                    type: 'horizontal',
                                    shadeIntensity: 0.5,
                                    gradientToColors: gradientColors,
                                    inverseColors: true,
                                    opacityFrom: 1,
                                    opacityTo: 1,
                                    stops: [0, 50, 100],
                                },
                            },

                            plotOptions: {
                                radialBar: {
                                    hollow: {
                                        margin: 0,
                                        size: '65%',
                                        background: 'transparent',
                                        image: 'images/face_png.png',
                                        imageWidth: 60,
                                        imageHeight: 60,
                                        imageClipped: false,
                                        imageOffsetY: -10,
                                    },
                                    dataLabels: {
                                        show: false,
                                    },
                                    startAngle: -110,
                                    endAngle: 110,
                                    track: {
                                        background: '#78C6E7', // Đổi màu cho phần không biểu thị (màu phần nằm ngoài)
                                    },
                                },
                            },

                            grid: {
                                show: false,
                            },
                            stroke: {
                                lineCap: 'round',
                            },
                        }}
                        series={[95]}
                        type="radialBar"
                    />
                    <Stack sx={{ width: '100%', alignItems: 'center', mt: '-6px', zIndex: 2 }}>
                        <Stack
                            sx={{
                                // position: 'absolute',
                                width: '80%',
                                height: { xs: '70px', lg: '100px' },
                                background: '#007DC0',
                                bottom: '-12px',
                                left: 'calc(50% - 40%)',
                                borderRadius: '20px',
                                justifyContent: 'space-between',
                                alignItems: 'start',
                                padding: '10px',
                                color: '#fff',
                            }}
                            direction={'row'}
                        >
                            <Typography
                                sx={{
                                    fontSize: '14px',
                                    height: '100%',
                                    fontWeight: 500,
                                }}
                            >
                                0%
                            </Typography>
                            <Stack
                                sx={{
                                    alignItems: 'center',
                                    justifyContent: 'end',
                                    height: '100%',
                                }}
                            >
                                <Typography
                                    sx={{
                                        fontSize: { md: '22px', lg: '32px' },
                                        fontWeight: 700,
                                    }}
                                >
                                    95%
                                </Typography>
                                <Typography
                                    sx={{
                                        fontSize: { md: '12px', lg: '14px' },
                                        fontWeight: 500,
                                    }}
                                >
                                    Đánh giá từ 4 sao trở lên
                                </Typography>
                            </Stack>
                            <Typography
                                sx={{
                                    fontSize: '14px',
                                    fontWeight: 500,
                                }}
                            >
                                100%
                            </Typography>
                        </Stack>
                    </Stack>
                </Stack>
            </CardContent>
        </Card>
    );
}
