import {
    calculatePercent,
    checkRoleDashboard,
    convertToDataChart,
    countOnline,
} from '@/ultis/index';
import { Box, Card, Divider, Stack, Typography } from '@mui/material';
import Image from 'next/image';
import { useContext, useEffect, useMemo, useRef, useState } from 'react';
import Revenue from '../child/revenue';
import { ContextDashboard } from '../dashboard-context';
import {
    AreaChartCompnent,
    ColumnChartComponent,
    DonutChartComponent,
    LineChartComponent,
} from './item';
import { useAppSelector } from '@/hooks/useReudx';
import { ContextLayoutDashboard } from '@/components/common';
import Grid from '@mui/material/Grid'; // Grid version 1
import ClientCategoryGraph from './box/client-category-graph';
import ComplaintIssuesGraph from './box/complaint-issues-graph';
import DeviceProblemChart from './box/device-problem-chart';
import Efficiency from './box/efficiency';
import Incidents from './box/incidents';
import Ratings from './box/ratings';
import RevenueInsightsPanel from './box/revenue-insights-panel';
import Statistics from './box/statistics';
import TimeBasedVehicleFlowChart from './box/time-based-vehicle-flow-chart';
import VehicleOccupancyChart from './box/vehicle-occupancy-chart';

interface DashboardChartComponentProps {
    top: number;
}
export const DashboardChartComponent = (props: DashboardChartComponentProps) => {
    const { top } = props;

    const [maxHeight, setMaxHeight] = useState(0);
    const { setOpenDashboardBar, openDashboardBar, setOpenRightBar } =
        useContext(ContextLayoutDashboard);
    const { dashboard, dashboardToday, device, role } = useContext(ContextDashboard);

    const ref = useRef<HTMLDivElement | null>(null);
    const parkings = useAppSelector((state) => state.parking.parkings);
    useEffect(() => {
        if (dashboard) {
            const head = document.querySelector('#dashboard-data');
            if (head) {
                setMaxHeight(head.clientHeight);
            }
        }
    }, [dashboard, parkings]);
    // const dataChartType = convertToDataChart(dashboard.ReportVehicleType, 'Xe khác');
    // const dataChartTypeMember = convertToDataChart(dashboard.ReportMemberInParking, 'Khác');
    const dataChartType = useMemo(() => {
        return convertToDataChart(dashboard.ReportVehicleType, 'Xe khác');
    }, [dashboard.ReportVehicleType]);

    const dataChartTypeMember = useMemo(() => {
        return convertToDataChart(dashboard.ReportMemberInParking, 'Khác');
    }, [dashboard.ReportMemberInParking]);
    const countOnlineNumber = countOnline(device);
    const deviceErr = device.length - countOnlineNumber;
    const dashboardChose = useAppSelector((state) => state.parking.chooseDashboard);
    const profile = useAppSelector((state) => state.common.profile);
    // console.log('test', maxHeight ? `${maxHeight - top}px` : '100%');
    const capacity = useMemo(() => {
        if (!dashboardChose) return 0;
        return (
            dashboardChose.Capacity -
            (dashboardToday.DataCarInParking +
                (dashboardToday.DataCarIn - dashboardToday.DataCarOut))
        );
    }, [dashboardToday, dashboardChose]);
    useEffect(() => {}, [openDashboardBar]);

    const check = () => {
        const target = dashboardChose?.ExpectedRevenue ? dashboardChose?.ExpectedRevenue : 0;
        const today = dashboard.ExpectedRevenueToday;

        if (target > today) {
            return [today, target - today];
        } else {
            return [1, 0];
        }
    };

    const isAdmin = Boolean(profile?.IsSupperAdmin) || Boolean(profile?.IsAdmin);

    return (
        <Stack
            sx={{
                flex: 1,
                maxHeight: `${maxHeight}px`,
                overflowX: 'hidden',
                overflowY: 'auto',
                padding: '10px 20px',
                maxWidth: '100%',
            }}
        >
            <Grid container rowSpacing={3} columnSpacing={{ xs: 3 }}>
                {/* action v*/}
                {checkRoleDashboard('DIALY_ACTION', isAdmin, role) ? (
                    <Grid item xs={12} md={12} lg={12} xl={6}>
                        <Statistics />
                    </Grid>
                ) : (
                    <></>
                )}
                {checkRoleDashboard('GLOBAL_NOTIFY', isAdmin, role) ? (
                    <Grid item xs={12} md={6} lg={6} xl={3}>
                        <DeviceProblemChart />
                    </Grid>
                ) : (
                    <></>
                )}
                {/* thong bao */}
                {/* khieu nai */}
                {checkRoleDashboard('EXHAUSTION_MATTERS', isAdmin, role) ? (
                    <Grid item xs={12} md={6} lg={6} xl={3}>
                        <ComplaintIssuesGraph />
                    </Grid>
                ) : (
                    <></>
                )}
                {/* xe trong bai */}
                {checkRoleDashboard('VEHICLE_IN_PARKING', isAdmin, role) ? (
                    <Grid
                        item
                        xs={12}
                        md={6}
                        lg={6}
                        xl={4}
                        display={{ xs: 'none', md: 'none', xl: 'block' }}
                    >
                        <VehicleOccupancyChart />
                    </Grid>
                ) : (
                    <></>
                )}
                {/* phan loai khach hang */}
                {checkRoleDashboard('CLASSIFY_ CUSTOMER', isAdmin, role) ? (
                    <Grid
                        item
                        xs={12}
                        md={6}
                        lg={6}
                        xl={4}
                        display={{ xs: 'none', md: 'none', xl: 'block' }}
                    >
                        <ClientCategoryGraph />
                    </Grid>
                ) : (
                    <></>
                )}
                {/* su co */}
                {checkRoleDashboard('ERROR_TRACKING', isAdmin, role) ? (
                    <Grid
                        item
                        md={6}
                        lg={6}
                        xl={4}
                        display={{ xs: 'block', md: 'block', xl: 'none' }}
                    >
                        <Incidents />
                    </Grid>
                ) : (
                    <></>
                )}
                {/* doanh  thu */}
                {checkRoleDashboard('TOTAL_REVENUE', isAdmin, role) ? (
                    <Grid item xs={12} md={6} lg={6} xl={4}>
                        <RevenueInsightsPanel />
                    </Grid>
                ) : (
                    <></>
                )}

                {/* xe trong bai */}

                {checkRoleDashboard('VEHICLE_IN_PARKING', isAdmin, role) ? (
                    <Grid
                        item
                        xs={12}
                        md={6}
                        lg={6}
                        xl={4}
                        display={{ xs: 'block', md: 'block', xl: 'none' }}
                    >
                        <VehicleOccupancyChart />
                    </Grid>
                ) : (
                    <></>
                )}
                {/* phan loai khach hang */}

                {checkRoleDashboard('VEHICLE_IN_PARKING', isAdmin, role) ? (
                    <Grid
                        item
                        xs={12}
                        md={6}
                        lg={6}
                        xl={4}
                        display={{ xs: 'block', md: 'block', xl: 'none' }}
                    >
                        <ClientCategoryGraph />
                    </Grid>
                ) : (
                    <></>
                )}

                {/* bieu do theo thoi gian */}
                {checkRoleDashboard('CHART_OVER_TIME', isAdmin, role) ? (
                    <Grid item xs={12}>
                        <TimeBasedVehicleFlowChart />
                    </Grid>
                ) : (
                    <></>
                )}
                {/* hieu suat bai e */}
                {checkRoleDashboard('PARKING_EFFICIENCY', isAdmin, role) ? (
                    <Grid item xs={12} md={6} lg={6} xl={4}>
                        <Efficiency />
                    </Grid>
                ) : (
                    <></>
                )}
                {/* su co */}
                {checkRoleDashboard('ERROR_TRACKING', isAdmin, role) ? (
                    <Grid
                        item
                        md={6}
                        lg={6}
                        xl={4}
                        display={{ xs: 'none', md: 'none', xl: 'block' }}
                    >
                        <Incidents />
                    </Grid>
                ) : (
                    <></>
                )}
                {/* danh gia */}

                {checkRoleDashboard('CUSTOMER_REVIEWS', isAdmin, role) ? (
                    <Grid item md={6} lg={6} xl={4}>
                        <Ratings />
                    </Grid>
                ) : (
                    <></>
                )}
            </Grid>
        </Stack>
        // <Stack
        //     sx={{
        //         flex: 1,
        //         maxHeight: `${maxHeight}px`,
        //         overflowX: 'hidden',
        //         overflowY: 'auto',
        //         padding: '10px 20px',
        //         maxWidth: '100%',
        //     }}
        //     spacing={'10px'}
        // >
        //     <Stack direction={{ xs: 'column', lg: 'row' }} spacing={2}>
        //         <Stack
        //             direction="row"
        //             sx={{
        //                 backgroundColor: 'rgba(255, 184, 98, 0.15)',
        //                 flex: 1,
        //                 boxShadow: '0px 2px 2px rgba(0, 0, 0, 0.25)',
        //                 borderRadius: '10px',
        //             }}
        //             alignItems="flex-start"
        //         >
        //             <DonutChartComponent
        //                 sx={{
        //                     width: '100px',
        //                     height: '100px',
        //                 }}
        //                 chartWidth="140px"
        //                 colors={['#067DC0', '#CDD2D1']}
        //                 data={[deviceErr, device.length - deviceErr]}
        //                 text={`${deviceErr}/${device.length}`}
        //             />
        //             <Stack sx={{ padding: '10px' }}>
        //                 <Typography
        //                     sx={{
        //                         color: deviceErr > 0 ? '#E94F4F' : '#5EB14A',
        //                         fontSize: '16px',
        //                         fontWeight: 700,
        //                     }}
        //                 >
        //                     {deviceErr} thiết bị có vấn đề hoặc không kết nối
        //                 </Typography>
        //                 <Typography sx={{ fontStyle: 'italic', fontWeight: 300, color: '#55595D' }}>
        //                     Bãi xe của bạn đang hoạt động {deviceErr > 0 && 'không '}bình thường.
        //                     {deviceErr > 0 && ' Kiểm tra ngay!'}
        //                 </Typography>
        //             </Stack>
        //         </Stack>

        //         <Stack
        //             direction="row"
        //             sx={{
        //                 backgroundColor: 'rgba(255, 184, 98, 0.15)',
        //                 flex: 1,
        //                 boxShadow: '0px 2px 2px rgba(0, 0, 0, 0.25)',
        //                 borderRadius: '10px',
        //                 padding: '10px',
        //                 minHeight: '100px',
        //             }}
        //         >
        //             <Stack
        //                 sx={{ height: '100%', aspectRatio: '1/1' }}
        //                 alignItems="center"
        //                 justifyContent="center"
        //             >
        //                 <Typography sx={{ fontSize: '32px', fontWeight: 700, color: '#55595D' }}>
        //                     {dashboard?.LostVehicle ? dashboard?.LostVehicle : 0}
        //                 </Typography>
        //             </Stack>
        //             <Stack>
        //                 <Typography
        //                     sx={{
        //                         color:
        //                             dashboard?.LostVehicle && dashboard?.LostVehicle > 0
        //                                 ? '#E94F4F'
        //                                 : '#5EB14A',
        //                         fontSize: '16px',
        //                         fontWeight: 700,
        //                     }}
        //                 >
        //                     Khiếu nại mất xe cần xử lý
        //                 </Typography>
        //                 <Typography sx={{ fontStyle: 'italic', fontWeight: 300, color: '#55595D' }}>
        //                     Hãy xử lý vấn đề càng sớm càng tốt, truy xuất video và lịch sử gửi xe để
        //                     đối chiếu
        //                 </Typography>
        //             </Stack>
        //         </Stack>
        //     </Stack>
        //     {/* ------------------------------------------ */}
        //     <Stack
        //         direction="row"
        //         alignItems={'center'}
        //         sx={{
        //             backgroundColor: 'rgba(217, 217, 217, 0.2)',
        //             boxShadow: '0px 4px 4px rgba(0, 0, 0, 0.25)',
        //             borderRadius: '15px',
        //             padding: '10px',
        //         }}
        //     >
        //         <Stack sx={{ height: '200px', width: '35%' }}>
        //             <ColumnChartComponent
        //                 colors={['#067DC0', '#FFB862', '#78C6E7', '#55595D']}
        //                 // data={[39, 25, 19, 30]}
        //                 data={dataChartType.map((item) => item.Total)}
        //                 labels={dataChartType.map((item) => item.Name)}
        //                 title="Xe trong bãi"
        //                 width="100%"
        //             />
        //         </Stack>
        //         <Stack sx={{ height: '200px', width: '35%' }}>
        //             <ColumnChartComponent
        //                 colors={['#067DC0', '#FFB862', '#78C6E7', '#55595D']}
        //                 data={dataChartTypeMember.map((item) => {
        //                     return Number(Number(item.Total).toFixed(2));
        //                 })}
        //                 labels={dataChartTypeMember.map((item) => item.Name)}
        //                 title="Phân loại khách"
        //                 width="100%"
        //             />
        //         </Stack>

        //         <Divider
        //             color="#dddddd"
        //             sx={{ width: '1px', height: '80%', marginRight: '30px' }}
        //         />
        //         <Box sx={{ width: '30%' }} justifyContent="space-between" ref={ref}>
        //             <Revenue dashboard={dashboard} />
        //             <AreaChartCompnent
        //                 color="#efeffd"
        //                 height="140px"
        //                 width={
        //                     '100%'
        //                     // ref?.current
        //                     //     ? `${
        //                     //           openDashboardBar
        //                     //               ? ref.current.clientWidth
        //                     //               : ref.current.clientWidth / 3
        //                     //       }px`
        //                     //     : 'unset'
        //                 }
        //             />
        //         </Box>
        //     </Stack>
        //     {/* ------------------Biểu đồ theo thời gian------------------------ */}
        //     <Stack>
        //         <Typography sx={{ fontSize: '13px', fontWeight: 700 }}>
        //             Biểu đồ theo thời gian
        //         </Typography>

        //         <Stack
        //             sx={{
        //                 backgroundColor: 'rgba(217, 217, 217, 0.2)',
        //                 boxShadow: '0px 4px 4px rgba(0, 0, 0, 0.25)',
        //                 borderRadius: '15px',
        //                 padding: '10px 20px',
        //                 minHeight: '280px',
        //             }}
        //         >
        //             <Stack direction="row-reverse" sx={{ gap: '20px' }} alignItems="center">
        //                 <Stack direction="row" sx={{ gap: '15px' }} alignItems="center">
        //                     <Stack
        //                         sx={{
        //                             height: '5px',
        //                             backgroundColor: '#067DC0',
        //                             borderRadius: '5px',
        //                             width: '50px',
        //                         }}
        //                     />
        //                     <Typography sx={{ fontSize: '12px', color: '#55595D' }}>
        //                         Xe vào
        //                     </Typography>
        //                 </Stack>
        //                 <Stack direction="row" sx={{ gap: '15px' }} alignItems="center">
        //                     <Stack
        //                         sx={{
        //                             height: '5px',
        //                             backgroundColor: '#55595D',
        //                             borderRadius: '5px',
        //                             width: '50px',
        //                         }}
        //                     />
        //                     <Typography sx={{ fontSize: '12px', color: '#55595D' }}>
        //                         Xe ra
        //                     </Typography>
        //                 </Stack>
        //             </Stack>
        //             <LineChartComponent
        //                 data1={
        //                     dashboard.ReportVehicleInParkingByHour?.dataCarInParkingByHour?.map(
        //                         (item: any) => item.Total
        //                     ) || []
        //                 }
        //                 data2={
        //                     dashboard.ReportVehicleInParkingByHour?.dataCarOutParkingByHour?.map(
        //                         (item: any) => item.Total
        //                     ) || []
        //                 }
        //             />
        //         </Stack>
        //     </Stack>
        //     {/* ------------------------------------------ */}
        //     <Stack
        //         direction={{
        //             xs: 'column',
        //             lg: 'row',
        //         }}
        //         sx={{ borderRadius: '15px' }}
        //         spacing={2}
        //     >
        //         <Stack
        //             direction={{ xs: 'column', lg: 'row' }}
        //             sx={{
        //                 flex: 6,
        //                 backgroundColor: 'rgba(217, 217, 217, 0.2)',
        //                 boxShadow: '0px 4px 4px rgba(0, 0, 0, 0.25)',
        //                 padding: '10px 20px',
        //                 borderRadius: '15px',
        //             }}
        //             spacing={3}
        //         >
        //             <Stack
        //                 sx={{ flex: 4 }}
        //                 direction={{ xs: 'row', lg: 'column' }}
        //                 spacing={{ xs: 3, lg: 0 }}
        //             >
        //                 <Stack flex={1}>
        //                     <Typography sx={{ fontWeight: 700, fontSize: '13px' }}>
        //                         Hiệu suất bãi xe
        //                     </Typography>
        //                     <Stack direction="row">
        //                         <DonutChartComponent
        //                             sx={{
        //                                 width: '130px',
        //                                 height: '130px',
        //                             }}
        //                             chartWidth="180px"
        //                             colors={['#067DC0', '#CDD2D1']}
        //                             data={[
        //                                 dashboardToday.DataCarInParking +
        //                                     (dashboardToday.DataCarIn - dashboardToday.DataCarOut),
        //                                 capacity,
        //                             ]}
        //                             text={`${calculatePercent(
        //                                 dashboardToday.DataCarInParking +
        //                                     (dashboardToday.DataCarIn - dashboardToday.DataCarOut),
        //                                 dashboardToday.DataCarInParking +
        //                                     (dashboardToday.DataCarIn - dashboardToday.DataCarOut) +
        //                                     capacity
        //                             )}%`}
        //                         />
        //                         <Stack spacing={'10px'}>
        //                             <Stack direction="row" sx={{}} spacing={'10px'}>
        //                                 <Stack
        //                                     sx={{
        //                                         backgroundColor: '#067DC0',
        //                                         width: '10px',
        //                                         height: '10px',
        //                                         borderRadius: '5px',
        //                                     }}
        //                                 />
        //                                 <Stack spacing={'5px'}>
        //                                     <Typography sx={{ fontSize: '14px', color: '#55595D' }}>
        //                                         Xe trong bãi
        //                                     </Typography>
        //                                     <Typography sx={{ fontSize: '13px', color: '#55595D' }}>
        //                                         {dashboardToday.DataCarInParking +
        //                                             (dashboardToday.DataCarIn -
        //                                                 dashboardToday.DataCarOut)}
        //                                     </Typography>
        //                                 </Stack>
        //                             </Stack>
        //                             <Stack direction="row" sx={{}} spacing={'10px'}>
        //                                 <Stack
        //                                     sx={{
        //                                         backgroundColor: '#CDD2D1',
        //                                         width: '10px',
        //                                         height: '10px',
        //                                         borderRadius: '5px',
        //                                     }}
        //                                 />
        //                                 <Stack sx={{}} spacing={'5px'}>
        //                                     <Typography sx={{ fontSize: '14px', color: '#55595D' }}>
        //                                         Chỗ trống
        //                                     </Typography>
        //                                     <Typography sx={{ fontSize: '13px', color: '#55595D' }}>
        //                                         {capacity}
        //                                     </Typography>
        //                                 </Stack>
        //                             </Stack>
        //                         </Stack>
        //                     </Stack>
        //                 </Stack>
        //                 {/* ------------------------------------ */}
        //                 <Stack flex={1}>
        //                     <Typography sx={{ fontWeight: 700, fontSize: '13px' }}>
        //                         KPI doanh thu
        //                     </Typography>
        //                     <Stack direction="row">
        //                         <DonutChartComponent
        //                             sx={{
        //                                 width: '130px',
        //                                 height: '130px',
        //                             }}
        //                             chartWidth="180px"
        //                             colors={['#067DC0', '#CDD2D1']}
        //                             data={check()}
        //                             text={`${Math.round(
        //                                 (dashboardChose && dashboardChose.ExpectedRevenue !== 0
        //                                     ? dashboard.ExpectedRevenueToday /
        //                                       dashboardChose.ExpectedRevenue
        //                                     : dashboard.ExpectedRevenueToday / 1) * 100
        //                             )}%`}
        //                         />
        //                         <Stack spacing={'10px'}>
        //                             <Stack direction="row" sx={{}} spacing={'10px'}>
        //                                 <Stack
        //                                     sx={{
        //                                         backgroundColor: '#067DC0',
        //                                         width: '10px',
        //                                         height: '10px',
        //                                         borderRadius: '5px',
        //                                     }}
        //                                 />
        //                                 <Stack sx={{}} spacing={'5px'}>
        //                                     <Typography sx={{ fontSize: '14px', color: '#55595D' }}>
        //                                         Đã đạt
        //                                     </Typography>
        //                                     <Typography sx={{ fontSize: '13px', color: '#55595D' }}>
        //                                         {dashboard.ExpectedRevenueToday}
        //                                     </Typography>
        //                                 </Stack>
        //                             </Stack>
        //                             <Stack direction="row" sx={{}} spacing={'10px'}>
        //                                 <Stack
        //                                     sx={{
        //                                         backgroundColor: '#CDD2D1',
        //                                         width: '10px',
        //                                         height: '10px',
        //                                         borderRadius: '5px',
        //                                     }}
        //                                 />
        //                                 <Stack sx={{}} spacing={'5px'}>
        //                                     <Typography sx={{ fontSize: '14px', color: '#55595D' }}>
        //                                         Chưa đạt
        //                                     </Typography>
        //                                     <Typography sx={{ fontSize: '13px', color: '#55595D' }}>
        //                                         {dashboardChose?.ExpectedRevenue &&
        //                                         dashboardChose?.ExpectedRevenue >
        //                                             dashboard.ExpectedRevenueToday
        //                                             ? dashboardChose?.ExpectedRevenue -
        //                                               dashboard.ExpectedRevenueToday
        //                                             : 0}
        //                                     </Typography>
        //                                 </Stack>
        //                             </Stack>
        //                         </Stack>
        //                     </Stack>
        //                 </Stack>
        //             </Stack>
        //             {/* --------------------------------- */}
        //             <Stack sx={{ flex: 6 }} spacing={'15px'}>
        //                 <Typography sx={{ fontSize: '13px', fontWeight: 700 }}>
        //                     Sự cố diễn ra
        //                 </Typography>
        //                 <Stack direction="row" justifyContent="space-between">
        //                     <Typography sx={{ fontSize: '13px', color: '#55595D' }}>
        //                         11:57
        //                     </Typography>
        //                     <Typography sx={{ fontSize: '13px', color: '#55595D' }}>
        //                         Barrie không phản hồi
        //                     </Typography>
        //                     <Typography sx={{ fontSize: '13px', color: '#E94F4F' }}>Cao</Typography>
        //                 </Stack>
        //                 <Stack direction="row" justifyContent="space-between">
        //                     <Typography sx={{ fontSize: '13px', color: '#55595D' }}>
        //                         11:57
        //                     </Typography>
        //                     <Typography sx={{ fontSize: '13px', color: '#55595D' }}>
        //                         Barrie không phản hồi
        //                     </Typography>
        //                     <Typography sx={{ fontSize: '13px', color: '#E94F4F' }}>Cao</Typography>
        //                 </Stack>
        //                 <Stack direction="row" justifyContent="space-between">
        //                     <Typography sx={{ fontSize: '13px', color: '#55595D' }}>
        //                         11:57
        //                     </Typography>
        //                     <Typography sx={{ fontSize: '13px', color: '#55595D' }}>
        //                         Barrie không phản hồi
        //                     </Typography>
        //                     <Typography sx={{ fontSize: '13px', color: '#E94F4F' }}>Cao</Typography>
        //                 </Stack>
        //                 <AreaChartCompnent color="#E94F4F" width="100%" height="150px" />
        //             </Stack>
        //         </Stack>
        //         {/* -------------------------------- */}
        //         <Stack
        //             sx={{
        //                 backgroundColor: 'rgba(217, 217, 217, 0.2)',
        //                 boxShadow: '0px 4px 4px rgba(0, 0, 0, 0.25)',
        //                 padding: '30px 20px',
        //                 borderRadius: '15px',
        //             }}
        //             justifyContent="space-between"
        //         >
        //             <Typography sx={{ fontSize: '18px', fontWeight: 700 }}>
        //                 Đánh giá khách hàng
        //             </Typography>
        //             <Stack direction="row" sx={{}} spacing={'20px'}>
        //                 <Stack>
        //                     <Typography sx={{ fontSize: '48px', fontWeight: 700 }}>4.4</Typography>
        //                     <Typography
        //                         sx={{ color: '#55595D', fontSize: '13px', fontStyle: 'italic' }}
        //                     >
        //                         53 đánh giá
        //                     </Typography>
        //                 </Stack>

        //                 <Stack spacing={'20px'}>
        //                     {[20, 15, 12, 5, 1].map((v, k) => {
        //                         const max = Math.max(...[20, 15, 12, 5, 1]);
        //                         return (
        //                             <Stack
        //                                 key={`vote-item-${k}`}
        //                                 direction="row"
        //                                 alignItems="center"
        //                                 sx={{}}
        //                                 spacing={'15px'}
        //                             >
        //                                 <Stack direction="row">
        //                                     <Typography sx={{ fontSize: '14ox', color: '#55595D' }}>
        //                                         {k}
        //                                     </Typography>
        //                                     <Image
        //                                         src="/icons/orange-start.svg"
        //                                         width={20}
        //                                         height={20}
        //                                         alt="start-orange"
        //                                     />
        //                                 </Stack>

        //                                 <Stack
        //                                     sx={{
        //                                         height: '15px',
        //                                         width: `${(v / max) * 200}px`,
        //                                         backgroundColor: '#FFB862',
        //                                         boxShadow: '0px 1px 1px rgba(0, 0, 0, 0.25)',
        //                                         borderRadius: '3px',
        //                                         maxWidth: '300px',
        //                                     }}
        //                                 />

        //                                 <Typography>{v}</Typography>
        //                             </Stack>
        //                         );
        //                     })}
        //                 </Stack>
        //             </Stack>
        //         </Stack>
        //     </Stack>
        // </Stack>
    );
};
