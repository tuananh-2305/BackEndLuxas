import * as React from 'react';
import styles from '../../dashboard.module.css';
import MoreVertIcon from '@mui/icons-material/MoreVert';
import { Card, CardContent, CardHeader, IconButton, Typography } from '@mui/material';
import { useMemo } from 'react';
import { convertToDataChart } from '@/ultis/index';
import { ContextDashboard } from '@/components/dashboard';
import { ColumnChartComponent } from '../../item';
export interface IVehicleOccupancyChartProps {}

export default function VehicleOccupancyChart(props: IVehicleOccupancyChartProps) {
    const { dashboard } = React.useContext(ContextDashboard);

    const dataChartType = useMemo(() => {
        return convertToDataChart(dashboard.ReportVehicleType, 'Xe khác');
    }, [dashboard.ReportVehicleType]);

    return (
        <Card className={styles.card}>
            <CardHeader
                title={<Typography className={styles.card_title}>Xe trong bãi</Typography>}
            />
            <CardContent sx={{ minHeight: '290px' }}>
                <ColumnChartComponent
                    colors={['#067DC0', '#FFB862', '#78C6E7', '#55595D']}
                    // data={[39, 25, 19, 30]}
                    data={dataChartType.map((item) => item.Total)}
                    labels={dataChartType.map((item) => item.Name)}
                    // title="Xe trong bãi"
                    width="100%"
                />
            </CardContent>
        </Card>
    );
}
