import * as React from 'react';
import styles from '../../dashboard.module.css';
import MoreVertIcon from '@mui/icons-material/MoreVert';
import { Card, CardContent, CardHeader, IconButton, Stack, Typography } from '@mui/material';
import { countOnline } from '@/ultis/index';
import { useContext, useEffect, useMemo } from 'react';
const ReactApexChart = dynamic(() => import('react-apexcharts'), { ssr: false });
import { ContextDashboard } from '@/components/dashboard';
import dynamic from 'next/dynamic';
import { log } from 'console';
export interface IDeviceProblemChartProps {}

export default function DeviceProblemChart(props: IDeviceProblemChartProps) {
    const { device } = useContext(ContextDashboard);
    const countOnlineNumber = countOnline(device);
    const deviceErr = device?.length - countOnlineNumber;
    const gradientColors = ['#007DC050', '#007DC0'];

    const percent = useMemo(() => {
        if (device && device?.length == 0) return 0;
        return (deviceErr / device.length) * 100;
    }, [device]);

    return (
        <Card className={styles.card}>
            <CardHeader
                action={
                    <IconButton aria-label="settings">
                        <MoreVertIcon />
                    </IconButton>
                }
                title={<Typography className={styles.card_title}>Thông báo</Typography>}
            />
            <CardContent className={styles.card_content}>
                {/* <DonutChartComponent
                    sx={{
                        width: '100px',
                        height: '100px',
                    }}
                    chartWidth="140px"
                    colors={['#067DC0', '#CDD2D1']}
                    data={[deviceErr, device.length - deviceErr]}
                    text={`${deviceErr}/${device.length}`}
                /> */}

                <ReactApexChart
                    options={{
                        chart: {
                            type: 'radialBar',
                            sparkline: {
                                enabled: true,
                            },
                            parentHeightOffset: 0,
                        },
                        fill: {
                            type: 'gradient',
                            gradient: {
                                shade: 'dark',
                                type: 'horizontal',
                                shadeIntensity: 0.5,
                                gradientToColors: gradientColors,
                                inverseColors: true,
                                opacityFrom: 1,
                                opacityTo: 1,
                                stops: [0, 50, 100],
                                colorStops: [],
                            },
                        },

                        plotOptions: {
                            radialBar: {
                                hollow: {
                                    margin: 0,
                                    size: '55%',
                                    background: 'transparent',
                                },
                                dataLabels: {
                                    show: true,
                                    total: {
                                        show: true,
                                        label: `${deviceErr}/${device.length}`,
                                        color: '#55595D',
                                        fontWeight: 700,
                                        fontSize: '32px',
                                    },
                                    value: {
                                        show: false,
                                    },
                                },
                                startAngle: -100,
                                endAngle: 100,
                                track: {
                                    background: '#78C6E7', // Đổi màu cho phần không biểu thị (màu phần nằm ngoài)
                                },
                            },
                        },
                        grid: {
                            padding: {
                                top: -30,
                                left: 0,
                                right: 0,
                                bottom: 20,
                            },
                        },
                        stroke: {
                            lineCap: 'round',
                        },
                        series: [65],
                    }}
                    series={[percent]}
                    type="radialBar"
                    height={'250px'}
                />

                <Stack sx={{ alignItems: { md: 'center', lg: 'start' } }}>
                    <Typography
                        sx={{
                            color: deviceErr > 0 ? '#E42727' : '#5EB14A',
                            fontSize: '16px',
                            fontWeight: 700,
                        }}
                    >
                        {deviceErr} thiết bị có vấn đề
                    </Typography>
                    <Typography
                        sx={{
                            fontWeight: 300,
                            color: '#55595D',
                            fontSize: 14,
                        }}
                    >
                        Bãi xe {deviceErr > 0 && 'không '}bình thường,
                        {deviceErr > 0 && ' Kiểm tra ngay!'}
                    </Typography>
                </Stack>
            </CardContent>
        </Card>
    );
}
