import * as React from 'react';
import styles from '../../dashboard.module.css';
import MoreVertIcon from '@mui/icons-material/MoreVert';
import { Box, Card, CardContent, CardHeader, IconButton, Stack, Typography } from '@mui/material';
import ImageNextjs from '@/components/common/image';
import Revenue from '@/components/dashboard/child/revenue';
import { AreaChartCompnent } from '../../item';
import { ContextDashboard } from '@/components/dashboard';
import { formatNumberVn } from '@/ultis/index';
export interface IRevenueInsightsPanelProps {}

export default function RevenueInsightsPanel(props: IRevenueInsightsPanelProps) {
    const { dashboard } = React.useContext(ContextDashboard);

    return (
        <Card className={styles.card}>
            <CardHeader
                action={
                    <IconButton aria-label="settings">
                        <MoreVertIcon />
                    </IconButton>
                }
                title={<Typography className={styles.card_title}>Doanh thu</Typography>}
                subheader={
                    <Stack className={styles.card_subheader}>
                        <ImageNextjs
                            path="icons/clock_icon.svg"
                            sx={{ width: '10px', height: '10px', mr: '5px' }}
                        />
                        Cập nhật lúc 12:06:13
                    </Stack>
                }
            />
            <CardContent
                sx={{ alignItems: 'center', minHeight: '280px', justifyContent: 'center' }}
            >
                <Stack
                    sx={{
                        position: 'relative',
                        alignItems: 'center',
                    }}
                >
                    <Stack
                        sx={{
                            // position: 'absolute',
                            backgroundColor:
                                dashboard.DataRevenueToday > dashboard?.DataRevenueYesterday
                                    ? '#5EB14A'
                                    : '#E94F4F',
                            borderRadius: '20px',
                            width: 'fit-content',
                            padding: '5px 10px',
                            bottom: '100%',
                            right: 'calc(50% - 30px)',
                        }}
                    >
                        <Typography sx={{ fontWeight: 700, fontSize: '12px', color: '#fff' }}>
                            {dashboard.DataRevenueToday > dashboard?.DataRevenueYesterday
                                ? '+'
                                : ''}
                            {dashboard.Percent} %
                        </Typography>
                    </Stack>

                    <Box>
                        <Typography
                            sx={{
                                fontWeight: 700,
                                fontSize: '36px',
                                lineHeight: '42px',
                                minWidth: '100px',
                            }}
                        >
                            {formatNumberVn(dashboard.DataRevenueToday || '0 VNĐ')}
                        </Typography>
                        <Typography
                            sx={{
                                fontSize: '10px',
                                fontWeight: 300,
                                color: '#55595d',
                                pl: 1,
                            }}
                        >
                            So với {dashboard.DataRevenueYesterday} trong quá khứ
                        </Typography>
                        <Typography
                            sx={{
                                fontSize: '10px',
                                fontWeight: 300,
                                color: '#55595d',
                                pl: 1,
                            }}
                        >
                            4 vé tháng sắp đến hạn: 415.000 VNĐ
                        </Typography>
                    </Box>
                </Stack>
                <AreaChartCompnent color="#48EC76" height="140px" width={'100%'} />
            </CardContent>
        </Card>
    );
}
