import * as React from 'react';
import styles from '../../dashboard.module.css';
import { Card, CardContent, CardHeader, IconButton, Stack, Typography } from '@mui/material';
import { calculatePercent } from '@/ultis/global-func';
import { DonutChartComponent } from '../../item';
import { useContext, useMemo } from 'react';
import { ContextDashboard } from '@/components/dashboard/dashboard-context';
import MoreVertIcon from '@mui/icons-material/MoreVert';
import { useAppSelector } from '@/hooks/index';
export interface IEfficiencyProps {}

export default function Efficiency(props: IEfficiencyProps) {
    const { dashboard, dashboardToday, device } = useContext(ContextDashboard);
    const dashboardChose = useAppSelector((state) => state.parking.chooseDashboard);

    const capacity = useMemo(() => {
        if (!dashboardChose) return 0;
        return (
            dashboardChose.Capacity -
            (dashboardToday.DataCarInParking +
                (dashboardToday.DataCarIn - dashboardToday.DataCarOut))
        );
    }, [dashboardToday, dashboardChose]);
    const check = () => {
        const target = dashboardChose?.ExpectedRevenue ? dashboardChose?.ExpectedRevenue : 0;
        const today = dashboard.ExpectedRevenueToday;

        if (target > today) {
            return [today, target - today];
        } else {
            return [1, 0];
        }
    };

    const kpiPersnent = () => {
        var todayKpi = dashboard.ExpectedRevenueToday;
        var dashboardKpi = dashboardChose?.ExpectedRevenue ?? 0;

        if (dashboardKpi == 0 && todayKpi == 0) return 100;
        if (dashboardKpi == 0 && todayKpi != 0) return 100;
        if (dashboardKpi == 0 || todayKpi == 0) return 0;
        var persent = (todayKpi / dashboardKpi) * 100;
        return persent > 100 ? 100 : persent;
    };

    return (
        <Card className={styles.card}>
            <CardHeader
                action={
                    <IconButton aria-label="settings">
                        <MoreVertIcon />
                    </IconButton>
                }
                title={<Typography className={styles.card_title}>Hiệu suất bãi xe</Typography>}
            />
            <CardContent className={styles.card_content}>
                <Stack direction="row" sx={{ alignItems: 'center' }}>
                    <DonutChartComponent
                        chartWidth="200px"
                        colors={['#067DC0', '#CDD2D1']}
                        // data={[
                        //     dashboardToday.DataCarInParking +
                        //         (dashboardToday.DataCarIn - dashboardToday.DataCarOut),
                        //     capacity,
                        // ]}
                        data={[
                            calculatePercent(
                                dashboardToday.DataCarInParking +
                                    (dashboardToday.DataCarIn - dashboardToday.DataCarOut),
                                dashboardToday.DataCarInParking +
                                    (dashboardToday.DataCarIn - dashboardToday.DataCarOut) +
                                    capacity
                            ),
                        ]}
                        text={`${calculatePercent(
                            dashboardToday.DataCarInParking +
                                (dashboardToday.DataCarIn - dashboardToday.DataCarOut),
                            dashboardToday.DataCarInParking +
                                (dashboardToday.DataCarIn - dashboardToday.DataCarOut) +
                                capacity
                        )}%`}
                    />
                    <Stack spacing={'10px'}>
                        <Stack direction="row" spacing={'10px'} sx={{ alignItems: 'center' }}>
                            <Stack
                                sx={{
                                    backgroundColor: '#067DC0',
                                    width: '10px',
                                    height: '10px',
                                    borderRadius: '5px',
                                }}
                            />
                            <Stack spacing={'5px'}>
                                <Typography
                                    sx={{
                                        fontSize: '14px',
                                        color: '#55595D',
                                        fontWeight: 400,
                                    }}
                                >
                                    Xe trong bãi{' '}
                                    <span
                                        style={{
                                            fontWeight: 700,
                                            fontSize: '16px',
                                        }}
                                    >
                                        {dashboardToday.DataCarInParking +
                                            (dashboardToday.DataCarIn - dashboardToday.DataCarOut)}
                                    </span>
                                </Typography>
                            </Stack>
                        </Stack>
                        <Stack direction="row" spacing={'10px'} sx={{ alignItems: 'center' }}>
                            <Stack
                                sx={{
                                    backgroundColor: '#78C6E7',
                                    width: '10px',
                                    height: '10px',
                                    borderRadius: '5px',
                                }}
                            />
                            <Stack sx={{}} spacing={'5px'}>
                                <Typography
                                    sx={{ fontSize: '14px', color: '#55595D', fontWeight: 400 }}
                                >
                                    Chỗ trống{' '}
                                    <span
                                        style={{
                                            fontWeight: 700,
                                            fontSize: '16px',
                                            color: '#55595D',
                                        }}
                                    >
                                        {capacity}
                                    </span>
                                </Typography>
                            </Stack>
                        </Stack>
                    </Stack>
                </Stack>
                {/* ------------------------------------ */}
                <Stack>
                    <Typography className={styles.card_title}>KPI doanh thu</Typography>
                    <Stack direction="row" sx={{ alignItems: 'center' }}>
                        <DonutChartComponent
                            chartWidth="200px"
                            colors={['#067DC0', '#CDD2D1']}
                            // data={check()}
                            data={[Math.round(kpiPersnent())]}
                            text={`${Math.round(kpiPersnent())}%`}
                            // text={`${Math.round(
                            //     (dashboardChose && dashboardChose.ExpectedRevenue !== 0
                            //         ? dashboard.ExpectedRevenueToday /
                            //           dashboardChose.ExpectedRevenue
                            //         : dashboard.ExpectedRevenueToday / 1) * 100
                            // )}%`}
                        />
                        <Stack spacing={'10px'}>
                            <Stack direction="row" spacing={'10px'} sx={{ alignItems: 'center' }}>
                                <Stack
                                    sx={{
                                        backgroundColor: '#067DC0',
                                        width: '10px',
                                        height: '10px',
                                        borderRadius: '5px',
                                    }}
                                />
                                <Stack spacing={'5px'}>
                                    <Typography
                                        sx={{
                                            fontSize: '14px',
                                            color: '#55595D',
                                            fontWeight: 400,
                                        }}
                                    >
                                        Đã đạt{' '}
                                        <span
                                            style={{
                                                fontWeight: 700,
                                                fontSize: '16px',
                                            }}
                                        >
                                            {dashboard.ExpectedRevenueToday}
                                        </span>
                                    </Typography>
                                </Stack>
                            </Stack>
                            <Stack direction="row" spacing={'10px'} sx={{ alignItems: 'center' }}>
                                <Stack
                                    sx={{
                                        backgroundColor: '#78C6E7',
                                        width: '10px',
                                        height: '10px',
                                        borderRadius: '5px',
                                    }}
                                />
                                <Stack sx={{}} spacing={'5px'}>
                                    <Typography
                                        sx={{ fontSize: '14px', color: '#55595D', fontWeight: 400 }}
                                    >
                                        Chưa đạt{' '}
                                        <span
                                            style={{
                                                fontWeight: 700,
                                                fontSize: '16px',
                                            }}
                                        >
                                            {dashboardChose?.ExpectedRevenue &&
                                            dashboardChose?.ExpectedRevenue >
                                                dashboard.ExpectedRevenueToday
                                                ? dashboardChose?.ExpectedRevenue -
                                                  dashboard.ExpectedRevenueToday
                                                : 0}
                                        </span>
                                    </Typography>
                                </Stack>
                            </Stack>
                        </Stack>
                    </Stack>
                </Stack>
            </CardContent>
        </Card>
    );
}
