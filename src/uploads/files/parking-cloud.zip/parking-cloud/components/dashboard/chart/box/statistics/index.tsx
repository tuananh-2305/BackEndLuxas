import * as React from 'react';
import styles from '../../dashboard.module.css';
import { Card, CardContent, CardHeader, IconButton, Stack, Typography } from '@mui/material';
import MoreVertIcon from '@mui/icons-material/MoreVert';
import Grid from '@mui/material/Grid';
import ImageNextjs from '@/components/common/image';
import { ContextDashboard } from '@/components/dashboard/dashboard-context';
import { checkRoleDashboard } from '@/ultis/global-func';

export interface IStatisticsProps {}

export default function Statistics(props: IStatisticsProps) {
    const { dashboardToday, device, role } = React.useContext(ContextDashboard);

    const deciveOnline = `${device.filter((e) => e.IsOnline).length}/${device.length}`;
    const carInParking =
        dashboardToday.DataCarInParking + (dashboardToday.DataCarIn - dashboardToday.DataCarOut);
    const carIn = dashboardToday.DataCarIn;
    const carOut = dashboardToday.DataCarOut;

    return (
        <Card className={styles.card}>
            <CardHeader
                action={
                    <IconButton aria-label="settings">
                        <MoreVertIcon />
                    </IconButton>
                }
                title={<Typography className={styles.card_title}>Hôm nay</Typography>}
            />
            <CardContent>
                <Grid container rowSpacing={3} columnSpacing={{ xs: 3 }}>
                    {/* item 1 */}

                    <Grid item xs={3}>
                        <Stack
                            className={styles.card_box}
                            sx={{ boxShadow: '0px 4px 16px #C5F4FF', background: '#C5F4FF' }}
                        >
                            <Stack
                                className={styles.card_box_icon}
                                sx={{ background: '#35d4f6', p: '12px' }}
                            >
                                <ImageNextjs path="icons/decive_icon.svg" />
                            </Stack>
                            <Typography className={styles.card_box_text} sx={{ py: '7px' }}>
                                Thiết bị hoạt động
                            </Typography>
                            <Typography className={styles.card_box_number}>
                                {deciveOnline}
                            </Typography>
                        </Stack>
                    </Grid>

                    {/* item 2*/}
                    <Grid item xs={3}>
                        <Stack
                            className={styles.card_box}
                            sx={{ boxShadow: '0px 4px 16px #F3E8FF', background: '#F3E8FF' }}
                        >
                            <Stack className={styles.card_box_icon} sx={{ background: '#BF83FF' }}>
                                <ImageNextjs path="icons/car_icon.svg" />
                            </Stack>
                            <Typography className={styles.card_box_text} sx={{ py: '7px' }}>
                                Xe trong bãi
                            </Typography>
                            <Typography className={styles.card_box_number}>
                                {carInParking}
                            </Typography>
                        </Stack>
                    </Grid>
                    {/* item 3*/}
                    <Grid item xs={3}>
                        <Stack
                            className={styles.card_box}
                            sx={{ boxShadow: '0px 4px 16px #DCFCE7', background: '#DCFCE7' }}
                        >
                            <Stack
                                className={styles.card_box_icon}
                                sx={{ background: '#3CD856', p: '10px' }}
                            >
                                <ImageNextjs path="icons/car_in_icon.svg" />
                            </Stack>
                            <Typography className={styles.card_box_text} sx={{ py: '7px' }}>
                                Lượt xe vào
                            </Typography>
                            <Typography className={styles.card_box_number}>{carIn}</Typography>
                        </Stack>
                    </Grid>
                    {/* item 4*/}
                    <Grid item xs={3}>
                        <Stack
                            className={styles.card_box}
                            sx={{ boxShadow: '0px 4px 16px #FFF4DE', background: '#FFF4DE' }}
                        >
                            <Stack
                                className={styles.card_box_icon}
                                sx={{ background: '#FF947A', p: '10px' }}
                            >
                                <ImageNextjs path="icons/car_out_icon.svg" />
                            </Stack>
                            <Typography className={styles.card_box_text} sx={{ py: '7px' }}>
                                Lượt xe ra
                            </Typography>
                            <Typography className={styles.card_box_number}>{carOut}</Typography>
                        </Stack>
                    </Grid>
                </Grid>
            </CardContent>
        </Card>
    );
}
