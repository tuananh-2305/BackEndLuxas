import { IconButton, Stack, Typography } from '@mui/material';
import DashboardCustomizeIcon from '@mui/icons-material/DashboardCustomize';
import { ContextDashboard } from '../dashboard-context';
import { useContext } from 'react';
interface DashboardStatusComponentProps {}
export const DashboardStatusComponent = (props: DashboardStatusComponentProps) => {
    const { dashboardToday, dashboard, device } = useContext(ContextDashboard);

    const data = [
        {
            title: 'Xe Trong Bãi',
            status:
                dashboardToday.DataCarInParking +
                (dashboardToday.DataCarIn - dashboardToday.DataCarOut),
            bgColor: '#FFB862',
        },
        { title: 'Lượt Vào', status: dashboardToday.DataCarIn, bgColor: '#78C6E7' },
        { title: 'Lượt Ra', status: dashboardToday.DataCarOut, bgColor: '#CDD2D1' },
        {
            title: 'Thiết bị hoạt động',
            status: `${device.filter((e) => e.IsOnline).length}/${device.length}`,
            bgColor: '#067DC0',
        },
    ];

    return (
        <Stack sx={{ padding: { xs: '10px', lg: '35px' }, justifyContent: 'space-around' }}>
            {data?.map((v, key) => {
                return (
                    <Stack
                        key={`item-status-dashboard-${key}`}
                        sx={{}}
                        justifyContent="center"
                        alignItems="center"
                        spacing={'15px'}
                    >
                        <Stack
                            sx={{
                                backgroundColor: v.bgColor,
                                width: '70px',
                                height: '70px',
                                boxShadow: '0px 2px 2px rgba(0, 0, 0, 0.25)',
                                borderRadius: '50%',
                            }}
                            alignItems="center"
                            justifyContent="center"
                        >
                            <Typography sx={{ fontWeight: 700, fontSize: '24px', color: '#fff' }}>
                                {v.status}
                            </Typography>
                        </Stack>
                        <Typography sx={{ fontWeight: 700, fontSize: '14px' }}>
                            {v.title}
                        </Typography>
                    </Stack>
                );
            })}
        </Stack>
    );
};
