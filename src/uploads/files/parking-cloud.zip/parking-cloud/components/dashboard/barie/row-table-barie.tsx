import { HistoryBarieModel } from '@/models/history-barie.model';
import { changeDataLane } from '@/ultis/change-data';
import { getDateTime } from '@/ultis/index';
import { TableCell, TableRow } from '@mui/material';
import moment from 'moment';

const BACKEND_DOMAIN = process.env.NEXT_PUBLIC_SERVER_PARKING_DOMAIN;

export interface IRowTableBarieProps {
    data: HistoryBarieModel;
    setOpen: any;
    reloadData: () => void;
    setDataDetail: any;
}

export default function RowTableBarie(props: IRowTableBarieProps) {
    const { data, setOpen, reloadData, setDataDetail } = props;

    return (
        <TableRow
            sx={{
                '&:last-child td, &:last-child th': { border: 0 },
                '&:not(:last-child)': { marginBottom: '10px' },
                cursor: 'pointer',
            }}
            onClick={() => {
                setDataDetail(data);
                setOpen(true);
            }}
        >
            <TableCell>
                {data?.TimeOpen ? moment(data.TimeOpen).format('HH:mm DD/MM/yyyy') : ''}
            </TableCell>
            <TableCell>{changeDataLane(data?.Lane) ?? '--'}</TableCell>
        </TableRow>
    );
}
