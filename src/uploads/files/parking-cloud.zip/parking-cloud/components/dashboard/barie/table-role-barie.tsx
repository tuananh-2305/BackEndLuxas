import { SettingEmptyComponent } from '@/components/settings/empty';
import HeaderTable from '@/components/table/header-table';
import { headerBarie } from '@/mocks/index';
import { formatTextPagination } from '@/ultis/index';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import ArrowForwardIcon from '@mui/icons-material/ArrowForward';
import {
    Pagination,
    PaginationItem,
    Stack,
    Table,
    TableBody,
    TableContainer,
    useTheme,
} from '@mui/material';
import { useRouter } from 'next/router';
import { useState } from 'react';
import DialogBarieDetail from './dialog-detail-barie';
import RowTableBarie from './row-table-barie';
import { HistoryBarieModel } from '@/models/history-barie.model';

export interface ITableBarieProps {
    data: HistoryBarieModel[];
    fetchData: () => void;
    maxPage: number;
    total: number;
    currentSize: number;
}

export default function TableBarie(props: ITableBarieProps) {
    const { data, fetchData, maxPage, total, currentSize } = props;

    const theme = useTheme();
    const router = useRouter();
    const { page } = router.query;
    const [open, setOpen] = useState(false);
    const [dataDetail, setDataDetail] = useState<HistoryBarieModel | null>(null);
    return (
        <TableContainer
            sx={{
                flex: 1,
                display: 'flex',
                flexDirection: 'column',
                justifyContent: 'space-between',
                p: 2,
            }}
        >
            <Stack
                sx={{
                    flex: 1,
                    overflow: 'auto',
                    maxHeight: '65vh',
                }}
            >
                <Table
                    stickyHeader
                    sx={{
                        borderCollapse: 'separate',
                        borderSpacing: '0 10px',
                        marginTop: '-10px',
                    }}
                >
                    <HeaderTable headerData={headerBarie} isHideAction={true} />
                    <TableBody
                        sx={{
                            '& td': {
                                background: 'rgba(217, 217, 217, 0.2)',
                            },
                            'td:first-of-type': {
                                borderTopLeftRadius: '10px',
                                borderBottomLeftRadius: '10px',
                            },
                            'td:last-of-type': {
                                borderTopRightRadius: '10px',
                                borderBottomRightRadius: '10px',
                            },
                        }}
                    >
                        {data?.map((c: HistoryBarieModel, index) => (
                            <RowTableBarie
                                data={c}
                                setOpen={setOpen}
                                key={index}
                                reloadData={fetchData}
                                setDataDetail={setDataDetail}
                            />
                        ))}
                    </TableBody>
                </Table>
            </Stack>
            {(!data || data?.length === 0) && <SettingEmptyComponent />}
            <Stack position={'relative'} alignItems={'center'}>
                <Pagination
                    count={maxPage}
                    page={
                        page?.toString() && page?.toString() !== 'undefined'
                            ? parseInt(page?.toString())
                            : 1
                    }
                    onChange={(event, page) => {
                        router.push({
                            pathname: router.pathname,
                            query: { page: page },
                        });
                    }}
                    renderItem={(item) => (
                        <PaginationItem
                            components={{ previous: ArrowBackIcon, next: ArrowForwardIcon }}
                            {...item}
                            shape="rounded"
                            sx={{
                                borderRadius: '4px',
                                border: '1px solid #DFE3E8',
                                '&.Mui-selected': {
                                    background: '#fff',
                                    border: '1px solid #067DC0',
                                    color: '#067DC0',
                                },

                                color: theme.palette.text.primary,
                            }}
                        />
                    )}
                    sx={{
                        py: 2,
                    }}
                />
                <Stack
                    position={'absolute'}
                    sx={{
                        right: '60px',
                        top: '0',
                        bottom: '0',
                    }}
                    alignItems={'center'}
                    justifyContent={'center'}
                >
                    {formatTextPagination(currentSize, data?.length, total)}
                </Stack>
            </Stack>

            {dataDetail && open && (
                <DialogBarieDetail
                    open={open}
                    handleClose={() => setOpen(false)}
                    data={dataDetail}
                />
            )}
        </TableContainer>
    );
}
