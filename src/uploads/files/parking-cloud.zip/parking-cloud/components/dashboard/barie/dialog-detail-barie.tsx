import ImageNextjs from '@/components/common/image';
import { HistoryBarieModel } from '@/models/history-barie.model';
import { getNameAddress, showAddress } from '@/ultis/global-func';
import ZoomOutMapIcon from '@mui/icons-material/ZoomOutMap';
import {
    Button,
    Dialog,
    DialogActions,
    DialogContent,
    DialogTitle,
    Divider,
    Stack,
    Tooltip,
    Typography,
} from '@mui/material';
import moment from 'moment';
import Image from 'next/image';
const BACKEND_DOMAIN = process.env.NEXT_PUBLIC_SERVER_PARKING_DOMAIN;

export interface IDialogBarieDetailProps {
    open: boolean;
    handleClose: (() => void) | undefined;
    data: HistoryBarieModel | null;
}

export default function DialogBarieDetail(props: IDialogBarieDetailProps) {
    const { data } = props;
    return (
        <Dialog
            open={props.open}
            onClose={props.handleClose}
            aria-labelledby="alert-dialog-title"
            aria-describedby="alert-dialog-description"
            fullWidth
            maxWidth="sm"
        >
            <Stack
                sx={{
                    justifyContent: 'space-between',
                }}
            >
                <Stack sx={{ m: 2 }} spacing={2}>
                    <Stack>
                        <Typography variant="h6">{data?.ParkingId?.Name}</Typography>
                        <Typography variant="subtitle1" sx={{ fontSize: '15px' }}>
                            {data?.ParkingId?.Address || data?.ParkingId?.Ward
                                ? `(${showAddress(
                                      data?.ParkingId?.Address || '',
                                      getNameAddress(data?.ParkingId?.Ward ?? ''),
                                      getNameAddress(data?.ParkingId?.District ?? ''),
                                      getNameAddress(data?.ParkingId?.Province ?? '')
                                  )})`
                                : '...'}
                        </Typography>
                    </Stack>
                    <Divider />
                </Stack>
            </Stack>
            <DialogContent>
                <Stack sx={{ flexDirection: 'column' }} gap={2}>
                    <Stack spacing={2}>
                        <Stack spacing={2}>
                            <Stack
                                direction={'row'}
                                justifyContent={'space-between'}
                                alignItems={'center'}
                            >
                                <Stack>
                                    <Typography sx={{ fontWeight: 400, fontSize: '14px' }}>
                                        Hình ảnh vào bãi
                                    </Typography>
                                    <Typography sx={{ fontWeight: 400, fontSize: '13px' }}>
                                        {data?.TimeOpen
                                            ? moment(data.TimeOpen).format('HH:mm DD-MM-YYYY')
                                            : ''}
                                    </Typography>
                                </Stack>
                                <Stack alignItems={'flex-end'} direction={'row'} gap={2}></Stack>
                            </Stack>
                            <Stack gap={2} direction={'row'}>
                                <Stack
                                    sx={{
                                        background: 'black',
                                        position: 'relative',
                                    }}
                                >
                                    <Image
                                        src={
                                            data?.ImageBefore
                                                ? `${BACKEND_DOMAIN}${data?.ImageBefore}`
                                                : '/logo/ORYZA-white.png'
                                        }
                                        width={270}
                                        height={190}
                                        alt={'Ảnh vào 1'}
                                    />

                                    <Tooltip title="Xem ảnh phóng lớn">
                                        <Stack
                                            onClick={() => {
                                                if (data?.ImageBefore) {
                                                    window.open(
                                                        BACKEND_DOMAIN + data?.ImageBefore,
                                                        '_blank'
                                                    );
                                                }
                                            }}
                                            sx={{
                                                position: 'absolute',
                                                bottom: '10px',
                                                right: '10px',
                                                backgroundColor: '#fff',
                                                padding: '5px',
                                                borderRadius: '50%',
                                                cursor: 'pointer',
                                                boxShadow: 'rgba(0, 0, 0, 0.24) 0px 3px 8px',
                                            }}
                                        >
                                            <ZoomOutMapIcon sx={{ fontSize: '16px' }} />
                                        </Stack>
                                    </Tooltip>
                                </Stack>
                                <Stack
                                    sx={{
                                        background: 'black',
                                        position: 'relative',
                                    }}
                                >
                                    <Image
                                        src={
                                            data?.ImageAfter
                                                ? `${BACKEND_DOMAIN}${data?.ImageAfter}`
                                                : '/logo/ORYZA-white.png'
                                        }
                                        width={270}
                                        height={190}
                                        alt={'Ảnh vào 2'}
                                    />

                                    <Tooltip title="Xem ảnh phóng lớn">
                                        <Stack
                                            onClick={() => {
                                                if (data?.ImageAfter) {
                                                    window.open(
                                                        BACKEND_DOMAIN + data?.ImageAfter,
                                                        '_blank'
                                                    );
                                                }
                                            }}
                                            sx={{
                                                position: 'absolute',
                                                bottom: '10px',
                                                right: '10px',
                                                backgroundColor: '#fff',
                                                padding: '5px',
                                                borderRadius: '50%',
                                                cursor: 'pointer',
                                                boxShadow: 'rgba(0, 0, 0, 0.24) 0px 3px 8px',
                                            }}
                                        >
                                            <ZoomOutMapIcon sx={{ fontSize: '16px' }} />
                                        </Stack>
                                    </Tooltip>
                                </Stack>
                            </Stack>
                        </Stack>
                    </Stack>
                </Stack>
            </DialogContent>
        </Dialog>
    );
}
