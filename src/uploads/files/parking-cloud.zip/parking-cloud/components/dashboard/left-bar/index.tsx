import CardParkingDashboard from '@/components/common/card/card-parking-dashboard';
import { useAppDispatch, useAppSelector } from '@/hooks/useReudx';
import {
    PARKING_CHOSE_DASHBOARD,
    PARKING_CHOSE_SETTING,
    getNameAddress,
    getRoleReport,
    getRoleSetting,
    showAddress,
} from '@/ultis/index';
import ParkingIcon from '@mui/icons-material/LocalParking';
import MenuOpenIcon from '@mui/icons-material/MenuOpen';
import { IconButton, Stack, Tooltip, Typography } from '@mui/material';
import { useState } from 'react';
import CardParking from '../../common/card/card-parking';
import LeftNav from '../../common/nav/left-nav';
import DialogCreateParking from '../../dialog/dialog-create-parking';
import ReplayIcon from '@mui/icons-material/Replay';
import { parkingApi } from '@/api/index';
import {
    changeParkingChoose,
    changeParkingChooseDashboard,
    updaProfile,
    updateDataParkings,
} from '@/redux/index';

export interface ILeftDashBoardProps {
    close: () => void;
    open: boolean;
}

export const LeftDashBoardComponent = (props: ILeftDashBoardProps) => {
    const { close, open } = props;

    const [openCreateDialog, setOpenCreateDialog] = useState(false);
    const parkings = useAppSelector((state) => state.parking.parkings);
    const profile = useAppSelector((state) => state.common.profile);
    const parkingChoseDashboard = useAppSelector((state) => state.parking.chooseDashboard);
    const dispatch = useAppDispatch();

    const reload = () => {
        if (profile) {
            parkingApi.getAllParking().then((res) => {
                const action = updateDataParkings({ data: res.data });
                dispatch(action);
                const parkingReport = getRoleReport(profile, res.data);
                if (res?.data?.length > 0 && parkings?.length == 0 && parkingReport.length > 0) {
                    // const profileClone = structuredClone(profile);
                    const profileClone = JSON.parse(JSON.stringify(profile));
                    const parkingSetting = getRoleSetting(profile, res.data);
                    profileClone.IsDashboard = true;
                    const currentParkingChooseId =
                        localStorage.getItem(PARKING_CHOSE_DASHBOARD) || '';
                    let parkingChoose = parkingReport.find(
                        (item) => item.ID == currentParkingChooseId
                    );
                    if (!parkingChoose) {
                        parkingChoose = parkingReport[0];
                    }
                    const actionChoseReport = changeParkingChooseDashboard({
                        parking: parkingChoose,
                    });
                    dispatch(actionChoseReport);
                    localStorage.setItem(PARKING_CHOSE_DASHBOARD, parkingChoose?.ID || '');

                    if (parkingSetting.length > 0) {
                        const currentParkingSettingChooseId =
                            localStorage.getItem(PARKING_CHOSE_SETTING) || '';
                        let parkingChooseSetting = parkingSetting.find(
                            (item) => item.ID == currentParkingSettingChooseId
                        );
                        if (!parkingChooseSetting) {
                            parkingChooseSetting = parkingSetting[0];
                        }
                        const actionChoseDefault = changeParkingChoose({
                            parking: parkingChooseSetting,
                        });
                        dispatch(actionChoseDefault);
                        profileClone.IsSetting = true;
                        localStorage.setItem(PARKING_CHOSE_SETTING, parkingChooseSetting?.ID || '');
                    }
                    const action = updaProfile({ profile: profileClone });
                    dispatch(action);

                    return;
                }
            });
        }
    };

    return (
        <LeftNav sx={{ display: open ? 'flex' : 'none' }}>
            <DialogCreateParking
                open={openCreateDialog}
                handleClose={() => {
                    setOpenCreateDialog(false);
                }}
            />

            {parkings.length !== 0 ? (
                <>
                    <CardParking
                        title={parkingChoseDashboard?.Name || ''}
                        description={''}
                        content={showAddress(
                            parkingChoseDashboard?.Address || '',
                            getNameAddress(parkingChoseDashboard?.Ward),
                            getNameAddress(parkingChoseDashboard?.District),
                            getNameAddress(parkingChoseDashboard?.Province)
                        )}
                        itemActions={
                            <Tooltip title="Đóng thanh công cụ trái.">
                                <IconButton
                                    aria-label="settings"
                                    color={'inherit'}
                                    onClick={(e) => {
                                        close();
                                    }}
                                >
                                    <MenuOpenIcon />
                                </IconButton>
                            </Tooltip>
                        }
                        avatar={
                            <Stack
                                sx={{
                                    border: '2px solid currentColor',
                                    borderRadius: '4px',
                                }}
                            >
                                <ParkingIcon fontSize={'small'} />
                            </Stack>
                        }
                        sx={{
                            color: 'black',
                            backgroundColor: 'transparent',
                            boxShadow: 'none',
                            p: 0,
                            my: 2,
                        }}
                    />
                    <Stack
                        spacing={2}
                        flex={1}
                        sx={{
                            overflowY: 'auto',
                            maxHeight: 'calc(100vh - 64px )',
                            padding: '10px 5px',
                        }}
                        pt={1}
                    >
                        {getRoleReport(profile, parkings).map((parking, index) => {
                            const isActived = parkingChoseDashboard?.ID === parking.ID;

                            return (
                                <CardParkingDashboard
                                    parking={parking}
                                    isActived={isActived}
                                    key={index}
                                />
                            );
                        })}
                    </Stack>
                </>
            ) : (
                <Stack sx={{ justifyContent: 'space-between', height: '100%', pt: 2, pb: 1 }}>
                    <Stack
                        sx={{
                            border: '1px dashed #000',
                            borderRadius: '15px',
                            width: '100%',
                            height: '130px',
                            gap: '10px',
                            cursor: 'pointer',
                        }}
                        justifyContent="center"
                        alignItems="center"
                        onClick={() => reload()}
                    >
                        <ReplayIcon />
                        <Stack justifyContent="center" alignItems="center">
                            <Typography sx={{ color: '#55595D', fontWeight: 700 }}>
                                Làm mới dữ liệu
                            </Typography>
                            <Typography
                                sx={{ fontSize: '12px', fontWeight: 300, fontStyle: 'italic' }}
                            >
                                (Nhấn để làm mới dữ liệu!)
                            </Typography>
                        </Stack>
                    </Stack>
                    <Stack sx={{ gap: '10px' }}>
                        <Stack
                            sx={{
                                cursor: 'pointer',
                                backgroundColor: '#FFB862',
                                boxShadow: '0px 2px 2px 0px #00000040',
                                padding: '10px',
                                borderRadius: '10px',
                            }}
                            justifyContent="center"
                        >
                            <Typography
                                sx={{ fontWeight: 700, color: '#fff', textAlign: 'center' }}
                            >
                                Báo cáo lỗi
                            </Typography>
                        </Stack>

                        <Typography
                            sx={{
                                fontWeight: 300,
                                fontSize: '12px',
                                fontStyle: 'italic',
                                textAlign: 'center',
                            }}
                        >
                            Nếu bạn cho rằng đây là một lỗi, hãy nhấn nút trên để chúng tôi hỗ trợ
                            bạn!
                        </Typography>
                    </Stack>
                </Stack>
            )}
        </LeftNav>
    );
};
