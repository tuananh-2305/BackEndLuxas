import { DashboardModel } from '@/models/dashboard.model';
import { formatNumberVn, formatTime } from '@/ultis/index';
import { Box, Stack, Typography } from '@mui/material';
import Image from 'next/image';

export interface IRevenueProps {
    dashboard: DashboardModel;
}

export default function Revenue(props: IRevenueProps) {
    const { dashboard } = props;
    return (
        <Stack sx={{ flex: 1 }} justifyContent="space-between">
            <Stack direction="row" sx={{ gap: '10px' }}>
                <Stack
                    sx={{
                        backgroundColor: '#78C6E7',
                        width: '35px',
                        height: '35px',
                        borderRadius: '50%',
                        boxShadow: '0px 2px 2px rgba(0, 0, 0, 0.25)',
                    }}
                    justifyContent="center"
                    alignItems="center"
                >
                    <Image src="/icons/money-white.svg" width={18} height={18} alt="monney" />
                </Stack>
                <Stack>
                    <Typography sx={{ fontWeight: 700, fontSize: '14px' }}>Doanh thu</Typography>
                    <Typography sx={{ color: '#55595D', fontSize: '10px' }}>
                        Cập nhật lúc {formatTime(dashboard.TimeNow || null)}
                    </Typography>
                </Stack>
            </Stack>

            <Stack alignItems="center" sx={{ transform: 'translateY(30px)' }}>
                <Stack sx={{ position: 'relative' }}>
                    <Stack
                        sx={{
                            position: 'absolute',
                            backgroundColor:
                                dashboard.DataRevenueToday > dashboard?.DataRevenueYesterday
                                    ? '#5EB14A'
                                    : '#E94F4F',
                            borderRadius: '20px',
                            width: 'fit-content',
                            padding: '5px 10px',
                            bottom: '100%',
                            right: '0',
                        }}
                    >
                        <Typography sx={{ fontWeight: 700, fontSize: '12px', color: '#fff' }}>
                            {dashboard.DataRevenueToday > dashboard?.DataRevenueYesterday
                                ? '+'
                                : ''}
                            {dashboard.Percent} %
                        </Typography>
                    </Stack>

                    <Box>
                        <Typography
                            sx={{
                                fontWeight: 700,
                                fontSize: '30px',
                                lineHeight: '42px',
                                minWidth: '100px',
                            }}
                        >
                            {formatNumberVn(dashboard.DataRevenueToday || 0)}
                        </Typography>
                        <Typography
                            sx={{
                                fontSize: '10px',
                                fontWeight: 300,
                                color: '#55595d',
                                pl: 1,
                            }}
                        >
                            So với {dashboard.DataRevenueYesterday} trong quá khứ
                        </Typography>
                    </Box>
                </Stack>
            </Stack>
        </Stack>
    );
}
