import { historyInOutApi } from '@/api/index';
import { systemRoleDetailRoleApi } from '@/api/system-role-detail-cloud';
import { useAppDispatch, useAppSelector } from '@/hooks/index';
import { showSnackbarWithClose } from '@/hooks/useSnackbarWithClose';
import { dashboardMock, dashboardTodayMock, deviceMock } from '@/mocks/context-mock';
import { DashBoardToday, DashboardModel } from '@/models/dashboard.model';
import { setLoadingGlobal } from '@/redux/index';
import { createContext, useCallback, useEffect, useState } from 'react';

const ContextDashboard = createContext({
    dashboard: dashboardMock,
    dashboardToday: dashboardTodayMock,
    device: deviceMock,
    role: [] as { ID: string; key: string; IsUse: boolean }[],
});

interface DashboardContextProps {
    children: React.ReactNode;
    idParking?: string;
    startDate: Date;
    endDate: Date;
}

const DashboardProvider = ({ children, idParking, startDate, endDate }: DashboardContextProps) => {
    const [dashboard, setDashboard] = useState<DashboardModel>(dashboardMock);
    const [dashboardToday, setDashboardToday] = useState<DashBoardToday>(dashboardTodayMock);
    const deviceOnline = useAppSelector((state) => state.socket.onlineDevice);
    const deviceOffline = useAppSelector((state) => state.socket.offlineDevice);
    const newHistory = useAppSelector((state) => state.socket.historyNew);
    const updateHistory = useAppSelector((state) => state.socket.historyUpdate);
    const profile = useAppSelector((state) => state.common.profile);
    const [device, setDevice] = useState(deviceMock);
    const [roleList, setRoleList] = useState<{ ID: string; key: string; IsUse: boolean }[]>([]);

    const dispatch = useAppDispatch();
    const context = {
        dashboard,
        dashboardToday,
        device,
        role: roleList,
    };
    const fetchData = useCallback(async () => {
        if (!idParking) return;
        const action = setLoadingGlobal({ isLoadingGlobal: true });
        dispatch(action);
        historyInOutApi
            .dashboard({
                ParkingId: idParking,
                StartDate: startDate,
                EndDate: endDate,
            })
            .then((res) => {
                if (profile) {
                    systemRoleDetailRoleApi.byUserAndParking(profile.ID, idParking).then((res) => {
                        setRoleList(
                            res.data.map((v: any) => ({
                                ID: v.ID,
                                IsUse: v.IsUse,
                                key: v.KeyRoleDetailId.KeyWord,
                            }))
                        );
                    });
                }
                setDevice(res.data.Device);
                setDashboard(res.data);
            })
            .catch((error) => {
                if (Array.isArray(error?.response?.data?.message)) {
                    error?.response?.data?.message.forEach((item: any) => {
                        showSnackbarWithClose(item, {
                            variant: 'error',
                        });
                    });
                } else {
                    showSnackbarWithClose(
                        error?.response ? error.response.data?.message : error.message,
                        {
                            variant: 'error',
                        }
                    );
                }
            })
            .finally(() => {
                const action = setLoadingGlobal({ isLoadingGlobal: false });
                dispatch(action);
            });
    }, [dispatch, endDate, idParking, profile, startDate]);
    useEffect(() => {
        if (!idParking) return;
        fetchData();
    }, [idParking, startDate, endDate, fetchData]);
    useEffect(() => {
        if (!idParking) return;
        // const fetchDataToday = async () => {
        //     const { data } = await historyInOutApi.dashboardToday(idParking);
        //     setDashboardToday(data);
        //     // console.log(data);
        // };

        historyInOutApi
            .dashboardToday(idParking)
            .then((res) => {
                setDashboardToday(res.data);
            })
            .catch((error) => {
                if (Array.isArray(error?.response?.data?.message)) {
                    error?.response?.data?.message.forEach((item: any) => {
                        showSnackbarWithClose(item, {
                            variant: 'error',
                        });
                    });
                } else {
                    showSnackbarWithClose(
                        error?.response ? error.response.data?.message : error.message,
                        {
                            variant: 'error',
                        }
                    );
                }
            });

        // fetchDataToday();
    }, [idParking]);
    useEffect(() => {
        if (!idParking || !deviceOnline || idParking !== deviceOnline?.ParkingId) return;
        const deviceIndex = device.findIndex((item) => item.ID === deviceOnline.ID);
        // console.log(deviceOnline, deviceIndex, device);
        if (deviceIndex !== -1) {
            setDevice((prev) => {
                // const clone = structuredClone(device);
                const clone = [...prev];
                clone[deviceIndex].IsOnline = true;
                return clone;
            });
        }
    }, [deviceOnline]);

    useEffect(() => {
        if (!idParking || !deviceOffline || idParking !== deviceOffline?.ParkingId) return;
        const deviceIndex = device.findIndex((item) => item.ID === deviceOffline.ID);
        // console.log(deviceIndex, device);

        if (deviceIndex !== -1) {
            setDevice((prev) => {
                // const clone = structuredClone(device);
                const clone = [...prev];
                clone[deviceIndex].IsOnline = false;
                return clone;
            });
        }
    }, [deviceOffline]);

    useEffect(() => {
        if (!newHistory || !idParking || newHistory?.ParkingId?.ID !== idParking) return;
        setDashboardToday((prev) => {
            const clone = {
                ...prev,
                DataCarIn: prev.DataCarIn + 1,
            };

            return clone;
        });
    }, [newHistory, idParking]);

    useEffect(() => {
        if (!updateHistory || !idParking || updateHistory?.ParkingId?.ID !== idParking) return;
        setDashboardToday((prev) => {
            const clone = {
                ...prev,
                DataCarOut: prev.DataCarOut + 1,
            };
            return clone;
        });
    }, [updateHistory, idParking]);
    return <ContextDashboard.Provider value={context}>{children}</ContextDashboard.Provider>;
};
export { ContextDashboard, DashboardProvider };
