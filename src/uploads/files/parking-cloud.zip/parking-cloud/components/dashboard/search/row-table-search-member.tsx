import { AvatarCustom } from '@/components/common';
import { MemberModel } from '@/models/index';
import { getDateCustom, getNameGender } from '@/ultis/index';
import { Stack, TableCell, TableRow, Typography } from '@mui/material';

const BACKEND_DOMAIN = process.env.NEXT_PUBLIC_SERVER_PARKING_DOMAIN;

export interface IRowTableMemberProps {
    data: MemberModel;
}

export default function RowTableMember(props: IRowTableMemberProps) {
    return (
        <TableRow
            sx={{
                '&:last-child td, &:last-child th': { border: 0 },
                '&:not(:last-child)': { marginBottom: '10px' },
            }}
        >
            <TableCell sx={{ width: '20%' }}>
                <Stack
                    direction={'row'}
                    spacing={1}
                    sx={{
                        maxWidth: '100%',
                        overflow: 'hidden',
                        wordBreak: 'break-all',
                        textOverflow: 'ellipsis',
                    }}
                >
                    <AvatarCustom
                        src={props.data.Avatar ? BACKEND_DOMAIN + props.data.Avatar : ''}
                        type="circle"
                        size={40}
                    />
                    <Stack justifyContent={'space-between'}>
                        <Typography
                            variant="body2"
                            sx={{
                                display: '-webkit-box',
                                WebkitLineClamp: 2,
                                lineClamp: 2,
                                WebkitBoxOrient: 'vertical',
                                overflow: 'hidden',
                                textOverflow: 'ellipsis',
                            }}
                        >
                            {props.data.Name}
                        </Typography>
                        <Typography
                            variant="caption"
                            sx={{
                                display: '-webkit-box',
                                WebkitLineClamp: 2,
                                lineClamp: 2,
                                WebkitBoxOrient: 'vertical',
                                overflow: 'hidden',
                                textOverflow: 'ellipsis',
                            }}
                        >
                            {props.data.Email}
                        </Typography>
                    </Stack>
                </Stack>
            </TableCell>
            <TableCell sx={{ width: '15%' }}>
                <Stack>
                    <Typography
                        variant="body2"
                        sx={{
                            display: '-webkit-box',
                            WebkitLineClamp: 2,
                            lineClamp: 2,
                            WebkitBoxOrient: 'vertical',
                            overflow: 'hidden',
                            textOverflow: 'ellipsis',
                        }}
                    >
                        {props.data.MemberTypeId?.Name}
                    </Typography>
                </Stack>
            </TableCell>
            <TableCell sx={{ width: '20%' }}>
                <Stack>
                    <Typography
                        variant="body2"
                        sx={{
                            display: '-webkit-box',
                            WebkitLineClamp: 2,
                            lineClamp: 2,
                            WebkitBoxOrient: 'vertical',
                            overflow: 'hidden',
                            textOverflow: 'ellipsis',
                        }}
                    >
                        {props.data.Address}
                    </Typography>
                </Stack>
            </TableCell>
            <TableCell sx={{ width: '15%' }}>{props.data.Phone}</TableCell>
            <TableCell sx={{ width: '10%' }}>{getNameGender(props.data.Gender)}</TableCell>
            <TableCell sx={{ width: '20%' }}>{getDateCustom(props.data.DOB)}</TableCell>
        </TableRow>
    );
}
