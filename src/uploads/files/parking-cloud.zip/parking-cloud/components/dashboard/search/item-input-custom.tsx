import { StyledOutlinedInput } from '@/components/common/style-component';
import { InputLabel, Stack } from '@mui/material';
import React from 'react';

export interface IItemInputCustomProps {
    value: string;
    setValue: (value: string) => void;
    title: string;
    plaveholder: string;
}

export default function ItemInputCustom(props: IItemInputCustomProps) {
    return (
        <Stack sx={{ width: '22%' }}>
            <InputLabel>{props.title}</InputLabel>
            <StyledOutlinedInput
                autoComplete="off"
                value={props.value}
                onChange={(e) => {
                    props.setValue(e.target.value);
                }}
                size="small"
                fullWidth
                placeholder={props.plaveholder}
                inputProps={{
                    sx: {
                        '&::placeholder': {
                            fontStyle: 'italic',
                            fontSize: '14px',
                            fontWeight: 300,
                            lineHeight: '16px',
                        },
                    },
                }}
            />
        </Stack>
    );
}
