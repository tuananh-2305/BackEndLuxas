import { SettingEmptyComponent } from '@/components/settings/empty';
import HeaderTable from '@/components/table/header-table';
import { columnsHistory } from '@/mocks/index';
import { HistoryModel } from '@/models/index';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import ArrowForwardIcon from '@mui/icons-material/ArrowForward';
import {
    Pagination,
    PaginationItem,
    Stack,
    Table,
    TableBody,
    TableContainer,
    useTheme,
} from '@mui/material';
import { useState } from 'react';
import RowTableSearch from './row-table-search-history';
import DialogDetailHistory from '@/components/dialog/dialog-detail-history/dialog-detail-history';
import { formatTextPagination } from '@/ultis/index';
export interface ITableSearchHistoryProps {
    data: HistoryModel[];
    maxPage: number;
    setPage: (page: number) => void;
    page: number;
    total: number;
    currentSize: number;
}

export default function TableSearchHistory(props: ITableSearchHistoryProps) {
    const { data, maxPage, setPage, page, total, currentSize } = props;

    const theme = useTheme();
    const [open, setOpen] = useState(false);
    const [dataDetail, setDataDetail] = useState<HistoryModel>();
    return (
        <TableContainer
            sx={{
                flex: 1,
                display: 'flex',
                flexDirection: 'column',
                justifyContent: 'space-between',
                p: 2,
            }}
        >
            <Table
                sx={{
                    borderCollapse: 'separate',
                    borderSpacing: '0 10px',
                    marginTop: '-10px',
                }}
            >
                <HeaderTable headerData={columnsHistory} isHideAction={true} />
                <TableBody
                    sx={{
                        '& td': {
                            background: 'rgba(217, 217, 217, 0.2)',
                        },
                        'td:first-of-type': {
                            borderTopLeftRadius: '10px',
                            borderBottomLeftRadius: '10px',
                        },
                        'td:last-of-type': {
                            borderTopRightRadius: '10px',
                            borderBottomRightRadius: '10px',
                        },
                    }}
                >
                    {data?.map((c: any, index) => (
                        <RowTableSearch
                            data={c}
                            setOpen={setOpen}
                            key={index}
                            setDataDetail={setDataDetail}
                        />
                    ))}
                </TableBody>
            </Table>
            <Stack position={'relative'} alignItems={'center'}>
                <Pagination
                    count={maxPage}
                    page={
                        page?.toString() && page?.toString() !== 'undefined'
                            ? parseInt(page?.toString())
                            : 1
                    }
                    onChange={(event, page) => {
                        setPage(page);
                    }}
                    renderItem={(item) => (
                        <PaginationItem
                            components={{ previous: ArrowBackIcon, next: ArrowForwardIcon }}
                            {...item}
                            shape="rounded"
                            sx={{
                                borderRadius: '4px',
                                border: '1px solid #DFE3E8',
                                '&.Mui-selected': {
                                    background: '#fff',
                                    border: '1px solid #067DC0',
                                    color: '#067DC0',
                                },

                                color: theme.palette.text.primary,
                            }}
                        />
                    )}
                    sx={{
                        py: 2,
                    }}
                />
                <Stack
                    position={'absolute'}
                    sx={{
                        right: '60px',
                        top: '0',
                        bottom: '0',
                    }}
                    alignItems={'center'}
                    justifyContent={'center'}
                >
                    {formatTextPagination(currentSize, data?.length, total)}
                </Stack>
            </Stack>
            <DialogDetailHistory open={open} handleClose={() => setOpen(false)} data={dataDetail} />
        </TableContainer>
    );
}
