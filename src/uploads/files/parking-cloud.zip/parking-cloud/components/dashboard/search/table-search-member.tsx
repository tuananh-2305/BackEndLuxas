import HeaderTable from '@/components/table/header-table';
import { columnsMember, columnsMemberDashboard } from '@/mocks/header-mock';
import { MemberModel } from '@/models/member.model';
import {
    Pagination,
    PaginationItem,
    Stack,
    Table,
    TableBody,
    TableContainer,
    useTheme,
} from '@mui/material';
import RowTableMember from './row-table-search-member';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import ArrowForwardIcon from '@mui/icons-material/ArrowForward';
import { formatTextPagination } from '@/ultis/index';
export interface ITableSearchMemberProps {
    data: MemberModel[];
    maxPage: number;
    setPage: (page: number) => void;
    page: number;
    total: number;
    currentSize: number;
}

export default function TableSearchMember(props: ITableSearchMemberProps) {
    const theme = useTheme();
    const { data, maxPage, setPage, page, total, currentSize } = props;
    return (
        <TableContainer
            sx={{
                flex: 1,
                display: 'flex',
                flexDirection: 'column',
                justifyContent: 'space-between',
                p: 2,
            }}
        >
            <Table
                sx={{
                    borderCollapse: 'separate',
                    borderSpacing: '0 10px',
                    marginTop: '-10px',
                }}
            >
                <HeaderTable headerData={columnsMemberDashboard} />
                <TableBody
                    sx={{
                        maxWidth: '800px',
                        '& td': {
                            background: 'rgba(217, 217, 217, 0.2)',
                        },
                        'td:first-of-type': {
                            borderTopLeftRadius: '10px',
                            borderBottomLeftRadius: '10px',
                        },
                        'td:last-of-type': {
                            borderTopRightRadius: '10px',
                            borderBottomRightRadius: '10px',
                        },
                    }}
                >
                    {props.data?.map((c: MemberModel, index) => (
                        <RowTableMember data={c} key={index} />
                    ))}
                </TableBody>
            </Table>
            <Stack position={'relative'} alignItems={'center'}>
                <Pagination
                    count={props.maxPage}
                    page={
                        props.page?.toString() && props.page?.toString() !== 'undefined'
                            ? parseInt(props.page?.toString())
                            : 1
                    }
                    onChange={(event, page) => {
                        props.setPage(page);
                    }}
                    renderItem={(item) => (
                        <PaginationItem
                            components={{ previous: ArrowBackIcon, next: ArrowForwardIcon }}
                            {...item}
                            shape="rounded"
                            sx={{
                                borderRadius: '4px',
                                border: '1px solid #DFE3E8',
                                '&.Mui-selected': {
                                    background: '#fff',
                                    border: '1px solid #067DC0',
                                    color: '#067DC0',
                                },

                                color: theme.palette.text.primary,
                            }}
                        />
                    )}
                    sx={{
                        py: 2,
                    }}
                />
                <Stack
                    position={'absolute'}
                    sx={{
                        right: '60px',
                        top: '0',
                        bottom: '0',
                    }}
                    alignItems={'center'}
                    justifyContent={'center'}
                >
                    {formatTextPagination(currentSize, data?.length, total)}
                </Stack>
            </Stack>
        </TableContainer>
    );
}
