import { StyledSelectInput } from '@/components/common/style-component';
import { useAppSelector } from '@/hooks/useReudx';
import { Button, InputLabel, MenuItem, Stack } from '@mui/material';
import React from 'react';
import ItemInputCustom from './item-input-custom';

export interface IFormSearchMemberProps {
    parking: string;
    setParking: (value: string) => void;
    infoCustomer: string;
    setInfoCustomer: (value: string) => void;
    handleSearch: () => void;
}

export default function FormSearchMember(props: IFormSearchMemberProps) {
    const listParking = useAppSelector((state) => state.parking.parkings);
    return (
        <Stack
            sx={{
                flexDirection: 'row',
                alignItems: 'flex-end',
            }}
            gap={2}
        >
            <Stack sx={{ width: '22%' }}>
                <InputLabel id="parking">Bãi xe quản lý</InputLabel>
                <StyledSelectInput
                    labelId="demo-simple-select-label"
                    value={props.parking}
                    onChange={(e: any) => {
                        props.setParking(e.target.value);
                    }}
                    variant="outlined"
                    fullWidth
                    size="small"
                >
                    <MenuItem value={'ALL'}>Tất cả</MenuItem>
                    {listParking.map((item, ind) => {
                        return (
                            <MenuItem key={ind} value={item.ID}>
                                {item.Name}
                            </MenuItem>
                        );
                    })}
                </StyledSelectInput>
            </Stack>
            <ItemInputCustom
                value={props.infoCustomer}
                setValue={props.setInfoCustomer}
                title={'Thông tin khách hàng'}
                plaveholder={'Nhập mã, tên, sđt, email...'}
            />
            <Stack sx={{ width: '10%' }}>
                <Button
                    sx={{
                        bgcolor: '#067DC0',
                        boxShadow: '0px 2px 2px rgba(0, 0, 0, 0.25)',
                        borderRadius: '10px',
                        height: '45px',
                        color: '#fff',
                        fontSize: '14px',
                        fontWeight: 700,
                        lineHeight: '16px',
                        textTransform: 'uppercase',
                        '&:hover': {
                            bgcolor: 'rgba(6, 125, 192, .8)',
                        },
                    }}
                    onClick={props.handleSearch}
                >
                    Tìm kiếm
                </Button>
            </Stack>
        </Stack>
    );
}
