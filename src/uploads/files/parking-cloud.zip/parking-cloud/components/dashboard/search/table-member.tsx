import HeaderTable from '@/components/table/header-table';
import { columnsMember } from '@/mocks/header-mock';
import { MemberModel } from '@/models/member.model';
import { Table, TableBody, useTheme } from '@mui/material';
import { useRouter } from 'next/router';
import DialogUpdateMember from '@/components/dialog/dialog-update/dialog-update-member';
import { useState } from 'react';
import RowTableMember from './row-table-search-member';
export interface ITableMemberProps {
    data: MemberModel[];
    fetchData: () => void;
}

export default function TableMember(props: ITableMemberProps) {
    const { data, fetchData } = props;
    const [itemHandle, setItemHandle] = useState<MemberModel>();
    const [openDialogUpdate, setOpenDialogUpdate] = useState(false);

    return (
        <Table
            sx={{
                borderCollapse: 'separate',
                borderSpacing: '0 10px',
                marginTop: '-10px',
            }}
        >
            {itemHandle && (
                <DialogUpdateMember
                    open={openDialogUpdate}
                    handleClose={() => {
                        setOpenDialogUpdate(false);
                    }}
                    item={itemHandle}
                    handleReload={fetchData}
                />
            )}

            <HeaderTable headerData={columnsMember} />
            <TableBody
                sx={{
                    maxWidth: '800px',
                    '& td': {
                        background: 'rgba(217, 217, 217, 0.2)',
                    },
                    'td:first-of-type': {
                        borderTopLeftRadius: '10px',
                        borderBottomLeftRadius: '10px',
                    },
                    'td:last-of-type': {
                        borderTopRightRadius: '10px',
                        borderBottomRightRadius: '10px',
                    },
                }}
            >
                {data?.map((c: MemberModel, index) => (
                    <RowTableMember data={c} key={index} />
                ))}
            </TableBody>
        </Table>
    );
}
