import { StyledSelectInput } from '@/components/common/style-component';
import { useAppSelector } from '@/hooks/useReudx';
import { Button, InputLabel, MenuItem, Stack } from '@mui/material';
import React from 'react';
import ItemInputCustom from './item-input-custom';

export interface IFormSearchHistoryProps {
    parking: string;
    setParking: (value: string) => void;
    plateNumber: string;
    setPlateNumber: (value: string) => void;
    cardNumber: string;
    setCardNumber: (value: string) => void;
    ticketId: string;
    setTicketId: (value: string) => void;
    handleSearch: () => void;
}

export default function FormSearchHistory(props: IFormSearchHistoryProps) {
    const listParking = useAppSelector((state) => state.parking.parkings);
    return (
        <Stack
            sx={{
                flexDirection: 'row',
                justifyContent: 'space-between',
                alignItems: 'flex-end',
            }}
        >
            <Stack sx={{ width: '22%' }}>
                <InputLabel id="parking">Bãi xe quản lý</InputLabel>
                <StyledSelectInput
                    labelId="demo-simple-select-label"
                    value={props.parking}
                    onChange={(e: any) => {
                        props.setParking(e.target.value);
                    }}
                    variant="outlined"
                    fullWidth
                    size="small"
                >
                    <MenuItem value={'ALL'}>Tất cả</MenuItem>
                    {listParking.map((item, ind) => {
                        return (
                            <MenuItem value={item.ID} key={ind}>
                                {item.Name}
                            </MenuItem>
                        );
                    })}
                </StyledSelectInput>
            </Stack>
            <ItemInputCustom
                value={props.plateNumber}
                setValue={props.setPlateNumber}
                title={'Biển số'}
                plaveholder={'Nhập biển số...'}
            />
            <ItemInputCustom
                value={props.cardNumber}
                setValue={props.setCardNumber}
                title={'Mã thẻ'}
                plaveholder={'Nhập mã thẻ...'}
            />
            <ItemInputCustom
                value={props.ticketId}
                setValue={props.setTicketId}
                title={'Mã phiếu gửi'}
                plaveholder={'Nhập mã phiếu gửi...'}
            />
            <Stack sx={{ width: '10%' }}>
                <Button
                    sx={{
                        bgcolor: '#067DC0',
                        boxShadow: '0px 2px 2px rgba(0, 0, 0, 0.25)',
                        borderRadius: '10px',
                        height: '45px',
                        color: '#fff',
                        fontSize: '14px',
                        fontWeight: 700,
                        lineHeight: '16px',
                        textTransform: 'uppercase',
                        '&:hover': {
                            bgcolor: 'rgba(6, 125, 192, .8)',
                        },
                    }}
                    onClick={props.handleSearch}
                >
                    Tìm kiếm
                </Button>
            </Stack>
        </Stack>
    );
}
