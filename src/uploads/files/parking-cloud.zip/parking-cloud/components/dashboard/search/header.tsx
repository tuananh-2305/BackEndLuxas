import { StyleCustomDateTimePickerComponent } from '@/components/common/custom-datetime-picker/StyleCustomDateTimePickerComponent';
import { StyledOutlinedInput, StyledSelectInput } from '@/components/common/style-component';
import { searchMock } from '@/mocks/search-mock';
import {
    Button,
    Divider,
    IconButton,
    InputLabel,
    MenuItem,
    Select,
    SelectChangeEvent,
    Stack,
    Typography,
} from '@mui/material';
import Image from 'next/image';
import React, { useContext, useEffect, useState } from 'react';
import MenuOpenIcon from '@mui/icons-material/MenuOpen';
import { ContextLayoutDashboard } from '@/components/common/layout/dashboard.layout';
import ItemInputCustom from './item-input-custom';
import { parkingApi } from '@/api/parking-api';
import { useAppSelector } from '@/hooks/useReudx';
import FormSearchHistory from './form-search-history';
import { searchApi } from '@/api/search-api';
import { SearchData } from '@/models/search.model';
import { enqueueSnackbar } from 'notistack';
import FormSearchMember from './form-search-member';
import { showSnackbarWithClose } from '@/hooks/useSnackbarWithClose';
import DashboardHeaderLayout from '../topbar/layout';

export interface IHeaderSearchProps {
    typeSelect: string;
    setTypeSelect: (value: string) => void;
    setData: (value: any) => void;
    page: number;
    setPage: (value: number) => void;
    setMaxPage: (value: number) => void;
    setTotal: (value: number) => void;
    SIZE_PAGE: number;
    loading: boolean;
    setLoading: (value: boolean) => void;
}

export default function HeaderSearch(props: IHeaderSearchProps) {
    const {
        typeSelect,
        setTypeSelect,
        setData,
        page,
        setMaxPage,
        setPage,
        setTotal,
        SIZE_PAGE,
        loading,
        setLoading,
    } = props;
    const [startDate, setStartDate] = useState<Date | null>(
        new Date(new Date().setDate(new Date().getDate() - 30))
    );
    const [endDate, setEndDate] = useState<Date | null>(
        new Date(new Date().setDate(new Date().getDate() + 1))
    );
    const [parking, setParking] = useState('ALL');
    const [plateNumber, setPlateNumber] = useState('');
    const [cardNumber, setCardNumber] = useState('');
    const [ticketId, setTicketId] = useState('');
    const [infoCustomer, setInfoCustomer] = useState('');
    const { setOpenDashboardBar, openDashboardBar } = useContext(ContextLayoutDashboard);
    const [isClickButton, setIsClickButton] = useState(true);

    const handleSearch = (pageNum: number) => {
        if (startDate && endDate) {
            const payload: SearchData = {
                Parking: parking,
                PlateNumber: plateNumber,
                CardNumber: cardNumber,
                Ticket: ticketId,
                StartDate: startDate,
                EndDate: endDate,
                Current: pageNum == 1 ? 0 : (pageNum - 1) * SIZE_PAGE,
                Limit: SIZE_PAGE,
                Type: typeSelect,
                InfoCustomer: infoCustomer,
            };
            setLoading(true);
            searchApi
                .search(payload)
                .then((res) => {
                    setData(res.data?.Data);
                    if (pageNum == 1) {
                        setMaxPage(Math.ceil(res.data?.Total / SIZE_PAGE));
                        setTotal(res.data?.Total);
                    }
                    setIsClickButton(false);
                })
                .finally(() => {
                    setLoading(false);
                });
        } else {
            showSnackbarWithClose('Vui lòng chọn thời gian bắt đầu và thời gian kết thúc!', {
                variant: 'error',
            });
        }
    };
    useEffect(() => {
        if (isClickButton) return;
        handleSearch(page);
    }, [page]);
    return (
        <Stack>
            <DashboardHeaderLayout>
                <Stack
                    sx={{
                        alignItems: 'center',
                        justifyContent: 'space-between',
                        pr: '10px',
                        flex: 1,
                    }}
                    spacing={'10px'}
                    direction={'row'}
                >
                    <Typography
                        sx={{ fontSize: '20px', fontWeight: 700, lineHeight: '24.2px', pl: '20px' }}
                    >
                        Tìm kiếm nhanh
                    </Typography>
                    <Stack spacing={'10px'} direction={'row'}>
                        <Stack direction="row" sx={{}} spacing={'10px'} alignItems="center">
                            <Typography>Hướng dẫn</Typography>
                            <Image
                                src="/icons/arrow-up-right.svg"
                                width={20}
                                height={20}
                                alt="arrow"
                            />
                        </Stack>
                        <Stack>
                            <Select
                                labelId="search"
                                id="demo-simple-select-province"
                                onChange={(event: SelectChangeEvent) => {
                                    setTypeSelect(event.target.value as string);
                                    setData([]);
                                    setPage(1);
                                }}
                                value={typeSelect}
                                fullWidth
                                size="small"
                                sx={{
                                    borderRadius: '10px',
                                    width: '200px',
                                }}
                            >
                                {searchMock.map((item: any, index) => (
                                    <MenuItem value={item.ID} key={index}>
                                        {item.Name}
                                    </MenuItem>
                                ))}
                            </Select>
                        </Stack>
                        <Stack spacing={'15px'} direction="row">
                            <Stack
                                direction="row"
                                sx={{
                                    border: '1px solid rgba(85, 89, 93, 0.5)',
                                    borderRadius: '10px',
                                    overflow: 'hidden',
                                    height: '40px',
                                }}
                                spacing={'1px'}
                            >
                                <StyleCustomDateTimePickerComponent
                                    time={startDate}
                                    setTime={(date: Date | null) => setStartDate(date)}
                                    //năm 9999
                                    maxTime={() => endDate}
                                    minTime={() => null}
                                    disShowCancel={true}
                                    startTitle={'Từ '}
                                />
                                <Divider
                                    orientation="vertical"
                                    flexItem
                                    sx={{ borderRightWidth: 1, borderColor: '#D9D9D9' }}
                                />
                                <StyleCustomDateTimePickerComponent
                                    time={endDate}
                                    setTime={(date: Date | null) => setEndDate(date)}
                                    maxTime={() => null}
                                    minTime={() => startDate}
                                    disShowCancel={true}
                                    startTitle={'Đến '}
                                />
                            </Stack>
                        </Stack>
                    </Stack>
                </Stack>
            </DashboardHeaderLayout>
            <Stack sx={{ p: '0 20px 20px 20px' }}>
                {typeSelect === 'HISTORY' ? (
                    <FormSearchHistory
                        cardNumber={cardNumber}
                        parking={parking}
                        plateNumber={plateNumber}
                        setCardNumber={setCardNumber}
                        setParking={setParking}
                        setPlateNumber={setPlateNumber}
                        setTicketId={setTicketId}
                        ticketId={ticketId}
                        handleSearch={() => {
                            setIsClickButton(true);
                            setPage(1);
                            handleSearch(1);
                        }}
                    />
                ) : (
                    <FormSearchMember
                        parking={parking}
                        setParking={setParking}
                        handleSearch={() => {
                            setIsClickButton(true);
                            setPage(1);
                            handleSearch(1);
                        }}
                        setInfoCustomer={setInfoCustomer}
                        infoCustomer={infoCustomer}
                    />
                )}
            </Stack>
        </Stack>

        // <Stack sx={{ p: 2 }} spacing={2}>
        //     <Stack sx={{ flexDirection: 'row', justifyContent: 'space-between' }}>
        //         <Stack direction={'row'} sx={{ alignItems: 'center' }}>
        //             <IconButton
        //                 onClick={() => setOpenDashboardBar(true)}
        //                 sx={{
        //                     transform: 'rotate(180deg)',
        //                     display: openDashboardBar ? 'none' : 'flex',
        //                 }}
        //             >
        //                 <MenuOpenIcon />
        //             </IconButton>
        //             <Typography sx={{ fontSize: '20px', fontWeight: 700, lineHeight: '24.2px' }}>
        //                 Tìm kiếm nhanh
        //             </Typography>
        //         </Stack>
        //         <Stack direction="row" spacing="40px">
        //             <Stack direction="row" sx={{}} spacing={'10px'} alignItems="center">
        //                 <Typography>Hướng dẫn</Typography>
        //                 <Image src="/icons/arrow-up-right.svg" width={20} height={20} alt="arrow" />
        //             </Stack>
        //             <Stack>
        //                 <Select
        //                     labelId="search"
        //                     id="demo-simple-select-province"
        //                     onChange={(event: SelectChangeEvent) => {
        //                         setTypeSelect(event.target.value as string);
        //                         setData([]);
        //                         setPage(1);
        //                     }}
        //                     value={typeSelect}
        //                     fullWidth
        //                     size="small"
        //                     sx={{
        //                         borderRadius: '10px',
        //                         width: '200px',
        //                     }}
        //                 >
        //                     {searchMock.map((item: any, index) => (
        //                         <MenuItem value={item.ID} key={index}>
        //                             {item.Name}
        //                         </MenuItem>
        //                     ))}
        //                 </Select>
        //             </Stack>
        //             <Stack spacing={'15px'} direction="row">
        //                 <Stack
        //                     direction="row"
        //                     sx={{
        //                         border: '1px solid rgba(85, 89, 93, 0.5)',
        //                         borderRadius: '10px',
        //                         overflow: 'hidden',
        //                     }}
        //                     spacing={'1px'}
        //                 >
        //                     <StyleCustomDateTimePickerComponent
        //                         time={startDate}
        //                         setTime={(date: Date | null) => setStartDate(date)}
        //                         //năm 9999
        //                         maxTime={() => endDate}
        //                         minTime={() => null}
        //                         disShowCancel={true}
        //                         startTitle={'Từ '}
        //                     />
        //                     <Divider
        //                         orientation="vertical"
        //                         flexItem
        //                         sx={{ borderRightWidth: 1, borderColor: '#D9D9D9' }}
        //                     />
        //                     <StyleCustomDateTimePickerComponent
        //                         time={endDate}
        //                         setTime={(date: Date | null) => setEndDate(date)}
        //                         maxTime={() => null}
        //                         minTime={() => startDate}
        //                         disShowCancel={true}
        //                         startTitle={'Đến '}
        //                     />
        //                 </Stack>
        //             </Stack>
        //         </Stack>
        //     </Stack>
        //     {typeSelect === 'HISTORY' ? (
        //         <FormSearchHistory
        //             cardNumber={cardNumber}
        //             parking={parking}
        //             plateNumber={plateNumber}
        //             setCardNumber={setCardNumber}
        //             setParking={setParking}
        //             setPlateNumber={setPlateNumber}
        //             setTicketId={setTicketId}
        //             ticketId={ticketId}
        //             handleSearch={() => {
        //                 setIsClickButton(true);
        //                 setPage(1);
        //                 handleSearch(1);
        //             }}
        //         />
        //     ) : (
        //         <FormSearchMember
        //             parking={parking}
        //             setParking={setParking}
        //             handleSearch={() => {
        //                 setIsClickButton(true);
        //                 setPage(1);
        //                 handleSearch(1);
        //             }}
        //             setInfoCustomer={setInfoCustomer}
        //             infoCustomer={infoCustomer}
        //         />
        //     )}
        // </Stack>
    );
}
