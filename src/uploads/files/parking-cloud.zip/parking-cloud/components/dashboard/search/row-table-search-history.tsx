import { HistoryModel } from '@/models/index';
import { formatMoney, getDateTime } from '@/ultis/index';
import { TableCell, TableRow } from '@mui/material';

const BACKEND_DOMAIN = process.env.NEXT_PUBLIC_SERVER_PARKING_DOMAIN;

export interface IRowTableSearchHistoryProps {
    data: HistoryModel;
    setOpen: any;
    setDataDetail: any;
}

export default function RowTableSearchHistory(props: IRowTableSearchHistoryProps) {
    const { data, setOpen, setDataDetail } = props;

    return (
        <TableRow
            sx={{
                '&:last-child td, &:last-child th': { border: 0 },
                '&:not(:last-child)': { marginBottom: '10px' },
                cursor: 'pointer',
            }}
            onClick={() => {
                setDataDetail(data);
                setOpen(true);
            }}
        >
            <TableCell>{data?.VehicleTypeId?.Name}</TableCell>
            <TableCell>{data?.PlateNumberIn}</TableCell>

            <TableCell>{data?.CodeCardIn}</TableCell>
            <TableCell>{getDateTime(data?.TimeIn)}</TableCell>
            <TableCell>{data?.CodeCardOut}</TableCell>
            <TableCell>{getDateTime(data?.TimeOut)}</TableCell>
            <TableCell>{formatMoney(data?.Price)}</TableCell>
        </TableRow>
    );
}
