import { Stack } from '@mui/material';
import HelpBtn from './components/help-btn';
import SelectOption from './components/select-option';
import SelectTime from './components/select-time';
import DashboardHeaderLayout from './layout';
export interface ITopBarDashboardProps {
    startDate: Date | null;
    handleStartDateChange: any;
    endDate: Date | null;
    handleEndDateChange: any;
}

export default function TopBarDashboard(props: ITopBarDashboardProps) {
    const { startDate, handleStartDateChange, endDate, handleEndDateChange } = props;

    return (
        <DashboardHeaderLayout>
            <Stack
                sx={{
                    alignItems: 'center',
                    justifyContent: 'end',
                    pr: '10px',
                    flex: 1,
                }}
                spacing={'10px'}
                direction={'row'}
            >
                <HelpBtn />
                {/* select time */}
                <SelectTime
                    startDate={startDate}
                    handleStartDateChange={handleStartDateChange}
                    endDate={endDate}
                    handleEndDateChange={handleEndDateChange}
                />

                {/* select */}
                <SelectOption />
            </Stack>
        </DashboardHeaderLayout>
    );
}
