import ImageNextjs from '@/components/common/image';
import { Stack, Tooltip, Typography } from '@mui/material';
import * as React from 'react';
import styles from '../topbar.module.css';
import { useState } from 'react';
import { getDateTime2 } from '@/ultis/index';
import PickDateMuiPopup from '@/components/common/custom-datetime-picker/picker-mui-popover';
import KeyboardArrowDownIcon from '@mui/icons-material/KeyboardArrowDown';

export interface ISelectTimeProps {
    startDate: Date | null;
    handleStartDateChange: any;
    endDate: Date | null;
    handleEndDateChange: any;
}

export default function SelectTime(props: ISelectTimeProps) {
    const { startDate, handleStartDateChange, endDate, handleEndDateChange } = props;

    const color = {
        red: '#E42727',
        white: '#ffffff',
        green: '#3CD856',
        grey1: '#CDD2D1',
        primary: '#007DC0',
        textBlack: '#323232',
        textBlack2: '#55595D',
    };

    const [anchorEl, setAnchorEl] = useState<HTMLDivElement | null>(null);

    return (
        <>
            <Stack
                onClick={(event: any) => setAnchorEl(event.currentTarget)}
                direction="row"
                sx={{
                    // border: `1px solid ${color.grey1}`,
                    border: anchorEl != null ? '1px solid #007DC0' : `1px solid ${color.grey1}`,
                    transition: 'all 0.35s ease-in-out',
                    borderRadius: '5px',
                    overflow: 'hidden',
                    height: '40px',
                    padding: { md: '0 10px', lg: '0 10px' },
                    alignItems: 'center',
                    justifyContent: 'center',
                    cursor: 'pointer',
                }}
            >
                <ImageNextjs
                    path={'icons/calendar_icon.svg'}
                    sx={{
                        width: { md: '18px', lg: '24px' },
                        height: { md: '18px', lg: '24px' },
                        pr: '5px',
                    }}
                />
                <Tooltip title="Thời gian bắt đầu">
                    <Stack
                        sx={{
                            cursor: 'pointer',
                            alignItems: 'center',
                            justifyContent: 'center',
                        }}
                    >
                        <Stack
                            sx={{
                                backgroundColor: 'transparent',
                                cursor: 'pointer',
                            }}
                            direction="row"
                            alignItems="center"
                            justifyContent="space-between"
                        >
                            <Stack sx={{ flex: 1 }}>
                                <Typography
                                    className={styles.text}
                                    sx={{
                                        fontSize: { md: '13px', lg: '16px' },
                                        minWidth: '107px',
                                    }}
                                >
                                    {startDate ? getDateTime2(startDate.toString()) : 'Chưa đặt'}
                                </Typography>
                            </Stack>
                        </Stack>
                    </Stack>
                </Tooltip>
                <Typography sx={{ px: '5px' }}>-</Typography>
                <Tooltip title="Thời gian kết thúc">
                    <Stack
                        sx={{
                            cursor: 'pointer',
                            alignItems: 'center',
                            justifyContent: 'center',
                        }}
                    >
                        <Stack
                            sx={{
                                backgroundColor: 'transparent',
                                cursor: 'pointer',
                            }}
                            direction="row"
                            alignItems="center"
                            justifyContent="space-between"
                        >
                            <Stack>
                                <Typography
                                    className={styles.text}
                                    sx={{
                                        fontSize: { md: '13px', lg: '16px' },
                                        minWidth: '107px',
                                    }}
                                >
                                    {endDate ? getDateTime2(endDate.toString()) : 'Chưa đặt'}
                                </Typography>
                            </Stack>
                        </Stack>
                    </Stack>
                </Tooltip>
                <KeyboardArrowDownIcon
                    sx={{
                        width: '24px',
                        height: '24px',
                        transform: anchorEl == null ? 'rotate(0deg)' : 'rotate(-180deg)',
                        transition: 'all 0.35s ease-in-out',
                    }}
                />
            </Stack>
            <PickDateMuiPopup
                anchorEl={anchorEl}
                startTime={startDate}
                endTime={endDate}
                minTime={null}
                maxTime={endDate}
                onclose={() => setAnchorEl(null)}
                timeStartchange={(t: Date | null) => handleStartDateChange(t)}
                timeEndchange={(t: Date | null) => handleEndDateChange(t)}
            />
        </>
    );
}
