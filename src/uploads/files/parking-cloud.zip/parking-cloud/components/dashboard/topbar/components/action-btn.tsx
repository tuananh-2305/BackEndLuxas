import ImageNextjs from '@/components/common/image';
import { Popover, Stack, Tooltip, Typography } from '@mui/material';
import * as React from 'react';

import { useRouter } from 'next/router';
import { ItemNavRight, navigationMock } from '../../right-bar/data.mock';
import DashboardIcon from './svg-icon/dashboard';
import SearchIcon from './svg-icon/search';
import HistoryIcon from './svg-icon/history';
import ReportIcon from './svg-icon/report';
import CarIcon from './svg-icon/car';
import CardIcon from './svg-icon/card';
import PhoneIcon from './svg-icon/phone';
import ChangeIcon from './svg-icon/change';
import PaymentIcon from './svg-icon/payment';
export interface IActionBtnProps {}

export default function ActionBtn(props: IActionBtnProps) {
    const color = {
        red: '#E42727',
        white: '#ffffff',
        green: '#3CD856',
        grey1: '#CDD2D1',
        primary: '#007DC0',
        textBlack: '#323232',
        textBlack2: '#55595D',
    };

    const [anchorEl, setAnchorEl] = React.useState<HTMLButtonElement | null>(null);

    const handleClose = () => {
        setAnchorEl(null);
    };

    const open = Boolean(anchorEl);
    const id = open ? 'simple-popover' : undefined;

    const router = useRouter();
    // get path
    const pathName = router.pathname;

    const renderIcon = (key: string, isActived: boolean) => {
        switch (key) {
            case 'dashboard':
                return <DashboardIcon color={!isActived ? '#55595D' : '#ffffff'} />;
            case 'search':
                return <SearchIcon color={!isActived ? '#55595D' : '#ffffff'} />;
            case 'history':
                return <HistoryIcon color={!isActived ? '#55595D' : '#ffffff'} />;
            case 'paymemt':
                return <PaymentIcon color={!isActived ? '#55595D' : '#ffffff'} />;
            case 'report':
                return <ReportIcon color={!isActived ? '#55595D' : '#ffffff'} />;
            case 'vehicle':
                return <CarIcon color={!isActived ? '#55595D' : '#ffffff'} />;
            case 'loss-report':
                return <CardIcon color={!isActived ? '#55595D' : '#ffffff'} />;
            case 'phone':
                return <PhoneIcon color={!isActived ? '#55595D' : '#ffffff'} />;
            default:
                return <DashboardIcon color={!isActived ? '#55595D' : '#ffffff'} />;
        }
    };

    return (
        <>
            {/* btn */}
            <Tooltip title="Mở thanh công cụ phải.">
                <Stack
                    // onClick={() => setOpenRightBar(true)}
                    onClick={(event: any) => setAnchorEl(event.currentTarget)}
                    sx={{
                        backgroundColor: open ? '#007DC0' : '#78C6E7',
                        boxShadow: '0px 2px 2px rgba(0, 0, 0, 0.25)',
                        width: '40px',
                        height: '40px',
                        borderRadius: '25px',
                        cursor: 'pointer',
                        minWidth: '40px',
                        minHeight: '40px',
                        padding: '1px',
                        transition: 'all .25s ease',
                        ':hover': {
                            background: '#007DC0',
                        },
                    }}
                    justifyContent="center"
                    alignItems="center"
                >
                    <ImageNextjs
                        path={'/icons/dashboard_icon.svg'}
                        sx={{ width: '25px', height: '25px' }}
                    />
                </Stack>
            </Tooltip>
            {/* popup */}
            <Popover
                id={id}
                open={open}
                anchorEl={anchorEl}
                onClose={handleClose}
                anchorOrigin={{
                    vertical: 'bottom',
                    horizontal: 'left',
                }}
                sx={{ mt: '20px' }}
            >
                <Stack sx={{ padding: '16px', minWidth: '300px' }}>
                    <Stack spacing={'16px'}>
                        {navigationMock.map((v: ItemNavRight, k: any) => {
                            const isActived = v?.path
                                ? v?.path === '/dashboard'
                                    ? pathName === v.path
                                    : pathName.includes(v.path)
                                : false;
                            return (
                                <Stack
                                    key={`navigation-item-right-bar-${k}`}
                                    direction="row"
                                    sx={{
                                        padding: '8px 16px',
                                        transition: 'all ease .5s',
                                        borderRadius: '8px',
                                        cursor: 'pointer',
                                        '&:hover ': {
                                            boxShadow: ' rgba(149, 157, 165, 0.24) 0px 8px 14px;',
                                        },
                                        backgroundColor: isActived ? '#007DC0' : 'transparent',
                                        color: isActived ? 'white' : '#55595D',
                                        alignItems: 'center',
                                        textTransform: 'capitalize',
                                    }}
                                    spacing={'15px'}
                                    onClick={() => {
                                        if (v?.path) {
                                            router.replace(v?.path);
                                        }
                                        // close();
                                    }}
                                >
                                    {/* <ImageNextjs path={v.icon} /> */}
                                    {/* <v.icon /> */}
                                    <Stack
                                        sx={{
                                            width: '25px',
                                            height: '25px',
                                            alignItems: 'center',
                                            justifyContent: 'center',
                                        }}
                                    >
                                        {renderIcon(v.key, isActived)}
                                    </Stack>
                                    <Typography
                                        sx={{
                                            fontSize: '16px',
                                            fontWeight: isActived ? '700' : '400',
                                        }}
                                    >
                                        {v.title}
                                    </Typography>
                                </Stack>
                            );
                        })}

                        <Stack sx={{ border: '1px dashed #9AA0A6;' }} />
                        <Stack
                            direction="row"
                            sx={{
                                padding: '8px 16px',
                                transition: 'all ease .5s',
                                borderRadius: '8px',
                                cursor: 'pointer',
                                '&:hover ': {
                                    boxShadow: ' rgba(149, 157, 165, 0.24) 0px 8px 24px;',
                                },
                                color: pathName.includes('/dashboard/quick-access')
                                    ? 'white'
                                    : '#55595D',
                                backgroundColor: pathName.includes('/dashboard/quick-access')
                                    ? '#007DC0'
                                    : 'transparent',
                                textTransform: 'capitalize',
                            }}
                            onClick={() => {
                                router.replace('/dashboard/quick-access');
                                handleClose();
                                // close();
                            }}
                            spacing={'15px'}
                        >
                            <Stack
                                sx={{
                                    width: '25px',
                                    height: '25px',
                                    alignItems: 'center',
                                    justifyContent: 'center',
                                }}
                            >
                                <ChangeIcon
                                    color={
                                        pathName.includes('/dashboard/quick-access')
                                            ? '#ffffff'
                                            : '#55595D'
                                    }
                                />
                            </Stack>
                            <Typography>Xử Lý Ra Vào Khẩn Cấp</Typography>
                        </Stack>

                        <Stack sx={{ border: '1px dashed #9AA0A6;' }} />
                        <Stack
                            direction="row"
                            sx={{
                                padding: '8px 16px',
                                transition: 'all ease .5s',
                                borderRadius: '8px',
                                cursor: 'pointer',
                                '&:hover ': {
                                    boxShadow: ' rgba(149, 157, 165, 0.24) 0px 8px 24px;',
                                },
                                color: '#55595D',
                                backgroundColor: 'transparent',
                                textTransform: 'capitalize',
                            }}
                            spacing={'15px'}
                        >
                            <ImageNextjs path="/icons/u_location-pin-alt.svg" />
                            <Typography>Quản Lý Vị Trí Đỗ</Typography>
                        </Stack>
                    </Stack>
                </Stack>
            </Popover>
        </>
    );
}
