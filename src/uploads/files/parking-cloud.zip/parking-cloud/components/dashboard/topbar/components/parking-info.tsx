import ImageNextjs from '@/components/common/image';
import { useAppSelector } from '@/hooks/index';
import { Popover, Stack, Typography } from '@mui/material';
import * as React from 'react';
import { useContext } from 'react';
import { ContextDashboard } from '../../dashboard-context';
import { countOnline, getNameAddress, showAddress } from '@/ultis/index';
import KeyboardArrowDownIcon from '@mui/icons-material/KeyboardArrowDown';
import { LeftDashboardPopup } from '../../left-bar/left-bar-popup';
import { ContextLayoutDashboard } from '@/components/common';

export interface IParkingInfoProps {}

export default function ParkingInfo(props: IParkingInfoProps) {
    const dashboardChose = useAppSelector((state) => state.parking.chooseDashboard);
    const [anchorElParking, setAnchorElParking] = React.useState<HTMLButtonElement | null>(null);
    const { setOpenDashboardBar, openDashboardBar } = React.useContext(ContextLayoutDashboard);
    const { device } = useContext(ContextDashboard);
    const countOnlineNumber = countOnline(device);
    const deviceErr = device?.length - countOnlineNumber;
    const color = {
        red: '#E42727',
        white: '#ffffff',
        green: '#3CD856',
        grey1: '#CDD2D1',
        primary: '#007DC0',
        textBlack: '#323232',
        textBlack2: '#55595D',
    };
    return (
        <>
            <Stack
                direction={'row'}
                sx={{
                    cursor: 'pointer',
                    justifyContent: 'center',
                }}
                spacing={1}
                onClick={(e: any) => setAnchorElParking(e.currentTarget)}
            >
                <Stack
                    sx={{
                        background: deviceErr > 0 ? color.red : color.green,
                        width: 15,
                        height: 15,
                        borderRadius: '50%',
                        mt: '5px',
                        alignItems: 'center',
                        justifyContent: 'center',
                    }}
                />
                <Stack sx={{ maxWidth: '284px' }}>
                    <Stack
                        direction={'row'}
                        sx={{
                            alignItems: 'center',
                        }}
                        spacing={1}
                    >
                        <ImageNextjs
                            sx={{
                                width: 16,
                                height: 16,
                                alignContent: 'center',
                                justifyContent: 'center',
                            }}
                            path={'/icons/parking_icon.svg'}
                            alt="language-icon"
                        />
                        <Typography
                            sx={{
                                color: color.primary,
                                fontWeight: 700,
                                fontSize: { md: '20px', lg: '24px' },
                                lineHeight: '28.13px',

                                display: '-webkit-box',
                                WebkitLineClamp: 1,
                                lineClamp: 1,
                                WebkitBoxOrient: 'vertical',
                                overflow: 'hidden',
                                textOverflow: 'ellipsis',
                            }}
                        >
                            {dashboardChose?.Name ?? ''}
                        </Typography>
                    </Stack>
                    <Typography
                        sx={{
                            fontSize: { md: '12px', lg: '14px' },
                            fontWeight: 300,
                            lineHeight: '16px',
                            color: color.textBlack,
                            display: '-webkit-box',
                            WebkitLineClamp: 1,
                            lineClamp: 1,
                            WebkitBoxOrient: 'vertical',
                            overflow: 'hidden',
                            textOverflow: 'ellipsis',
                            maxWidth: '220px',
                        }}
                    >
                        {showAddress(
                            dashboardChose?.Address || '',
                            getNameAddress(dashboardChose?.Ward),
                            getNameAddress(dashboardChose?.District),
                            getNameAddress(dashboardChose?.Province)
                        )}
                    </Typography>
                </Stack>
                <Stack sx={{}}>
                    <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="17"
                        height="16"
                        viewBox="0 0 17 16"
                        fill="none"
                        style={{
                            transform: Boolean(anchorElParking) ? 'rotate(180deg)' : 'rotate(0deg)',
                            transition: 'all 0.25s ease-in-out',
                            marginTop: '5px',
                        }}
                    >
                        <path
                            d="M9.0269 14.9833C8.52953 15.5801 7.64081 15.6199 7.09126 15.1027L6.97896 14.9833L0.314419 6.98584C-0.376163 6.15714 0.154944 4.91851 1.18754 4.80762L1.33839 4.79962L14.6675 4.79962C15.7462 4.79962 16.3577 6.00058 15.7819 6.86483L15.6914 6.98584L9.0269 14.9833Z"
                            fill="#007DC0"
                        />
                    </svg>
                </Stack>
                {/* <KeyboardArrowDownIcon sx={{ mt: '5px', width: '24px', height: '24px' }} /> */}
            </Stack>
            <Popover
                open={Boolean(anchorElParking)}
                anchorEl={anchorElParking}
                onClose={() => setAnchorElParking(null)}
                anchorOrigin={{
                    vertical: 'bottom',
                    horizontal: 'left',
                }}
            >
                <LeftDashboardPopup
                    open={openDashboardBar}
                    close={() => setOpenDashboardBar(false)}
                />
            </Popover>
        </>
    );
}
