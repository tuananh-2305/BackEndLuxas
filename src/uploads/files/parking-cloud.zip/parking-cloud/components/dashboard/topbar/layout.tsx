import { LayoutProps } from '@/models/index';
import { Stack } from '@mui/material';
import ActionBtn from './components/action-btn';
import ParkingInfo from './components/parking-info';
import { useAppSelector } from '@/hooks';

export interface IDashboardHeaderLayoutProps {}
export default function DashboardHeaderLayout({ children }: LayoutProps) {
    const parkings = useAppSelector((state) => state.parking.parkings);
    return (
        <Stack
            direction="row"
            justifyContent="space-between"
            sx={{
                padding: '10px 20px',
                background: '#fff',
                height: '80px',
                alignItems: 'center',
            }}
        >
            {/* parking choose */}
            {parkings.length !== 0 ? <ParkingInfo /> : <></>}

            {children}
            <ActionBtn />
        </Stack>
    );
}
