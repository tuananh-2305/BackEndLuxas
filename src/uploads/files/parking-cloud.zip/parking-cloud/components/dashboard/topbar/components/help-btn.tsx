import { Stack, Tooltip, Typography } from '@mui/material';
import * as React from 'react';
import Image from 'next/image';

export interface IHelpBtnProps {}

export default function HelpBtn(props: IHelpBtnProps) {
    const color = {
        red: '#E42727',
        white: '#ffffff',
        green: '#3CD856',
        grey1: '#CDD2D1',
        primary: '#007DC0',
        textBlack: '#323232',
        textBlack2: '#55595D',
    };
    return (
        <Tooltip title="Hướng dẫn">
            <Stack
                direction="row"
                sx={{ cursor: 'pointer' }}
                spacing={{ md: '0', lg: '10px' }}
                alignItems="center"
                onClick={() => {
                    window.open(
                        'https://release.oryzacloud.vn/docs/category/gi%E1%BA%A3i-ph%C3%A1p',
                        '_blank'
                    );
                }}
            >
                <Typography
                    sx={{
                        color: color.textBlack2,
                        fontSize: { md: '12px', lg: '14px' },
                        fontWeight: 400,
                        minWidth: '60px',
                    }}
                >
                    Hướng dẫn
                </Typography>
                <Image src="/icons/arrow-up-right.svg" width={20} height={20} alt="arrow" />
            </Stack>
        </Tooltip>
    );
}
