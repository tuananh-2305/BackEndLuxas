import { historyInOutApi } from '@/api/index';
import { memberApi } from '@/api/member-api';
import { AvatarCustom } from '@/components/common';
import ActionTable from '@/components/common/action-table/action-table';
import DialogUpdateGroupHistory from '@/components/dialog/dialog-update/dialog-update-group-role';
import { HistoryModel } from '@/models/index';
import { checkPlateNo, formatMoney, formatNumberVn, getDateTime } from '@/ultis/index';
import { MenuItem, Stack, TableCell, TableRow, Typography } from '@mui/material';
import { enqueueSnackbar } from 'notistack';
import { useState } from 'react';

const BACKEND_DOMAIN = process.env.NEXT_PUBLIC_SERVER_PARKING_DOMAIN;

export interface IRowTableHistoryProps {
    data: HistoryModel;
    setOpen: any;
    reloadData: () => void;
    setDataDetail: any;
}

export default function RowTableHistory(props: IRowTableHistoryProps) {
    const { data, setOpen, reloadData, setDataDetail } = props;

    // function formatPlateno(input: string): string {
    //     const matches = input.match(/(\d+)([A-Z])?(\d+)(\d+)(\-\d+)?/);

    //     if (matches) {
    //         const [, prefix, letter, middleDigits, lastDigits, hyphenSuffix] = matches;
    //         return `${prefix}${letter ? letter + '-' : ''}${middleDigits}-${lastDigits}${
    //             hyphenSuffix || ''
    //         }`;
    //     }

    //     return input;
    // }
    function splitString(input: string, lengthOfLastPart: number): [string, string] {
        if (lengthOfLastPart >= input.length) {
            return ['', input];
        }

        const lastPart = input.slice(-lengthOfLastPart);
        const remainingPart = input.slice(0, -lengthOfLastPart);

        return [remainingPart, lastPart];
    }

    function formatPlateno(input: string): string {
        const matches = input.match(/(\d+)([A-Z])(\d+)$/);

        if (matches) {
            const [, prefix, letter, suffix] = matches;

            if (suffix.length >= 6) {
                const [remainingPart, lastPart] = splitString(suffix, 5);
                return `${prefix}${letter}${remainingPart}-${lastPart}`;
            } else {
                return `${prefix}${letter}-${suffix}`;
            }
        }

        return input;
    }

    const processPlateNumber = () => {
        if (data?.PlateNumberIn) {
            if (checkPlateNo(data?.PlateNumberIn)) {
                return formatPlateno(data?.PlateNumberIn);
            } else {
                return data?.PlateNumberIn;
            }
        } else {
            return 'Không có biển số';
        }
    };

    return (
        <TableRow
            sx={{
                '&:last-child td, &:last-child th': { border: 0 },
                '&:not(:last-child)': { marginBottom: '10px' },
                cursor: 'pointer',
            }}
            onClick={() => {
                setDataDetail(data);
                setOpen(true);
            }}
        >
            <TableCell>{data?.VehicleTypeId?.Name}</TableCell>
            <TableCell>{processPlateNumber()}</TableCell>

            <TableCell>{data?.CodeCardIn}</TableCell>
            <TableCell>{data?.IdCard}</TableCell>
            <TableCell>{getDateTime(data?.TimeIn)}</TableCell>
            <TableCell>{getDateTime(data?.TimeOut)}</TableCell>
            <TableCell>{formatMoney(Number(data?.Price))}</TableCell>
        </TableRow>
    );
}
