import { Popover, Stack, Typography } from '@mui/material';
import { useRef, useState } from 'react';

interface TypeHistorySelectProps {
    type: 'ALL' | 'MEMBER' | 'GUEST';
    change: (v: 'ALL' | 'MEMBER' | 'GUEST') => void;
}

export const TypeHistorySelect = (props: TypeHistorySelectProps) => {
    const { change, type } = props;
    const ref = useRef<HTMLDivElement | null>(null);
    const [open, setOpen] = useState(false);

    const generatorTitle = () => {
        switch (type) {
            case 'ALL':
                return 'Tất cả khách hàng';
            case 'MEMBER':
                return 'Cư dân';
            case 'GUEST':
                return 'Vãng lai';
            default:
                return 'Chưa thiết lập';
        }
    };

    return (
        <Stack>
            <Stack
                ref={ref}
                sx={{
                    width: '200px',
                    border: '1px solid #55595D',
                    padding: '5px 10px',
                    borderRadius: '5px',
                    cursor: 'pointer',
                }}
                onClick={() => setOpen(true)}
            >
                <Typography sx={{ fontSize: '12px', fontWeight: 700 }}>
                    {generatorTitle()}
                </Typography>
            </Stack>
            <Popover
                open={open}
                anchorEl={ref.current}
                onClose={() => setOpen(false)}
                anchorOrigin={{
                    vertical: 'bottom',
                    horizontal: 'left',
                }}
            >
                <Stack sx={{ width: `${ref.current?.clientWidth}px` }}>
                    <Stack
                        sx={{
                            padding: '5px 10px',
                            cursor: 'pointer',
                            '&:hover': {
                                backgroundColor: '#d9d9d9',
                            },
                        }}
                        onClick={() => {
                            change('ALL');
                            setOpen(false);
                        }}
                    >
                        <Typography
                            sx={{
                                fontSize: '12px',
                                fontWeight: 700,
                            }}
                        >
                            Tất cả
                        </Typography>
                    </Stack>
                    <Stack
                        sx={{
                            padding: '5px 10px',
                            cursor: 'pointer',
                            '&:hover': {
                                backgroundColor: '#d9d9d9',
                            },
                        }}
                        onClick={() => {
                            change('MEMBER');
                            setOpen(false);
                        }}
                    >
                        <Typography sx={{ fontSize: '12px', fontWeight: 700 }}>Cư dân</Typography>
                    </Stack>
                    <Stack
                        sx={{
                            padding: '5px 10px',
                            cursor: 'pointer',
                            '&:hover': {
                                backgroundColor: '#d9d9d9',
                            },
                        }}
                        onClick={() => {
                            change('GUEST');
                            setOpen(false);
                        }}
                    >
                        <Typography sx={{ fontSize: '12px', fontWeight: 700 }}>Vãng lai</Typography>
                    </Stack>
                </Stack>
            </Popover>
        </Stack>
    );
};
