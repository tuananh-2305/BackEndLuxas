import HeaderTable from '@/components/table/header-table';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import ArrowForwardIcon from '@mui/icons-material/ArrowForward';
import {
    Box,
    Pagination,
    PaginationItem,
    Stack,
    Table,
    TableBody,
    TableContainer,
    useTheme,
} from '@mui/material';
import RowTableHistory from './row-table-history';
import { SettingEmptyComponent } from '@/components/settings/empty';
import { useState } from 'react';
import DialogUpdateGroupHistory from '@/components/dialog/dialog-update/dialog-update-group-role';
import { useRouter } from 'next/router';
import { columnsHistory } from '@/mocks/index';
import { HistoryModel } from '@/models/index';
import { useAppSelector } from '@/hooks/useReudx';
import DialogDetailHistory from '@/components/dialog/dialog-detail-history/dialog-detail-history';
import { formatTextPagination } from '@/ultis/index';

export interface ITableHistoryProps {
    data: HistoryModel[];
    fetchData: () => void;
    maxPage: number;
    total: number;
    currentSize: number;
}

export default function TableHistory(props: ITableHistoryProps) {
    const { data, fetchData, maxPage, total, currentSize } = props;

    const theme = useTheme();
    const router = useRouter();
    const { page } = router.query;
    const [open, setOpen] = useState(false);
    const [dataDetail, setDataDetail] = useState<HistoryModel>();
    return (
        <TableContainer
            sx={{
                flex: 1,
                display: 'flex',
                flexDirection: 'column',
                justifyContent: 'space-between',
                p: 2,
            }}
        >
            <Table
                sx={{
                    borderCollapse: 'separate',
                    borderSpacing: '0 10px',
                    marginTop: '-10px',
                }}
            >
                <HeaderTable headerData={columnsHistory} isHideAction={true} />
                <TableBody
                    sx={{
                        '& td': {
                            background: 'rgba(217, 217, 217, 0.2)',
                        },
                        'td:first-of-type': {
                            borderTopLeftRadius: '10px',
                            borderBottomLeftRadius: '10px',
                        },
                        'td:last-of-type': {
                            borderTopRightRadius: '10px',
                            borderBottomRightRadius: '10px',
                        },
                    }}
                >
                    {data?.map((c: any, index) => (
                        <RowTableHistory
                            data={c}
                            setOpen={setOpen}
                            key={index}
                            reloadData={fetchData}
                            setDataDetail={setDataDetail}
                        />
                    ))}
                </TableBody>
            </Table>
            {(!data || data?.length === 0) && <SettingEmptyComponent />}
            <Stack position={'relative'} alignItems={'center'}>
                <Pagination
                    count={maxPage}
                    page={
                        page?.toString() && page?.toString() !== 'undefined'
                            ? parseInt(page?.toString())
                            : 1
                    }
                    onChange={(event, page) => {
                        router.push({
                            pathname: router.pathname,
                            query: { page: page },
                        });
                    }}
                    renderItem={(item) => (
                        <PaginationItem
                            components={{ previous: ArrowBackIcon, next: ArrowForwardIcon }}
                            {...item}
                            shape="rounded"
                            sx={{
                                borderRadius: '4px',
                                border: '1px solid #DFE3E8',
                                '&.Mui-selected': {
                                    background: '#fff',
                                    border: '1px solid #067DC0',
                                    color: '#067DC0',
                                },

                                color: theme.palette.text.primary,
                            }}
                        />
                    )}
                    sx={{
                        py: 2,
                    }}
                />
                <Stack
                    position={'absolute'}
                    sx={{
                        right: '60px',
                        top: '0',
                        bottom: '0',
                    }}
                    alignItems={'center'}
                    justifyContent={'center'}
                >
                    {formatTextPagination(currentSize, data?.length, total)}
                </Stack>
            </Stack>

            <DialogDetailHistory
                open={open}
                handleClose={() => setOpen(false)}
                data={dataDetail}
                isUpdateDetail={true}
            />
        </TableContainer>
    );
}
