import { memberTypeApi } from '@/api/member-type-api';
import { useAppSelector } from '@/hooks/useReudx';
import { theme } from '@/ultis/index';
import {
    CircularProgress,
    Dialog,
    DialogActions,
    DialogContent,
    DialogTitle,
    InputLabel,
    Stack,
    useMediaQuery,
} from '@mui/material';
import { enqueueSnackbar } from 'notistack';
import { useEffect, useState } from 'react';
import { StyledOutlinedInput } from '../common/style-component';
import { StyleButton } from '../common/style-component/button';
import { showSnackbarWithClose } from '@/hooks/useSnackbarWithClose';
import { green } from '@mui/material/colors';
import { ComfirmCloseDialog } from './dialog-comfirm-close';
export interface IDialogCreateMemberTypeProps {
    open: boolean;
    reload: () => void;
    handleClose: () => void;
}

export default function DialogCreateMemberType(props: IDialogCreateMemberTypeProps) {
    const { open, handleClose, reload } = props;
    const fullScreen = useMediaQuery(theme.breakpoints.down('md'));
    const [name, setName] = useState<string>('');
    const [description, setDescription] = useState<string>('');
    const chooose = useAppSelector((state) => state.parking.choose);
    const [isLoadingButton, setIsLoadingButton] = useState(false);
    const [openComfirm, setOpenComfirm] = useState(false);

    const handleCreateMemberType = async () => {
        const nameDialog = 'loại cư dân';

        if (!name || name.trim() === '') {
            showSnackbarWithClose(`Tên ${nameDialog} không được để trống`, { variant: 'error' });
            return;
        }

        if (!chooose) {
            showSnackbarWithClose(`Vui lòng chọn bãi đỗ xe`, { variant: 'error' });
            return;
        }
        setIsLoadingButton(true);
        memberTypeApi
            .createMemberType({
                Name: name.trim(),
                ParkingId: chooose.ID,
                Description: description,
            })
            .then(() => {
                reload();
                showSnackbarWithClose(`Tạo ${nameDialog} thành công`, { variant: 'success' });
                handleClose();
            })
            .catch((error) => {
                if (Array.isArray(error?.response?.data?.message)) {
                    error?.response?.data?.message.forEach((item: any) => {
                        showSnackbarWithClose(item, {
                            variant: 'error',
                        });
                    });
                } else {
                    showSnackbarWithClose(
                        error?.response ? error.response.data?.message : error.message,
                        {
                            variant: 'error',
                        }
                    );
                }
            })
            .finally(() => {
                setTimeout(() => {
                    setIsLoadingButton(false);
                }, 1000);
            });
    };
    useEffect(() => {
        if (!open) {
            setName('');
            setDescription('');
            setIsLoadingButton(false);
        }
    }, [open]);

    return (
        <Dialog
            fullScreen={fullScreen}
            open={open}
            onClose={() => {
                if (name || description) {
                    setOpenComfirm(true);
                } else {
                    handleClose();
                }
            }}
            aria-labelledby="responsive-dialog-title"
            sx={{
                '& .MuiPaper-root': {
                    md: { minWidth: '500px', borderRadius: '16px' },
                },
            }}
        >
            <DialogTitle>{'Tạo loại cư dân'}</DialogTitle>
            <DialogContent>
                <Stack py={2} spacing={2}>
                    <Stack>
                        <InputLabel required>Tên</InputLabel>
                        <StyledOutlinedInput
                            autoComplete="off"
                            value={name}
                            onChange={(e) => {
                                setName(e.target.value);
                            }}
                            size="small"
                            fullWidth
                        />
                    </Stack>
                    <Stack>
                        <InputLabel>Mô tả</InputLabel>
                        <StyledOutlinedInput
                            value={description}
                            autoComplete="off"
                            onChange={(e) => {
                                setDescription(e.target.value);
                            }}
                            size="small"
                            fullWidth
                            multiline
                            rows={4}
                        />
                    </Stack>
                </Stack>
            </DialogContent>
            <DialogActions
                sx={{
                    px: 3,
                    pb: 3,
                }}
            >
                <Stack sx={{ m: 1, position: 'relative' }}>
                    <StyleButton
                        variant="contained"
                        onClick={handleCreateMemberType}
                        disabled={isLoadingButton}
                    >
                        Tạo mới
                    </StyleButton>
                    {isLoadingButton && (
                        <CircularProgress
                            size={24}
                            sx={{
                                color: green[500],
                                position: 'absolute',
                                top: '50%',
                                left: '50%',
                                marginTop: '-12px',
                                marginLeft: '-12px',
                            }}
                        />
                    )}
                </Stack>
            </DialogActions>
            {openComfirm ? (
                <ComfirmCloseDialog
                    close={() => setOpenComfirm(false)}
                    action={() => {
                        setOpenComfirm(false);
                        handleClose();
                    }}
                />
            ) : (
                <></>
            )}
        </Dialog>
    );
}
