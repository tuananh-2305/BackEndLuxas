import { companyApi } from '@/api/index';
import { CompanyCreatePayload } from '@/models/index';
import { isValidHttpUrl, theme } from '@/ultis/index';
import {
    Dialog,
    DialogActions,
    DialogContent,
    DialogTitle,
    InputLabel,
    Stack,
    useMediaQuery,
} from '@mui/material';
import Grid2 from '@mui/material/Unstable_Grid2';
import { enqueueSnackbar } from 'notistack';
import { useEffect, useState } from 'react';
import InputAddress from '../common/input/input-address';
import { StyledOutlinedInput } from '../common/style-component';
import { StyleButton } from '../common/style-component/button';
import { showSnackbarWithClose } from '@/hooks/useSnackbarWithClose';
import { HeaderWithSearchAndCreate } from '@/components/common/header-with-search-create';
import { useAppDispatch, useAppSelector } from '@/hooks/useReudx';
import { changeIsCreateDialog } from '@/redux/index';
import { useRouter } from 'next/router';
import { ComfirmCloseDialog } from './dialog-comfirm-close';

export default function DialogCreateCompany() {
    const fullScreen = useMediaQuery(theme.breakpoints.down('md'));

    const isCreate = useAppSelector((state) => state.common.control.isCreate);
    const router = useRouter();
    // const [phone, setPhone] = useState('');
    const [name, setName] = useState('');
    const [sortName, setSortName] = useState('');
    const [website, setWebsite] = useState('');
    const [province, setProvince] = useState<string>('');
    const [district, setDistrict] = useState<string>('');
    const [ward, setWard] = useState<string>('');
    const [address, setAddress] = useState<string>('');
    const [email, setEmail] = useState('');
    const [phone, setPhone] = useState('');
    const [representative, setRepresentative] = useState('');
    const [taxCode, setTaxCode] = useState('');
    const [openComfirm, setOpenComfirm] = useState(false);

    const [isLoading, setIsLoading] = useState(false);
    const nameDialog = 'công ty';

    const dispatch = useAppDispatch();

    const handleCreateCompany = async (e: any) => {
        if (!name || !name.trim()) {
            showSnackbarWithClose('Vui lòng nhập tên công ty', { variant: 'error' });
            return;
        }
        if (!sortName || !sortName.trim()) {
            showSnackbarWithClose('Vui lòng nhập tên viết tắt của công ty', { variant: 'error' });
            return;
        }
        if (sortName.trim().length > 50) {
            showSnackbarWithClose('Tên viết tắt công ty không được quá 50 ký tự', {
                variant: 'error',
            });
            return;
        }
        if (website && isValidHttpUrl(website) === false) {
            showSnackbarWithClose('Vui lòng nhập đúng link websdite', { variant: 'error' });
            return;
        }
        setIsLoading(true);

        // form data
        const payload: CompanyCreatePayload = {
            Name: name?.trim(),
            SortName: sortName?.trim(),
            Address: address?.trim(),
            Province: province,
            District: district,
            Ward: ward,
            Email: email?.trim(),
            Phone: phone?.trim(),
            Website: website?.trim(),
            Representative: representative?.trim(),
            TaxCode: taxCode?.trim(),
        };

        try {
            await companyApi.createCompany(payload);

            showSnackbarWithClose(`Tạo ${nameDialog} thành công`, {
                variant: 'success',
            });
            router.reload();
        } catch (error: any) {
            if (Array.isArray(error?.response?.data?.message)) {
                error?.response?.data?.message.forEach((item: any) => {
                    showSnackbarWithClose(item, {
                        variant: 'error',
                    });
                });
            } else {
                showSnackbarWithClose(
                    error?.response ? error.response.data?.message : error.message,
                    {
                        variant: 'error',
                    }
                );
            }
        } finally {
            setTimeout(() => {
                setIsLoading(false);
            }, 1000);
        }
    };

    const handleClose = () => {
        const action = changeIsCreateDialog({ isOpen: false });
        dispatch(action);
    };

    useEffect(() => {
        if (!open) {
            setName('');
            setWebsite('');
            setIsLoading(false);
            setSortName('');
            setProvince('');
            setDistrict('');
            setWard('');
            setAddress('');
            setEmail('');
            setPhone('');
            setRepresentative('');
            setTaxCode('');
        }
    }, [isCreate]);

    return (
        <Dialog
            fullScreen={fullScreen}
            open={isCreate}
            onClose={() => {
                if (
                    name ||
                    website ||
                    sortName ||
                    address ||
                    email ||
                    phone ||
                    representative ||
                    taxCode
                ) {
                    setOpenComfirm(true);
                } else {
                    handleClose();
                }
            }}
            aria-labelledby="responsive-dialog-title"
            sx={{
                '& .MuiPaper-root': {
                    md: { minWidth: '600px', borderRadius: '16px' },
                },
            }}
        >
            <DialogTitle>{`Tạo ${nameDialog} mới`}</DialogTitle>
            <DialogContent>
                <Stack py={2} spacing={2}>
                    <Stack>
                        <InputLabel required>Tên Viết Tắt</InputLabel>
                        <StyledOutlinedInput
                            autoComplete="off"
                            value={sortName}
                            onChange={(e) => {
                                setSortName(e.target.value);
                            }}
                            size="small"
                            fullWidth
                        />
                    </Stack>
                    <Stack>
                        <InputLabel required>Tên Công Ty</InputLabel>
                        <StyledOutlinedInput
                            autoComplete="off"
                            value={name}
                            onChange={(e) => {
                                setName(e.target.value);
                            }}
                            size="small"
                            fullWidth
                        />
                    </Stack>
                    <Grid2 container>
                        <Grid2 xs={12} sm={6} pr={0.5}>
                            <Stack>
                                <InputLabel>Người đại diện pháp luật</InputLabel>
                                <StyledOutlinedInput
                                    autoComplete="off"
                                    value={representative}
                                    onChange={(e) => {
                                        setRepresentative(e.target.value);
                                    }}
                                    size="small"
                                    fullWidth
                                    type={'email'}
                                />
                            </Stack>
                        </Grid2>
                        <Grid2 xs={12} sm={6} pl={0.5}>
                            <Stack>
                                <InputLabel>Mã số thuế</InputLabel>
                                <StyledOutlinedInput
                                    autoComplete="off"
                                    value={taxCode}
                                    onChange={(e) => {
                                        setTaxCode(e.target.value);
                                    }}
                                    size="small"
                                    fullWidth
                                />
                            </Stack>
                        </Grid2>
                    </Grid2>
                    <Grid2 container>
                        <Grid2 xs={12} sm={6} pr={0.5}>
                            <Stack>
                                <InputLabel>Email</InputLabel>
                                <StyledOutlinedInput
                                    autoComplete="off"
                                    value={email}
                                    onChange={(e) => {
                                        setEmail(e.target.value);
                                    }}
                                    size="small"
                                    fullWidth
                                    type={'email'}
                                />
                            </Stack>
                        </Grid2>
                        <Grid2 xs={12} sm={6} pl={0.5}>
                            <Stack>
                                <InputLabel>Số điện thoại</InputLabel>
                                <StyledOutlinedInput
                                    autoComplete="off"
                                    value={phone}
                                    onChange={(e) => {
                                        setPhone(e.target.value);
                                    }}
                                    size="small"
                                    fullWidth
                                />
                            </Stack>
                        </Grid2>
                    </Grid2>
                    <InputAddress
                        selectedProvince={province}
                        selectedDistrict={district}
                        selectedWard={ward}
                        setSelectedProvince={setProvince}
                        setSelectedDistrict={setDistrict}
                        setSelectedWard={setWard}
                    />

                    <Stack>
                        <InputLabel>Địa chỉ</InputLabel>
                        <StyledOutlinedInput
                            autoComplete="off"
                            value={address}
                            onChange={(e) => {
                                setAddress(e.target.value);
                            }}
                            size="small"
                            fullWidth
                        />
                    </Stack>
                    <Stack>
                        <InputLabel>Trang web</InputLabel>
                        <StyledOutlinedInput
                            autoComplete="off"
                            value={website}
                            onChange={(e) => {
                                setWebsite(e.target.value);
                            }}
                            size="small"
                            fullWidth
                        />
                    </Stack>
                </Stack>
            </DialogContent>
            <DialogActions
                sx={{
                    px: 3,
                    pb: 3,
                }}
            >
                <StyleButton variant="contained" onClick={handleCreateCompany} loading={isLoading}>
                    Tạo mới
                </StyleButton>
            </DialogActions>
            {openComfirm ? (
                <ComfirmCloseDialog
                    close={() => setOpenComfirm(false)}
                    action={() => {
                        setOpenComfirm(false);
                        handleClose();
                    }}
                />
            ) : (
                <></>
            )}
        </Dialog>
    );
}
