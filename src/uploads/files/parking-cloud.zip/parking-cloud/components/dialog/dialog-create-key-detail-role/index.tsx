import { useAppSelector } from '@/hooks/useReudx';
import { Button, Dialog, DialogActions, DialogContent, DialogTitle, Stack } from '@mui/material';
import { useState } from 'react';
import TextFieldForm from '@/components/common/input/text-field-form/text-field-form';
import { showSnackbarWithClose } from '@/hooks/useSnackbarWithClose';
import { keyDetailCloudApi } from '@/api/key-detai-cloud';
import { ComfirmCloseDialog } from '../dialog-comfirm-close';

export interface IDialogCreatekeyClientProps {
    open: boolean;
    handleClose: () => void;
    handleReload: () => void;
}

export const DialogCreateKeyDetailRole = (props: IDialogCreatekeyClientProps) => {
    const { handleClose, handleReload } = props;
    const parkingChoose = useAppSelector((state) => state.parking.choose);
    const [name, setName] = useState('');
    const [keyWork, setKeyWork] = useState('');
    const [openComfirm, setOpenComfirm] = useState(false);

    const submit = () => {
        if (!parkingChoose) {
            return;
        }
        if (!name || name.trim() === '') {
            showSnackbarWithClose('Vui lòng nhập tên', {
                variant: 'error',
            });
            return;
        }
        if (!keyWork || keyWork.trim() === '') {
            showSnackbarWithClose('Vui lòng nhập key', {
                variant: 'error',
            });
            return;
        }

        const payload = {
            Name: name,
            KeyWord: keyWork,
        };
        keyDetailCloudApi
            .create(payload)
            .then(() => {
                showSnackbarWithClose('Tạo mới thành công', {
                    variant: 'success',
                });
                setName('');
                setKeyWork('');
                handleClose();
                handleReload();
            })
            .catch((error) => {
                if (Array.isArray(error?.response?.data?.message)) {
                    error?.response?.data?.message.forEach((item: any) => {
                        showSnackbarWithClose(item, {
                            variant: 'error',
                        });
                    });
                } else {
                    showSnackbarWithClose(
                        error?.response ? error.response.data?.message : error.message,
                        {
                            variant: 'error',
                        }
                    );
                }
            });
    };

    return (
        <Dialog
            open={props.open}
            onClose={handleClose}
            aria-labelledby="alert-dialog-title"
            aria-describedby="alert-dialog-description"
            maxWidth={'sm'}
            fullWidth
        >
            <DialogTitle id="alert-dialog-title">{'Tạo mới Key client'}</DialogTitle>
            <DialogContent>
                <TextFieldForm
                    lable={'Tên'}
                    value={name}
                    onChange={(e) => {
                        const { value } = e.target;
                        setName(value);
                    }}
                />
                <Stack sx={{ py: '5px' }} />
                <TextFieldForm
                    lable={'Key'}
                    value={keyWork}
                    onChange={(e) => {
                        const { value } = e.target;
                        setKeyWork(value);
                    }}
                />
            </DialogContent>
            <DialogActions sx={{ gap: '10px', mr: '20px', mb: '10px' }}>
                <Button
                    onClick={handleClose}
                    variant="contained"
                    sx={{
                        background: '#CDD2D1',
                        ':hover': {
                            background: '#DBE8E1',
                        },
                        fontSize: '14px',
                        fontWeight: '500',
                        borderRadius: '6px',
                        textTransform: 'revert-layer',
                    }}
                >
                    Hủy
                </Button>
                <Button
                    onClick={submit}
                    variant="contained"
                    sx={{
                        background: '#007DC0',
                        ':hover': {
                            background: '#009FD0',
                        },
                        fontSize: '14px',
                        fontWeight: '500',
                        textTransform: 'revert-layer',
                        borderRadius: '6px',
                    }}
                    autoFocus
                >
                    Tạo mới
                </Button>
            </DialogActions>
            {openComfirm ? (
                <ComfirmCloseDialog
                    close={() => setOpenComfirm(false)}
                    action={() => {
                        setOpenComfirm(false);
                        handleClose();
                    }}
                />
            ) : (
                <></>
            )}
        </Dialog>
    );
};
