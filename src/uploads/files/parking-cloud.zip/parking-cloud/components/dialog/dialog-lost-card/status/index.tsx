import { Stack, Typography } from '@mui/material';
import Image from 'next/image';

interface ILostCardComplete {
    close: () => void;
    setCaseView: (c: 'info' | 'move' | 'process' | 'status') => void;
    status: 'success' | 'error';
}

export const LostCardComplete = (props: ILostCardComplete) => {
    const { close, status, setCaseView } = props;
    return (
        <Stack sx={{ width: '100%', height: '100%' }} justifyContent="center" alignItems="center">
            {status === 'error' ? (
                <Image src="/icons/error-folder.svg" width={100} height={100} alt="photo" />
            ) : (
                <></>
            )}
            {status === 'success' ? (
                <Image src="/icons/green-checked-round.svg" width={100} height={100} alt="photo" />
            ) : (
                <></>
            )}

            <Typography
                sx={{
                    color: '#323232',
                    fontSize: '22px',
                    fontStyle: 'normal',
                    fontWeight: 600,
                    marginTop: '16px',
                    lineHeight: 'normal',
                }}
            >
                {status === 'success' ? 'Chuyển dữ liệu thành công' : ''}
                {status === 'error' ? 'Chuyển dữ liệu thất bại' : ''}
            </Typography>

            <Stack
                sx={{
                    display: 'flex',
                    width: '140px',
                    padding: '12px 16px',
                    justifyContent: 'center',
                    alignItems: 'center',
                    gap: '10px',
                    flexShrink: 0,
                    backgroundColor: '#007DC0',
                    cursor: 'pointer',
                    marginTop: '30px',
                    borderRadius: '6px',
                }}
                onClick={() => {
                    if (status === 'error') {
                        setCaseView('move');
                    }

                    if (status === 'success') {
                        close();
                    }
                }}
            >
                <Typography
                    sx={{
                        color: '#FFF',
                        fontSize: '14px',
                        fontStyle: 'normal',
                        fontWeight: 500,
                        lineHeight: 'normal',
                    }}
                >
                    {status === 'success' ? 'Thoát' : ''}
                    {status === 'error' ? 'Thử lại' : ''}
                </Typography>
            </Stack>
        </Stack>
    );
};
