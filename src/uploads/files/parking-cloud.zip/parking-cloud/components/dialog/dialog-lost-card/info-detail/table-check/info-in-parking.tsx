import { formatNumber } from '@/ultis/global-func';
import { Stack, Typography } from '@mui/material';
import Image from 'next/image';

interface IDataVehicelInParking {
    imageIn: { after: string | null; before: string | null; TimeIn: string | null };
}

export const DataVehicelInParking = (props: IDataVehicelInParking) => {
    const { imageIn } = props;

    return (
        <>
            <Stack
                sx={{
                    position: 'absolute',
                    left: 'calc(100% + 8px)',
                    backgroundColor: '#fff',
                    padding: '16px',
                    borderRadius: '6px',
                    boxShadow: '0px 4px 16px 0px rgba(0, 0, 0, 0.10)',
                    marginBottom: '16px',
                }}
            >
                <Stack direction="row" justifyContent="space-between" alignItems="center">
                    <Stack direction="row" alignItems="center" sx={{ display: 'flex' }}>
                        <Image src="/icons/img-blue.svg" width={24} height={24} alt="photo" />
                        <Typography
                            sx={{
                                color: '#007DC0',
                                fontSize: '13px',
                                fontStyle: 'normal',
                                fontWeight: 500,
                                whiteSpace: 'nowrap',
                            }}
                        >
                            Hình ảnh vào bãi
                        </Typography>
                    </Stack>

                    {imageIn.TimeIn ? (
                        <Stack
                            direction="row"
                            alignItems="center"
                            justifyContent="center"
                            sx={{ display: 'flex' }}
                        >
                            <Typography
                                sx={{
                                    color: '#55595D',
                                    fontSize: '13px',
                                    fontStyle: 'normal',
                                    fontWeight: 500,
                                    marginRight: '3px',
                                }}
                            >
                                Thời gian
                            </Typography>

                            <Typography
                                sx={{
                                    color: '#55595D',
                                    fontSize: '11px',
                                    fontStyle: 'normal',
                                    fontWeight: 400,
                                }}
                            >
                                {`${formatNumber(
                                    new Date(imageIn.TimeIn).getHours()
                                )}:${formatNumber(new Date(imageIn.TimeIn).getMinutes())}`}
                            </Typography>
                            <Stack
                                sx={{
                                    width: '1px',
                                    height: '12px',
                                    backgroundColor: '#E3E5E5',
                                    margin: '0px 3px',
                                }}
                            />
                            <Typography
                                sx={{
                                    color: '#55595D',
                                    fontSize: '11px',
                                    fontStyle: 'normal',
                                    fontWeight: 400,
                                }}
                            >
                                {`${formatNumber(
                                    new Date(imageIn.TimeIn).getDate()
                                )}/${formatNumber(
                                    new Date(imageIn.TimeIn).getMonth() + 1
                                )}/${formatNumber(new Date(imageIn.TimeIn).getFullYear())}`}
                            </Typography>
                        </Stack>
                    ) : (
                        <></>
                    )}
                </Stack>
                <Stack direction="row" gap="6px">
                    <Image src={`/service/${imageIn.after}`} width={240} height={132} alt="image" />
                    <Image
                        src={`/service/${imageIn.before}`}
                        width={240}
                        height={132}
                        alt="image"
                    />
                </Stack>
            </Stack>
            <Stack
                sx={{
                    position: 'absolute',
                    left: 'calc(100% - 8px)',
                    clipPath: 'polygon(0 50%, 100% 0, 100% 100%)',
                    boxShadow: '0px 4px 16px 0px rgba(0, 0, 0, 0.10)',
                    backgroundColor: '#fff',
                    width: '20px',
                    height: '20px',
                }}
            />
        </>
    );
};
