import { vehicleColor } from '@/constants/vehicle-color';
import { formatNumber, renderVehicleColor } from '@/ultis/global-func';
import { Stack, Typography } from '@mui/material';
import { DataVehicelInParking } from './info-in-parking';

export interface IRow {
    member: {
        image: string | null;
        name: string;
        address: string;
        type: string;
    };
    card: {
        ID: string;
        numberInSide: string;
        numberOutSide: string;
    } | null;
    vehicel: {
        ID: string;
        plateNumber: string;
        type: string;
        brand: string;
        color: string;
        startDate: string;
        endDate: string;
    } | null;
}

interface ITableCheckCard {
    item: IRow;
    imageIn: {
        after: string | null;
        before: string | null;
        TimeIn: string | null;
    };
    isOnParking: boolean | 'unset';
    caseRemove: 'card' | 'vehicel';
}

export const TableCheckCardOrVehicel = (props: ITableCheckCard) => {
    const { item, caseRemove, isOnParking, imageIn } = props;

    const generatorTime = (t: string) => {
        const time = new Date(t);

        return `${formatNumber(time.getDate())}/${formatNumber(time.getMonth())}/${formatNumber(
            time.getFullYear()
        )}`;
    };

    return (
        <Stack sx={{ width: '100%', gap: '2px', flex: 1, marginTop: '24px' }}>
            <Stack
                direction="row"
                sx={{
                    borderRadius: '4px',
                    backgroundColor: '#F4FAFE',
                    padding: '8px',
                    display: 'flex !important',
                }}
            >
                <Stack sx={{ width: '100px' }}>
                    <Typography
                        sx={{
                            color: '#323232',
                            fontSize: '14px',
                            fontStyle: 'normal',
                            fontWeight: 500,
                            lineHeight: 'normal',
                        }}
                    >
                        Biển số
                    </Typography>
                </Stack>
                <Stack sx={{ width: '95px' }}>
                    <Typography
                        sx={{
                            color: '#323232',
                            fontSize: '14px',
                            fontStyle: 'normal',
                            fontWeight: 500,
                            lineHeight: 'normal',
                        }}
                    >
                        Loại xe
                    </Typography>
                </Stack>
                <Stack sx={{ width: '75px' }}>
                    <Typography
                        sx={{
                            color: '#323232',
                            fontSize: '14px',
                            fontStyle: 'normal',
                            fontWeight: 500,
                            lineHeight: 'normal',
                        }}
                    >
                        Màu xe
                    </Typography>
                </Stack>
                <Stack sx={{ width: '102px' }}>
                    <Typography
                        sx={{
                            color: '#323232',
                            fontSize: '14px',
                            fontStyle: 'normal',
                            fontWeight: 500,
                            lineHeight: 'normal',
                        }}
                    >
                        Ngày đăng ký
                    </Typography>
                </Stack>
                <Stack sx={{ width: '99px' }}>
                    <Typography
                        sx={{
                            color: '#323232',
                            fontSize: '14px',
                            fontStyle: 'normal',
                            fontWeight: 500,
                            lineHeight: 'normal',
                        }}
                    >
                        Ngày hết hạn
                    </Typography>
                </Stack>
                <Stack sx={{ width: '127px' }}>
                    <Typography
                        sx={{
                            color: '#323232',
                            fontSize: '14px',
                            fontStyle: 'normal',
                            fontWeight: 500,
                            lineHeight: 'normal',
                        }}
                    >
                        Tình trạng
                    </Typography>
                </Stack>
            </Stack>
            <Stack
                direction="row"
                sx={{
                    borderRadius: '4px',
                    backgroundColor: '#F4FAFE',
                    padding: '8px',
                    display: 'flex !important',
                }}
            >
                <Stack sx={{ width: '100px' }}>
                    <Typography
                        sx={{
                            color: '#808080',
                            fontSize: '14px',
                            fontStyle: 'normal',
                            fontWeight: 400,
                            lineHeight: '140%',
                        }}
                    >
                        {item.vehicel?.plateNumber ? item.vehicel?.plateNumber : '---'}
                    </Typography>
                </Stack>
                <Stack sx={{ width: '95px' }}>
                    <Typography
                        sx={{
                            color: '#808080',
                            fontSize: '14px',
                            fontStyle: 'normal',
                            fontWeight: 400,
                            lineHeight: '140%',
                        }}
                    >
                        {item.vehicel?.type ? item.vehicel?.type : '--'}
                    </Typography>
                </Stack>
                <Stack sx={{ width: '75px', display: 'flex', gap: '4px' }} direction="row">
                    {item.vehicel?.color
                        ? renderVehicleColor(item.vehicel?.color)
                              .filter((v) => {
                                  const color = vehicleColor.find((c) => c.name === v.name);
                                  return Boolean(color);
                              })
                              .map((v: any) => {
                                  const color: any = vehicleColor.find((c) => c.name === v.name);

                                  return (
                                      <Stack
                                          key={color.value}
                                          sx={{
                                              width: '16px',
                                              height: '16px',
                                              borderRadius: '4px',
                                              border: '1px solid #D0D0D0',
                                              background: color.value,
                                          }}
                                      />
                                  );
                              })
                        : '--'}
                </Stack>
                <Stack sx={{ width: '102px' }}>
                    <Typography
                        sx={{
                            color: '#808080',
                            fontSize: '14px',
                            fontStyle: 'normal',
                            fontWeight: 400,
                            lineHeight: '140%',
                        }}
                    >
                        {item.vehicel?.startDate ? generatorTime(item.vehicel?.startDate) : '--'}
                    </Typography>
                </Stack>
                <Stack sx={{ width: '99px' }}>
                    <Typography
                        sx={{
                            color: '#808080',
                            fontSize: '14px',
                            fontStyle: 'normal',
                            fontWeight: 400,
                            lineHeight: '140%',
                        }}
                    >
                        {item.vehicel?.endDate ? generatorTime(item.vehicel?.endDate) : '--'}
                    </Typography>
                </Stack>
                <Stack
                    sx={{
                        width: '110px',
                        position: 'relative',
                        cursor: 'default',
                        transition: 'all ease .5s',
                        '& > div ': {
                            opacity: 0,
                            visibility: 'hidden !impotant',
                        },
                        '&:hover  > div ': {
                            opacity: 1,
                            visibility: 'visible !impotant',
                        },
                    }}
                    direction="row"
                    alignItems="center"
                >
                    <Typography
                        sx={{
                            padding: '4px 8px',
                            borderRadius: '4px',
                            background: isOnParking ? '#FFE3E3' : '#BBF6D9',
                            color: isOnParking ? '#F95959' : '#008E47',
                            fontSize: '14px',
                            fontStyle: 'normal',
                            fontWeight: 500,
                            lineHeight: 'normal',
                            width: 'fit-content',
                        }}
                    >
                        {isOnParking ? 'Còn trong bãi' : 'Đã ra khỏi bãi'}
                    </Typography>
                    {isOnParking ? <DataVehicelInParking imageIn={imageIn} /> : <></>}
                </Stack>
            </Stack>
        </Stack>
    );
};
