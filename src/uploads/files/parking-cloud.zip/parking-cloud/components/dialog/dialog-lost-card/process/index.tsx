import { cardApi } from '@/api/card-api';
import { Stack, Typography } from '@mui/material';
import { useAmp } from 'next/amp';
import Image from 'next/image';
import { useEffect, useState } from 'react';

export interface IRow {
    member: {
        image: string | null;
        name: string;
        address: string;
        type: string;
    };
    card: {
        ID: string;
        numberInSide: string;
        numberOutSide: string;
    } | null;
    vehicel: {
        ID: string;
        plateNumber: string;
        type: string;
        brand: string;
        color: string;
        startDate: string;
        endDate: string;
    } | null;
}

interface ILostCardMoveDataProcess {
    item: IRow;
    cardNumber: { log: string; value: string };
    idCard: string;
    setCaseView: (s: 'info' | 'move' | 'process' | 'status') => void;
}

export const LostCardMoveDataProcess = (props: ILostCardMoveDataProcess) => {
    const { cardNumber, item, idCard, setCaseView } = props;

    const [process, setProcess] = useState(0);

    useEffect(() => {
        if (process + 10 >= 2000) {
            setCaseView('status');
        }

        const increaseCount = () => {
            setProcess((prevCount) => prevCount + 10);
        };

        const timer = setTimeout(increaseCount, 10);

        return () => {
            clearTimeout(timer);
        };
    }, [process]);

    return (
        <>
            <Image
                src="/icons/card-transaction.svg"
                width={140}
                height={100}
                alt="photo"
                style={{ marginTop: '24px' }}
            />

            <Typography
                sx={{
                    color: '#323232',
                    marginTop: '16px',
                    marginBottom: '32px',
                    fontSize: '22px',
                    fontStyle: 'normal',
                    fontWeight: 600,
                    lineHeight: 'normal',
                }}
            >
                Chuyển dữ liệu
            </Typography>

            <Typography
                sx={{
                    marginBottom: '16px',
                    color: '#323232',
                    fontSize: '16px',
                    fontStyle: 'normal',
                    fontWeight: 400,
                    lineHeight: '20px',
                }}
            >
                Đang thực hiện chuyển dữ liệu
            </Typography>

            <Stack
                sx={{
                    borderRadius: '8px',
                    width: '100%',
                    height: '8px',
                    display: 'flex',
                    backgroundColor: '#ECF4FF',
                    marginBottom: '24px',
                    position: 'relative',
                    '&::before': {
                        content: '""',
                        borderRadius: '8px',
                        position: 'absolute',
                        height: '100%',
                        width: `${process / 20}%`,
                        backgroundColor: '#007DC0',
                    },
                }}
            />

            <Stack
                sx={{ display: 'flex', alignItems: 'center', width: '100%', gap: '16px' }}
                direction="row"
            >
                <Stack sx={{ display: 'flex' }} alignItems="center">
                    <Typography
                        sx={{
                            color: '#007DC0',
                            fontSize: '16px',
                            fontStyle: 'normal',
                            fontWeight: 500,
                            lineHeight: 'normal',
                            whiteSpace: 'nowrap',
                        }}
                    >
                        Số thẻ ngoài cũ
                    </Typography>
                    <Typography
                        sx={{
                            color: '#55595D',
                            fontSize: '16px',
                            fontStyle: 'normal',
                            fontWeight: 500,
                            whiteSpace: 'nowrap',
                            lineHeight: 'normal',
                        }}
                    >
                        {item.card?.numberInSide}
                    </Typography>
                </Stack>
                {/* --------------- */}
                <Stack sx={{ height: '1px', backgroundColor: '#D9D9D9', width: '100%' }} />
                {/* --------------- */}
                <Stack
                    sx={{
                        width: '50px',
                        height: '50px',
                        borderRadius: '50%',
                        aspectRatio: '1/1',
                        border: '1px dashed #78C6E7',
                    }}
                    justifyContent="center"
                    alignItems="center"
                >
                    <Image src="/icons/blue-arrow.svg" height={28} width={33} alt="arrow" />
                </Stack>
                {/* --------------- */}
                <Stack sx={{ height: '1px', backgroundColor: '#D9D9D9', width: '100%' }} />
                {/* --------------- */}
                <Stack sx={{ display: 'flex' }} alignItems="center">
                    <Typography
                        sx={{
                            color: '#007DC0',
                            fontSize: '16px',
                            fontStyle: 'normal',
                            fontWeight: 500,
                            lineHeight: 'normal',
                            whiteSpace: 'nowrap',
                        }}
                    >
                        Số thẻ ngoài mới
                    </Typography>
                    <Typography
                        sx={{
                            color: '#55595D',
                            fontSize: '16px',
                            fontStyle: 'normal',
                            fontWeight: 500,
                            lineHeight: 'normal',
                            whiteSpace: 'nowrap',
                        }}
                    >
                        {cardNumber.value}
                    </Typography>
                </Stack>
            </Stack>
        </>
    );
};
