import { cardApi } from '@/api/card-api';
import { historyInOutApi } from '@/api/index';
import { useAppSelector } from '@/hooks';
import { showSnackbarWithClose } from '@/hooks/useSnackbarWithClose';
import { useDebouncedValue } from '@mantine/hooks';
import { Stack, Typography } from '@mui/material';
import Image from 'next/image';
import { Dispatch, SetStateAction, useCallback, useEffect, useState } from 'react';

export interface IRow {
    member: {
        image: string | null;
        name: string;
        address: string;
        type: string;
    };
    card: {
        ID: string;
        numberInSide: string;
        numberOutSide: string;
    } | null;
    vehicel: {
        ID: string;
        plateNumber: string;
        type: string;
        brand: string;
        color: string;
        startDate: string;
        endDate: string;
    } | null;
}

interface ILostCardMoveInfo {
    item: IRow;
    cardNumber: { log: string; value: string };
    setCaseView: (c: 'info' | 'move' | 'process' | 'status') => void;
    setCardNumber: Dispatch<
        SetStateAction<{
            log: string;
            value: string;
        }>
    >;
    changeStatus: (s: 'success' | 'error') => void;
    idCard: string;
    setIdCard: Dispatch<SetStateAction<string>>;
}

export const LostCardMoveInfo = (props: ILostCardMoveInfo) => {
    const { cardNumber, idCard, item, setCardNumber, setCaseView, setIdCard, changeStatus } = props;

    // const [caseAction, setCaseAction] = useState<'success' | 'error' | 'unset'>('unset');

    // useEffect(() => {
    //     const handleGlobalKeyDown = (event: any) => {
    //         const isNumber = event.code.includes('Digit');

    //         if (event.key === 'Enter' && cardNumber.log.length !== 0) {
    //             setCardNumber({ ...cardNumber, value: cardNumber.log, log: '' });
    //         }

    //         if (isNumber) {
    //             setCardNumber({ ...cardNumber, log: cardNumber.log + event.key });
    //         }
    //     };

    //     document.addEventListener('keydown', handleGlobalKeyDown);

    //     return () => {
    //         document.removeEventListener('keydown', handleGlobalKeyDown);
    //     };
    // }, [cardNumber, setCardNumber]);

    const onSubmit = () => {
        if (!idCard) {
            showSnackbarWithClose('Chưa nhập mã thẻ ngoài', { variant: 'error' });
            return;
        }

        if (!cardNumber.value) {
            showSnackbarWithClose('Chưa nhập mã thẻ trong', { variant: 'error' });
            return;
        }

        if (!item.card) {
            return;
        }

        setCaseView('process');
        cardApi
            .remodeWhenLostCard(
                {
                    ID: item.card?.ID,
                    CardNumberNew: cardNumber.value,
                    IdCardNew: idCard,
                },
                (state: number | 'done') => {}
            )
            .then(() => {
                changeStatus('success');
            })
            .catch(() => {
                changeStatus('error');
            });
    };

    return (
        <>
            <Stack sx={{ gap: '8px' }} justifyContent="center" alignItems="center">
                <Image src="/icons/scan-card.svg" width={47} height={60} alt="photo" />
                <Typography
                    sx={{
                        color: '#323232',
                        fontSize: '22px',
                        fontStyle: 'normal',
                        fontWeight: 600,
                        lineHeight: 'normal',
                    }}
                >
                    Chuyển thông tin sang thẻ mới
                </Typography>
                <Stack
                    sx={{
                        color: '#55595D',
                        fontSize: '18px',
                        fontStyle: 'normal',
                        fontWeight: 400,
                        lineHeight: 'normal',
                        whiteSpace: 'nowrap',
                    }}
                    direction="row"
                    alignItems="center"
                >
                    <span>Sau khi nhấn</span>
                    <span
                        style={{
                            color: '#55595D',
                            fontSize: '18px',
                            fontStyle: 'normal',
                            fontWeight: 500,
                            lineHeight: '24px',
                        }}
                    >
                        “Tiếp tục”
                    </span>
                    <span>, không thể hoàn tác tác vụ này</span>
                </Stack>
            </Stack>
            <Stack
                sx={{
                    width: '100%',
                    height: '70px',
                    backgroundColor: '#F8F8F8',
                    border: '1px solid #E3E5E5',
                    borderRadius: '6px',
                    margin: '24px',
                }}
                justifyContent="center"
                alignItems="center"
            >
                <input
                    placeholder="Vui lòng đưa thẻ lại đầu đọc để kiểm tra"
                    style={{
                        color: '#007DC0',
                        fontSize: '16px',
                        fontStyle: 'normal',
                        fontWeight: 400,
                        lineHeight: '20px',
                        width: '100%',
                        height: '100%',
                        background: 'none',
                        border: 'none',
                        outline: 'none',
                        textAlign: 'center',
                    }}
                    value={cardNumber.value}
                    onChange={(e) => {
                        const { value } = e.target;

                        setCardNumber({ ...cardNumber, value });
                    }}
                />
                {/* <Typography
                    sx={{
                        color: '#007DC0',
                        fontSize: '16px',
                        fontStyle: 'normal',
                        fontWeight: 400,
                        lineHeight: '20px',
                    }}
                    o
                >
                    {cardNumber.value
                        ? cardNumber.value
                        : 'Vui lòng đưa thẻ lại đầu đọc để kiểm tra'}
                </Typography> */}
            </Stack>

            <Stack direction="row" alignItems="center" sx={{ gap: '16px', width: '100%' }}>
                <Stack sx={{ gap: '4px' }} direction="row">
                    <Typography
                        sx={{
                            color: '#55595D',
                            fontSize: '14px',
                            fontStyle: 'normal',
                            fontWeight: 400,
                            lineHeight: '140%',
                        }}
                    >
                        Số thẻ ngoài
                    </Typography>
                    <Typography
                        sx={{
                            color: '#E42727',
                            fontSize: '14px',
                            fontStyle: 'normal',
                            fontWeight: '400',
                            lineHeight: '140%',
                        }}
                    >
                        (*)
                    </Typography>
                </Stack>

                <Typography
                    component="input"
                    sx={{
                        outline: 'none',
                        border: '1px solid #E3E5E5',
                        borderRadius: '6px',
                        padding: '5px 10px',
                        flex: 1,
                    }}
                    value={idCard}
                    onChange={(e) => {
                        const { value } = e.target;
                        setIdCard(value);
                    }}
                />
            </Stack>
            <Stack
                sx={{
                    display: 'flex',
                    width: '140px',
                    padding: '12px 16px',
                    justifyContent: 'center',
                    alignItems: 'center',
                    gap: '10px',
                    flexShrink: 0,
                    backgroundColor: '#007DC0',
                    cursor: 'pointer',
                    marginTop: '30px',
                    borderRadius: '6px',
                }}
                onClick={() => onSubmit()}
            >
                <Typography
                    sx={{
                        color: '#FFF',
                        fontSize: '14px',
                        fontStyle: 'normal',
                        fontWeight: 500,
                        lineHeight: 'normal',
                    }}
                >
                    Tiếp tục
                </Typography>
            </Stack>
        </>
    );
};
