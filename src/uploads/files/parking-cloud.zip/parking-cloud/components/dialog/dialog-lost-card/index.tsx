import { Stack } from '@mui/material';
import Image from 'next/image';
import { useState } from 'react';
import { LostCardInfoDetail } from './info-detail';
import { LostCardMoveInfo } from './move-detail';
import { LostCardMoveDataProcess } from './process';
import { LostCardComplete } from './status';
import { MiniCloseDialog } from './mini-close-dialog';

export interface IRow {
    member: {
        image: string | null;
        name: string;
        address: string;
        type: string;
    };
    card: {
        ID: string;
        numberInSide: string;
        numberOutSide: string;
    } | null;
    vehicel: {
        ID: string;
        plateNumber: string;
        type: string;
        brand: string;
        color: string;
        startDate: string;
        endDate: string;
    } | null;
}

interface IDialogLostCardlAction {
    close: () => void;
    item: IRow;
    reload: () => void;
}

export const DialogLostCardlAction = (props: IDialogLostCardlAction) => {
    const { close, item, reload } = props;
    const [comfirm, setComfirm] = useState(false);

    const [caseView, setCaseView] = useState<'info' | 'move' | 'process' | 'status'>('info');

    const [caseResult, setSaseResult] = useState<'success' | 'error'>('success');

    const [cardNumber, setCardNumber] = useState<{ log: string; value: string }>({
        log: '',
        value: '',
    });
    const [idCard, setIdCard] = useState('');

    return (
        <>
            <Stack
                sx={{
                    display: 'flex',
                    position: 'fixed',
                    height: '100vh',
                    width: '100vw',
                    top: 0,
                    left: 0,
                }}
                justifyContent="center"
                alignItems="center"
            >
                <Stack
                    sx={{ width: '100%', height: '100%', backgroundColor: '#80808040' }}
                    onClick={() => {
                        if (caseView === 'move') {
                            setComfirm(true);
                        } else {
                            close();
                        }
                    }}
                />

                <Stack
                    sx={{
                        position: 'absolute',
                        backgroundColor: '#fff',
                        display: 'flex',
                        width: '646px',
                        height: '423px',
                        borderRadius: '11px',
                        padding: '24px',
                    }}
                    alignItems="center"
                >
                    <Image
                        src="/icons/x-gray.svg"
                        style={{
                            position: 'absolute',
                            top: '24px',
                            right: '24px',
                            cursor: 'pointer',
                        }}
                        onClick={() => {
                            if (caseView === 'move') {
                                setComfirm(true);
                            } else {
                                close();
                            }
                        }}
                        width={24}
                        height={24}
                        alt="photo"
                    />

                    {caseView === 'info' ? (
                        <LostCardInfoDetail
                            item={item}
                            reload={() => reload()}
                            close={() => close()}
                            toUpdate={() => setCaseView('move')}
                        />
                    ) : (
                        <></>
                    )}

                    {caseView === 'move' ? (
                        <LostCardMoveInfo
                            item={item}
                            changeStatus={(c) => setSaseResult(c)}
                            cardNumber={cardNumber}
                            setCardNumber={setCardNumber}
                            idCard={idCard}
                            setIdCard={setIdCard}
                            setCaseView={(c: 'info' | 'move' | 'process' | 'status') =>
                                setCaseView(c)
                            }
                        />
                    ) : (
                        <></>
                    )}

                    {caseView === 'process' ? (
                        <LostCardMoveDataProcess
                            item={item}
                            cardNumber={cardNumber}
                            idCard={idCard}
                            setCaseView={(s: 'info' | 'move' | 'process' | 'status') =>
                                setCaseView(s)
                            }
                        />
                    ) : (
                        <></>
                    )}

                    {caseView === 'status' ? (
                        <LostCardComplete
                            close={() => close()}
                            status={caseResult}
                            setCaseView={(c: 'info' | 'move' | 'process' | 'status') =>
                                setCaseView(c)
                            }
                        />
                    ) : (
                        <></>
                    )}
                </Stack>
            </Stack>

            {comfirm ? (
                <MiniCloseDialog confirm={() => close()} close={() => setComfirm(false)} />
            ) : (
                <></>
            )}
        </>
    );
};
