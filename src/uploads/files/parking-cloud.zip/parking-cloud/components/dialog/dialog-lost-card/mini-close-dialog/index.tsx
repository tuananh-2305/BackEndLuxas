import { Stack, Typography } from '@mui/material';
import Image from 'next/image';

interface IMiniCloseDialog {
    close: () => void;
    confirm: () => void;
}

export const MiniCloseDialog = (props: IMiniCloseDialog) => {
    const { close, confirm } = props;
    return (
        <Stack
            sx={{
                display: 'flex',
                position: 'fixed',
                height: '100vh',
                width: '100vw',
                top: 0,
                left: 0,
                zIndex: 100,
            }}
            justifyContent="center"
            alignItems="center"
        >
            <Stack
                sx={{ width: '100%', height: '100%', backgroundColor: '#80808040' }}
                onClick={() => close()}
            />

            <Stack
                sx={{
                    position: 'absolute',
                    backgroundColor: '#fff',
                    display: 'flex',
                    width: '430px',
                    borderRadius: '11px',
                    padding: '24px',
                }}
                alignItems="center"
                justifyContent="center"
            >
                <Image
                    src="/icons/empty-red.svg"
                    onClick={() => close()}
                    width={60}
                    height={60}
                    alt="photo"
                />

                <Typography
                    sx={{
                        color: '#323232',
                        fontSize: '22px',
                        fontStyle: 'normal',
                        fontWeight: 600,
                        lineHeight: 'normal',
                        marginTop: '24px',
                        marginBottom: '6px',
                    }}
                >
                    Bạn chắn chắn dừng lại không?
                </Typography>
                <Typography
                    sx={{
                        color: '#55595D',
                        fontSize: '16px',
                        fontStyle: 'normal',
                        fontWeight: 400,
                        lineHeight: '20px',
                    }}
                >
                    Không thể hoàn tác tác vụ này
                </Typography>

                <Stack sx={{ display: 'flex', gap: '16px', marginTop: '32px' }} direction="row">
                    <Stack
                        sx={{
                            display: 'flex',
                            padding: '12px 49px',
                            justifyContent: 'center',
                            alignItems: 'center',
                            gap: '10px',
                            width: '140px',
                            borderRadius: '6px',
                            border: '1px solid #D0D0D0',
                            cursor: 'pointer',
                        }}
                        onClick={() => close()}
                    >
                        <Typography
                            sx={{
                                color: '#AFAFAF',
                                fontSize: '14px',
                                fontStyle: 'normal',
                                fontWeight: 500,
                                lineHeight: 'normal',
                            }}
                        >
                            Không
                        </Typography>
                    </Stack>
                    <Stack
                        sx={{
                            display: 'flex',
                            padding: '12px 49px',
                            width: '140px',
                            justifyContent: 'center',
                            alignItems: 'center',
                            gap: '10px',
                            borderRadius: '6px',
                            cursor: 'pointer',
                            backgroundColor: '#E42727',
                        }}
                        onClick={() => confirm()}
                    >
                        <Typography
                            sx={{
                                color: '#FFF',
                                fontSize: '14px',
                                fontStyle: 'normal',
                                fontWeight: 500,
                                lineHeight: 'normal',
                            }}
                        >
                            Có
                        </Typography>
                    </Stack>
                </Stack>
            </Stack>
        </Stack>
    );
};
