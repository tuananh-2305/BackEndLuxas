import { boxImeiApi } from '@/api/index';
import { DeviceImeiCreatePayload } from '@/models/index';
import { theme } from '@/ultis/index';
import DoubleArrowIcon from '@mui/icons-material/DoubleArrow';
import {
    Box,
    Dialog,
    DialogActions,
    DialogContent,
    DialogTitle,
    InputLabel,
    Stack,
    Typography,
    useMediaQuery,
} from '@mui/material';
import { enqueueSnackbar } from 'notistack';
import { useEffect, useState } from 'react';
import { CustomDateTimePickerComponent } from '../common';
import { StyledOutlinedInput } from '../common/style-component';
import { StyleButton } from '../common/style-component/button';
import { showSnackbarWithClose } from '@/hooks/useSnackbarWithClose';
import { ComfirmCloseDialog } from './dialog-comfirm-close';

export interface IDialogCreateImeiProps {
    open: boolean;
    handleClose: () => void;
    handleReload?: () => void;
}

export default function DialogCreateImei(props: IDialogCreateImeiProps) {
    const { open, handleClose, handleReload } = props;
    const fullScreen = useMediaQuery(theme.breakpoints.down('md'));
    const [name, setName] = useState<string>('');
    const [description, setDescription] = useState<string>('');
    const [openAuto, setOpenAuto] = useState(false);
    const [imei, setImei] = useState<string>('');
    const [startTime, setStartTime] = useState<Date>(new Date());
    const [endTime, setEndTime] = useState<Date>(new Date());
    const [activeTime, setActiveTime] = useState<Date | null>(null);
    const [openComfirm, setOpenComfirm] = useState(false);

    //reset data when open dialog

    useEffect(() => {
        if (!open) {
            setActiveTime(new Date());
            setEndTime(new Date());
            setStartTime(new Date());
            setImei('');
            setDescription('');
            setName('');
        }
    }, [open]);
    const handleCreateImei = async () => {
        if (!name || name.trim() === '') {
            showSnackbarWithClose('Tên không được để trống', { variant: 'error' });
            return;
        }

        if (!imei || imei.trim() === '') {
            showSnackbarWithClose('Imei không được để trống', { variant: 'error' });
            return;
        }
        if (!startTime) {
            showSnackbarWithClose('Ngày sản xuất không được để trống', { variant: 'error' });
            return;
        }

        const payload: DeviceImeiCreatePayload = {
            ProductionDate: startTime,
            WarrantyExpirationDate: endTime,
            Description: description,
            Name: name.trim(),
            Imei: imei.trim(),
        };

        try {
            const { data } = await boxImeiApi.createBoxImei(payload);
            showSnackbarWithClose('Tạo imei thành công', { variant: 'success' });
            handleReload && handleReload();
            handleClose();
        } catch (error: any) {
            if (Array.isArray(error?.response?.data?.message)) {
                error?.response?.data?.message.forEach((item: any) => {
                    showSnackbarWithClose(item, {
                        variant: 'error',
                    });
                });
            } else {
                showSnackbarWithClose(
                    error?.response ? error.response.data?.message : error.message,
                    {
                        variant: 'error',
                    }
                );
            }
        }
    };
    return (
        <Dialog
            fullScreen={fullScreen}
            open={open}
            onClose={() => {
                if (imei || name || description) {
                    setOpenComfirm(true);
                } else {
                    handleClose();
                }
            }}
            aria-labelledby="responsive-dialog-title"
            sx={{
                '& .MuiPaper-root': {
                    md: { minWidth: '500px', borderRadius: '16px' },
                },
            }}
        >
            <DialogTitle>{'Tạo thiết bị'}</DialogTitle>
            <DialogContent>
                <Stack py={2} spacing={2}>
                    <Stack>
                        <InputLabel required>Tên</InputLabel>
                        <StyledOutlinedInput
                            autoComplete="off"
                            value={name}
                            onChange={(e) => {
                                setName(e.target.value);
                            }}
                            size="small"
                            fullWidth
                        />
                    </Stack>
                    <Stack>
                        <InputLabel required>Imei</InputLabel>
                        <StyledOutlinedInput
                            autoComplete="off"
                            value={imei}
                            onChange={(e) => {
                                setImei(e.target.value);
                            }}
                            size="small"
                            fullWidth
                        />
                    </Stack>

                    {/* <Stack>
                        <Box>
                            <Typography variant="subtitle2">Ngày kích hoạt</Typography>
                            <CustomDateTimePickerComponent
                                time={activeTime}
                                setTime={function (t: Date | null): void {
                                    if (t) {
                                        setActiveTime(t);
                                    }
                                }}
                                maxTime={function (): Date | null | undefined {
                                    return null;
                                }}
                                minTime={function (): Date | null | undefined {
                                    return new Date();
                                }}
                                size="small"
                            />
                        </Box>
                    </Stack> */}

                    <Stack>
                        <Stack direction={'row'} spacing={1} alignItems={'center'}>
                            <Box>
                                <Typography variant="subtitle2">
                                    Ngày sản xuất <span style={{ color: 'red' }}>*</span>
                                </Typography>
                                <CustomDateTimePickerComponent
                                    time={startTime}
                                    setTime={function (t: Date | null): void {
                                        if (t) {
                                            setStartTime(t);
                                        }
                                    }}
                                    maxTime={function (): Date | null | undefined {
                                        return endTime;
                                    }}
                                    minTime={function (): Date | null | undefined {
                                        return null;
                                    }}
                                    size="small"
                                />
                            </Box>
                            <DoubleArrowIcon />
                            <Box>
                                <Typography variant="subtitle2">
                                    Ngày hết hạn bảo hành <span style={{ color: 'red' }}>*</span>
                                </Typography>
                                <CustomDateTimePickerComponent
                                    time={endTime}
                                    setTime={function (t: Date | null): void {
                                        if (t) {
                                            setEndTime(t);
                                        }
                                    }}
                                    maxTime={function (): Date | null | undefined {
                                        return null;
                                    }}
                                    minTime={function (): Date | null | undefined {
                                        return startTime;
                                    }}
                                    size="small"
                                />
                            </Box>
                        </Stack>
                    </Stack>

                    {/* 
                    <InputIP
                        onChange={(value) => {
                            setIdAddress(value);
                        }}
                        setIsValidateIp={setIsValidateIp}
                    /> */}
                    <Stack>
                        <InputLabel>Mô tả</InputLabel>
                        <StyledOutlinedInput
                            autoComplete="off"
                            value={description}
                            onChange={(e) => {
                                setDescription(e.target.value);
                            }}
                            size="small"
                            fullWidth
                            multiline
                            rows={4}
                        />
                    </Stack>
                </Stack>
            </DialogContent>
            <DialogActions
                sx={{
                    px: 3,
                    pb: 3,
                }}
            >
                <StyleButton variant="contained" onClick={handleCreateImei}>
                    Tạo mới
                </StyleButton>
            </DialogActions>
            {openComfirm ? (
                <ComfirmCloseDialog
                    close={() => setOpenComfirm(false)}
                    action={() => {
                        setOpenComfirm(false);
                        handleClose();
                    }}
                />
            ) : (
                <></>
            )}
        </Dialog>
    );
}
