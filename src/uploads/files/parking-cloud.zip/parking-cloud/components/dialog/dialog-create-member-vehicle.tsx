import { memberVehicleApi } from '@/api/member-vehicle-api';
import { vehicleTypeApi } from '@/api/vehicle-type-api';
import { useAppSelector } from '@/hooks/useReudx';
import { showSnackbarWithClose } from '@/hooks/useSnackbarWithClose';
import { MemberVehicleCreatePayload } from '@/models/member.vehicle.model';
import { hasSpecialCharsOrWhitespace, theme } from '@/ultis/index';
import {
    CircularProgress,
    Dialog,
    DialogActions,
    DialogContent,
    DialogTitle,
    InputLabel,
    Select,
    SelectChangeEvent,
    Stack,
    useMediaQuery,
} from '@mui/material';
import MenuItem from '@mui/material/MenuItem';
import { green } from '@mui/material/colors';
import dayjs from 'dayjs';
import { useEffect, useState } from 'react';
import { StyledOutlinedInput } from '../common/style-component';
import { StyleButton } from '../common/style-component/button';
import { Vehicel } from '../formular/interface';
import { DatePicker } from '@mui/x-date-pickers';
import { ComfirmCloseDialog } from './dialog-comfirm-close';
import AutoCompoleteMember from '../common/input/autocomplete-member';

export interface IDialogCreateMemberVehicleProps {
    open: boolean;
    handleClose: () => void;
    handleReload?: () => void;
    idMember?: string;
}

export default function DialogCreateMemberVehicle(props: IDialogCreateMemberVehicleProps) {
    const { open, handleClose, handleReload, idMember } = props;

    const [plateNumber, setPlateNumber] = useState('');
    const [color, setColor] = useState('');
    const [vehicleBrand, setVehicleBrand] = useState('');
    const [description, setDescription] = useState('');

    const [member, setMember] = useState<any>(null);
    const [vehicleTypeId, setVehicleTypeId] = useState<string>(''); // list vehicle type of parking
    const [listVehicle, setListVehicle] = useState<Vehicel[]>([]); // list vehicle of member
    const nameDialog = 'phương tiện';
    const parkingChoose = useAppSelector((state) => state.parking.choose);
    const fullScreen = useMediaQuery(theme.breakpoints.down('md'));
    const [isHiddenPlateNumber, setIsHiddenPlateNumber] = useState<boolean>(false);
    const [isLoadingButton, setIsLoadingButton] = useState(false);
    const [dateExpire, setDateExpire] = useState<Date | null>(
        new Date(new Date().setFullYear(new Date().getFullYear() + 1))
    );
    const [openComfirm, setOpenComfirm] = useState(false);
    useEffect(() => {
        if (!listVehicle.find((item) => item.ID === vehicleTypeId)?.IsPlateNumber) {
            setIsHiddenPlateNumber(false);
        } else {
            setIsHiddenPlateNumber(true);
        }
    }, [vehicleTypeId]);
    useEffect(() => {
        if (!parkingChoose) return;
        vehicleTypeApi.getVehicleTypes().then((res) => {
            setListVehicle(res.data);
            // console.log(res.data.Data);
        });
    }, [parkingChoose]);

    // handle reset checked

    // reset name and checked when close dialog
    useEffect(() => {
        if (!open) {
            setPlateNumber('');
            setColor('');
            setVehicleBrand('');
            setDescription('');
            setVehicleTypeId('');
            setIsLoadingButton(false);
            setDateExpire(new Date(new Date().setFullYear(new Date().getFullYear() + 1)));
        }
    }, [open]);

    const handleCreate = async () => {
        if (vehicleTypeId === '') {
            showSnackbarWithClose('Loại xe không được để trống', {
                variant: 'error',
            });
            return;
        }
        if (isHiddenPlateNumber && !plateNumber) {
            showSnackbarWithClose('Biển số không được để trống', {
                variant: 'error',
            });
            return;
        }

        if (!dateExpire) {
            showSnackbarWithClose('Chưa chọn ngày hết hạn', {
                variant: 'error',
            });
            return;
        }

        // if (isHiddenPlateNumber && hasSpecialCharsOrWhitespace(plateNumber)) {
        //     showSnackbarWithClose('Biển số không được tồn tại ký tự đặc biệc', {
        //         variant: 'error',
        //     });
        //     return;
        // }

        if (!idMember && !member) {
            showSnackbarWithClose('Bắc buộc phải chọn 1 thành viên.', {
                variant: 'error',
            });
            return;
        }

        if (parkingChoose === null) return;
        setIsLoadingButton(true);
        const payload: MemberVehicleCreatePayload = {
            VehicleBrand: vehicleBrand,
            VehicleColor: color,
            PlateNumber: plateNumber,
            MemberId: idMember ? idMember : member?.ID,
            ParkingId: parkingChoose.ID,
            VehicleTypeId: vehicleTypeId,
            Description: description,
            ExpirationDate: dateExpire,
        };

        try {
            await memberVehicleApi.createMemberVehicle(payload);
            showSnackbarWithClose(`Tạo ${nameDialog} thành công`, {
                variant: 'success',
            });
            handleReload && handleReload();
            handleClose();
        } catch (error: any) {
            if (Array.isArray(error?.response?.data?.message)) {
                error?.response?.data?.message.forEach((item: any) => {
                    showSnackbarWithClose(item, {
                        variant: 'error',
                    });
                });
            } else {
                showSnackbarWithClose(
                    error?.response ? error.response.data?.message : error.message,
                    {
                        variant: 'error',
                    }
                );
            }
        }
        setTimeout(() => {
            setIsLoadingButton(false);
        }, 1000);
    };
    return (
        <Dialog
            fullScreen={fullScreen}
            open={open}
            onClose={() => {
                if (plateNumber || color || vehicleBrand || description) {
                    setOpenComfirm(true);
                } else {
                    handleClose();
                }
            }}
            aria-labelledby="responsive-dialog-title"
            sx={{
                '& .MuiPaper-root': {
                    md: { minWidth: '500px', borderRadius: '16px' },
                },
            }}
        >
            <DialogTitle>{`Tạo ${nameDialog} mới`}</DialogTitle>
            <DialogContent>
                <Stack py={2} spacing={2}>
                    {parkingChoose && !idMember ? (
                        <AutoCompoleteMember
                            setValue={setMember}
                            parkingId={parkingChoose?.ID}
                            value={member}
                        />
                    ) : (
                        <></>
                    )}

                    <Stack>
                        <InputLabel id="type" required>
                            Loại xe
                        </InputLabel>
                        <Select
                            labelId="type"
                            id="demo-simple-select-districts"
                            size="small"
                            sx={{
                                borderRadius: '10px',
                            }}
                            onChange={(event: SelectChangeEvent) => {
                                setVehicleTypeId(event.target.value);
                            }}
                        >
                            {listVehicle.map((item, index) => (
                                <MenuItem value={item.ID} key={index}>
                                    {item.Name}
                                </MenuItem>
                            ))}
                        </Select>
                    </Stack>

                    {isHiddenPlateNumber && (
                        <Stack>
                            <InputLabel>Biển số xe*</InputLabel>
                            <StyledOutlinedInput
                                autoComplete="off"
                                value={plateNumber}
                                onChange={(e) => {
                                    const { value } = e.target;

                                    setPlateNumber(value.toUpperCase());
                                }}
                                size="small"
                                fullWidth
                            />
                        </Stack>
                    )}

                    <Stack>
                        <InputLabel required>Ngày hết hạn phương tiện</InputLabel>
                        <DatePicker
                            format="dd/MM/yyyy"
                            slotProps={{
                                textField: {
                                    size: 'small',
                                },
                            }}
                            minDate={new Date()}
                            value={dateExpire}
                            onChange={(newValue) => {
                                setDateExpire(newValue);
                            }}
                            sx={{
                                '& .MuiInputBase-root': {
                                    borderRadius: '10px',
                                },
                            }}
                        />
                    </Stack>
                    <Stack>
                        <InputLabel>Hiệu xe</InputLabel>
                        <StyledOutlinedInput
                            autoComplete="off"
                            size="small"
                            fullWidth
                            value={vehicleBrand}
                            onChange={(e) => {
                                setVehicleBrand(e.target.value);
                            }}
                        />
                    </Stack>
                    <Stack>
                        <InputLabel>Màu</InputLabel>
                        <StyledOutlinedInput
                            autoComplete="off"
                            size="small"
                            fullWidth
                            value={color}
                            onChange={(e) => {
                                setColor(e.target.value);
                            }}
                        />
                    </Stack>

                    <Stack>
                        <InputLabel>Mô tả</InputLabel>
                        <StyledOutlinedInput
                            autoComplete="off"
                            value={description}
                            onChange={(e) => {
                                setDescription(e.target.value);
                            }}
                            size="small"
                            label="Mô tả"
                            fullWidth
                            multiline
                            rows={4}
                        />
                    </Stack>
                </Stack>
            </DialogContent>
            <DialogActions
                sx={{
                    px: 3,
                    pb: 3,
                }}
            >
                <Stack sx={{ m: 1, position: 'relative' }}>
                    <StyleButton
                        variant="contained"
                        onClick={handleCreate}
                        disabled={isLoadingButton}
                    >
                        Tạo mới
                    </StyleButton>
                    {isLoadingButton && (
                        <CircularProgress
                            size={24}
                            sx={{
                                color: green[500],
                                position: 'absolute',
                                top: '50%',
                                left: '50%',
                                marginTop: '-12px',
                                marginLeft: '-12px',
                            }}
                        />
                    )}
                </Stack>
            </DialogActions>
            {openComfirm ? (
                <ComfirmCloseDialog
                    close={() => setOpenComfirm(false)}
                    action={() => {
                        setOpenComfirm(false);
                        handleClose();
                    }}
                />
            ) : (
                <></>
            )}
        </Dialog>
    );
}
