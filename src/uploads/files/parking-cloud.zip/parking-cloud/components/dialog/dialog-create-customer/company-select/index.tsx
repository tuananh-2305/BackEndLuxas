import { useAppDispatch, useAppSelector } from '@/hooks/useReudx';
import { InputLabel, MenuItem, Select, SelectChangeEvent, Stack } from '@mui/material';
import { useEffect } from 'react';
import { companyApi } from '@/api/company-api';
import { fillCompanys } from '@/redux/index';

interface CreateCustomerCompanySelectProps {
    company: string;
    changeCompany: (c: string) => void;
}
const ITEM_HEIGHT = 48;
const ITEM_PADDING_TOP = 8;
export const CreateCustomerCompanySelect = (props: CreateCustomerCompanySelectProps) => {
    const { changeCompany, company } = props;

    const dispatch = useAppDispatch();
    const listCompany = useAppSelector((state) => state.admin.company.data);

    useEffect(() => {
        companyApi.getAllCompany({ Current: 0, Limit: 10, TextSearch: '' }).then((res) => {
            const { Data, Total } = res.data;
            const action = fillCompanys({ data: Data, max: Total });
            dispatch(action);
        });

        return () => {
            const action = fillCompanys({ data: [], max: null });
            dispatch(action);
        };
    }, [dispatch]);
    const MenuProps = {
        PaperProps: {
            style: {
                maxHeight: ITEM_HEIGHT * 4.5 + ITEM_PADDING_TOP,
                width: 250,
            },
            onScroll: (e: any) => {
                if (
                    e.currentTarget.scrollHeight - e.currentTarget.scrollTop ===
                    e.currentTarget.clientHeight
                ) {
                    companyApi
                        .getAllCompany({
                            TextSearch: '',
                            Current: listCompany.length,
                            Limit: 10,
                        })
                        .then((res) => {
                            const { data } = res;
                            const newData = [...listCompany, ...data.Data];
                            const action = fillCompanys({
                                data: newData,
                                max: null,
                            });
                            dispatch(action);
                        });
                }
            },
        },
    };
    return (
        <Stack>
            <InputLabel>Công ty</InputLabel>

            <Select
                fullWidth
                size="small"
                sx={{
                    borderRadius: '10px',
                }}
                value={company}
                onChange={(e: SelectChangeEvent) => {
                    // console.log(e);
                    changeCompany(e.target.value);
                }}
                MenuProps={MenuProps}
            >
                {listCompany.map((item, index) => (
                    <MenuItem key={index} value={item.ID}>
                        {item.Name}
                    </MenuItem>
                ))}
                {/* <Stack
                    sx={{ maxHeight: '200px', overflow: 'auto' }}
                    onScroll={(e) => {
                        if (
                            e.currentTarget.scrollHeight - e.currentTarget.scrollTop ===
                            e.currentTarget.clientHeight
                        ) {
                            companyApi
                                .getAllCompany({
                                    TextSearch: '',
                                    Current: listCompany.length,
                                    Limit: 10,
                                })
                                .then((res) => {
                                    const { data } = res;
                                    const newData = [...listCompany, ...data.Data];
                                    const action = fillCompanys({
                                        data: newData,
                                        max: null,
                                    });
                                    dispatch(action);
                                });
                        }
                    }}
                >
                    {listCompany.map((item, index) => (
                        <MenuItem key={index} value={item.ID}>
                            {item.Name}
                        </MenuItem>
                    ))}
                </Stack> */}
            </Select>
        </Stack>
    );
};
