import { customerApi } from '@/api/customer-api';
import { useAppDispatch, useAppSelector } from '@/hooks/useReudx';
import { showSnackbarWithClose } from '@/hooks/useSnackbarWithClose';
import { changeIsCreateDialog } from '@/redux/index';
import { handleCompressImage, theme } from '@/ultis/index';
import {
    Dialog,
    DialogActions,
    DialogContent,
    DialogTitle,
    InputLabel,
    Stack,
    useMediaQuery,
} from '@mui/material';
import { useEffect, useState } from 'react';
import InputAddress from '../../common/input/input-address';
import InputUploadImage from '../../common/input/input-upload-image';
import { StyledOutlinedInput } from '../../common/style-component';
import { StyleButton } from '../../common/style-component/button';

import { CreateCustomerCompanySelect } from './company-select';
import { ComfirmCloseDialog } from '../dialog-comfirm-close';

export interface IDialogCreateCustomerProps {
    handleReload: () => void;
}

export default function DialogCreateCustomer(props: IDialogCreateCustomerProps) {
    const { handleReload } = props;

    const dispatch = useAppDispatch();
    const isOpenCreate = useAppSelector((state) => state.common.control.isCreate);

    const fullScreen = useMediaQuery(theme.breakpoints.down('md'));
    const [phone, setPhone] = useState('');
    const [name, setName] = useState('');
    const [email, setEmail] = useState('');
    const [avatar, setAvatar] = useState<File | null>(null);
    const [company, setCompany] = useState('');
    const [province, setProvince] = useState<string>('');
    const [district, setDistrict] = useState<string>('');
    const [ward, setWard] = useState<string>('');
    const [address, setAddress] = useState<string>('');
    const [openComfirm, setOpenComfirm] = useState(false);

    const handleClose = () => {
        const action = changeIsCreateDialog({ isOpen: false });
        dispatch(action);
    };

    const handleCreateCustomer = async () => {
        if (!name || !name.trim()) {
            showSnackbarWithClose('Vui lòng nhập họ tên', { variant: 'error' });
            return;
        }
        if (!phone || !phone.trim()) {
            showSnackbarWithClose('Vui lòng nhập số điện thoại', { variant: 'error' });
            return;
        }

        const payload = new FormData();
        payload.append('PhoneNumber', phone.trim());
        payload.append('FullName', name.trim());
        if (email) payload.append('Email', email.trim());

        if (avatar) {
            const imageCompress = await handleCompressImage(avatar);
            payload.append('files', imageCompress, avatar.name);
        }
        payload.append('CompanyId', company);
        payload.append('Province', province);
        payload.append('District', district);
        payload.append('Wards', ward);
        payload.append('Address', address.trim());

        customerApi
            .createCustomer(payload)
            .then((res) => {
                showSnackbarWithClose('Tạo người dùng thành công', { variant: 'success' });
                // router.reload();
                const action = changeIsCreateDialog({ isOpen: false });
                dispatch(action);
                handleReload();
            })
            .catch((error) => {
                if (typeof error?.response?.data?.message === 'string') {
                    showSnackbarWithClose(
                        error?.response ? error.response.data?.message : error.message,
                        {
                            variant: 'error',
                        }
                    );
                } else {
                    error?.response?.data?.message.forEach((item: any) => {
                        showSnackbarWithClose(item, {
                            variant: 'error',
                        });
                    });
                }
            });

        // try {
        //     const { data } = await customerApi.createCustomer(payload);
        //     showSnackbarWithClose('Tạo người dùng thành công', { variant: 'success' });
        //     handleReload && handleReload();
        //     handleClose();
        // } catch (error: any) {
        //     if (Array.isArray(error?.response?.data?.message)) {
        //         error?.response?.data?.message.forEach((item: any) => {
        //             showSnackbarWithClose(item, {
        //                 variant: 'error',
        //             });
        //         });
        //     } else {
        //         showSnackbarWithClose(
        //             error?.response ? error.response.data?.message : error.message,
        //             {
        //                 variant: 'error',
        //             }
        //         );
        //     }
        // }
    };
    useEffect(() => {
        if (!isOpenCreate) {
            setName('');
            setPhone('');
            setEmail('');
            setAvatar(null);
            setCompany('');
            setProvince('');
            setDistrict('');
            setWard('');
            setAddress('');
        }
    }, [isOpenCreate]);
    return (
        <Dialog
            fullScreen={fullScreen}
            open={isOpenCreate}
            onClose={() => {
                if (name || phone || email || avatar || company || province || district || ward) {
                    setOpenComfirm(true);
                } else {
                    handleClose();
                }
            }}
            aria-labelledby="responsive-dialog-title"
            sx={{
                '& .MuiDialog-paper': {
                    minWidth: '600px',
                    borderRadius: '16px',
                },
            }}
        >
            <DialogTitle>{'Tạo khách hàng mới'}</DialogTitle>
            <DialogContent>
                <Stack py={2} spacing={2}>
                    <InputUploadImage avatar={avatar} setAvatar={setAvatar} />
                    <Stack>
                        <InputLabel required>Họ tên</InputLabel>
                        <StyledOutlinedInput
                            autoComplete="off"
                            value={name}
                            onChange={(e) => {
                                setName(e.target.value);
                            }}
                            size="small"
                            fullWidth
                        />
                    </Stack>

                    <Stack>
                        <InputLabel required>Số điện thoại</InputLabel>
                        <StyledOutlinedInput
                            autoComplete="off"
                            value={phone}
                            onChange={(e) => {
                                setPhone(e.target.value);
                            }}
                            size="small"
                            fullWidth
                        />
                    </Stack>
                    <Stack>
                        <InputLabel>Email</InputLabel>
                        <StyledOutlinedInput
                            autoComplete="off"
                            value={email}
                            onChange={(e) => {
                                setEmail(e.target.value);
                            }}
                            size="small"
                            fullWidth
                        />
                    </Stack>
                    {/* --------------------------- */}

                    <CreateCustomerCompanySelect
                        company={company}
                        changeCompany={(c) => setCompany(c)}
                    />

                    {/* --------------------------- */}

                    <InputAddress
                        selectedProvince={province}
                        selectedDistrict={district}
                        selectedWard={ward}
                        setSelectedProvince={setProvince}
                        setSelectedDistrict={setDistrict}
                        setSelectedWard={setWard}
                    />

                    <Stack>
                        <InputLabel>Địa chỉ</InputLabel>
                        <StyledOutlinedInput
                            autoComplete="off"
                            value={address}
                            onChange={(e) => {
                                setAddress(e.target.value);
                            }}
                            size="small"
                            fullWidth
                        />
                    </Stack>
                </Stack>
            </DialogContent>
            <DialogActions
                sx={{
                    px: 3,
                    pb: 3,
                }}
            >
                <StyleButton variant="contained" onClick={handleCreateCustomer}>
                    Tạo mới
                </StyleButton>
            </DialogActions>
            {openComfirm ? (
                <ComfirmCloseDialog
                    close={() => setOpenComfirm(false)}
                    action={() => {
                        setOpenComfirm(false);
                        handleClose();
                    }}
                />
            ) : (
                <></>
            )}
        </Dialog>
    );
}
