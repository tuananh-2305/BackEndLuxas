import { Stack, Typography } from '@mui/material';
import WarningIcon from '@mui/icons-material/Warning';

interface ComfirmCloseDialogProps {
    close: () => void;

    action: () => void;
}

export const ComfirmCloseDialog = (props: ComfirmCloseDialogProps) => {
    const { close, action } = props;
    return (
        <Stack
            sx={{ position: 'fixed', top: 0, bottom: 0, right: 0, left: 0, zIndex: 99 }}
            alignItems="center"
            justifyContent="center"
        >
            <Stack
                sx={{
                    position: 'absolute',
                    top: 0,
                    left: 0,
                    bottom: 0,
                    right: 0,
                    zIndex: 2,
                    backgroundColor: '#00000050',
                }}
            />
            <Stack
                sx={{
                    width: '460px',
                    height: 'fit-content',
                    backgroundColor: '#e6f4fa',
                    boxShadow: '0px 2px 2px 0px #00000040',
                    borderRadius: '15px',
                    padding: '20px 30px',
                    gap: '20px',
                    zIndex: 3,
                }}
                alignItems="center"
            >
                <WarningIcon sx={{ color: '#E94F4F', fontSize: '30px' }} />

                <Stack sx={{ gap: '20px' }} alignItems="center" justifyContent="center">
                    <Typography component="span" sx={{ fontSize: '14px', textAlign: 'center' }}>
                        Bạn đang thực hiện thao tác <strong>hủy bỏ nhập liệu</strong>. Bạn có muốn
                        tiếp tục hay không?
                    </Typography>

                    <Typography sx={{ fontSize: '14px', textAlign: 'center', color: '#E94F4F' }}>
                        Dữ liệu đang nhập không được lưu sau thao tác này!
                    </Typography>
                </Stack>

                <Stack direction="row-reverse" sx={{ gap: '25px', width: '100%' }}>
                    <Stack
                        sx={{
                            boxShadow: '0px 2px 2px 0px #00000040',
                            borderRadius: '10px',
                            backgroundColor: '#f9d3d3',
                            padding: '10px 20px',
                            cursor: 'pointer',
                        }}
                        onClick={() => action()}
                    >
                        <Typography sx={{ color: '#E94F4F', fontWeight: 700 }}>Tiếp tục</Typography>
                    </Stack>

                    <Stack
                        sx={{
                            boxShadow: '0px 2px 2px 0px #00000040',
                            borderRadius: '10px',
                            backgroundColor: '#78C6E7',
                            padding: '10px 20px',
                            cursor: 'pointer',
                        }}
                        onClick={() => close()}
                    >
                        <Typography sx={{ color: '#fff', fontWeight: 700 }}>Quay lại</Typography>
                    </Stack>
                </Stack>
            </Stack>
        </Stack>
    );
};
