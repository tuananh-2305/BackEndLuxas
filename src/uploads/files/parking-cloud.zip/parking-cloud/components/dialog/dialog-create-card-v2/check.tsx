import { CircularProgress, IconButton, Stack, TextField, Typography } from '@mui/material';
import DialogAlert from '../dialog-alert';
import { useState } from 'react';
import ReplayIcon from '@mui/icons-material/Replay';
import { useAppSelector } from '@/hooks/useReudx';
import Image from 'next/image';
import { cardApi } from '@/api/card-api';
import { showSnackbarWithClose } from '@/hooks/useSnackbarWithClose';
import { hasSpecialCharsOrWhitespace } from '@/ultis/global-func';

interface CreateCardCheckComponentProps {
    changeView: (v: 'check' | 'control') => void;
    changeCardChoose: (v: { cardNumber: string; cardData: any }) => void;
}

export const CreateCardCheckComponent = (props: CreateCardCheckComponentProps) => {
    const { changeCardChoose, changeView } = props;

    const parkingChoose = useAppSelector((state) => state.parking.choose);

    const [card, setCard] = useState<string>('');
    const [cardData, setCardData] = useState<any>(null);
    const [ischeck, setIsCheck] = useState(false);
    const [loading, setLoading] = useState(false);

    const checkButton = () => {
        if (ischeck) {
            if (cardData) {
                return (
                    <Stack
                        sx={{
                            backgroundColor: '#007DC0',
                            padding: '5px',
                            borderRadius: '5px',
                            width: '150px',
                            cursor: 'pointer',
                        }}
                        justifyContent="center"
                        alignItems="center"
                        onClick={() => {
                            if (parkingChoose) {
                                setIsCheck(false);
                                changeCardChoose({ cardData: cardData, cardNumber: card });
                                setCardData(null);
                                changeView('control');
                            }
                        }}
                    >
                        <Typography sx={{ fontWeight: 700, color: '#fff', fontSize: '14px' }}>
                            Cập nhật
                        </Typography>
                    </Stack>
                );
            } else {
                return (
                    <Stack
                        sx={{
                            backgroundColor: '#007DC0',
                            padding: '5px',
                            borderRadius: '5px',
                            width: '150px',
                            cursor: 'pointer',
                        }}
                        justifyContent="center"
                        alignItems="center"
                        onClick={() => {
                            if (parkingChoose) {
                                setIsCheck(false);
                                changeCardChoose({ cardData: null, cardNumber: card });
                                setCardData(null);
                                changeView('control');
                            }
                        }}
                    >
                        <Typography sx={{ fontWeight: 700, color: '#fff', fontSize: '14px' }}>
                            Tạo mới
                        </Typography>
                    </Stack>
                );
            }
        } else {
            if (card && card.length >= 8) {
                return (
                    <Stack
                        sx={{
                            backgroundColor: '#007DC0',
                            padding: '5px',
                            borderRadius: '5px',
                            width: '150px',
                            cursor: 'pointer',
                        }}
                        justifyContent="center"
                        alignItems="center"
                        onClick={() => {
                            if (parkingChoose && card) {
                                setLoading(true);
                                cardApi
                                    .getCheckCard(card, parkingChoose.ID)
                                    .then((res) => {
                                        setIsCheck(true);
                                        setCardData(res.data ? res.data : null);
                                    })
                                    .catch((error) => {
                                        if (Array.isArray(error?.response?.data?.message)) {
                                            error?.response?.data?.message.forEach((item: any) => {
                                                showSnackbarWithClose(item, {
                                                    variant: 'error',
                                                });
                                            });
                                        } else {
                                            showSnackbarWithClose(
                                                error?.response
                                                    ? error.response.data?.message
                                                    : error.message,
                                                {
                                                    variant: 'error',
                                                }
                                            );
                                        }
                                    })
                                    .finally(() => {
                                        setLoading(false);
                                    });
                            }
                        }}
                    >
                        {loading ? (
                            <CircularProgress
                                size={20}
                                sx={{
                                    color: '#fff',
                                    ml: '10px',
                                }}
                            />
                        ) : (
                            <Typography sx={{ fontWeight: 700, color: '#fff', fontSize: '14px' }}>
                                Kiểm tra
                            </Typography>
                        )}
                    </Stack>
                );
            } else {
                return (
                    <Stack
                        sx={{
                            backgroundColor: '#55595D95',
                            padding: '5px',
                            borderRadius: '5px',
                            width: '150px',
                        }}
                        justifyContent="center"
                        alignItems="center"
                    >
                        {loading ? (
                            <CircularProgress
                                size={20}
                                sx={{
                                    color: '#fff',
                                    ml: '10px',
                                }}
                            />
                        ) : (
                            <Typography
                                sx={{
                                    fontWeight: 700,
                                    fontSize: '14px',
                                    color: '#000',
                                }}
                            >
                                Kiểm tra
                            </Typography>
                        )}
                    </Stack>
                );
            }
        }
    };

    const checkMessage = () => {
        if (ischeck) {
            if (cardData) {
                if (cardData.MemberId) {
                    return (
                        <Stack sx={{ gap: '10px' }}>
                            <Typography
                                sx={{ fontSize: '14px', fontWeight: 600, color: '#ff304f' }}
                            >
                                Mã thẻ đã được sử dụng
                            </Typography>
                            <Stack justifyContent="center" alignItems="center">
                                <Image
                                    src={
                                        cardData?.MemberId?.Avatar
                                            ? `/service/${cardData?.MemberId?.Avatar}`
                                            : '/default-user.jpg'
                                    }
                                    style={{
                                        objectFit: 'cover',
                                        border: '2px solid white',
                                        borderRadius: '50%',
                                        boxShadow: 'rgba(0, 0, 0, 0.24) 0px 3px 8px',
                                    }}
                                    width={60}
                                    height={60}
                                    alt="photo"
                                />
                            </Stack>

                            <Stack>
                                <Typography sx={{ fontSize: '14px' }}>
                                    <strong>Người dùng hiện tại :</strong> {cardData?.MemberId.Name}
                                </Typography>
                                {cardData?.MemberId?.Phone ? (
                                    <Typography sx={{ fontSize: '14px' }}>
                                        <strong>Sổ điện thoại :</strong> {cardData.MemberId.Phone}
                                    </Typography>
                                ) : (
                                    <></>
                                )}
                                {cardData?.MemberId?.Email ? (
                                    <Typography sx={{ fontSize: '14px' }}>
                                        <strong>Địa chỉ mail :</strong> {cardData.MemberId.Email}
                                    </Typography>
                                ) : (
                                    <></>
                                )}
                                {cardData?.Address ? (
                                    <Typography sx={{ fontSize: '14px' }}>
                                        <strong>Địa chỉ căn hộ :</strong> {cardData.Address}
                                    </Typography>
                                ) : (
                                    <></>
                                )}
                            </Stack>

                            <Stack>
                                <Typography sx={{ fontSize: '14px', fontWeight: 700 }}>
                                    Tình trạng :
                                </Typography>
                                <Stack component="ul" sx={{ paddingLeft: '20px' }}>
                                    {cardData?.IsCardParking ? (
                                        <Typography component="li" sx={{ fontSize: '14px' }}>
                                            Được dùng cho bãi xe
                                        </Typography>
                                    ) : (
                                        <Typography component="li" sx={{ fontSize: '14px' }}>
                                            Không dùng cho bãi xe
                                        </Typography>
                                    )}

                                    {cardData?.IsCardElevator ? (
                                        <Typography component="li" sx={{ fontSize: '14px' }}>
                                            Được dùng cho thang máy
                                        </Typography>
                                    ) : (
                                        <Typography component="li" sx={{ fontSize: '14px' }}>
                                            Không dùng cho thang máy
                                        </Typography>
                                    )}
                                </Stack>
                            </Stack>
                        </Stack>
                    );
                } else {
                    return (
                        <Stack>
                            <Typography
                                sx={{
                                    fontSize: '14px',
                                    fontWeight: 600,
                                    color: '#ff304f',
                                }}
                            >
                                Mã thẻ đã được sử dụng nhưng chưa gán cho cư dân
                            </Typography>
                            <Typography sx={{ fontSize: '14px', fontWeight: 700 }}>
                                Tình trạng :
                            </Typography>
                            <Stack component="ul" sx={{ paddingLeft: '20px' }}>
                                {cardData?.Address ? (
                                    <Typography sx={{ fontSize: '14px' }}>
                                        <strong>Địa chỉ căn hộ :</strong> {cardData.Address}
                                    </Typography>
                                ) : (
                                    <></>
                                )}
                                {cardData?.IsCardParking ? (
                                    <Typography component="li" sx={{ fontSize: '14px' }}>
                                        Được dùng cho bãi xe
                                    </Typography>
                                ) : (
                                    <Typography component="li" sx={{ fontSize: '14px' }}>
                                        Không dùng cho bãi xe
                                    </Typography>
                                )}

                                {cardData?.IsCardElevator ? (
                                    <Typography component="li" sx={{ fontSize: '14px' }}>
                                        Được dùng cho thang máy
                                    </Typography>
                                ) : (
                                    <Typography component="li" sx={{ fontSize: '14px' }}>
                                        Không dùng cho thang máy
                                    </Typography>
                                )}
                            </Stack>
                        </Stack>
                    );
                }
            } else {
                return (
                    <Typography sx={{ fontSize: '14px', fontWeight: 600, color: '#17b978' }}>
                        Mã thẻ Chưa được sử dụng trong bãi
                    </Typography>
                );
            }
        } else {
            return <></>;
        }
    };
    return (
        <Stack
            sx={{
                padding: '10px',
                gap: '10px',
                height: 'fit-content',
                justifyContent: 'space-between',
            }}
        >
            <Stack
                sx={{ gap: '10px', padding: '10px', flex: 1, width: '100%' }}
                alignItems="center"
                justifyContent="center"
                direction="row"
            >
                <TextField
                    size="small"
                    value={card}
                    disabled={ischeck && !loading}
                    sx={{ width: '100%', fontSize: '14px' }}
                    placeholder="Quét thẻ để kiểm tra"
                    onChange={(e) => {
                        const { value } = e.target;

                        if (!hasSpecialCharsOrWhitespace(value)) {
                            setCard(value);
                        }
                    }}
                />
                {ischeck && !loading ? (
                    <Stack
                        sx={{
                            backgroundColor: '#007DC0',
                            padding: '5px',
                            borderRadius: '5px',
                            width: '150px',
                            cursor: 'pointer',
                        }}
                        justifyContent="center"
                        alignItems="center"
                        onClick={() => {
                            setIsCheck(false);
                            setCardData(null);
                        }}
                    >
                        <Typography sx={{ fontSize: '14px', fontWeight: 600, color: '#fff' }}>
                            Làm mới
                        </Typography>
                    </Stack>
                ) : (
                    <></>
                )}
            </Stack>

            {checkMessage()}
            <Stack direction="row" justifyContent="flex-end" sx={{ gap: '10px' }}>
                {checkButton()}
            </Stack>
        </Stack>
    );
};
