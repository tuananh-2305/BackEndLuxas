import { StyledOutlinedInput } from '@/components/common/style-component';
import { Vehicel } from '@/components/formular/interface';
import { MemberModel } from '@/models/index';
import {
    CardMedia,
    IconButton,
    InputLabel,
    MenuItem,
    Select,
    Stack,
    Tooltip,
    Typography,
    Checkbox,
    Button,
    CircularProgress,
} from '@mui/material';
import Image from 'next/image';
import { useEffect, useMemo, useState } from 'react';
import ImageIcon from '@mui/icons-material/Image';
import { showSnackbarWithClose } from '@/hooks/useSnackbarWithClose';
import { useAppSelector } from '@/hooks/useReudx';
import { cardApi } from '@/api/card-api';
import { memberVehicleApi } from '@/api/member-vehicle-api';
import { AutoCompleteVehicel } from '@/components/common/input/autocomplete-vehicel';
import { MemberVehicleModel } from '@/models/member.vehicle.model';
import AutoCompoleteMember from '@/components/common/input/autocomplete-member';

interface CreateCardActionComponentProps {
    cardData: { cardNumber: string; cardData: any };
    onlyElevator: boolean;
    changeView: (v: 'check' | 'control') => void;
    reload: () => void;
}

export const CreateCardActionComponent = (props: CreateCardActionComponentProps) => {
    const { cardData, onlyElevator, changeView, reload } = props;

    // const [keyRoles, setKeyRoles] = useState([]);
    const parking = useAppSelector((state) => state.parking.choose);
    const [vehicel, setVehicel] = useState<MemberVehicleModel | null>(
        cardData?.cardData?.MemberVehicleId ? cardData?.cardData?.MemberVehicleId : null
    );
    const [description, setDescription] = useState(
        cardData?.cardData?.Description ? cardData?.cardData?.Description : ''
    );
    const [member, setMember] = useState<MemberModel | null>(
        cardData?.cardData?.MemberId ? cardData?.cardData?.MemberId : null
    );
    // const [dateExpire, setDateExpire] = useState<Date | null>(dayjs().endOf('month').toDate());
    const [typeAuthen, setTypeAuthen] = useState<'CARD' | 'FACE'>('CARD');
    const [isLoadingButton, setIsLoadingButton] = useState(false);

    // const [cardNumber, setCardNumber] = useState(
    //     cardData?.cardData ? cardData?.cardData?.CardNumber : ''
    // );
    const [idCard, setIdCard] = useState(
        cardData?.cardData?.IdCard ? cardData?.cardData.IdCard : ''
    );
    // const [faceImage, setFaceImage] = useState<File | string | null>(null);
    const [isCardElevator, setIsCardElevator] = useState(
        cardData?.cardData ? cardData?.cardData.IsCardElevator : Boolean(onlyElevator)
    );
    const [isCardParking, setIsCardParking] = useState(
        cardData?.cardData ? cardData?.cardData.IsCardParking : false
    );
    const handleCreateCard = () => {
        if (!member) {
            showSnackbarWithClose('Chưa chọn cư dân', {
                variant: 'error',
            });
            return;
        }

        if (typeAuthen === 'CARD') {
            if (Boolean(cardData?.cardNumber.trim())) {
                if (cardData?.cardNumber.trim().length < 8) {
                    showSnackbarWithClose('Mã thẻ phải ít nhất 8 ký tự', {
                        variant: 'error',
                    });
                    return;
                }
            } else {
                showSnackbarWithClose('Mã thẻ không được để trống', {
                    variant: 'error',
                });
                return;
            }
        }

        if (!parking) {
            showSnackbarWithClose('Chưa chọn bãi xe', {
                variant: 'error',
            });
            return;
        }

        if (!isCardElevator && !isCardParking) {
            showSnackbarWithClose('Bạn chưa chọn mục tiêu sử dụng', {
                variant: 'error',
            });
            return;
        }

        if (isCardParking && !vehicel) {
            showSnackbarWithClose('Bạn chưa chọn phương tiện', {
                variant: 'error',
            });
            return;
        }

        if (!isCardElevator && !isCardParking) {
            showSnackbarWithClose('Bạn phải chọn ít nhất một mục tiêu sử dụng.', {
                variant: 'error',
            });
            return;
        }

        const formData = new FormData();

        if (idCard) {
            formData.append('IdCard', idCard);
        }

        formData.append('MemberId', member.ID);
        formData.append('ParkingId', parking.ID);
        formData.append('Description', description);
        formData.append('TypeAuthen', typeAuthen);

        if (typeAuthen === 'CARD') {
            if (cardData?.cardNumber) {
                formData.append('CardNumber', cardData?.cardNumber);
            }
        }

        // if (typeAuthen === 'FACE' && faceImage) {
        //     if (faceImage) {
        //         formData.append('files', faceImage, faceImage.name);
        //     } else {
        //         showSnackbarWithClose('Bạn cần chọn một tấm ảnh!.', { variant: 'error' });
        //         return;
        //     }
        // }

        formData.append('IsCardElevator', isCardElevator.toString());
        formData.append('IsCardParking', isCardParking.toString());

        if (isCardParking && vehicel) {
            formData.append('MemberVehicleId', vehicel.ID);
        }

        if (formData) {
            if (cardData?.cardData) {
                formData.append('ID', cardData.cardData.ID);
                setIsLoadingButton(true);
                cardApi
                    .updateCard(formData)
                    .then((res) => {
                        reload();
                        showSnackbarWithClose('Cập nhật thành công', {
                            variant: 'success',
                        });
                    })
                    .catch((error) => {
                        if (Array.isArray(error?.response?.data?.message)) {
                            error?.response?.data?.message.forEach((item: any) => {
                                showSnackbarWithClose(item, {
                                    variant: 'error',
                                });
                            });
                        } else {
                            showSnackbarWithClose(
                                error?.response ? error.response.data?.message : error.message,
                                {
                                    variant: 'error',
                                }
                            );
                        }
                    })
                    .finally(() => {
                        setIsLoadingButton(false);
                    });
            } else {
                cardApi
                    .createCard(formData)
                    .then(() => {
                        showSnackbarWithClose('Thêm mới thành công', {
                            variant: 'success',
                        });
                        reload();
                    })
                    .catch((error) => {
                        if (Array.isArray(error?.response?.data?.message)) {
                            error?.response?.data?.message.forEach((item: any) => {
                                showSnackbarWithClose(item, {
                                    variant: 'error',
                                });
                            });
                        } else {
                            showSnackbarWithClose(
                                error?.response ? error.response.data?.message : error.message,
                                {
                                    variant: 'error',
                                }
                            );
                        }
                    })
                    .finally(() => {
                        setIsLoadingButton(false);
                    });
            }
        }
    };
    // useEffect(() => {
    //     if (!vehicel) {
    //         setIsCardParking(false);
    //     }
    // }, [vehicel]);

    // useEffect(() => {
    //     if (member && parkingChoose) {
    //         memberVehicleApi.getMemberVehicleByIdMemberAndParking(member.ID, {
    //             ID: member.ID,
    //             Current: 0,
    //             Limit: 1000,
    //             TextSearch: '',
    //         });
    //     }
    // }, [member, parkingChoose]);
    // console.log(typeof cardData?.cardData);

    return (
        <Stack
            sx={{
                padding: '10px 0px',
                maxHeight: '800px',
                overflow: 'auto',
            }}
        >
            <Typography sx={{ fontSize: '20px', fontWeight: 600, padding: '10px' }}>
                {cardData?.cardData ? 'Cập nhật thẻ tháng' : 'Tạo mới thẻ tháng'}
            </Typography>
            <Stack sx={{ padding: '10px', gap: '10px', height: '100%' }}>
                {parking ? (
                    <AutoCompoleteMember
                        setValue={(value) => {
                            setMember(value);
                            setVehicel(null);
                        }}
                        parkingId={parking.ID}
                        value={member}
                    />
                ) : (
                    <></>
                )}
                {parking && isCardParking ? (
                    <AutoCompleteVehicel
                        setValue={function (value: MemberVehicleModel | null): void {
                            setVehicel(value);
                        }}
                        parkingId={parking.ID}
                        value={vehicel}
                        memberId={member?.ID}
                    />
                ) : (
                    <></>
                )}
                <Stack>
                    <InputLabel>Loại xác thực</InputLabel>
                    <Select
                        labelId="demo-simple-select-label"
                        fullWidth
                        size="small"
                        sx={{
                            borderRadius: '10px',
                        }}
                        value={typeAuthen}
                        onChange={(e: any) => {
                            setTypeAuthen(e.target.value);
                        }}
                    >
                        <MenuItem value={'CARD'}>Thẻ từ</MenuItem>
                        {/* <MenuItem value={'FACE'}>Gương mặt</MenuItem> */}
                    </Select>
                </Stack>
                {typeAuthen === 'CARD' && (
                    <Tooltip
                        title={
                            'Dãy số từ 8 số, chỉ có thể kiểm tra thông qua việc quét bằng máy đọc'
                        }
                    >
                        <Stack>
                            <InputLabel>Mã thẻ*</InputLabel>
                            <StyledOutlinedInput
                                autoComplete="off"
                                defaultValue={cardData?.cardNumber}
                                disabled={true}
                                // value={CardNumber}
                                // onChange={(e) => {
                                //     setCardNumber(e.target.value);
                                // }}
                                size="small"
                                fullWidth
                            />
                        </Stack>
                    </Tooltip>
                )}
                {typeAuthen === 'CARD' ? (
                    <Tooltip title="Dãy số in bên ngoài thẻ vật lý có thể kiểm tra trực tiếp trên thẻ">
                        <Stack>
                            <InputLabel>Số thẻ ngoài</InputLabel>
                            <StyledOutlinedInput
                                autoComplete="off"
                                value={idCard}
                                onChange={(e) => {
                                    setIdCard(e.target.value);
                                }}
                                size="small"
                                fullWidth
                            />
                        </Stack>
                    </Tooltip>
                ) : (
                    <></>
                )}

                {/* {typeAuthen === 'FACE' && (
                    <Stack>
                        <Typography sx={{ fontSize: '12px', fontStyle: 'italic' }}>
                            * Hình ảnh: Chụp 1 người, rõ mặt
                        </Typography>

                        <Stack
                            sx={{
                                position: 'relative',
                                width: '80%',
                                aspectRatio: '16/9',
                                left: '10%',
                            }}
                        >

                            <Image
                                src={
                                    faceImage
                                        ? URL.createObjectURL(faceImage)
                                        : '/images/default_background_company.png'
                                }
                                style={{ objectFit: 'cover' }}
                                fill
                                alt="face-image"
                            />

                            <Tooltip title="Thêm ảnh">
                                <IconButton
                                    sx={{
                                        position: 'absolute',
                                        zIndex: 3,
                                        bottom: '15px',
                                        right: '15px',
                                        backgroundColor: 'rgba(217, 217, 217, 0.6)',
                                        color: '#fff',
                                        boxShadow: '0 0 5px rgba(0, 0, 0, 0.2)',
                                    }}
                                    component="label"
                                >
                                    <input
                                        hidden
                                        accept="image/*"
                                        type="file"
                                        onChange={(e: any) => {
                                            if (!e.target.files[0]) return;
                                            setFaceImage(e.target.files[0]);
                                        }}
                                        autoComplete="off"
                                    />
                                    <ImageIcon />
                                </IconButton>
                            </Tooltip>
                        </Stack>
                    </Stack>
                )} */}
                <Typography>Mục tiêu sử dụng :</Typography>
                <Stack direction="row" alignItems="center">
                    <Checkbox
                        size="small"
                        checked={isCardElevator}
                        onChange={(e) => {
                            setIsCardElevator(e.target.checked);
                        }}
                    />
                    <Typography sx={{ fontSize: '14px', fontWeight: 600 }}>
                        Dùng cho phân tầng thang máy.
                    </Typography>
                </Stack>
                <Stack direction="row" alignItems="center">
                    <Checkbox
                        size="small"
                        checked={isCardParking}
                        onChange={(e) => {
                            setIsCardParking(e.target.checked);
                        }}
                    />

                    <Typography
                        sx={{
                            fontSize: '14px',
                            fontWeight: 600,
                            color: vehicel ? '#000' : '#55595D',
                        }}
                    >
                        Dùng cho bãi xe.
                    </Typography>
                </Stack>
                <Stack>
                    <InputLabel>Mô tả</InputLabel>
                    <StyledOutlinedInput
                        autoComplete="off"
                        value={description}
                        onChange={(e) => {
                            setDescription(e.target.value);
                        }}
                        size="small"
                        fullWidth
                        multiline
                        rows={4}
                    />
                </Stack>
                <Stack sx={{ flex: 1 }} />
                <Stack direction="row" sx={{ gap: '10px' }} justifyContent="flex-end">
                    {!isLoadingButton ? (
                        <Stack
                            sx={{
                                width: 'fit-content',
                                backgroundColor: '#55595D',
                                borderRadius: '5px',
                                padding: '5px 20px',
                                cursor: 'pointer',
                                transition: 'all ease .5s',
                                '&:hover ': { boxShadow: 'rgba(0, 0, 0, 0.24) 0px 3px 8px' },
                            }}
                            alignItems="center"
                            onClick={() => {
                                changeView('check');
                            }}
                        >
                            <Typography sx={{ fontSize: '14px', fontWeight: 700, color: '#fff' }}>
                                Quay về
                            </Typography>
                        </Stack>
                    ) : (
                        <></>
                    )}

                    <Stack
                        sx={{
                            width: '100px',
                            backgroundColor: '#007DC0',
                            borderRadius: '5px',
                            padding: '5px 20px',
                            cursor: 'pointer',
                            '&:hover ': { boxShadow: 'rgba(0, 0, 0, 0.24) 0px 3px 8px' },
                        }}
                        onClick={() => handleCreateCard()}
                        justifyContent="center"
                        alignItems="center"
                    >
                        {isLoadingButton ? (
                            <CircularProgress
                                size={20}
                                sx={{
                                    color: '#fff',
                                    ml: '10px',
                                }}
                            />
                        ) : (
                            <Typography sx={{ fontSize: '14px', fontWeight: 700, color: '#fff' }}>
                                {cardData?.cardData ? 'Cập nhật' : 'Tạo mới'}
                            </Typography>
                        )}
                    </Stack>
                </Stack>
            </Stack>
        </Stack>
    );
};
