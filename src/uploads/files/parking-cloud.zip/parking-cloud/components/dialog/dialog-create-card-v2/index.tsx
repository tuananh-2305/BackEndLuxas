import { Stack, Typography } from '@mui/material';
import { CreateCardCheckComponent } from './check';
import { CreateCardActionComponent } from './control';
import { useState } from 'react';

interface DialogCreateCardProps {
    close: () => void;
    reload: () => void;
    onlyElevator?: boolean;
}
export const DialogCreateCard = (props: DialogCreateCardProps) => {
    const { close, onlyElevator, reload } = props;
    const [caseView, setCaseView] = useState<'check' | 'control'>('check');
    const [cardData, setCardData] = useState<{ cardNumber: string; cardData: any }>({
        cardData: null,
        cardNumber: '',
    });
    return (
        <Stack
            sx={{
                position: 'fixed',
                top: 0,
                bottom: 0,
                left: 0,
                right: 0,
                justifyContent: 'center',
                alignItems: 'center',
                zIndex: 10,
            }}
        >
            <Stack
                sx={{
                    position: 'absolute',
                    top: 0,
                    bottom: 0,
                    left: 0,
                    right: 0,
                    backgroundColor: '#55595D26',
                    zIndex: 2,
                }}
                onClick={() => close()}
            />
            <Stack
                sx={{
                    width: '600px',
                    height: 'fit-content',
                    backgroundColor: '#fff',
                    zIndex: 2,
                    boxShadow: 'rgba(0, 0, 0, 0.1) 0px 4px 12px',
                    borderRadius: '5px',
                    padding: '20px',
                }}
            >
                {caseView === 'check' ? (
                    <>
                        <Stack direction={'row'} sx={{ gap: '10px' }} alignItems="center">
                            <Typography sx={{ fontWeight: 600, fontSize: '20px' }}>
                                Kiểm tra mã thẻ
                            </Typography>
                            {/* <span style={{ fontSize: '18px', fontWeight: 300, color: '#f85959' }}>
                                (ít nhất 8 ký tự)
                            </span> */}
                        </Stack>
                        <CreateCardCheckComponent
                            changeView={(v) => setCaseView(v)}
                            changeCardChoose={(v) => setCardData(v)}
                        />
                    </>
                ) : (
                    <></>
                )}
                {caseView === 'control' ? (
                    <CreateCardActionComponent
                        cardData={cardData}
                        onlyElevator={Boolean(onlyElevator)}
                        changeView={(v) => setCaseView(v)}
                        reload={() => {
                            reload();
                            close();
                        }}
                    />
                ) : (
                    <></>
                )}
            </Stack>
        </Stack>
    );
};
