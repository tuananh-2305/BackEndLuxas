import { historyInOutApi } from '@/api/history-in-out-api';
import { useAppSelector } from '@/hooks/useReudx';
import { CardModel } from '@/models/card.model';
import { MemberModel } from '@/models/member.model';
import { MemberVehicleModel } from '@/models/member.vehicle.model';
import DeleteOutlineOutlinedIcon from '@mui/icons-material/DeleteOutlineOutlined';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import { Grid, Stack, Typography, useTheme } from '@mui/material';
import Accordion from '@mui/material/Accordion';
import AccordionDetails from '@mui/material/AccordionDetails';
import AccordionSummary from '@mui/material/AccordionSummary';
import Button from '@mui/material/Button';
import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import DialogContentText from '@mui/material/DialogContentText';
import DialogTitle from '@mui/material/DialogTitle';
import { useEffect, useState } from 'react';
export interface IDeleteMemberDialogProps {
    open: boolean;
    handleClose: (() => void) | undefined;

    handleConfirm: () => void;
    data: MemberModel;
}

export default function DeleteMemberDialog(props: IDeleteMemberDialogProps) {
    const { handleClose, data, handleConfirm } = props;
    const theme = useTheme();

    const [check, setCheck] = useState<string[]>([]);
    // chưa xong
    const optionText = (CountCard: any, CountVehicle: any) => {
        var text;
        if (CountCard == 0 && CountVehicle == 0) {
            return false;
        }
        if (CountCard > 0 && CountVehicle > 0) {
            text = `${CountCard} thẻ và ${CountVehicle} phương tiện`;
        } else if (CountCard == 0) {
            text = `${CountVehicle} phương tiện`;
        } else if (CountVehicle == 0) {
            text = `${CountCard} thẻ`;
        } else {
            text = false;
        }
        return text;
    };

    const parking = useAppSelector((state) => state.parking.choose);

    useEffect(() => {
        if (parking && data.CountAuthentication && data.CountAuthentication.length !== 0) {
            historyInOutApi
                .checkByCardNumberAndParkingId({
                    ParkingId: parking.ID,
                    Data: data.CountAuthentication.map((v) => v.CardNumber),
                })
                .then((res) => setCheck(res.data));
        }
    }, [data.CountAuthentication, parking]);

    return (
        <Dialog
            open={props.open}
            aria-labelledby="alert-dialog-title"
            aria-describedby="alert-dialog-description"
            maxWidth={
                optionText(
                    props?.data?.CountAuthentication?.length,
                    props?.data?.CountVehicle?.length
                ) != false
                    ? 'sm'
                    : 'xs'
            }
            fullWidth
            sx={{
                '& .MuiDialog-paper': {
                    borderRadius: '10px',
                    pb: '20px',
                },
            }}
        >
            <DialogTitle
                id="alert-dialog-title"
                sx={{
                    display: 'flex',
                    flexDirection: 'row',
                    justifyContent: 'center',
                    alignItems: 'center',
                }}
            >
                <Stack
                    sx={{
                        background: '#E42727',
                        borderRadius: '50%',
                        padding: '10px',
                        width: '28px',
                        height: '28px',
                        justifyContent: 'center',
                        alignItems: 'center',
                        fontSize: '20px',
                        fontWeight: '700',
                        color: '#323232',
                        mr: '10px',
                    }}
                >
                    <DeleteOutlineOutlinedIcon
                        sx={{ width: '18px', height: '18px', color: '#fff' }}
                    />
                </Stack>
                Xóa dữ liệu
            </DialogTitle>
            <DialogContent>
                {optionText(
                    props?.data?.CountAuthentication?.length,
                    props?.data?.CountVehicle?.length
                ) != false && (
                    <DialogContentText
                        id="alert-dialog-description"
                        sx={{
                            fontSize: '14px',
                            fontWeight: '400',
                            color: '#007DC0',
                            textAlign: 'center',
                            pb: '10px',
                        }}
                    >
                        cư dân <strong> {props?.data?.Name}</strong> có{' '}
                        {optionText(
                            props?.data?.CountAuthentication?.length,
                            props?.data?.CountVehicle?.length
                        )}
                    </DialogContentText>
                )}

                {data?.CountAuthentication?.length !== 0 && (
                    <Accordion>
                        <AccordionSummary
                            expandIcon={<ExpandMoreIcon />}
                            aria-controls="panel1a-content"
                            id="panel1a-header"
                            sx={{
                                borderBottom: '1px solid #d9d9d9',
                            }}
                        >
                            <Stack direction={'row'} sx={{ gap: '10px' }} alignItems="center">
                                <Typography
                                    sx={{
                                        fontWeight: 500,
                                    }}
                                >
                                    {data?.CountAuthentication?.length} Thẻ
                                </Typography>

                                {check.length > 0 ? (
                                    <Typography
                                        sx={{
                                            color: '#f85959',
                                            textAlign: 'center',
                                            fontSize: '12px',
                                            padding: '5px',
                                        }}
                                    >
                                        Vẫn còn {check.length} thẻ trong bãi. Không được xóa.
                                    </Typography>
                                ) : (
                                    <></>
                                )}
                            </Stack>
                        </AccordionSummary>
                        <AccordionDetails sx={{ px: 0 }}>
                            {data?.CountAuthentication?.map((item: CardModel, index) => {
                                return (
                                    <Stack
                                        key={index}
                                        sx={{
                                            background: index % 2 == 0 ? '#F4FAFE' : '#fff',
                                            p: '5px 10px',
                                            // m: '5px',
                                        }}
                                    >
                                        <Grid container spacing={2}>
                                            <Grid item xs={5}>
                                                <Typography
                                                    sx={{
                                                        fontSize: '14px',
                                                        fontWeight: 500,
                                                        color: '#55595D',
                                                    }}
                                                >
                                                    Số thẻ ngoài: {item.IdCard}
                                                </Typography>
                                            </Grid>
                                            <Grid item xs={5}>
                                                <Typography
                                                    sx={{
                                                        fontSize: '14px',
                                                        fontWeight: 500,
                                                        color: '#55595D',
                                                    }}
                                                >
                                                    Mã thẻ: {item.CardNumber}
                                                </Typography>
                                            </Grid>
                                            <Grid item xs={2}>
                                                <Stack
                                                    style={{
                                                        backgroundColor: check.includes(
                                                            item.CardNumber
                                                        )
                                                            ? '#f85959'
                                                            : '#17b978',
                                                        borderRadius: '5px',
                                                    }}
                                                    justifyContent="center"
                                                    alignContent="center"
                                                >
                                                    <Typography
                                                        sx={{
                                                            fontSize: '14px',
                                                            fontWeight: 500,
                                                            color: '#333',
                                                            textAlign: 'center',
                                                        }}
                                                    >
                                                        {check.includes(item.CardNumber)
                                                            ? 'Chưa ra'
                                                            : 'Đã ra'}
                                                    </Typography>
                                                </Stack>
                                            </Grid>
                                        </Grid>
                                    </Stack>
                                );
                            })}
                        </AccordionDetails>
                    </Accordion>
                )}
                {data?.CountVehicle?.length !== 0 && (
                    <Accordion>
                        <AccordionSummary
                            expandIcon={<ExpandMoreIcon />}
                            aria-controls="panel2a-content"
                            id="panel2a-header"
                        >
                            <Typography
                                sx={{
                                    fontWeight: 500,
                                }}
                            >
                                {data?.CountVehicle?.length} Phương tiện
                            </Typography>
                        </AccordionSummary>
                        <AccordionDetails sx={{ px: 0 }}>
                            {data?.CountVehicle?.map((item: MemberVehicleModel, index: number) => {
                                return (
                                    <Stack
                                        key={index}
                                        sx={{
                                            background: index % 2 == 0 ? '#F4FAFE' : '#fff',
                                            p: '5px 10px',
                                        }}
                                    >
                                        <Grid container spacing={2}>
                                            <Grid item xs={6}>
                                                <Typography
                                                    sx={{
                                                        fontSize: '14px',
                                                        fontWeight: 500,
                                                        color: '#55595D',
                                                    }}
                                                >
                                                    {item.VehicleTypeId?.Name}{' '}
                                                    {item.PlateNumber ?? ''}
                                                </Typography>
                                            </Grid>
                                        </Grid>
                                    </Stack>
                                );
                            })}
                        </AccordionDetails>
                    </Accordion>
                )}
                <DialogContentText
                    id="alert-dialog-description"
                    sx={{
                        fontSize: '14px',
                        fontWeight: '400',
                        color: '#55595D',
                        textAlign: 'center',
                        px:
                            optionText(
                                props?.data?.CountAuthentication?.length,
                                props?.data?.CountVehicle?.length
                            ) != false
                                ? '10%'
                                : 0,
                        pt: '10px',
                    }}
                >
                    Dữ liệu sẽ không thể phục hồi sau khi thực hiện hành động này, bạn có chắc chắn
                    xóa không?
                </DialogContentText>
            </DialogContent>
            <DialogActions sx={{ px: '10%', gap: '10px' }}>
                <Button
                    onClick={handleClose}
                    variant="contained"
                    sx={{
                        flex: 1,
                        background: '#CDD2D1',
                        ':hover': {
                            background: '#DBE8E1',
                        },
                        fontSize: '14px',
                        fontWeight: '500',
                        borderRadius: '6px',
                        textTransform: 'revert-layer',
                    }}
                >
                    Hủy
                </Button>

                {check.length === 0 ? (
                    <Button
                        onClick={() => {
                            handleConfirm();
                        }}
                        variant="contained"
                        sx={{
                            flex: 1,
                            background: '#007DC0',
                            ':hover': {
                                background: '#009FD0',
                            },
                            fontSize: '14px',
                            fontWeight: '500',
                            textTransform: 'revert-layer',
                            borderRadius: '6px',
                        }}
                        autoFocus
                    >
                        Xác nhận
                    </Button>
                ) : (
                    <></>
                )}
            </DialogActions>
        </Dialog>
    );
}
