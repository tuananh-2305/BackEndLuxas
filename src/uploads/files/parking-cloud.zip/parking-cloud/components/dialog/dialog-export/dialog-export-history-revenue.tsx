import { HistoryRevenueExportPayl, ParkingModel } from '@/models/index';
import { handleDownloadFile, theme } from '@/ultis/index';
import {
    Dialog,
    DialogActions,
    DialogContent,
    Divider,
    Stack,
    Typography,
    useMediaQuery,
} from '@mui/material';
import { enqueueSnackbar } from 'notistack';
import { useEffect, useState } from 'react';

import { historyInOutApi } from '@/api/history-in-out-api';
import { StyleCustomDateTimePickerComponent } from '@/components/common/custom-datetime-picker/StyleCustomDateTimePickerComponent';
import { StyleButton } from '@/components/common/style-component';
import { showSnackbarWithClose } from '@/hooks/useSnackbarWithClose';
const BACKEND_DOMAIN = process.env.NEXT_PUBLIC_SERVER_PARKING_DOMAIN;

export interface IDialogExportHistoryRevenueProps {
    open: boolean;
    handleClose: () => void;
    parking: ParkingModel;
}

export default function DialogExportHistoryRevenue(props: IDialogExportHistoryRevenueProps) {
    const { open, handleClose, parking } = props;

    const [startDate, setStartDate] = useState<Date | null>(
        new Date(new Date().setDate(new Date().getDate() - 30))
    );
    const [endDate, setEndDate] = useState<Date | null>(new Date(new Date()));
    const handleStartDateChange = (date: Date | null) => {
        setStartDate(date);
    };
    const handleEndDateChange = (date: Date | null) => {
        setEndDate(date);
    };
    const nameDialog = 'Xuất báo cáo doanh thu';

    const fullScreen = useMediaQuery(theme.breakpoints.down('md'));

    // handle reset checked

    // reset name and checked when close dialog
    useEffect(() => {
        if (!open) {
            setStartDate(new Date(new Date().setDate(new Date().getDate() - 30)));
            setEndDate(new Date());
        }
    }, [open]);

    const handleExport = async () => {
        try {
            const payload: HistoryRevenueExportPayl = {
                ParkingId: parking.ID,
                StartDate: startDate,
                EndDate: endDate,
            };

            const { data } = await historyInOutApi.exportHistoryRevenueByExcel(payload);
            const url = `${BACKEND_DOMAIN}${data}`;
            // window.open(url);
            handleDownloadFile(url);
            showSnackbarWithClose(`${nameDialog} thành công`, {
                variant: 'success',
            });
            handleClose();
        } catch (error: any) {
            if (Array.isArray(error?.response?.data?.message)) {
                error?.response?.data?.message.forEach((item: any) => {
                    showSnackbarWithClose(item, {
                        variant: 'error',
                    });
                });
            } else {
                showSnackbarWithClose(
                    error?.response ? error.response.data?.message : error.message,
                    {
                        variant: 'error',
                    }
                );
            }
        }
    };
    return (
        <Dialog
            fullScreen={fullScreen}
            open={open}
            onClose={handleClose}
            aria-labelledby="responsive-dialog-title"
            sx={{
                '& .MuiPaper-root': {
                    md: { borderRadius: '16px', minWidth: '600px' },
                },
            }}
        >
            <DialogContent>
                <Typography variant="body2" fontWeight={550}>
                    {nameDialog}
                </Typography>
                <Stack spacing={2} pt={2}>
                    <Stack direction={'row'} alignItems={'center'} justifyContent={'space-between'}>
                        <Typography variant="subtitle2" fontStyle={'italic'}>
                            {parking.Name}
                        </Typography>
                        <Stack
                            direction="row"
                            sx={{
                                border: '1px solid rgba(85, 89, 93, 0.5)',
                                borderRadius: '4px',
                                overflow: 'hidden',
                                minHeight: '40px',
                            }}
                            spacing={'1px'}
                        >
                            <StyleCustomDateTimePickerComponent
                                time={startDate}
                                setTime={handleStartDateChange}
                                //năm 9999
                                maxTime={() => endDate}
                                minTime={() => null}
                                disShowCancel={true}
                                startTitle={'Từ '}
                            />
                            <Divider
                                orientation="vertical"
                                flexItem
                                sx={{ borderRightWidth: 1, borderColor: '#D9D9D9' }}
                            />
                            <StyleCustomDateTimePickerComponent
                                time={endDate}
                                setTime={handleEndDateChange}
                                //năm 9999
                                maxTime={() => null}
                                minTime={() => startDate}
                                disShowCancel={true}
                                startTitle={'Đến '}
                            />
                        </Stack>
                    </Stack>
                </Stack>
            </DialogContent>
            <DialogActions
                sx={{
                    px: 3,
                    pb: 3,
                }}
            >
                <StyleButton variant="contained" onClick={handleExport}>
                    XUẤT
                </StyleButton>
            </DialogActions>
        </Dialog>
    );
}
