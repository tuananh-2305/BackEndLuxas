import { cardApi } from '@/api/card-api';
import { keyRoleApi } from '@/api/key-role-api';
import {
    CardCreatePayload,
    HistoryExportPayload,
    MemberModel,
    ParkingModel,
    VehicelTypeModel,
} from '@/models/index';
import { handleDownloadFile, theme } from '@/ultis/index';
import {
    Dialog,
    DialogActions,
    DialogContent,
    DialogTitle,
    Divider,
    InputLabel,
    MenuItem,
    Select,
    Stack,
    Typography,
    useMediaQuery,
} from '@mui/material';
import { enqueueSnackbar } from 'notistack';
import { useEffect, useState } from 'react';

import { DatePicker } from '@mui/x-date-pickers';
import AutoCompoleteMember from '@/components/common/input/autocomplete-member';
import { StyleButton, StyledOutlinedInput } from '@/components/common/style-component';
import { StyleCustomDateTimePickerComponent } from '@/components/common/custom-datetime-picker/StyleCustomDateTimePickerComponent';
import Grid2 from '@mui/material/Unstable_Grid2';
import { vehicleTypeApi } from '@/api/vehicle-type-api';
import { historyInOutApi } from '@/api/history-in-out-api';
import { showSnackbarWithClose } from '@/hooks/useSnackbarWithClose';
const BACKEND_DOMAIN = process.env.NEXT_PUBLIC_SERVER_PARKING_DOMAIN;

export interface IDialogExportHistoryProps {
    open: boolean;
    handleClose: () => void;
    parking: ParkingModel;
}

export default function DialogExportHistory(props: IDialogExportHistoryProps) {
    const { open, handleClose, parking } = props;
    const [keyRoles, setKeyRoles] = useState([]);
    const [plateNumber, setPlateNumber] = useState('');
    const [member, setMember] = useState<MemberModel | null>(null);
    const [typeInOut, setTypeInOut] = useState<'ALL' | 'IN' | 'OUT'>('ALL');
    const [listVehicleType, setListVehicleType] = useState<VehicelTypeModel[]>([]);
    const [vehicleType, setVehicleType] = useState<string>('ALL');
    const [startDate, setStartDate] = useState<Date | null>(
        new Date(new Date().setDate(new Date().getDate() - 30))
    );
    const [endDate, setEndDate] = useState<Date | null>(new Date(new Date()));
    const handleStartDateChange = (date: Date | null) => {
        setStartDate(date);
    };
    const handleEndDateChange = (date: Date | null) => {
        setEndDate(date);
    };
    const nameDialog = 'Xuất dữ liệu ra vào';

    const fullScreen = useMediaQuery(theme.breakpoints.down('md'));
    useEffect(() => {
        if (!parking?.ID) return;
        vehicleTypeApi.getVehicleTypes().then((res) => {
            setListVehicleType(res?.data);
        });
    }, [parking]);

    // handle reset checked

    // reset name and checked when close dialog
    useEffect(() => {
        if (!open) {
            setPlateNumber('');
            setMember(null);
            setTypeInOut('ALL');
            setVehicleType('ALL');
            setStartDate(new Date(new Date().setDate(new Date().getDate() - 30)));
            setEndDate(new Date());
        }
    }, [open]);
    useEffect(() => {
        //default checked
        if (keyRoles.length === 0) return;
    }, [keyRoles]);
    const handleExport = async () => {
        try {
            const payload: HistoryExportPayload = {
                ParkingId: parking.ID,
                PlateNumber: plateNumber,
                MemberId: member?.ID,
                Type: typeInOut,
                StartDate: startDate,
                EndDate: endDate,
            };
            // console.log('payload', payload);
            if (vehicleType !== 'ALL') payload.VehicleTypeId = vehicleType;

            const { data } = await historyInOutApi.exportHistory(payload);
            const url = `${BACKEND_DOMAIN}${data}`;
            // window.open(url);
            handleDownloadFile(url);
            showSnackbarWithClose(`${nameDialog} thành công`, {
                variant: 'success',
            });
            handleClose();
        } catch (error: any) {
            if (Array.isArray(error?.response?.data?.message)) {
                error?.response?.data?.message.forEach((item: any) => {
                    showSnackbarWithClose(item, {
                        variant: 'error',
                    });
                });
            } else {
                showSnackbarWithClose(
                    error?.response ? error.response.data?.message : error.message,
                    {
                        variant: 'error',
                    }
                );
            }
        }
    };
    return (
        <Dialog
            fullScreen={fullScreen}
            open={open}
            onClose={() => {
                window.location.reload();
                handleClose();
            }}
            aria-labelledby="responsive-dialog-title"
            sx={{
                '& .MuiPaper-root': {
                    md: { minWidth: '700px', borderRadius: '16px' },
                },
            }}
        >
            <DialogContent>
                <Typography variant="body2" fontWeight={550}>
                    {nameDialog}
                </Typography>
                <Stack spacing={2}>
                    <Stack direction={'row'} alignItems={'center'} justifyContent={'space-between'}>
                        <Typography variant="subtitle2" fontStyle={'italic'}>
                            {parking.Name}
                        </Typography>
                        <Stack
                            direction="row"
                            sx={{
                                border: '1px solid rgba(85, 89, 93, 0.5)',
                                borderRadius: '4px',
                                overflow: 'hidden',
                                minHeight: '40px',
                            }}
                            spacing={'1px'}
                        >
                            <StyleCustomDateTimePickerComponent
                                time={startDate}
                                setTime={handleStartDateChange}
                                //năm 9999
                                maxTime={() => endDate}
                                minTime={() => null}
                                disShowCancel={true}
                                startTitle={'Từ '}
                            />
                            <Divider
                                orientation="vertical"
                                flexItem
                                sx={{ borderRightWidth: 1, borderColor: '#D9D9D9' }}
                            />
                            <StyleCustomDateTimePickerComponent
                                time={endDate}
                                setTime={handleEndDateChange}
                                //năm 9999
                                maxTime={() => null}
                                minTime={() => startDate}
                                disShowCancel={true}
                                startTitle={'Đến '}
                            />
                        </Stack>
                    </Stack>
                    <Stack px={4}>
                        <Divider
                            sx={{
                                '&:before, &:after': {
                                    borderTop: '1px dashed #9AA0A6',
                                },
                            }}
                        >
                            Tùy chọn
                        </Divider>
                    </Stack>

                    <Stack direction="row" sx={{ width: '100%', gap: '20px' }} alignItems="center">
                        <Stack sx={{ flex: 1 }}>
                            <InputLabel required>Phân loại ra - vào</InputLabel>
                            <Select
                                fullWidth
                                size="small"
                                sx={{
                                    borderRadius: '10px',
                                }}
                                value={typeInOut}
                                onChange={(e: any) => setTypeInOut(e.target.value)}
                            >
                                <MenuItem value={'ALL'}>Tất cả</MenuItem>
                                <MenuItem value={'IN'}>Vào</MenuItem>
                                <MenuItem value={'OUT'}>Ra</MenuItem>
                            </Select>
                        </Stack>

                        <Stack sx={{ flex: 1 }}>
                            <Stack>
                                <InputLabel required>Loại xe</InputLabel>
                                <Select
                                    fullWidth
                                    size="small"
                                    sx={{
                                        borderRadius: '10px',
                                    }}
                                    value={vehicleType}
                                    onChange={(e) => setVehicleType(e.target.value)}
                                >
                                    <MenuItem value={'ALL'}>Tất cả</MenuItem>

                                    {listVehicleType.map((item, index) => (
                                        <MenuItem value={item.ID} key={index}>
                                            {item.Name}
                                        </MenuItem>
                                    ))}
                                </Select>
                            </Stack>
                        </Stack>
                    </Stack>
                    <Stack direction="row" sx={{ width: '100%', gap: '20px' }} alignItems="center">
                        <Stack sx={{ flex: 1 }}>
                            <InputLabel>Biển số</InputLabel>
                            <StyledOutlinedInput
                                autoComplete="off"
                                value={plateNumber}
                                onChange={(e) => {
                                    setPlateNumber(e.target.value);
                                }}
                                size="small"
                                fullWidth
                            />
                        </Stack>

                        <Stack sx={{ flex: 1 }}>
                            <AutoCompoleteMember
                                setValue={setMember}
                                parkingId={parking.ID}
                                value={member}
                                isNotRequired={true}
                            />
                        </Stack>
                    </Stack>
                </Stack>
            </DialogContent>
            <DialogActions
                sx={{
                    px: 3,
                    pb: 3,
                }}
            >
                <StyleButton variant="contained" onClick={handleExport}>
                    XUẤT
                </StyleButton>
            </DialogActions>
        </Dialog>
    );
}
