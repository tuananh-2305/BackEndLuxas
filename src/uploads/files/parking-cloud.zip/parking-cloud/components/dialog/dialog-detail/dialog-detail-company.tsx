import { AvatarCustom } from '@/components/common';
import { StyleButton } from '@/components/common/style-component';
import { CompanyModel } from '@/models/index';
import { getNameAddress, handleCallApi, handleCompressImage, showAddress } from '@/ultis/index';
import { theme } from '@/ultis/theme';
import DeleteOutlinedIcon from '@mui/icons-material/DeleteOutlined';
import ImageIcon from '@mui/icons-material/Image';
import {
    Box,
    Dialog,
    DialogActions,
    DialogContent,
    IconButton,
    Link,
    Stack,
    Tooltip,
    Typography,
    useMediaQuery,
} from '@mui/material';
import Image from 'next/image';
import BorderColorIcon from '@mui/icons-material/BorderColor';
import { companyApi } from '@/api/company-api';
import { useAppDispatch } from '@/hooks/useReudx';
import { setLoadingGlobal } from '@/redux/index';
import { enqueueSnackbar } from 'notistack';
import { showSnackbarWithClose } from '@/hooks/useSnackbarWithClose';
import { useState } from 'react';
import DialogWarning from '../dialog-warning';

export interface IDialogDetailCompanyProps {
    open: boolean;
    handleClose: () => void;
    data: CompanyModel;
    handleUpdate?: () => void;
    handleReload?: () => void;
}
const BACKEND_DOMAIN = process.env.NEXT_PUBLIC_SERVER_PARKING_DOMAIN;

export default function DialogDetailCompany(props: IDialogDetailCompanyProps) {
    const { open, handleClose, data, handleUpdate, handleReload } = props;
    const nameDialog = 'công ty';
    const fullScreen = useMediaQuery(theme.breakpoints.down('md'));
    const dispatch = useAppDispatch();
    const [openWarning, setOpenWarning] = useState(false);

    const handleDelete = () => {
        if (!data) return;
        companyApi
            .deleteCompany(data?.ID)
            .then((res) => {
                if (res.data) {
                    handleReload && handleReload();
                    showSnackbarWithClose('Xóa thành công', { variant: 'success' });
                }
            })
            .catch((error) => {
                if (Array.isArray(error?.response?.data?.message)) {
                    error?.response?.data?.message.forEach((item: any) => {
                        showSnackbarWithClose(item, {
                            variant: 'error',
                        });
                    });
                } else {
                    showSnackbarWithClose(
                        error?.response ? error.response.data?.message : error.message,
                        {
                            variant: 'error',
                        }
                    );
                }
            });
    };
    const handleUploadBackground = async (e: any) => {
        if (!e.target.files[0]) return;
        const file = e.target.files[0];
        const payload = new FormData();
        payload.append('ID', data.ID);
        const imageBackCompress = await handleCompressImage(file);
        payload.append('Background', imageBackCompress, file.name);
        const action = setLoadingGlobal({ isLoadingGlobal: true });
        dispatch(action);
        await handleCallApi(
            payload,
            handleReload,
            `Chỉnh sửa background`,
            companyApi.updateCompany
        );
        const action2 = setLoadingGlobal({ isLoadingGlobal: false });
        dispatch(action2);
    };
    const handleUploadAvatar = async (e: any) => {
        if (!e.target.files[0]) return;
        const file = e.target.files[0];
        const payload = new FormData();
        payload.append('ID', data.ID);
        const imageBackCompress = await handleCompressImage(file);
        payload.append('Logo', imageBackCompress, file.name);
        const action = setLoadingGlobal({ isLoadingGlobal: true });
        dispatch(action);
        await handleCallApi(payload, handleReload, `Chỉnh sửa logo`, companyApi.updateCompany);
        const action2 = setLoadingGlobal({ isLoadingGlobal: false });
        dispatch(action2);
    };
    return (
        <Dialog
            fullScreen={fullScreen}
            open={open}
            onClose={handleClose}
            aria-labelledby="responsive-dialog-title"
            sx={{
                '& .MuiPaper-root': {
                    md: { minWidth: '600px', borderRadius: '16px' },
                },
            }}
        >
            <DialogContent
                sx={{
                    padding: '0px',
                }}
            >
                <DialogWarning
                    open={openWarning}
                    handleClose={() => {
                        setOpenWarning(false);
                    }}
                    handleConfirm={() => {
                        handleDelete();
                        setOpenWarning(false);
                        handleClose();
                    }}
                    title="Bạn đang thực hiện hành động xóa dữ liệu khỏi hệ thống, "
                />
                <Stack sx={{ position: 'relative' }}>
                    <Image
                        src={
                            data.Background
                                ? BACKEND_DOMAIN + data.Background
                                : '/images/default_background_company.png'
                        }
                        alt={data.Name ? data.Name : 'company'}
                        width={900}
                        height={900}
                        style={{
                            objectFit: 'cover',
                            objectPosition: 'center',
                            width: '100%',
                            height: '300px',
                            cursor: 'pointer',
                        }}
                    />
                    <Tooltip title="Sửa background">
                        <IconButton
                            sx={{
                                position: 'absolute',
                                zIndex: 3,
                                bottom: '15px',
                                right: '15px',
                                backgroundColor: 'rgba(217, 217, 217, 0.6)',
                                color: '#fff',
                                boxShadow: '0 0 5px rgba(0, 0, 0, 0.2)',
                            }}
                            component="label"
                        >
                            <input
                                hidden
                                autoComplete="off"
                                accept="image/*"
                                type="file"
                                onChange={handleUploadBackground}
                            />
                            <ImageIcon />
                        </IconButton>
                    </Tooltip>
                    <Stack
                        sx={{
                            position: 'absolute',
                            top: 'calc(100% - 60px)',
                            left: '34px',
                        }}
                        direction={'row'}
                        alignItems={'center'}
                    >
                        <AvatarCustom
                            src={data.Logo ? BACKEND_DOMAIN + data.Logo : ''}
                            alt={data.Name}
                            sx={{ zIndex: 3 }}
                            size={120}
                        />
                        <Tooltip title="Sửa avatar">
                            <IconButton
                                sx={{
                                    position: 'absolute',
                                    zIndex: 3,
                                    bottom: '0',
                                    right: '0',
                                    backgroundColor: 'rgba(217, 217, 217, 1)',
                                    color: '#fff',
                                    '&:hover': {
                                        backgroundColor: 'rgba(6, 125, 192, 0.8)',
                                    },
                                }}
                                component="label"
                            >
                                <BorderColorIcon />
                                <input
                                    autoComplete="off"
                                    hidden
                                    accept="image/*"
                                    type="file"
                                    onChange={handleUploadAvatar}
                                />
                            </IconButton>
                        </Tooltip>
                    </Stack>
                    <Stack
                        sx={{
                            height: '30px',
                            borderRadius: '0px 37px 0px 0px',
                            bgcolor: '#fff',
                            px: 3.5,
                            py: 0.5,
                            bottom: 0,
                            position: 'absolute',
                            left: 'calc(34px + 60px + 48px)',
                            minWidth: '150px',
                        }}
                    >
                        <Typography>{data.SortName}</Typography>
                    </Stack>
                    <Stack
                        sx={{
                            position: 'absolute',
                            top: '100%',
                            left: 'calc(34px + 120px)',
                            px: 2,
                            py: 1.5,
                        }}
                    >
                        <Typography>{data.Name}</Typography>
                    </Stack>
                </Stack>

                <Stack>
                    <Stack
                        p={2.5}
                        gap={2.5}
                        mt={'60px'}
                        sx={{
                            fontSize: '14px',
                        }}
                    >
                        <Stack direction={'row'}>
                            <Box
                                sx={{
                                    flex: '0 0 200px',
                                }}
                            >
                                <Typography color={'#55595D'} fontSize={'inherit'}>
                                    Người đại điện pháp luật
                                </Typography>
                            </Box>
                            <Typography fontSize={'inherit'}>{data.Representative}</Typography>
                        </Stack>
                        <Stack direction={'row'}>
                            <Box
                                sx={{
                                    flex: '0 0 200px',
                                }}
                            >
                                <Typography color={'#55595D'} fontSize={'inherit'}>
                                    Mã số thuế
                                </Typography>
                            </Box>
                            <Typography fontSize={'inherit'}>{data.TaxCode}</Typography>
                        </Stack>
                        <Stack direction={'row'}>
                            <Box
                                sx={{
                                    flex: '0 0 200px',
                                }}
                            >
                                <Typography color={'#55595D'} fontSize={'inherit'}>
                                    Email
                                </Typography>
                            </Box>
                            <Typography fontSize={'inherit'}>{data.Email}</Typography>
                        </Stack>
                        <Stack direction={'row'}>
                            <Box
                                sx={{
                                    flex: '0 0 200px',
                                }}
                            >
                                <Typography color={'#55595D'} fontSize={'inherit'}>
                                    Số điện thoại
                                </Typography>
                            </Box>
                            <Typography fontSize={'inherit'}>{data.Phone}</Typography>
                        </Stack>
                        <Stack direction={'row'}>
                            <Box
                                sx={{
                                    flex: '0 0 200px',
                                }}
                            >
                                <Typography color={'#55595D'} fontSize={'inherit'}>
                                    Địa chỉ
                                </Typography>
                            </Box>
                            <Typography fontSize={'inherit'}>
                                {showAddress(
                                    data?.Address,
                                    getNameAddress(data.Ward),
                                    getNameAddress(data.District),
                                    getNameAddress(data.Province)
                                )}
                            </Typography>
                        </Stack>
                        <Stack direction={'row'}>
                            <Box
                                sx={{
                                    flex: '0 0 200px',
                                }}
                            >
                                <Typography color={'#55595D'} fontSize={'inherit'}>
                                    Trang web
                                </Typography>
                            </Box>
                            <Typography fontSize={'inherit'}>
                                <Link
                                    href={data.Website}
                                    target="_blank"
                                    sx={{
                                        color: '#1E88E5',
                                        textDecorationColor: '#1E88E5',
                                    }}
                                >
                                    {data.Website}
                                </Link>
                            </Typography>
                        </Stack>
                    </Stack>
                </Stack>
            </DialogContent>
            <DialogActions
                sx={{
                    px: 3,
                    pb: 3,
                    gap: '8px',
                }}
            >
                <Tooltip title="Xóa">
                    <IconButton
                        color="error"
                        sx={{
                            backgroundColor: 'rgba(233, 79, 79, 0.3)',
                            '&:hover': {
                                backgroundColor: 'rgba(233, 79, 79, 0.2)',
                            },
                            boxShadow: '0px 2px 2px rgba(0, 0, 0, 0.25)',
                        }}
                        onClick={() => {
                            setOpenWarning(true);
                        }}
                    >
                        <DeleteOutlinedIcon />
                    </IconButton>
                </Tooltip>
                <StyleButton variant="contained" onClick={handleUpdate}>
                    chỉnh sửa
                </StyleButton>
            </DialogActions>
        </Dialog>
    );
}
