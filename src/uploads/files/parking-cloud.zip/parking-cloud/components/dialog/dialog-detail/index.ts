export * from './dialog-detail-company';
