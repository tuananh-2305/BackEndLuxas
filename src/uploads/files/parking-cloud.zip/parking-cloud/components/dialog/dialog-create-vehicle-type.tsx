import { vehicleTypeApi } from '@/api/vehicle-type-api';
import { useAppSelector } from '@/hooks/useReudx';
import { showSnackbarWithClose } from '@/hooks/useSnackbarWithClose';
import { Stack, Typography, Checkbox } from '@mui/material';
import { useRouter } from 'next/router';
import { useSnackbar } from 'notistack';
import { useState } from 'react';

interface Vehicel {
    CreatedAt: string;
    Description: string;
    ID: string;
    IsDelete: boolean;
    IsInsert: boolean;
    IsUpdate: boolean;
    Name: string;
    UpdatedAt: string | null;
}
export interface IDialogCreateVehicleTypeProps {
    close: () => void;
    reload: () => void;
}

export const DialogCreateVehicleType = (props: IDialogCreateVehicleTypeProps) => {
    const { close, reload } = props;

    const router = useRouter();

    const parkingChoose = useAppSelector((state) => state.parking.choose);
    const [data, setData] = useState<{ name: string; description: string; IsPlateNumber: boolean }>(
        {
            name: '',
            description: '',
            IsPlateNumber: true,
        }
    );

    const submit = () => {
        if (parkingChoose) {
            vehicleTypeApi
                .createVehicleType({
                    Name: data.name.trim(),
                    Description: data.description,
                    ParkingId: parkingChoose.ID,
                    IsPlateNumber: data.IsPlateNumber,
                })
                .then(() => {
                    showSnackbarWithClose('Thêm mới thành công.', {
                        variant: 'success',
                    });
                    reload();
                    close();
                })
                .catch((err) => {
                    if (err?.response?.data?.message) {
                        (err?.response?.data?.message as string[]).map((v) => {
                            showSnackbarWithClose(v, {
                                variant: 'error',
                            });
                        });
                    }
                });
        }
    };

    return (
        <Stack
            sx={{ position: 'fixed', top: 0, left: 0, bottom: 0, right: 0, zIndex: 9999 }}
            alignItems="center"
            justifyContent="center"
        >
            <Stack
                onClick={() => close()}
                sx={{
                    position: 'absolute',
                    top: 0,
                    left: 0,
                    right: 0,
                    bottom: 0,
                    backgroundColor: 'rgba(85, 89, 93, 0.35)',
                    backdropFilter: 'blur(1.5px)',
                    zIndex: 2,
                }}
            />
            <Stack
                sx={{
                    width: '600px',
                    height: '350px',
                    backgroundColor: '#fff',
                    zIndex: 3,
                    padding: '20px',
                    boxShadow: '0px 4px 4px rgba(0, 0, 0, 0.25)',
                    borderRadius: '20px',
                }}
                spacing={'20px'}
            >
                <Stack>
                    <Typography sx={{ fontWeight: 700, fontSize: '16px' }}>
                        Tạo mới loại xe
                    </Typography>
                </Stack>

                <Stack sx={{ flex: 1 }} spacing={'20px'}>
                    <Stack>
                        <Typography>Tên thể loại</Typography>
                        <input
                            onChange={(e) => {
                                const { value } = e.target;
                                setData({ ...data, ['name']: value });
                            }}
                            autoComplete="off"
                            style={{
                                outline: 'none',
                                border: '1px solid rgba(85, 89, 93, 0.5)',
                                backgroundColor: 'transparent',
                                padding: '10px 20px',
                                borderRadius: '10px',
                                fontStyle: 'italic',
                                fontWeight: 300,
                            }}
                            placeholder="Nhập tên loại xe..."
                        />
                    </Stack>
                    <Stack>
                        <Typography>Mô tả</Typography>
                        <input
                            onChange={(e) => {
                                const { value } = e.target;
                                setData({ ...data, ['description']: value });
                            }}
                            autoComplete="off"
                            style={{
                                outline: 'none',
                                border: '1px solid rgba(85, 89, 93, 0.5)',
                                backgroundColor: 'transparent',
                                padding: '10px 20px',
                                borderRadius: '10px',
                            }}
                            placeholder="Nhập mô tả loại xe..."
                        />
                    </Stack>
                    <Stack direction="row" alignItems="center">
                        <Checkbox
                            color="info"
                            checked={data.IsPlateNumber}
                            onChange={(e) => {
                                const { checked } = e.target;
                                setData({ ...data, ['IsPlateNumber']: checked });
                            }}
                        />
                        <Typography>Có biển số xe</Typography>
                    </Stack>
                </Stack>

                <Stack direction="row-reverse">
                    <Stack
                        onClick={() => submit()}
                        sx={{
                            backgroundColor: '#FFB862',
                            width: 'fit-content',
                            padding: '10px 50px',
                            borderRadius: '10px',
                            filter: 'drop-shadow(0px 2px 2px rgba(0, 0, 0, 0.25))',
                            cursor: 'pointer',
                        }}
                    >
                        <Typography sx={{ fontWeight: 700, color: '#fff' }}>Lưu</Typography>
                    </Stack>
                </Stack>
            </Stack>
        </Stack>
    );
};
