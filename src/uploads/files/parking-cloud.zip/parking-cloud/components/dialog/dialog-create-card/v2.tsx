import { Stack } from '@mui/material';
import { useState } from 'react';
import { CreateCardCheck } from './check';
import { CreateCardMain } from './create';
import { UpdateCardMain } from './update';

interface CreateCardDialog {
    close: () => void;
    reload: () => void;
    onlyElevator?: boolean;
    idMember?: string;
}

export const CreateCardDialog = (props: CreateCardDialog) => {
    const { close, onlyElevator, reload, idMember } = props;
    const [caseView, setCaseView] = useState<'check' | 'create' | 'update'>('check');
    const [cardIdChoose, setCardIdChoose] = useState<{
        cardNumber: string | null;
        cardId: string | null;
    }>({
        cardNumber: null,
        cardId: null,
    });
    const renderView = () => {
        switch (caseView) {
            case 'check':
                return (
                    <CreateCardCheck
                        changeCardChoose={(c: {
                            cardNumber: string | null;
                            cardId: string | null;
                        }) => setCardIdChoose(c)}
                        changeView={(v: 'check' | 'update' | 'create') => setCaseView(v)}
                    />
                );
            case 'create':
                return (
                    <CreateCardMain
                        cardChoose={cardIdChoose}
                        idMember={idMember}
                        handleReload={() => reload()}
                        handleClose={() => close()}
                        onlyElevator={onlyElevator}
                        changeView={(v: 'check' | 'update' | 'create') => setCaseView(v)}
                    />
                );
            case 'update':
                return (
                    <UpdateCardMain
                        cardChoose={cardIdChoose}
                        idMember={idMember}
                        onlyElevator={onlyElevator}
                        handleReload={() => reload()}
                        handleClose={() => close()}
                        changeView={(v: 'check' | 'update' | 'create') => setCaseView(v)}
                    />
                );
            default:
                return <Stack></Stack>;
        }
    };

    return (
        <Stack
            sx={{
                position: 'fixed',
                top: 0,
                bottom: 0,
                left: 0,
                right: 0,
                zIndex: 10,
                justifyContent: 'center',
                alignItems: 'center',
            }}
        >
            <Stack
                sx={{
                    backgroundColor: '#55595D30',
                    position: 'absolute',
                    top: 0,
                    bottom: 0,
                    left: 0,
                    right: 0,
                    zIndex: 2,
                }}
                onClick={() => close()}
            />
            <Stack
                sx={{
                    zIndex: 3,
                    width: '500px',
                    height: 'fit-content',
                    backgroundColor: '#fff',
                    borderRadius: '10px',
                    boxShadow:
                        'rgba(50, 50, 93, 0.25) 0px 6px 12px -2px, rgba(0, 0, 0, 0.3) 0px 3px 7px -3px',
                }}
            >
                {renderView()}
            </Stack>
        </Stack>
    );
};
