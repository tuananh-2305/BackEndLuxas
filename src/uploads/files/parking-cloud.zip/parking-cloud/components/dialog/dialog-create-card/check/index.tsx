import { cardApi } from '@/api/card-api';
import { useAppSelector } from '@/hooks/useReudx';
import { showSnackbarWithClose } from '@/hooks/useSnackbarWithClose';
import { hasSpecialCharsOrWhitespace } from '@/ultis/global-func';
import { useDebouncedValue } from '@mantine/hooks';
import { Stack, Typography, TextField } from '@mui/material';
import { useEffect, useState } from 'react';

interface CreateCardCheckProps {
    changeCardChoose: (v: { cardNumber: string | null; cardId: string | null }) => void;
    changeView: (v: 'check' | 'create' | 'update') => void;
}

export const CreateCardCheck = (props: CreateCardCheckProps) => {
    const { changeView, changeCardChoose } = props;
    const parkingChoose = useAppSelector((state) => state.parking.choose);

    const [card, setCard] = useState('');
    const [error, setError] = useState('');
    const [cardChoose, setCardChoose] = useState<{
        value: string;
        isExist: boolean;
        haveMember: boolean;
        idCard?: string;
        usingForParking: boolean | 'unset';
    }>({ value: '', isExist: false, haveMember: false, usingForParking: 'unset' });
    const [debounced] = useDebouncedValue(card, 300);

    useEffect(() => {
        if (parkingChoose && debounced.trim().length >= 8) {
            cardApi
                .getCheckCard(debounced, parkingChoose.ID)
                .then((res) => {
                    if (res.data) {
                        if (res.data.MemberId) {
                            if (res.data.IsCardParking) {
                                setError('Thẻ này đã có người sử dụng trong bãi xe này!.');
                            } else {
                                setError('');
                            }

                            setCardChoose({
                                value: debounced,
                                isExist: true,
                                haveMember: true,
                                idCard: res.data.ID,
                                usingForParking: res.data.IsCardParking,
                            });
                        } else {
                            setError('');
                            setCardChoose({
                                value: debounced,
                                isExist: true,
                                haveMember: false,
                                idCard: res.data.ID,
                                usingForParking: res.data.IsCardParking,
                            });
                        }
                    } else {
                        setError('');
                        setCardChoose({
                            value: debounced,
                            isExist: false,
                            haveMember: false,
                            usingForParking: 'unset',
                        });
                    }
                })
                .catch((error) => {
                    if (Array.isArray(error?.response?.data?.message)) {
                        setError(error?.response?.data?.message[0]);
                    } else {
                        setError(error?.response ? error.response.data?.message : error.message);
                    }
                });
        } else {
            setError('');
            setCardChoose({
                value: '',
                isExist: false,
                haveMember: false,
                usingForParking: 'unset',
            });
        }
    }, [debounced, parkingChoose]);

    return (
        <Stack
            sx={{ padding: '40px', gap: '10px', height: '300px', justifyContent: 'space-between' }}
        >
            <Stack direction={'row'} sx={{ gap: '10px' }} alignItems="center">
                <Typography sx={{ fontWeight: 600, fontSize: '20px' }}>Kiểm tra mã thẻ</Typography>
                {/* <span style={{ fontSize: '16px', fontWeight: 300, color: '#f85959' }}>
                    (ít nhất 8 ký tự)
                </span> */}
            </Stack>

            <Stack sx={{ gap: '10px' }}>
                <TextField
                    size="small"
                    autoComplete="off"
                    placeholder="Quét thẻ để kiểm tra"
                    value={card}
                    onChange={(e) => {
                        const { value } = e.target;
                        if (!hasSpecialCharsOrWhitespace(value)) {
                            setCard(value);
                        }
                    }}
                />

                {error ? (
                    <Typography sx={{ color: '#cc1223', fontSize: '14px', fontWeight: 600 }}>
                        {error}
                    </Typography>
                ) : (
                    <></>
                )}

                {cardChoose.value &&
                ((cardChoose.isExist && !cardChoose.haveMember) || !cardChoose.usingForParking) ? (
                    <Typography sx={{ color: '#e0c45c', fontSize: '14px', fontWeight: 600 }}>
                        Thẻ đã tồn tại trong bãi nhưng chưa được sử dụng hoặc chỉ dùng cho thang máy
                    </Typography>
                ) : (
                    <></>
                )}

                {cardChoose.value && !cardChoose.isExist && !cardChoose.haveMember ? (
                    <Typography sx={{ color: '#2cb978', fontSize: '14px', fontWeight: 600 }}>
                        Thẻ chưa tồn tại trong bãi
                    </Typography>
                ) : (
                    <></>
                )}
            </Stack>

            <Stack direction="row-reverse">
                {!error && !cardChoose.isExist && !cardChoose.haveMember && cardChoose.value ? (
                    <Stack
                        sx={{
                            backgroundColor: '#007DC0',
                            padding: '10px',
                            borderRadius: '10px',
                            width: 'fit-content',
                            cursor: 'pointer',
                        }}
                        onClick={() => {
                            changeView('create');
                            changeCardChoose({ cardId: null, cardNumber: debounced });
                        }}
                    >
                        <Typography sx={{ fontWeight: 700, color: '#fff', fontSize: '14px' }}>
                            Tạo mới thẻ
                        </Typography>
                    </Stack>
                ) : (
                    <></>
                )}

                {cardChoose.value &&
                ((cardChoose.isExist && !cardChoose.haveMember) || !cardChoose.usingForParking) ? (
                    <Stack
                        sx={{
                            backgroundColor: '#007DC0',
                            padding: '10px',
                            borderRadius: '10px',
                            width: 'fit-content',
                            cursor: 'pointer',
                        }}
                        onClick={() => {
                            if (cardChoose.idCard) {
                                changeView('update');
                                changeCardChoose({
                                    cardNumber: cardChoose.value,
                                    cardId: cardChoose.idCard,
                                });
                            }
                        }}
                    >
                        <Typography sx={{ fontWeight: 700, color: '#fff', fontSize: '14px' }}>
                            Cập nhật thẻ
                        </Typography>
                    </Stack>
                ) : (
                    <></>
                )}

                {error || !cardChoose.value ? (
                    <Stack
                        sx={{
                            backgroundColor: '#55595D',
                            padding: '10px',
                            borderRadius: '10px',
                            width: 'fit-content',
                            cursor: 'pointer',
                        }}
                    >
                        <Typography sx={{ fontWeight: 700, color: '#fff', fontSize: '14px' }}>
                            Giá trị không hợp lệ
                        </Typography>
                    </Stack>
                ) : (
                    <></>
                )}
            </Stack>
        </Stack>
    );
};
