import { cardApi } from '@/api/card-api';
import { keyRoleApi } from '@/api/key-role-api';
import { showSnackbarWithClose } from '@/hooks/useSnackbarWithClose';
import { MemberModel } from '@/models/index';
import { hasSpecialCharsOrWhitespace, theme } from '@/ultis/index';
import ImageIcon from '@mui/icons-material/Image';
import {
    Card,
    CardMedia,
    CircularProgress,
    Dialog,
    DialogActions,
    DialogContent,
    DialogTitle,
    IconButton,
    InputLabel,
    MenuItem,
    Select,
    Stack,
    Tooltip,
    Typography,
    useMediaQuery,
    Checkbox,
    TextField,
} from '@mui/material';
import { green } from '@mui/material/colors';
import dayjs from 'dayjs';
import { useEffect, useMemo, useState } from 'react';
import AutoCompoleteMember from '../../common/input/autocomplete-member';
import { StyledOutlinedInput } from '../../common/style-component';
import { StyleButton } from '../../common/style-component/button';
import { ComfirmCloseDialog } from '../dialog-comfirm-close';
import { AutoCompleteVehicel } from '../../common/input/autocomplete-vehicel';
import { MemberVehicleModel } from '@/models/member.vehicle.model';
import { useAppSelector } from '@/hooks/useReudx';

export interface IDialogCreateCardProps {
    open: boolean;
    handleClose: () => void;
    handleReload?: () => void;
    idParking: string;
    idMember?: string;
}

export default function DialogCreateCard(props: IDialogCreateCardProps) {
    const { open, handleClose, handleReload, idParking, idMember } = props;
    const [keyRoles, setKeyRoles] = useState([]);
    const [cardNumber, setCardNumber] = useState('');
    const [vehicel, setVehicel] = useState<MemberVehicleModel | null>(null);
    const [description, setDescription] = useState('');
    const [member, setMember] = useState<MemberModel | null>(null);
    const [dateExpire, setDateExpire] = useState<Date | null>(dayjs().endOf('month').toDate());
    const [typeAuthen, setTypeAuthen] = useState<'CARD' | 'FACE'>('CARD');
    const [isLoadingButton, setIsLoadingButton] = useState(false);
    const [idCard, setIdCard] = useState('');
    const [faceImage, setFaceImage] = useState<File | null>(null);
    const [isCardElevator, setIsCardElevator] = useState(false);
    const [isCardParking, setIsCardParking] = useState(false);
    const nameDialog = 'thẻ';
    const [openComfirm, setOpenComfirm] = useState(false);
    const [caseView, setCaseView] = useState<'check' | 'main'>('check');
    const [error, setError] = useState('');

    const parking = useAppSelector((state) => state.parking.choose);

    const fullScreen = useMediaQuery(theme.breakpoints.down('md'));
    useEffect(() => {
        keyRoleApi.getKeyRole().then((res) => {
            setKeyRoles(res.data);
        });
    }, []);

    // handle reset checked

    // reset name and checked when close dialog
    useEffect(() => {
        if (!open) {
            setCardNumber('');
            setDescription('');
            setMember(null);
            setDateExpire(dayjs().endOf('month').toDate());
            setTypeAuthen('CARD');
            setIdCard('');
            setIsCardElevator(false);
            setIsLoadingButton(false);
        }
    }, [open]);
    useEffect(() => {
        //default checked
        if (keyRoles.length === 0) return;
    }, [keyRoles]);

    const renderImage = useMemo(
        () => (
            <CardMedia
                sx={{ height: 300 }}
                image={
                    faceImage
                        ? URL.createObjectURL(faceImage)
                        : '/images/default_background_company.png'
                }
                title="green iguana"
            />
        ),
        [faceImage]
    );

    const handleCreate = async () => {
        if (typeAuthen === 'CARD') {
            if (Boolean(cardNumber.trim())) {
                if (cardNumber.trim().length < 8) {
                    showSnackbarWithClose('Mã thẻ phải ít nhất 8 ký tự', {
                        variant: 'error',
                    });
                    return;
                }
            } else {
                showSnackbarWithClose('Mã thẻ không được để trống', {
                    variant: 'error',
                });
                return;
            }
        }

        if (!member && !idMember) {
            showSnackbarWithClose('Chưa chọn thành viên', {
                variant: 'error',
            });
            return;
        }
        // if (!dateExpire) {
        //     showSnackbarWithClose('Chưa chọn ngày hết hạn', {
        //         variant: 'error',
        //     });
        // }
        // if (!member || !cardNumber || cardNumber.trim() === '') {
        //     return;
        // }

        if (!isCardParking && !isCardElevator) {
            showSnackbarWithClose('Chưa chọn hình thức sử dụng.', {
                variant: 'error',
            });
            return;
        }

        if (isCardParking && !vehicel) {
            showSnackbarWithClose('Chưa chọn loại xe', {
                variant: 'error',
            });
            return;
        }

        setIsLoadingButton(true);

        const formData = new FormData();

        if (member) {
            formData.append('MemberId', member.ID);
        }

        if (idMember) {
            formData.append('MemberId', idMember);
        }

        if (vehicel && isCardParking) {
            formData.append('MemberVehicleId', vehicel.ID);
        }

        formData.append('IsCardParking', isCardParking.toString());
        formData.append('IsCardElevator', isCardElevator.toString());

        if (idCard) {
            formData.append('IdCard', idCard);
        }

        formData.append('ParkingId', idParking);
        formData.append('Description', description);
        if (dateExpire) {
            formData.append('ExpirationDate', dateExpire?.toString());
        }
        formData.append('TypeAuthen', typeAuthen);

        if (typeAuthen === 'CARD') {
            if (cardNumber) {
                formData.append('CardNumber', cardNumber);
            } else {
                showSnackbarWithClose('Bạn chưa nhập mã thẻ!.', { variant: 'error' });
                return;
            }
        }

        if (typeAuthen === 'FACE' && faceImage) {
            if (faceImage) {
                formData.append('files', faceImage, faceImage.name);
            } else {
                showSnackbarWithClose('Bạn cần chọn một tấm ảnh!.', { variant: 'error' });
                return;
            }
        }

        try {
            await cardApi.createCard(formData);

            showSnackbarWithClose(`Tạo ${nameDialog} thành công`, {
                variant: 'success',
            });
            handleReload && handleReload();
            handleClose();
        } catch (error: any) {
            if (Array.isArray(error?.response?.data?.message)) {
                error?.response?.data?.message.forEach((item: any) => {
                    showSnackbarWithClose(item, {
                        variant: 'error',
                    });
                });
            } else {
                showSnackbarWithClose(
                    error?.response ? error.response.data?.message : error.message,
                    {
                        variant: 'error',
                    }
                );
            }
        }
        setTimeout(() => {
            setIsLoadingButton(false);
        }, 1000);
    };

    const renderView = () => {
        switch (caseView) {
            case 'check':
                return (
                    <Stack sx={{ padding: '20px' }}>
                        <DialogTitle>{`Check Mã Thẻ.`}</DialogTitle>

                        <TextField
                            id="outlined-basic"
                            label="Nhập mã thẻ"
                            placeholder="Nhập giá trị"
                            variant="outlined"
                        />

                        <Typography></Typography>

                        <DialogActions
                            sx={{
                                px: 3,
                                pb: 3,
                            }}
                        >
                            <Stack sx={{ m: 1, position: 'relative' }}>
                                <StyleButton
                                    variant="contained"
                                    onClick={handleCreate}
                                    disabled={isLoadingButton}
                                >
                                    Tạo mới
                                </StyleButton>
                                {isLoadingButton && (
                                    <CircularProgress
                                        size={24}
                                        sx={{
                                            color: green[500],
                                            position: 'absolute',
                                            top: '50%',
                                            left: '50%',
                                            marginTop: '-12px',
                                            marginLeft: '-12px',
                                        }}
                                    />
                                )}
                            </Stack>
                        </DialogActions>
                    </Stack>
                );
            case 'main':
                return (
                    <>
                        <DialogTitle>{`Tạo ${nameDialog} mới`}</DialogTitle>
                        <DialogContent>
                            <Stack py={2} spacing={2}>
                                {!idMember ? (
                                    <AutoCompoleteMember
                                        setValue={setMember}
                                        parkingId={idParking}
                                        value={member}
                                    />
                                ) : (
                                    <></>
                                )}
                                <Typography>Hình thức :</Typography>
                                <Stack direction="row" justifyContent="center">
                                    <Stack direction="row" flex={1} alignItems="center">
                                        <Checkbox
                                            size="small"
                                            checked={isCardElevator}
                                            onChange={(e) => setIsCardElevator(e.target.checked)}
                                        />
                                        <Typography sx={{ textTransform: 'capitalize' }}>
                                            thang máy
                                        </Typography>
                                    </Stack>
                                    <Stack direction="row" flex={1} alignItems="center">
                                        <Checkbox
                                            size="small"
                                            checked={isCardParking}
                                            onChange={(e) => setIsCardParking(e.target.checked)}
                                        />

                                        <Typography sx={{ textTransform: 'capitalize' }}>
                                            bãi xe
                                        </Typography>
                                    </Stack>
                                </Stack>

                                {parking && isCardParking ? (
                                    <AutoCompleteVehicel
                                        setValue={function (
                                            value: MemberVehicleModel | null
                                        ): void {
                                            setVehicel(value);
                                        }}
                                        memberId={member ? member.ID : idMember}
                                        parkingId={parking?.ID}
                                        value={vehicel}
                                    />
                                ) : (
                                    <></>
                                )}
                                <Tooltip title="Dãy số in bên ngoài thẻ vật lý có thể kiểm tra trực tiếp trên thẻ">
                                    <Stack>
                                        <InputLabel>Số thẻ ngoài</InputLabel>
                                        <StyledOutlinedInput
                                            autoComplete="off"
                                            value={idCard}
                                            onChange={(e) => {
                                                setIdCard(e.target.value);
                                            }}
                                            size="small"
                                            fullWidth
                                        />
                                    </Stack>
                                </Tooltip>

                                <Stack>
                                    <InputLabel>Loại xác thực</InputLabel>
                                    <Select
                                        labelId="demo-simple-select-label"
                                        fullWidth
                                        size="small"
                                        sx={{
                                            borderRadius: '10px',
                                        }}
                                        value={typeAuthen}
                                        onChange={(e: any) => {
                                            setTypeAuthen(e.target.value);
                                        }}
                                    >
                                        <MenuItem value={'CARD'}>Thẻ từ</MenuItem>
                                        {/* <MenuItem value={'FACE'}>Gương mặt</MenuItem> */}
                                    </Select>
                                </Stack>

                                {typeAuthen === 'CARD' && (
                                    <Tooltip
                                        title={
                                            'Dãy số từ 8 số, chỉ có thể kiểm tra thông qua việc quét bằng máy đọc'
                                        }
                                    >
                                        <Stack>
                                            <InputLabel>Mã thẻ*</InputLabel>
                                            <StyledOutlinedInput
                                                autoComplete="off"
                                                value={cardNumber}
                                                onChange={(e) => {
                                                    const { value } = e.target;

                                                    if (!hasSpecialCharsOrWhitespace(value)) {
                                                        setCardNumber(e.target.value);
                                                    }
                                                }}
                                                size="small"
                                                fullWidth
                                            />
                                        </Stack>
                                    </Tooltip>
                                )}
                                {typeAuthen === 'FACE' && (
                                    <Stack>
                                        <Typography
                                            sx={{
                                                fontSize: '12px',
                                                color: 'red',
                                                fontStyle: 'italic',
                                            }}
                                        >
                                            * Hình ảnh: Chụp 1 người, rõ mặt
                                        </Typography>
                                        <Card sx={{ maxWidth: 345, position: 'relative' }}>
                                            {renderImage}

                                            <Tooltip title="Thêm ảnh">
                                                <IconButton
                                                    sx={{
                                                        position: 'absolute',
                                                        zIndex: 3,
                                                        bottom: '15px',
                                                        right: '15px',
                                                        backgroundColor: 'rgba(217, 217, 217, 0.6)',
                                                        color: '#fff',
                                                        boxShadow: '0 0 5px rgba(0, 0, 0, 0.2)',
                                                    }}
                                                    component="label"
                                                >
                                                    <input
                                                        hidden
                                                        autoComplete="off"
                                                        accept="image/*"
                                                        type="file"
                                                        onChange={(e: any) => {
                                                            if (!e.target.files[0]) return;
                                                            setFaceImage(e.target.files[0]);
                                                        }}
                                                    />
                                                    <ImageIcon />
                                                </IconButton>
                                            </Tooltip>
                                        </Card>
                                    </Stack>
                                )}

                                <Stack>
                                    <InputLabel>Mô tả</InputLabel>
                                    <StyledOutlinedInput
                                        autoComplete="off"
                                        value={description}
                                        onChange={(e) => {
                                            setDescription(e.target.value);
                                        }}
                                        size="small"
                                        fullWidth
                                        multiline
                                        rows={4}
                                    />
                                </Stack>
                            </Stack>
                        </DialogContent>
                        <DialogActions
                            sx={{
                                px: 3,
                                pb: 3,
                            }}
                        >
                            <Stack sx={{ m: 1, position: 'relative' }}>
                                <StyleButton
                                    variant="contained"
                                    onClick={handleCreate}
                                    disabled={isLoadingButton}
                                >
                                    Tạo mới
                                </StyleButton>
                                {isLoadingButton && (
                                    <CircularProgress
                                        size={24}
                                        sx={{
                                            color: green[500],
                                            position: 'absolute',
                                            top: '50%',
                                            left: '50%',
                                            marginTop: '-12px',
                                            marginLeft: '-12px',
                                        }}
                                    />
                                )}
                            </Stack>
                        </DialogActions>
                        {openComfirm ? (
                            <ComfirmCloseDialog
                                close={() => setOpenComfirm(false)}
                                action={() => {
                                    handleClose();
                                    setOpenComfirm(false);
                                }}
                            />
                        ) : (
                            <></>
                        )}
                    </>
                );
            default:
                return <Stack></Stack>;
        }
    };

    useEffect(() => {
        setVehicel(null);
    }, [member]);
    return (
        <Dialog
            fullScreen={fullScreen}
            open={open}
            onClose={() => {
                if (cardNumber || description || member) {
                    setOpenComfirm(true);
                } else {
                    handleClose();
                }
            }}
            aria-labelledby="responsive-dialog-title"
            sx={{
                '& .MuiPaper-root': {
                    md: { minWidth: '500px', borderRadius: '16px' },
                },
            }}
        >
            {renderView()}
        </Dialog>
    );
}
