import { cardApi } from '@/api/card-api';
import AutoCompoleteMember from '@/components/common/input/autocomplete-member';
import { AutoCompleteVehicel } from '@/components/common/input/autocomplete-vehicel';
import { StyledOutlinedInput } from '@/components/common/style-component';
import { MemberVehicleModel } from '@/models/member.vehicle.model';
import {
    Card,
    CardMedia,
    Checkbox,
    IconButton,
    InputLabel,
    MenuItem,
    Select,
    Stack,
    Tooltip,
    Typography,
} from '@mui/material';
import { useEffect, useMemo, useState } from 'react';
import ImageIcon from '@mui/icons-material/Image';
import { keyRoleApi } from '@/api/key-role-api';
import { useAppSelector } from '@/hooks/useReudx';
import { MemberModel } from '@/models/index';
import { showSnackbarWithClose } from '@/hooks/useSnackbarWithClose';

interface UpdateCardMainProps {
    cardChoose: { cardNumber: string | null; cardId: string | null };
    handleReload?: () => void;
    handleClose: () => void;
    changeView: (v: 'check' | 'update' | 'create') => void;
    onlyElevator?: boolean;
    idMember?: string;
}
export const UpdateCardMain = (props: UpdateCardMainProps) => {
    const { cardChoose, handleReload, handleClose, changeView, idMember, onlyElevator } = props;
    // const {  cardChoose } = props;

    // const [keyRoles, setKeyRoles] = useState([]);
    const parking = useAppSelector((state) => state.parking.choose);
    const [vehicel, setVehicel] = useState<MemberVehicleModel | null>(null);
    const [description, setDescription] = useState('');
    const [member, setMember] = useState<MemberModel | null>(null);
    // const [dateExpire, setDateExpire] = useState<Date | null>(dayjs().endOf('month').toDate());
    const [typeAuthen, setTypeAuthen] = useState<'CARD' | 'FACE'>('CARD');
    const [isLoadingButton, setIsLoadingButton] = useState(false);
    const [idCard, setIdCard] = useState('');
    const [faceImage, setFaceImage] = useState<File | string | null>(null);
    const [isCardElevator, setIsCardElevator] = useState(Boolean(onlyElevator));
    const [isCardParking, setIsCardParking] = useState(false);

    const renderImage = useMemo(() => {
        if (typeof faceImage === 'string') {
            return (
                <CardMedia
                    sx={{ height: 300 }}
                    image={`/service/${faceImage}`}
                    title="green iguana"
                />
            );
        } else {
            return (
                <CardMedia
                    sx={{ height: 300 }}
                    image={
                        faceImage
                            ? URL.createObjectURL(faceImage)
                            : '/images/default_background_company.png'
                    }
                    title="green iguana"
                />
            );
        }
    }, [faceImage]);

    // useEffect(() => {
    //     keyRoleApi.getKeyRole().then((res) => {

    //     });
    // }, []);

    useEffect(() => {
        if (cardChoose.cardId) {
            cardApi.getCardById(cardChoose.cardId).then((res) => {
                setVehicel(res.data.MemberVehicleId);
                setTypeAuthen(res.data.TypeAuthen);
                setDescription(res.data.Description ? res.data.Description : '');
                setIsCardElevator(res.data.IsCardElevator);
                setIsCardParking(res.data.IsCardParking);
                setFaceImage(res.data.FaceImage ? res.data.FaceImage : null);
                setIdCard(res.data.IdCard ? res.data.IdCard : '');
            });
        }
    }, [cardChoose.cardId]);

    const handleUpdate = async () => {
        // if (cardNumber === '' || cardNumber.trim() === '') {
        //     showSnackbarWithClose('Mã thẻ không được để trống', {
        //         variant: 'error',
        //     });
        // }
        // if (!dateExpire) {
        //     showSnackbarWithClose('Chưa chọn ngày hết hạn', {
        //         variant: 'error',
        //     });
        // }

        if (!member && !idMember) {
            showSnackbarWithClose('Bạn chưa chọn cư dân cho thẻ này.', {
                variant: 'error',
            });
            return;
        }

        if (!isCardParking && !isCardElevator) {
            showSnackbarWithClose('Chưa chọn hình thức sử dụng.', {
                variant: 'error',
            });
            return;
        }

        if (isCardParking && !vehicel) {
            showSnackbarWithClose('Chưa chọn loại xe', {
                variant: 'error',
            });
            return;
        }

        if (!cardChoose.cardId || !parking) {
            return;
        }

        // const payload: CardUpdatePayload = {
        //     ID: item.ID,
        //     CardNumber: cardNumber.trim(),
        //     MemberId: member.ID,
        //     Description: description,
        //     ExpirationDate: dateExpire,
        // };

        const formData = new FormData();
        formData.append('ID', cardChoose.cardId);

        if (member) {
            formData.append('MemberId', member.ID);
        }

        if (idMember) {
            formData.append('MemberId', idMember);
        }
        formData.append('ParkingId', parking.ID);
        formData.append('Description', description);

        if (idCard) {
            // console.log('idCard 2 : ', idCard);
            formData.append('IdCard', idCard);
        }
        if (vehicel && isCardParking) {
            formData.append('MemberVehicleId', vehicel.ID);
        }

        if (onlyElevator) {
            formData.append('IsCardParking', 'false');
            formData.append('IsCardElevator', 'true');
        } else {
            formData.append('IsCardParking', isCardParking.toString());
            formData.append('IsCardElevator', isCardElevator.toString());
        }

        formData.append('TypeAuthen', typeAuthen);

        if (typeAuthen === 'CARD') {
            if (cardChoose.cardNumber) {
                formData.append('CardNumber', cardChoose.cardNumber);
            } else {
                showSnackbarWithClose('Bạn chưa nhập mã thẻ!.', { variant: 'error' });
                return;
            }
        }

        if (typeAuthen === 'FACE' && faceImage && typeof faceImage !== 'string') {
            if (faceImage) {
                formData.append('files', faceImage, faceImage.name);
            } else {
                showSnackbarWithClose('Bạn cần chọn một tấm ảnh!.', { variant: 'error' });
                return;
            }
        }

        try {
            await cardApi.updateCard(formData);
            showSnackbarWithClose(`Cập nhật thẻ thành công`, {
                variant: 'success',
            });
            handleReload && handleReload();
            handleClose();
        } catch (error: any) {
            if (Array.isArray(error?.response?.data?.message)) {
                error?.response?.data?.message.forEach((item: any) => {
                    showSnackbarWithClose(item, {
                        variant: 'error',
                    });
                });
            } else {
                showSnackbarWithClose(
                    error?.response ? error.response.data?.message : error.message,
                    {
                        variant: 'error',
                    }
                );
            }
        }
    };

    return (
        <Stack sx={{ padding: '20px', gap: '20px', maxHeight: '900px', overflow: 'auto' }}>
            <Typography sx={{ fontSize: '20px', fontWeight: 600, padding: '10px' }}>
                Chỉnh sửa thẻ tháng
            </Typography>
            {parking && !idMember ? (
                <AutoCompoleteMember
                    setValue={(value) => {
                        setMember(value);
                        setVehicel(null);
                    }}
                    parkingId={parking.ID}
                    value={member}
                />
            ) : (
                <></>
            )}
            {onlyElevator ? (
                <></>
            ) : (
                <>
                    <Typography sx={{ fontSize: '14px', fontWeight: 700 }}>Hình thức :</Typography>
                    <Stack direction="row" justifyContent="center">
                        <Stack direction="row" flex={1} alignItems="center">
                            <Checkbox
                                size="small"
                                checked={isCardElevator}
                                onChange={(e) => setIsCardElevator(e.target.checked)}
                            />
                            <Typography sx={{ textTransform: 'capitalize' }}>thang máy</Typography>
                        </Stack>
                        <Stack direction="row" flex={1} alignItems="center">
                            <Checkbox
                                size="small"
                                checked={isCardParking}
                                onChange={(e) => setIsCardParking(e.target.checked)}
                            />

                            <Typography sx={{ textTransform: 'capitalize' }}>bãi xe</Typography>
                        </Stack>
                    </Stack>
                </>
            )}

            {parking && isCardParking ? (
                <AutoCompleteVehicel
                    setValue={function (value: MemberVehicleModel | null): void {
                        setVehicel(value);
                    }}
                    memberId={member ? member.ID : idMember ? idMember : undefined}
                    parkingId={parking?.ID}
                    value={vehicel}
                />
            ) : (
                <></>
            )}

            <Stack>
                <InputLabel>Loại xác thực</InputLabel>
                <Select
                    labelId="demo-simple-select-label"
                    fullWidth
                    size="small"
                    sx={{
                        borderRadius: '10px',
                    }}
                    value={typeAuthen}
                    onChange={(e: any) => {
                        setTypeAuthen(e.target.value);
                    }}
                >
                    <MenuItem value={'CARD'}>Thẻ từ</MenuItem>
                    {/* <MenuItem value={'FACE'}>Gương mặt</MenuItem> */}
                </Select>
            </Stack>

            {typeAuthen === 'CARD' && (
                <Tooltip
                    title={'Dãy số từ 8 số, chỉ có thể kiểm tra thông qua việc quét bằng máy đọc'}
                >
                    <Stack sx={{ gap: '10px' }}>
                        <Typography>Mã thẻ</Typography>
                        <Stack
                            sx={{
                                padding: '10px 20px',
                                backgroundColor: '#55595D60',
                                borderRadius: '10px',
                            }}
                        >
                            <Typography>{cardChoose.cardNumber}</Typography>
                        </Stack>

                        <Stack>
                            <InputLabel>Số thẻ ngoài</InputLabel>
                            <StyledOutlinedInput
                                autoComplete="off"
                                value={idCard}
                                onChange={(e) => {
                                    setIdCard(e.target.value);
                                }}
                                size="small"
                                fullWidth
                            />
                        </Stack>
                    </Stack>
                </Tooltip>
            )}
            {typeAuthen === 'FACE' && (
                <Stack>
                    <Typography
                        sx={{
                            fontSize: '12px',
                            color: 'red',
                            fontStyle: 'italic',
                        }}
                    >
                        * Hình ảnh: Chụp 1 người, rõ mặt
                    </Typography>
                    <Card sx={{ position: 'relative' }}>
                        {renderImage}

                        <Tooltip title="Thêm ảnh">
                            <IconButton
                                sx={{
                                    position: 'absolute',
                                    zIndex: 3,
                                    bottom: '15px',
                                    right: '15px',
                                    backgroundColor: 'rgba(217, 217, 217, 0.6)',
                                    color: '#fff',
                                    boxShadow: '0 0 5px rgba(0, 0, 0, 0.2)',
                                }}
                                component="label"
                            >
                                <input
                                    hidden
                                    autoComplete="off"
                                    accept="image/*"
                                    type="file"
                                    onChange={(e: any) => {
                                        if (!e.target.files[0]) return;
                                        setFaceImage(e.target.files[0]);
                                    }}
                                />
                                <ImageIcon />
                            </IconButton>
                        </Tooltip>
                    </Card>
                </Stack>
            )}

            <Stack>
                <InputLabel>Mô tả</InputLabel>
                <StyledOutlinedInput
                    autoComplete="off"
                    value={description}
                    onChange={(e) => {
                        setDescription(e.target.value);
                    }}
                    size="small"
                    fullWidth
                    multiline
                    rows={4}
                />
            </Stack>

            <Stack direction="row" justifyContent="flex-end" sx={{ gap: '10px' }}>
                <Stack
                    sx={{
                        backgroundColor: '#55595D',
                        padding: '10px',
                        borderRadius: '5px',
                        cursor: 'pointer',
                    }}
                    onClick={() => {
                        changeView('check');
                    }}
                >
                    <Typography sx={{ fontSize: '14px', color: '#fff', fontWeight: 700 }}>
                        Quay lại
                    </Typography>
                </Stack>
                <Stack
                    sx={{
                        backgroundColor: '#007DC0',
                        padding: '10px',
                        borderRadius: '5px',
                        cursor: 'pointer',
                    }}
                    onClick={() => handleUpdate()}
                >
                    <Typography sx={{ fontSize: '14px', color: '#fff', fontWeight: 700 }}>
                        Cập nhật
                    </Typography>
                </Stack>
            </Stack>
        </Stack>
    );
};
