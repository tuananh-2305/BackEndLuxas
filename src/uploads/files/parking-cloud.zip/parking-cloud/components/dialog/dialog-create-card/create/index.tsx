import AutoCompoleteMember from '@/components/common/input/autocomplete-member';
import { AutoCompleteVehicel } from '@/components/common/input/autocomplete-vehicel';
import { StyledOutlinedInput } from '@/components/common/style-component';
import { useAppSelector } from '@/hooks/useReudx';
import { MemberModel } from '@/models/member.model';
import { MemberVehicleModel } from '@/models/member.vehicle.model';
import {
    Card,
    CardMedia,
    Checkbox,
    IconButton,
    InputLabel,
    MenuItem,
    Select,
    Stack,
    Tooltip,
    Typography,
} from '@mui/material';
import dayjs from 'dayjs';
import ImageIcon from '@mui/icons-material/Image';
import { useEffect, useMemo, useState } from 'react';
import { showSnackbarWithClose } from '@/hooks/useSnackbarWithClose';
import { cardApi } from '@/api/card-api';
import { keyRoleApi } from '@/api/key-role-api';

interface CreateCardMainProps {
    cardChoose: { cardNumber: string | null; cardId: string | null };
    handleReload?: () => void;
    handleClose: () => void;
    changeView: (v: 'check' | 'update' | 'create') => void;
    onlyElevator?: boolean;
    idMember?: string;
}
export const CreateCardMain = (props: CreateCardMainProps) => {
    const { cardChoose, handleReload, handleClose, changeView, idMember, onlyElevator } = props;
    // const {  cardChoose } = props;

    const [keyRoles, setKeyRoles] = useState([]);
    const [vehicel, setVehicel] = useState<MemberVehicleModel | null>(null);
    const [description, setDescription] = useState('');
    const [member, setMember] = useState<MemberModel | null>(null);
    // const [dateExpire, setDateExpire] = useState<Date | null>(dayjs().endOf('month').toDate());
    const [typeAuthen, setTypeAuthen] = useState<'CARD' | 'FACE'>('CARD');
    const [isLoadingButton, setIsLoadingButton] = useState(false);
    const [idCard, setIdCard] = useState('');
    const [faceImage, setFaceImage] = useState<File | null>(null);
    const [isCardElevator, setIsCardElevator] = useState(Boolean(onlyElevator));
    const [isCardParking, setIsCardParking] = useState(false);

    const parking = useAppSelector((state) => state.parking.choose);

    const renderImage = useMemo(
        () => (
            <CardMedia
                sx={{ height: 300 }}
                image={
                    faceImage
                        ? URL.createObjectURL(faceImage)
                        : '/images/default_background_company.png'
                }
                title="green iguana"
            />
        ),
        [faceImage]
    );

    useEffect(() => {
        keyRoleApi.getKeyRole().then((res) => {
            setKeyRoles(res.data);
        });
    }, []);

    useEffect(() => {
        if (keyRoles.length === 0) return;
    }, [keyRoles]);

    const onCreate = async () => {
        if (typeAuthen === 'CARD') {
            if (Boolean(cardChoose?.cardNumber?.trim())) {
                if (cardChoose?.cardNumber && cardChoose?.cardNumber.length < 8) {
                    showSnackbarWithClose('Mã thẻ phải ít nhất 8 ký tự', {
                        variant: 'error',
                    });
                    return;
                }
            } else {
                showSnackbarWithClose('Mã thẻ không được để trống', {
                    variant: 'error',
                });
                return;
            }
        }

        if (!member && !idMember) {
            showSnackbarWithClose('Chưa chọn thành viên', {
                variant: 'error',
            });
            return;
        }

        if (!isCardParking && !isCardElevator) {
            showSnackbarWithClose('Chưa chọn hình thức sử dụng.', {
                variant: 'error',
            });
            return;
        }

        if (isCardParking && !vehicel) {
            showSnackbarWithClose('Chưa chọn loại xe', {
                variant: 'error',
            });
            return;
        }

        if (!parking) {
            showSnackbarWithClose('Chưa chọn bãi xe', {
                variant: 'error',
            });
            return;
        }

        setIsLoadingButton(true);

        const formData = new FormData();

        if (member) {
            formData.append('MemberId', member.ID);
        }

        if (idMember) {
            formData.append('MemberId', idMember);
        }

        if (vehicel && isCardParking) {
            formData.append('MemberVehicleId', vehicel.ID);
        }
        if (onlyElevator) {
            formData.append('IsCardParking', 'false');
            formData.append('IsCardElevator', 'true');
        } else {
            formData.append('IsCardParking', isCardParking.toString());
            formData.append('IsCardElevator', isCardElevator.toString());
        }

        if (idCard) {
            formData.append('IdCard', idCard);
        }

        formData.append('ParkingId', parking?.ID);
        formData.append('Description', description);

        formData.append('TypeAuthen', typeAuthen);

        if (typeAuthen === 'CARD' && cardChoose.cardNumber) {
            formData.append('CardNumber', cardChoose.cardNumber);
        }

        if (typeAuthen === 'FACE' && faceImage) {
            if (faceImage) {
                formData.append('files', faceImage, faceImage.name);
            } else {
                showSnackbarWithClose('Bạn cần chọn một tấm ảnh!.', { variant: 'error' });
                return;
            }
        }

        try {
            await cardApi.createCard(formData);

            showSnackbarWithClose(`Tạo thẻ thành công`, {
                variant: 'success',
            });
            handleReload && handleReload();
            handleClose();
        } catch (error: any) {
            if (Array.isArray(error?.response?.data?.message)) {
                error?.response?.data?.message.forEach((item: any) => {
                    showSnackbarWithClose(item, {
                        variant: 'error',
                    });
                });
            } else {
                showSnackbarWithClose(
                    error?.response ? error.response.data?.message : error.message,
                    {
                        variant: 'error',
                    }
                );
            }
        }
        setTimeout(() => {
            setIsLoadingButton(false);
        }, 1000);
    };

    return (
        <Stack sx={{ padding: '20px', gap: '20px', maxHeight: '900px', overflow: 'auto' }}>
            <Typography sx={{ fontSize: '20px', fontWeight: 600, padding: '10px' }}>
                Tạo mới thẻ tháng
            </Typography>

            {parking && !idMember ? (
                <AutoCompoleteMember
                    setValue={(value) => {
                        setVehicel(null);
                        setMember(value);
                    }}
                    parkingId={parking.ID}
                    value={member}
                />
            ) : (
                <></>
            )}

            {onlyElevator ? (
                <></>
            ) : (
                <>
                    <Typography sx={{ fontSize: '14px', fontWeight: 700 }}>Hình thức :</Typography>
                    <Stack direction="row" justifyContent="center">
                        <Stack direction="row" flex={1} alignItems="center">
                            <Checkbox
                                size="small"
                                checked={isCardElevator}
                                onChange={(e) => setIsCardElevator(e.target.checked)}
                            />
                            <Typography sx={{ textTransform: 'capitalize' }}>thang máy</Typography>
                        </Stack>
                        <Stack direction="row" flex={1} alignItems="center">
                            <Checkbox
                                size="small"
                                checked={isCardParking}
                                onChange={(e) => setIsCardParking(e.target.checked)}
                            />

                            <Typography sx={{ textTransform: 'capitalize' }}>bãi xe</Typography>
                        </Stack>
                    </Stack>
                </>
            )}

            {parking && isCardParking ? (
                <AutoCompleteVehicel
                    setValue={function (value: MemberVehicleModel | null): void {
                        setVehicel(value);
                    }}
                    memberId={member ? member.ID : idMember ? idMember : undefined}
                    parkingId={parking?.ID}
                    value={vehicel}
                />
            ) : (
                <></>
            )}

            <Stack>
                <InputLabel>Loại xác thực</InputLabel>
                <Select
                    labelId="demo-simple-select-label"
                    fullWidth
                    size="small"
                    sx={{
                        borderRadius: '10px',
                    }}
                    value={typeAuthen}
                    onChange={(e: any) => {
                        setTypeAuthen(e.target.value);
                    }}
                >
                    <MenuItem value={'CARD'}>Thẻ từ</MenuItem>
                    {/* <MenuItem value={'FACE'}>Gương mặt</MenuItem> */}
                </Select>
            </Stack>

            {typeAuthen === 'CARD' && (
                <Stack sx={{ gap: '10px' }}>
                    <Typography>Mã thẻ</Typography>
                    <Stack
                        sx={{
                            padding: '10px 20px',
                            backgroundColor: '#55595D60',
                            borderRadius: '10px',
                        }}
                    >
                        <Tooltip
                            title={
                                'Dãy số từ 8 số, chỉ có thể kiểm tra thông qua việc quét bằng máy đọc'
                            }
                        >
                            <Typography>{cardChoose.cardNumber}</Typography>
                        </Tooltip>
                    </Stack>

                    <Stack>
                        <InputLabel>Số thẻ ngoài</InputLabel>

                        <Tooltip title="Dãy số in bên ngoài thẻ vật lý có thể kiểm tra trực tiếp trên thẻ">
                            <StyledOutlinedInput
                                autoComplete="off"
                                value={idCard}
                                onChange={(e) => {
                                    setIdCard(e.target.value);
                                }}
                                size="small"
                                fullWidth
                            />
                        </Tooltip>
                    </Stack>
                </Stack>
            )}

            {typeAuthen === 'FACE' && (
                <Stack>
                    <Typography
                        sx={{
                            fontSize: '12px',
                            color: 'red',
                            fontStyle: 'italic',
                        }}
                    >
                        * Hình ảnh: Chụp 1 người, rõ mặt
                    </Typography>
                    <Card sx={{ position: 'relative' }}>
                        {renderImage}

                        <Tooltip title="Thêm ảnh">
                            <IconButton
                                sx={{
                                    position: 'absolute',
                                    zIndex: 3,
                                    bottom: '15px',
                                    right: '15px',
                                    backgroundColor: 'rgba(217, 217, 217, 0.6)',
                                    color: '#fff',
                                    boxShadow: '0 0 5px rgba(0, 0, 0, 0.2)',
                                }}
                                component="label"
                            >
                                <input
                                    hidden
                                    autoComplete="off"
                                    accept="image/*"
                                    type="file"
                                    onChange={(e: any) => {
                                        if (!e.target.files[0]) return;
                                        setFaceImage(e.target.files[0]);
                                    }}
                                />
                                <ImageIcon />
                            </IconButton>
                        </Tooltip>
                    </Card>
                </Stack>
            )}

            <Stack>
                <InputLabel>Mô tả</InputLabel>
                <StyledOutlinedInput
                    autoComplete="off"
                    value={description}
                    onChange={(e) => {
                        setDescription(e.target.value);
                    }}
                    size="small"
                    fullWidth
                    multiline
                    rows={4}
                />
            </Stack>

            <Stack direction="row" justifyContent="flex-end" sx={{ gap: '10px' }}>
                <Stack
                    sx={{
                        backgroundColor: '#55595D',
                        padding: '10px',
                        borderRadius: '5px',
                        cursor: 'pointer',
                    }}
                    onClick={() => {
                        changeView('check');
                    }}
                >
                    <Typography sx={{ fontSize: '14px', color: '#fff', fontWeight: 700 }}>
                        Quay lại
                    </Typography>
                </Stack>
                <Stack
                    sx={{
                        backgroundColor: '#007DC0',
                        padding: '10px',
                        borderRadius: '5px',
                        cursor: 'pointer',
                    }}
                    onClick={() => onCreate()}
                >
                    <Typography sx={{ fontSize: '14px', color: '#fff', fontWeight: 700 }}>
                        Tạo mới
                    </Typography>
                </Stack>
            </Stack>
        </Stack>
    );
};
