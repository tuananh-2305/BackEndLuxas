import { AuthenVipApi } from '@/api/authentication-vip';
import { parkingApi } from '@/api/index';
import TextFieldForm from '@/components/common/input/text-field-form/text-field-form';
import { useAppSelector } from '@/hooks/index';
import { showSnackbarWithClose } from '@/hooks/useSnackbarWithClose';
import { ParkingModel } from '@/models/authen-role-client';
import { AuthenVipItem } from '@/models/authen-vip';
import { InputLabel, MenuItem, Select, Stack } from '@mui/material';
import Button from '@mui/material/Button';
import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import DialogTitle from '@mui/material/DialogTitle';
import InputBase from '@mui/material/InputBase';
import { styled } from '@mui/material/styles';
import { useEffect, useState } from 'react';
import { ComfirmCloseDialog } from '../dialog-comfirm-close';

export interface IDialogUpdateAuthenVipProps {
    open: boolean;
    handleClose: () => void;
    handleReload: () => void;
    item: AuthenVipItem;
}

const BootstrapInput = styled(InputBase)(({ theme }) => ({
    '& .MuiInputBase-input': {
        borderRadius: 4,
        position: 'relative',
        backgroundColor: '#fff',
        borderColor: theme.palette.primary.main,
        borderWidth: '1px',
        borderStyle: 'solid',
        fontSize: 16,
        padding: '8px 26px 8px 12px',
        transition: theme.transitions.create(['border-color', 'box-shadow']),
        '&:focus': {
            borderRadius: 4,
            borderColor: theme.palette.primary.main,
        },
    },
}));

export default function DialogUpdateAuthenVip(props: IDialogUpdateAuthenVipProps) {
    const { handleClose, handleReload, item } = props;
    const parkingChoose = useAppSelector((state) => state.parking.choose);
    const [openComfirm, setOpenComfirm] = useState(false);
    //
    const [plateNumber, setPlateNumber] = useState('');
    const [cardNumber, setCardNumber] = useState('');
    const [parking, setParking] = useState<string>('');
    const [parkingList, setParkingList] = useState<ParkingModel[]>([]);
    // console.log(item);
    useEffect(() => {
        if (item) {
            setPlateNumber(item.PlateNumber);
            setCardNumber(item.CardNumber);
            setParking(item.ParkingId?.ID ?? '');
        }
    }, []);

    const handleChangeParking = (event: any) => {
        setParking(event.target.value);
    };

    const getAllParking = async () => {
        await parkingApi.getAllParking().then((res) => {
            setParkingList(res.data);
        });
    };

    // KeyClientApi
    useEffect(() => {
        getAllParking();
    }, []);
    const submit = () => {
        if (!parkingChoose) {
            return;
        }
        if (!plateNumber || plateNumber.trim() === '') {
            showSnackbarWithClose('Vui lòng nhập biển số', {
                variant: 'error',
            });
            return;
        }
        if (!cardNumber || cardNumber.trim() === '') {
            showSnackbarWithClose('Vui lòng nhập mã thẻ', {
                variant: 'error',
            });
            return;
        }
        if (!parking || parking.trim() === '') {
            showSnackbarWithClose('Vui lòng chọn bãi xe', {
                variant: 'error',
            });
            return;
        }
        const payload = {
            PlateNumber: plateNumber,
            CardNumber: cardNumber,
            ParkingId: parking,
            ID: item.ID,
        };

        AuthenVipApi.updateKeyClient(payload)
            .then(() => {
                showSnackbarWithClose('Cập nhật thành công', {
                    variant: 'success',
                });
                handleClose();
                handleReload();
            })
            .catch((error) => {
                if (Array.isArray(error?.response?.data?.message)) {
                    error?.response?.data?.message.forEach((item: any) => {
                        showSnackbarWithClose(item, {
                            variant: 'error',
                        });
                    });
                } else {
                    showSnackbarWithClose(
                        error?.response ? error.response.data?.message : error.message,
                        {
                            variant: 'error',
                        }
                    );
                }
            });
    };

    return (
        <Dialog
            open={props.open}
            onClose={handleClose}
            aria-labelledby="alert-dialog-title"
            aria-describedby="alert-dialog-description"
            maxWidth={'sm'}
            fullWidth
        >
            <DialogTitle id="alert-dialog-title">{'Cập Nhật Thẻ Vip'}</DialogTitle>
            <DialogContent>
                <TextFieldForm
                    lable={'Biển số'}
                    value={plateNumber}
                    onChange={(e) => {
                        const { value } = e.target;
                        setPlateNumber(value);
                    }}
                />
                <Stack sx={{ py: '5px' }} />
                <TextFieldForm
                    lable={'Mã thẻ'}
                    value={cardNumber}
                    onChange={(e) => {
                        const { value } = e.target;
                        setCardNumber(value);
                    }}
                />
                {/* parking */}
                <Stack sx={{ my: '15px' }}>
                    <InputLabel id="demo-select-small-label">Bãi xe</InputLabel>
                    <Select
                        labelId="demo-select-small-label"
                        id="demo-select-small"
                        value={parking}
                        onChange={handleChangeParking}
                        input={<BootstrapInput />}
                    >
                        {parkingList.length > 0 &&
                            parkingList.map((item: ParkingModel, index) => {
                                return (
                                    <MenuItem key={index} value={item.ID}>
                                        {item.Name}
                                    </MenuItem>
                                );
                            })}
                    </Select>
                </Stack>
            </DialogContent>

            {/* action */}
            <DialogActions sx={{ gap: '10px', mr: '20px', mb: '10px' }}>
                <Button
                    onClick={handleClose}
                    variant="contained"
                    sx={{
                        background: '#CDD2D1',
                        ':hover': {
                            background: '#DBE8E1',
                        },
                        fontSize: '14px',
                        fontWeight: '500',
                        borderRadius: '6px',
                        textTransform: 'revert-layer',
                    }}
                >
                    Hủy
                </Button>
                <Button
                    onClick={submit}
                    variant="contained"
                    sx={{
                        background: '#007DC0',
                        ':hover': {
                            background: '#009FD0',
                        },
                        fontSize: '14px',
                        fontWeight: '500',
                        textTransform: 'revert-layer',
                        borderRadius: '6px',
                    }}
                    autoFocus
                >
                    Cập nhật
                </Button>
            </DialogActions>
            {openComfirm ? (
                <ComfirmCloseDialog
                    close={() => setOpenComfirm(false)}
                    action={() => {
                        setOpenComfirm(false);
                        handleClose();
                    }}
                />
            ) : (
                <></>
            )}
        </Dialog>
    );
}
