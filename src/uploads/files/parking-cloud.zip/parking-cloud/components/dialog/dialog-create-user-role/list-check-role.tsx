import { keyDetailCloudApi } from '@/api/key-detai-cloud';
import { Stack, Checkbox, Typography } from '@mui/material';
import { useEffect, useState } from 'react';

interface RoleDetailCloud {
    CreatedAt: string;
    DeletedAt: string | null;
    ID: string;
    KeyWord: string;
    Name: string;
    UpdatedAt: string;
    IsUse: boolean;
}

interface ListCheckRoleProps {
    listRoleCloud: RoleDetailCloud[];
    change: (data: RoleDetailCloud[]) => void;
}

export const ListCheckRole = (props: ListCheckRoleProps) => {
    const { change, listRoleCloud } = props;

    const fetchData = () => {
        keyDetailCloudApi.all().then((res) => {
            const listRole = res.data.map((v: any) => ({ ...v, IsUse: true }));
            change(listRole);
        });
    };

    useEffect(() => {
        fetchData();
    }, []);

    return (
        <Stack sx={{ maxHeight: '200px', overflow: 'auto', scrollSnapType: 'y mandatory' }}>
            {listRoleCloud.map((v, index: number) => (
                <Stack
                    key={v.ID}
                    direction="row"
                    alignItems="center"
                    sx={{ gap: 2, scrollSnapAlign: 'start' }}
                >
                    <Checkbox
                        checked={v.IsUse}
                        onChange={(e) => {
                            const { checked } = e.target;
                            let clone = [...listRoleCloud];
                            clone[index].IsUse = checked;

                            change([...clone]);
                        }}
                    />
                    <Typography>{v.Name}</Typography>
                </Stack>
            ))}
        </Stack>
    );
};
