import { groupRoleApi, userParkingApi } from '@/api/index';
import { useAppSelector } from '@/hooks/useReudx';
import { showSnackbarWithClose } from '@/hooks/useSnackbarWithClose';
import { RoleModel } from '@/models/group.role.model';
import { theme } from '@/ultis/theme';
import {
    CircularProgress,
    Dialog,
    DialogActions,
    DialogContent,
    DialogTitle,
    InputLabel,
    MenuItem,
    Select,
    Stack,
    useMediaQuery,
} from '@mui/material';
import { green } from '@mui/material/colors';
import { useEffect, useState } from 'react';
import AutoCompoleteUserParking from '../../common/input/autocomplete-user';
import { StyleButton } from '../../common/style-component';
import { ComfirmCloseDialog } from '../dialog-comfirm-close';
import { ListCheckRole } from './list-check-role';
import { systemRoleDetailRoleApi } from '@/api/system-role-detail-cloud';

export interface IDialogCreateUserRoleProps {
    open: boolean;
    handleClose: () => void;
    handleReload?: () => void;
    idParking?: string;
}

interface RoleDetailCloud {
    CreatedAt: string;
    DeletedAt: string | null;
    ID: string;
    KeyWord: string;
    Name: string;
    UpdatedAt: string;
    IsUse: boolean;
}

export default function DialogCreateUserRole(props: IDialogCreateUserRoleProps) {
    const { open, handleClose, handleReload, idParking } = props;
    const [selectUserParking, setSelectUserParking] = useState<any>();
    const [dataRole, setDataRole] = useState<RoleModel[]>([]);
    const [selectRole, setSelectRole] = useState<string>();
    const [isLoadingButton, setIsLoadingButton] = useState(false);

    const [listRoleCloud, setListRoleCloud] = useState<RoleDetailCloud[]>([]);

    const nameDialog = 'nhân viên bãi xe';
    const idCustomer = useAppSelector((state) => state.common.profile?.CustomerId?.ID);

    const fullScreen = useMediaQuery(theme.breakpoints.down('md'));
    const [openComfirm, setOpenComfirm] = useState(false);

    useEffect(() => {}, []);
    // reset name and checked when close dialog
    useEffect(() => {
        if (open) {
            if (!idCustomer) return;
            setSelectRole(undefined);
            setSelectUserParking(undefined);
            groupRoleApi.getGroupRoleByCustomerId(idCustomer).then((res) => {
                setDataRole(res.data);
            });
        }
    }, [open]);

    const handleCreate = async () => {
        if (!selectRole) {
            showSnackbarWithClose(`Vui lòng chọn nhóm quyền`, {
                variant: 'error',
            });
            setIsLoadingButton(false);
            return;
        }
        if (!selectUserParking) {
            showSnackbarWithClose(`Vui lòng chọn nhân viên`, {
                variant: 'error',
            });
            setIsLoadingButton(false);
            return;
        }

        if (!idParking) {
            return;
        }

        const payload: any = {
            GroupRoleId: selectRole,
            ParkingId: idParking,
            UserId: selectUserParking?.ID,
        };

        try {
            const { data } = await userParkingApi.createUserParking(payload);

            await systemRoleDetailRoleApi.create({
                UserId: selectUserParking?.ID,
                ParkingId: idParking,
                DataCreate: listRoleCloud.map((item) => ({
                    KeyRoleDetailId: item.ID,
                    IsUse: item.IsUse,
                })),
            });

            showSnackbarWithClose(`Tạo ${nameDialog} thành công`, {
                variant: 'success',
            });
            handleReload && handleReload();
            handleClose();
        } catch (error: any) {
            if (Array.isArray(error?.response?.data?.message)) {
                error?.response?.data?.message.forEach((item: any) => {
                    showSnackbarWithClose(item, {
                        variant: 'error',
                    });
                });
            } else {
                showSnackbarWithClose(
                    error?.response ? error.response.data?.message : error.message,
                    {
                        variant: 'error',
                    }
                );
            }
        }
        setTimeout(() => {
            setIsLoadingButton(false);
        }, 1000);
    };

    return (
        <Dialog
            fullScreen={fullScreen}
            open={open}
            onClose={() => {
                if (selectRole || selectUserParking) {
                    setOpenComfirm(true);
                } else {
                    handleClose();
                }
            }}
            aria-labelledby="responsive-dialog-title"
            sx={{
                '& .MuiPaper-root': {
                    md: { minWidth: '500px', borderRadius: '16px' },
                },
            }}
        >
            <DialogTitle>{`Tạo ${nameDialog} mới`}</DialogTitle>
            <DialogContent>
                <Stack py={2} spacing={2}>
                    <AutoCompoleteUserParking
                        setValue={(value: any) => {
                            setSelectUserParking(value);
                        }}
                        parkingId={idParking || ''}
                    />
                    <Stack>
                        <InputLabel>Nhóm quyền</InputLabel>
                        <Select
                            labelId="demo-simple-select-label"
                            fullWidth
                            size="small"
                            sx={{
                                borderRadius: '10px',
                            }}
                            value={selectRole}
                            onChange={(e) => {
                                setSelectRole(e.target.value as string);
                            }}
                        >
                            {dataRole.map((item, ind) => (
                                <MenuItem key={ind} value={item.ID}>
                                    {item.Name}
                                </MenuItem>
                            ))}
                        </Select>
                    </Stack>
                    <ListCheckRole
                        listRoleCloud={listRoleCloud}
                        change={(data) => setListRoleCloud(data)}
                    />
                </Stack>
            </DialogContent>
            <DialogActions
                sx={{
                    px: 3,
                    pb: 3,
                }}
            >
                <Stack sx={{ m: 1, position: 'relative' }}>
                    <StyleButton
                        variant="contained"
                        onClick={() => {
                            setIsLoadingButton(true);
                            handleCreate();
                        }}
                        disabled={isLoadingButton}
                    >
                        Tạo mới
                    </StyleButton>
                    {isLoadingButton && (
                        <CircularProgress
                            size={24}
                            sx={{
                                color: green[500],
                                position: 'absolute',
                                top: '50%',
                                left: '50%',
                                marginTop: '-12px',
                                marginLeft: '-12px',
                            }}
                        />
                    )}
                </Stack>
            </DialogActions>
            {openComfirm ? (
                <ComfirmCloseDialog
                    close={() => setOpenComfirm(false)}
                    action={() => {
                        setOpenComfirm(false);
                        handleClose();
                    }}
                />
            ) : (
                <></>
            )}
        </Dialog>
    );
}
