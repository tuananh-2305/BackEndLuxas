import { cardApi } from '@/api/card-api';
import { memberVehicleApi } from '@/api/member-vehicle-api';
import { useAppSelector } from '@/hooks/useReudx';
import { showSnackbarWithClose } from '@/hooks/useSnackbarWithClose';
import { Stack, Typography, TextField, Button, InputLabel } from '@mui/material';
import { useState } from 'react';

interface DialogCreateReportVehicleProps {
    close: () => void;
    handleReload: () => void;
}

export const DialogCreateReportVehicle = (props: DialogCreateReportVehicleProps) => {
    const { close, handleReload } = props;

    const parkingChoose = useAppSelector((state) => state.parking.chooseDashboard);
    const [plateNumber, setPlateNumber] = useState('');
    const [descripton, setDescription] = useState('');

    const submit = () => {
        if (!parkingChoose) {
            return;
        }
        if (!plateNumber || plateNumber.trim() === '') {
            showSnackbarWithClose('Vui lòng nhập biển số xe', {
                variant: 'error',
            });
            return;
        }
        memberVehicleApi
            .makeResportLostVehicle({
                ParkingId: parkingChoose.ID,
                PlateNumber: plateNumber,
                Description: descripton,
            })
            .then(() => {
                showSnackbarWithClose('Báo mất xe thành công', {
                    variant: 'success',
                });
                close();
                handleReload();
            })
            .catch((error) => {
                if (Array.isArray(error?.response?.data?.message)) {
                    error?.response?.data?.message.forEach((item: any) => {
                        showSnackbarWithClose(item, {
                            variant: 'error',
                        });
                    });
                } else {
                    showSnackbarWithClose(
                        error?.response ? error.response.data?.message : error.message,
                        {
                            variant: 'error',
                        }
                    );
                }
            });
    };
    return (
        <Stack
            sx={{
                position: 'fixed',
                top: 0,
                left: 0,
                right: 0,
                bottom: 0,
                zIndex: 10,
            }}
            justifyContent="center"
            alignItems="center"
        >
            <Stack
                sx={{
                    position: 'absolute',
                    width: '100%',
                    height: '100%',
                    backgroundColor: 'rgba(85, 89, 93, 0.15)',
                    zIndex: 2,
                }}
                onClick={() => close()}
            />

            <Stack
                sx={{
                    width: '400px',
                    height: 'fit-content',
                    backgroundColor: '#fff',
                    borderRadius: '20px',
                    zIndex: 3,
                    padding: '20px',
                    boxShadow: '0px 4px 4px 0px rgba(0, 0, 0, 0.25)',
                    gap: '20px',
                }}
            >
                <Typography sx={{ fontSize: '16px', color: '#55595D', fontWeight: 700 }}>
                    Báo mất xe
                </Typography>

                <Stack sx={{ gap: '20px' }}>
                    <Stack>
                        <InputLabel required>Biển số</InputLabel>
                        <TextField
                            variant="outlined"
                            size="small"
                            placeholder="Nhập biển số xe đã mất"
                            onChange={(e) => {
                                const { value } = e.target;
                                setPlateNumber(value);
                            }}
                        />
                    </Stack>
                    <Stack>
                        <InputLabel>Mô tả</InputLabel>
                        <TextField
                            multiline
                            rows={3}
                            variant="outlined"
                            size="small"
                            placeholder="Mô tả chi tiết "
                            onChange={(e) => {
                                const { value } = e.target;
                                setDescription(value);
                            }}
                        />
                    </Stack>
                </Stack>

                <Stack direction="row-reverse">
                    <Button color="error" variant="contained" onClick={() => submit()}>
                        Báo cáo
                    </Button>
                </Stack>
            </Stack>
        </Stack>
    );
};
