import { cardApi } from '@/api/card-api';
import { useAppSelector } from '@/hooks/useReudx';
import { Stack, Typography, TextField, Button } from '@mui/material';
import { useState } from 'react';

interface DialogCreateReportProps {
    close: () => void;
    handleReload: () => void;
}

export const DialogCreateReport = (props: DialogCreateReportProps) => {
    const { close, handleReload } = props;

    const parkingChoose = useAppSelector((state) => state.parking.chooseDashboard);
    const [cardNumber, setCardNumber] = useState('');
    const [descripton, setDescription] = useState('');

    const submit = () => {
        if (!parkingChoose) {
            return;
        }

        cardApi
            .makeResportLostCard({
                ParkingId: parkingChoose.ID,
                CardNumber: cardNumber,
                Description: descripton,
            })
            .then(() => {
                close();
                handleReload();
            });
    };
    return (
        <Stack
            sx={{
                position: 'fixed',
                top: 0,
                left: 0,
                right: 0,
                bottom: 0,
                zIndex: 10,
            }}
            justifyContent="center"
            alignItems="center"
        >
            <Stack
                sx={{
                    position: 'absolute',
                    width: '100%',
                    height: '100%',
                    backgroundColor: 'rgba(85, 89, 93, 0.15)',
                    zIndex: 2,
                }}
                onClick={() => close()}
            />

            <Stack
                sx={{
                    width: '400px',
                    height: 'fit-content',
                    backgroundColor: '#fff',
                    borderRadius: '20px',
                    zIndex: 3,
                    padding: '20px',
                    boxShadow: '0px 4px 4px 0px rgba(0, 0, 0, 0.25)',
                    gap: '20px',
                }}
            >
                <Typography sx={{ fontSize: '16px', color: '#55595D', fontWeight: 700 }}>
                    Báo mất thẻ
                </Typography>

                <Stack sx={{ gap: '20px' }}>
                    <TextField
                        variant="outlined"
                        size="small"
                        placeholder="Nhập mã thẻ đã mất"
                        onChange={(e) => {
                            const { value } = e.target;
                            setCardNumber(value);
                        }}
                    />
                    <TextField
                        multiline
                        rows={3}
                        variant="outlined"
                        size="small"
                        placeholder="Nhập nội dung cần trình bày"
                        onChange={(e) => {
                            const { value } = e.target;
                            setDescription(value);
                        }}
                    />
                </Stack>

                <Stack direction="row-reverse">
                    <Button color="error" variant="contained" onClick={() => submit()}>
                        Báo cáo
                    </Button>
                </Stack>
            </Stack>
        </Stack>
    );
};
