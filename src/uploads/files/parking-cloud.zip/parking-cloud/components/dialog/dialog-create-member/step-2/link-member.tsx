import { memberApi } from '@/api/index';
import AutoCompoleteMemberType from '@/components/common/input/autocomplete-member-type';
import { StyledOutlinedInput } from '@/components/common/style-component';
import { useAppSelector } from '@/hooks/index';
import { showSnackbarWithClose } from '@/hooks/useSnackbarWithClose';
import { MemberLinkParkingCreatePayload, MemberModel } from '@/models/member.model';
import { MemberTypeModel } from '@/models/member.type.model';
import { validatePhoneNumber } from '@/ultis/index';
import { Button, CircularProgress, InputLabel, Stack, Typography } from '@mui/material';
import { useEffect, useState } from 'react';
import Image from 'next/image';
import DialogAlert from '../../dialog-alert';

interface LinkingViewProps {
    changeStep: (step: number) => void;
    phoneChoose: { value: string; isExist: boolean } | null;
    changeMember: (m: MemberModel | null) => void;
    fecthData: () => void;
}

export const LinkingView = (props: LinkingViewProps) => {
    const { changeMember, changeStep, phoneChoose, fecthData } = props;

    const parkingChoose = useAppSelector((state) => state.parking.choose);

    const [memberType, setMemberType] = useState<MemberTypeModel | null>(null);
    const [member, setMember] = useState<MemberModel | null>(null);
    const [address, setAddress] = useState('');
    const [loading, setLoading] = useState(false);
    useEffect(() => {
        if (phoneChoose && parkingChoose) {
            if (validatePhoneNumber(phoneChoose.value)) {
                memberApi
                    .searchMemberByPhone(phoneChoose.value, parkingChoose?.ID)
                    .then((res) => {
                        const { data } = res;
                        if (data) {
                            setMember(data);
                        } else {
                            changeStep(0);
                        }
                    })
                    .catch((err) => {
                        changeStep(0);
                    });

                return;
            }
        }
    }, [changeStep, parkingChoose, phoneChoose]);

    if (!parkingChoose || !phoneChoose || !phoneChoose.value) {
        changeStep(0);
        return <></>;
    }

    const handleCreateLink = async () => {
        if (!parkingChoose.ID) {
            showSnackbarWithClose(`Vui lòng chọn bãi đỗ xe`, { variant: 'error' });
            return;
        }
        if (!memberType) {
            showSnackbarWithClose(`Vui lòng chọn loại khách hàng/cư dân`, { variant: 'error' });
            return;
        }
        if (!address || !address.trim()) {
            showSnackbarWithClose(`Địa chỉ không được để trống`, {
                variant: 'error',
            });
            return;
        }
        if (!member) {
            showSnackbarWithClose(`Vui lòng tạo khách hàng/cư dân trước`, { variant: 'error' });
            return;
        }

        let payload: MemberLinkParkingCreatePayload = {
            ParkingId: parkingChoose.ID,
            MemberId: member.ID,
            MemberTypeId: memberType.ID,
            Address: address,
        };
        setLoading(true);
        memberApi
            .linkMemberParking(payload)
            .then((res) => {
                changeMember(res.data);
                fecthData();
                changeStep(2);
            })
            .catch((error) => {
                if (Array.isArray(error?.response?.data?.message)) {
                    error?.response?.data?.message.forEach((item: any) => {
                        showSnackbarWithClose(item, {
                            variant: 'error',
                        });
                    });
                } else {
                    showSnackbarWithClose(
                        error?.response ? error.response.data?.message : error.message,
                        {
                            variant: 'error',
                        }
                    );
                }
            })
            .finally(() => {
                setLoading(false);
            });
    };
    return (
        <Stack
            sx={{ height: '100%', padding: '10px', gap: '10px' }}
            justifyContent="space-between"
            alignItems="center"
        >
            <Stack sx={{ width: '100%', gap: '20px' }}>
                {member ? (
                    <Stack
                        direction="row"
                        sx={{
                            padding: '5px 10px',
                            borderRadius: '5px',
                            width: '100%',
                            gap: '10px',
                            boxShadow:
                                'rgba(50, 50, 93, 0.25) 0px 2px 5px -1px, rgba(0, 0, 0, 0.3) 0px 1px 3px -1px',
                        }}
                        alignItems="center"
                    >
                        <Image
                            src="/default-user.jpg"
                            style={{
                                borderRadius: '50%',
                                boxShadow:
                                    'rgba(0, 0, 0, 0.12) 0px 1px 3px, rgba(0, 0, 0, 0.24) 0px 1px 2px',
                            }}
                            width={50}
                            height={50}
                            alt="photo"
                        />
                        <Stack>
                            <Typography sx={{ fontWeight: 500, fontSize: '14px' }}>
                                {member.Name}
                            </Typography>
                            <Typography
                                sx={{
                                    color: member.IsExist ? '#ff304f' : '#ffd615',
                                    fontSize: '12px',
                                    fontWeight: 700,
                                }}
                            >
                                {member.IsExist
                                    ? 'Đã tồn tại trong bãi xe này'
                                    : 'Đã có thông tin, nhấn liên kết thành viên để tiếp tục'}
                            </Typography>
                        </Stack>
                    </Stack>
                ) : (
                    <></>
                )}

                <Stack sx={{ width: '100%' }}>
                    <AutoCompoleteMemberType
                        setValue={setMemberType}
                        parkingId={parkingChoose.ID}
                        value={memberType}
                    />
                </Stack>

                <Stack sx={{ width: '100%' }}>
                    <InputLabel>Địa chỉ *</InputLabel>
                    <StyledOutlinedInput
                        autoComplete="off"
                        value={address}
                        onChange={(e) => {
                            setAddress(e.target.value);
                        }}
                        size="small"
                        fullWidth
                        type={'text'}
                    />
                </Stack>
            </Stack>
            <Stack sx={{ flex: 1 }} />

            <Stack direction="row" sx={{ width: '100%', gap: '10px' }} justifyContent="flex-end">
                {!loading ? (
                    <Stack
                        sx={{
                            width: 'fit-content',
                            backgroundColor: '#55595D',
                            borderRadius: '5px',
                            padding: '5px 20px',
                            cursor: 'pointer',
                            transition: 'all ease .5s',
                            '&:hover ': { boxShadow: 'rgba(0, 0, 0, 0.24) 0px 3px 8px' },
                        }}
                        alignItems="center"
                        onClick={() => changeStep(0)}
                    >
                        <Typography sx={{ fontSize: '14px', fontWeight: 700, color: '#fff' }}>
                            Quay về
                        </Typography>
                    </Stack>
                ) : (
                    <></>
                )}

                <Stack
                    sx={{
                        width: '180px',
                        backgroundColor: '#007DC0',
                        borderRadius: '5px',
                        padding: '5px 20px',
                        cursor: 'pointer',
                        '&:hover ': { boxShadow: 'rgba(0, 0, 0, 0.24) 0px 3px 8px' },
                    }}
                    onClick={() => {
                        if (!loading) {
                            handleCreateLink();
                        }
                    }}
                    justifyContent="center"
                    alignItems="center"
                >
                    {loading ? (
                        <CircularProgress
                            size={20}
                            sx={{
                                color: '#fff',
                                ml: '10px',
                            }}
                        />
                    ) : (
                        <Typography sx={{ fontSize: '14px', fontWeight: 700, color: '#fff' }}>
                            Liên kết với bãi xe
                        </Typography>
                    )}
                </Stack>
            </Stack>
        </Stack>
    );
};
