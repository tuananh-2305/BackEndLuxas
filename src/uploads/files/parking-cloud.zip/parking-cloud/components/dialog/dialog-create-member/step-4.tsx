import { cardApi } from '@/api/card-api';
import { useAppSelector } from '@/hooks/useReudx';
import { showSnackbarWithClose } from '@/hooks/useSnackbarWithClose';
import { useDebouncedValue } from '@mantine/hooks';
import { Stack, Typography, TextField, IconButton, CircularProgress } from '@mui/material';
import { useEffect, useState } from 'react';
import Image from 'next/image';
import ReplayIcon from '@mui/icons-material/Replay';
import DialogAlert from '@/components/dialog/dialog-alert';
import { hasSpecialCharsOrWhitespace } from '@/ultis/global-func';

interface CreateCardCheckProps {
    changeStep: (v: number) => void;
    changeCardChoose: (v: { cardNumber: string | null; cardData: any }) => void;
}

export const CreateMemberStepFour = (props: CreateCardCheckProps) => {
    const { changeCardChoose, changeStep } = props;
    const parkingChoose = useAppSelector((state) => state.parking.choose);

    const [card, setCard] = useState<string>('');
    const [cardData, setCardData] = useState<any>(null);
    const [debounced] = useDebouncedValue(card, 300);
    const [ischeck, setIsCheck] = useState(false);
    const [openAlert, setOpenAlert] = useState(false);
    const [loading, setLoading] = useState(false);

    const checkButton = () => {
        if (ischeck) {
            if (cardData) {
                return (
                    <Stack
                        sx={{
                            backgroundColor: '#007DC0',
                            padding: '5px',
                            borderRadius: '5px',
                            width: '150px',
                            cursor: 'pointer',
                        }}
                        justifyContent="center"
                        alignItems="center"
                        onClick={() => {
                            if (parkingChoose) {
                                if (cardData.MemberId) {
                                    setOpenAlert(true);
                                } else {
                                    setIsCheck(false);
                                    changeCardChoose({ cardNumber: card, cardData: cardData });
                                    setCardData(null);
                                }
                            }
                        }}
                    >
                        <Typography sx={{ fontWeight: 700, color: '#fff', fontSize: '14px' }}>
                            Cập nhật
                        </Typography>
                    </Stack>
                );
            } else {
                return (
                    <Stack
                        sx={{
                            backgroundColor: '#007DC0',
                            padding: '5px',
                            borderRadius: '5px',
                            width: '150px',
                            cursor: 'pointer',
                        }}
                        justifyContent="center"
                        alignItems="center"
                        onClick={() => {
                            if (parkingChoose) {
                                setIsCheck(false);
                                setCardData(null);
                                changeCardChoose({
                                    cardNumber: card,
                                    cardData: null,
                                });
                            }
                        }}
                    >
                        <Typography sx={{ fontWeight: 700, color: '#fff', fontSize: '14px' }}>
                            Tạo mới
                        </Typography>
                    </Stack>
                );
            }
        } else {
            // console.log('cardData : ', cardData);
            return (
                <Stack
                    sx={{
                        backgroundColor: !debounced || debounced.length < 8 ? '#55595D' : '#007DC0',
                        padding: '5px',
                        borderRadius: '5px',
                        width: '150px',
                        cursor: 'pointer',
                    }}
                    justifyContent="center"
                    alignItems="center"
                    onClick={() => {
                        if (!debounced || debounced.length < 8) {
                            return;
                        }

                        if (parkingChoose && debounced) {
                            setLoading(true);
                            cardApi
                                .getCheckCard(debounced, parkingChoose.ID)
                                .then((res) => {
                                    setIsCheck(true);
                                    setCardData(res.data ? res.data : null);
                                })
                                .catch((error) => {
                                    if (Array.isArray(error?.response?.data?.message)) {
                                        error?.response?.data?.message.forEach((item: any) => {
                                            showSnackbarWithClose(item, {
                                                variant: 'error',
                                            });
                                        });
                                    } else {
                                        showSnackbarWithClose(
                                            error?.response
                                                ? error.response.data?.message
                                                : error.message,
                                            {
                                                variant: 'error',
                                            }
                                        );
                                    }
                                })
                                .finally(() => {
                                    setLoading(false);
                                });
                        }
                    }}
                >
                    {loading ? (
                        <CircularProgress
                            size={20}
                            sx={{
                                color: '#fff',
                                ml: '10px',
                            }}
                        />
                    ) : (
                        <Typography sx={{ fontWeight: 700, color: '#fff', fontSize: '14px' }}>
                            Kiểm tra
                        </Typography>
                    )}
                </Stack>
            );
        }
    };

    const checkMessage = () => {
        if (ischeck) {
            if (cardData) {
                if (cardData.MemberId) {
                    return (
                        <Stack sx={{ gap: '10px' }}>
                            <Typography
                                sx={{ fontSize: '14px', fontWeight: 600, color: '#ff304f' }}
                            >
                                Mã thẻ đã được sử dụng
                            </Typography>
                            <Stack justifyContent="center" alignItems="center">
                                <Image
                                    src={
                                        cardData?.MemberId?.Avatar
                                            ? `/service/${cardData?.MemberId?.Avatar}`
                                            : '/default-user.jpg'
                                    }
                                    style={{
                                        objectFit: 'cover',
                                        border: '2px solid white',
                                        borderRadius: '50%',
                                        boxShadow: 'rgba(0, 0, 0, 0.24) 0px 3px 8px',
                                    }}
                                    width={60}
                                    height={60}
                                    alt="photo"
                                />
                            </Stack>

                            <Stack>
                                <Typography sx={{ fontSize: '14px' }}>
                                    <strong>Người dùng hiện tại :</strong> {cardData?.MemberId.Name}
                                </Typography>
                                {cardData?.MemberId?.Phone ? (
                                    <Typography sx={{ fontSize: '14px' }}>
                                        <strong>Sổ điện thoại :</strong> {cardData.MemberId.Phone}
                                    </Typography>
                                ) : (
                                    <></>
                                )}
                                {cardData?.MemberId?.Email ? (
                                    <Typography sx={{ fontSize: '14px' }}>
                                        <strong>Địa chỉ mail :</strong> {cardData.MemberId.Email}
                                    </Typography>
                                ) : (
                                    <></>
                                )}
                                {cardData?.Address ? (
                                    <Typography sx={{ fontSize: '14px' }}>
                                        <strong>Địa chỉ căn hộ :</strong> {cardData.Address}
                                    </Typography>
                                ) : (
                                    <></>
                                )}
                            </Stack>

                            <Stack>
                                <Typography sx={{ fontSize: '14px', fontWeight: 700 }}>
                                    Tình trạng :
                                </Typography>
                                <Stack component="ul" sx={{ paddingLeft: '20px' }}>
                                    {cardData?.IsCardParking ? (
                                        <Typography component="li" sx={{ fontSize: '14px' }}>
                                            Được dùng cho bãi xe
                                        </Typography>
                                    ) : (
                                        <Typography component="li" sx={{ fontSize: '14px' }}>
                                            Không dùng cho bãi xe
                                        </Typography>
                                    )}

                                    {cardData?.IsCardElevator ? (
                                        <Typography component="li" sx={{ fontSize: '14px' }}>
                                            Được dùng cho thang máy
                                        </Typography>
                                    ) : (
                                        <Typography component="li" sx={{ fontSize: '14px' }}>
                                            Không dùng cho thang máy
                                        </Typography>
                                    )}
                                </Stack>
                            </Stack>
                        </Stack>
                    );
                } else {
                    return (
                        <Stack>
                            <Typography
                                sx={{
                                    fontSize: '14px',
                                    fontWeight: 600,
                                    color: '#ff304f',
                                }}
                            >
                                Mã thẻ đã được sử dụng nhưng chưa gán cho cư dân
                            </Typography>
                            <Typography sx={{ fontSize: '14px', fontWeight: 700 }}>
                                Tình trạng :
                            </Typography>
                            <Stack component="ul" sx={{ paddingLeft: '20px' }}>
                                {cardData?.IsCardParking ? (
                                    <Typography component="li" sx={{ fontSize: '14px' }}>
                                        Được dùng cho bãi xe
                                    </Typography>
                                ) : (
                                    <Typography component="li" sx={{ fontSize: '14px' }}>
                                        Không dùng cho bãi xe
                                    </Typography>
                                )}

                                {cardData?.IsCardElevator ? (
                                    <Typography component="li" sx={{ fontSize: '14px' }}>
                                        Được dùng cho thang máy
                                    </Typography>
                                ) : (
                                    <Typography component="li" sx={{ fontSize: '14px' }}>
                                        Không dùng cho thang máy
                                    </Typography>
                                )}
                            </Stack>
                        </Stack>
                    );
                }
            } else {
                return (
                    <Typography sx={{ fontSize: '14px', fontWeight: 600, color: '#17b978' }}>
                        Mã thẻ Chưa được sử dụng trong bãi
                    </Typography>
                );
            }
        } else {
            return <></>;
        }
    };

    return (
        <Stack
            sx={{
                padding: '10px',
                gap: '10px',
                height: 'fit-content',
                justifyContent: 'space-between',
            }}
        >
            <Stack
                sx={{ gap: '10px', padding: '10px', flex: 1, width: '100%' }}
                alignItems="center"
                justifyContent="center"
                direction="row"
            >
                <TextField
                    size="small"
                    value={card}
                    disabled={ischeck && !loading}
                    sx={{ width: '100%' }}
                    placeholder="Quét thẻ."
                    onChange={(e) => {
                        const { value } = e.target;

                        if (!hasSpecialCharsOrWhitespace(value)) {
                            setCard(value);
                        }
                    }}
                />
                {ischeck && !loading ? (
                    <Stack
                        sx={{
                            backgroundColor: '#007DC0',
                            padding: '5px',
                            borderRadius: '5px',
                            width: '150px',
                            cursor: 'pointer',
                        }}
                        justifyContent="center"
                        alignItems="center"
                        onClick={() => {
                            setIsCheck(false);
                            setCardData(null);
                        }}
                    >
                        <Typography sx={{ fontSize: '14px', fontWeight: 600, color: '#fff' }}>
                            Làm mới
                        </Typography>
                    </Stack>
                ) : (
                    <></>
                )}
            </Stack>

            {checkMessage()}
            <Stack direction="row" justifyContent="flex-end" sx={{ gap: '10px' }}>
                {loading ? (
                    <></>
                ) : (
                    <Stack
                        sx={{
                            width: 'fit-content',
                            backgroundColor: '#55595D',
                            borderRadius: '5px',
                            padding: '5px 20px',
                            cursor: 'pointer',
                            transition: 'all ease .5s',
                            '&:hover ': { boxShadow: 'rgba(0, 0, 0, 0.24) 0px 3px 8px' },
                        }}
                        alignItems="center"
                        onClick={() => {
                            setIsCheck(false);
                            setCardData(null);
                            changeStep(2);
                        }}
                    >
                        <Typography sx={{ fontSize: '14px', fontWeight: 700, color: '#fff' }}>
                            Tạo thêm xe
                        </Typography>
                    </Stack>
                )}

                {checkButton()}
            </Stack>
            <DialogAlert
                open={openAlert}
                handleClose={() => setOpenAlert(false)}
                title={'Cảnh báo.!'}
                content={'Bạn thật sự muốn thay thế cư hiện tại của thẻ.'}
                handleConfirm={() => {
                    changeCardChoose({ cardNumber: card, cardData: cardData });
                    setCardData(null);
                }}
                type={'error'}
            />
        </Stack>
    );
};
