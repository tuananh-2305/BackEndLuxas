import { memberVehicleApi } from '@/api/member-vehicle-api';
import { vehicleTypeApi } from '@/api/vehicle-type-api';
import { StyledOutlinedInput } from '@/components/common/style-component';
import { Vehicel } from '@/components/formular/interface';
import { useAppSelector } from '@/hooks/useReudx';
import { showSnackbarWithClose } from '@/hooks/useSnackbarWithClose';
import { MemberModel } from '@/models/index';
import { MemberVehicleCreatePayload } from '@/models/member.vehicle.model';
import {
    CircularProgress,
    InputLabel,
    MenuItem,
    Select,
    SelectChangeEvent,
    Stack,
    Typography,
} from '@mui/material';
import { DatePicker } from '@mui/x-date-pickers';
import Image from 'next/image';
import { useEffect, useState } from 'react';
interface CreateMemberStepThreeProps {
    changeStep: (step: number) => void;
    changeVehicel: (v: Vehicel | null) => void;
    memberChoose: MemberModel | null;
    fecthData: () => void;
}

export const CreateMemberStepThree = (props: CreateMemberStepThreeProps) => {
    const { memberChoose, changeStep, changeVehicel, fecthData } = props;

    const parkingChoose = useAppSelector((state) => state.parking.choose);

    const [vehicleTypeId, setVehicleTypeId] = useState('');
    const [listVehicle, setListVehicle] = useState<Vehicel[]>([]);
    const [isHiddenPlateNumber, setIsHiddenPlateNumber] = useState<boolean>(false);
    const [loading, setLoading] = useState(false);
    const [dateExpire, setDateExpire] = useState<Date | null>(
        new Date(new Date().setFullYear(new Date().getFullYear() + 1))
    );
    const [color, setColor] = useState('');
    const [plateNumber, setPlateNumber] = useState('');
    const [vehicleBrand, setVehicleBrand] = useState('');
    const [description, setDescription] = useState('');
    useEffect(() => {
        vehicleTypeApi.getVehicleTypes().then((res) => {
            setListVehicle(res.data);
        });
    }, []);

    useEffect(() => {
        if (!listVehicle.find((item) => item.ID === vehicleTypeId)?.IsPlateNumber) {
            setIsHiddenPlateNumber(false);
        } else {
            setIsHiddenPlateNumber(true);
        }
    }, [listVehicle, vehicleTypeId]);

    const handleCreateVehicle = async () => {
        if (vehicleTypeId === '') {
            showSnackbarWithClose('Loại xe không được để trống', {
                variant: 'error',
            });
            return;
        }
        if (isHiddenPlateNumber && !plateNumber) {
            showSnackbarWithClose('Biển số không được để trống', {
                variant: 'error',
            });
            return;
        }

        if (!dateExpire) {
            showSnackbarWithClose('Chưa chọn ngày hết hạn', {
                variant: 'error',
            });
            return;
        }

        if (!parkingChoose) {
            return;
        }
        const payload: MemberVehicleCreatePayload = {
            VehicleBrand: vehicleBrand,
            VehicleColor: color,
            PlateNumber: plateNumber,
            MemberId: memberChoose?.ID ?? '',
            ParkingId: parkingChoose.ID,
            VehicleTypeId: vehicleTypeId,
            Description: description,
            ExpirationDate: dateExpire,
        };

        setLoading(true);
        memberVehicleApi
            .createMemberVehicle(payload)
            .then((res) => {
                changeVehicel(res.data);
                fecthData();
                changeStep(3);
            })
            .catch((error) => {
                if (Array.isArray(error?.response?.data?.message)) {
                    error?.response?.data?.message.forEach((item: any) => {
                        showSnackbarWithClose(item, {
                            variant: 'error',
                        });
                    });
                } else {
                    showSnackbarWithClose(
                        error?.response ? error.response.data?.message : error.message,
                        {
                            variant: 'error',
                        }
                    );
                }
            })
            .finally(() => {
                setLoading(false);
            });
    };

    return (
        <Stack>
            <Stack py={2} spacing={2}>
                {memberChoose ? (
                    <Stack
                        direction="row"
                        sx={{
                            padding: '5px 10px',
                            borderRadius: '5px',
                            width: '100%',
                            gap: '10px',
                            boxShadow:
                                'rgba(50, 50, 93, 0.25) 0px 2px 5px -1px, rgba(0, 0, 0, 0.3) 0px 1px 3px -1px',
                        }}
                        alignItems="center"
                    >
                        <Image
                            src="/default-user.jpg"
                            style={{
                                borderRadius: '50%',
                                boxShadow:
                                    'rgba(0, 0, 0, 0.12) 0px 1px 3px, rgba(0, 0, 0, 0.24) 0px 1px 2px',
                            }}
                            width={50}
                            height={50}
                            alt="photo"
                        />
                        <Stack>
                            <Typography sx={{ fontWeight: 500, fontSize: '14px' }}>
                                {memberChoose.Name}
                            </Typography>
                            <Typography
                                sx={{
                                    color: '#17b978',
                                    fontSize: '12px',
                                    fontWeight: 700,
                                }}
                            >
                                Đã tồn tại trong bãi xe này
                            </Typography>
                        </Stack>
                    </Stack>
                ) : (
                    <></>
                )}

                <Stack>
                    <InputLabel id="type" required>
                        Loại xe
                    </InputLabel>
                    <Select
                        labelId="type"
                        id="demo-simple-select-districts"
                        size="small"
                        sx={{
                            borderRadius: '10px',
                        }}
                        onChange={(event: SelectChangeEvent) => {
                            setVehicleTypeId(event.target.value);
                        }}
                        value={vehicleTypeId}
                    >
                        {listVehicle.map((item, index) => (
                            <MenuItem value={item.ID} key={index}>
                                {item.Name}
                            </MenuItem>
                        ))}
                    </Select>
                </Stack>

                {isHiddenPlateNumber && (
                    <Stack>
                        <InputLabel>Biển số xe*</InputLabel>
                        <StyledOutlinedInput
                            autoComplete="off"
                            value={plateNumber}
                            onChange={(e: any) => {
                                const { value } = e.target;

                                setPlateNumber(value.toUpperCase());
                            }}
                            size="small"
                            fullWidth
                        />
                    </Stack>
                )}

                <Stack>
                    <InputLabel required>Ngày hết hạn phương tiện</InputLabel>
                    <DatePicker
                        format="dd/MM/yyyy"
                        slotProps={{
                            textField: {
                                size: 'small',
                            },
                        }}
                        minDate={new Date()}
                        value={dateExpire}
                        onChange={(newValue) => {
                            setDateExpire(newValue);
                        }}
                        sx={{
                            '& .MuiInputBase-root': {
                                borderRadius: '10px',
                            },
                        }}
                    />
                </Stack>

                <Stack direction="row" sx={{ gap: '10px' }}>
                    <Stack flex={1}>
                        <InputLabel>Hiệu xe</InputLabel>
                        <StyledOutlinedInput
                            autoComplete="off"
                            size="small"
                            fullWidth
                            value={vehicleBrand}
                            onChange={(e) => {
                                setVehicleBrand(e.target.value);
                            }}
                        />
                    </Stack>
                    <Stack flex={1}>
                        <InputLabel>Màu</InputLabel>
                        <StyledOutlinedInput
                            autoComplete="off"
                            size="small"
                            fullWidth
                            value={color}
                            onChange={(e) => {
                                setColor(e.target.value);
                            }}
                        />
                    </Stack>
                </Stack>

                <Stack>
                    <InputLabel>Mô tả</InputLabel>
                    <StyledOutlinedInput
                        autoComplete="off"
                        value={description}
                        onChange={(e) => {
                            setDescription(e.target.value);
                        }}
                        size="small"
                        label="Mô tả"
                        fullWidth
                        multiline
                        rows={4}
                    />
                </Stack>
            </Stack>
            <Stack direction="row" sx={{ width: '100%', gap: '10px' }} justifyContent="flex-end">
                {loading ? (
                    <></>
                ) : (
                    <Stack
                        sx={{
                            width: 'fit-content',
                            backgroundColor: '#55595D',
                            borderRadius: '5px',
                            padding: '5px 20px',
                            cursor: 'pointer',
                            transition: 'all ease .5s',
                            '&:hover ': { boxShadow: 'rgba(0, 0, 0, 0.24) 0px 3px 8px' },
                        }}
                        alignItems="center"
                        onClick={() => {
                            changeStep(3);
                        }}
                    >
                        <Typography sx={{ fontSize: '14px', fontWeight: 700, color: '#fff' }}>
                            Bỏ qua
                        </Typography>
                    </Stack>
                )}

                <Stack
                    sx={{
                        width: '180px',
                        backgroundColor: '#007DC0',
                        borderRadius: '5px',
                        padding: '5px 20px',
                        cursor: 'pointer',
                        '&:hover ': { boxShadow: 'rgba(0, 0, 0, 0.24) 0px 3px 8px' },
                    }}
                    onClick={() => {
                        if (!loading) {
                            handleCreateVehicle();
                        }
                    }}
                    justifyContent="center"
                    alignItems="center"
                >
                    {loading ? (
                        <CircularProgress
                            size={20}
                            sx={{
                                color: '#fff',
                                ml: '10px',
                            }}
                        />
                    ) : (
                        <Typography sx={{ fontSize: '14px', fontWeight: 700, color: '#fff' }}>
                            Tạo mới phương tiện
                        </Typography>
                    )}
                </Stack>
            </Stack>
        </Stack>
    );
};
