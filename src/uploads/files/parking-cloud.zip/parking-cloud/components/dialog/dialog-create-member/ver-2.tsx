import { Stack, Step, StepContent, StepLabel, Stepper, Tooltip, Typography } from '@mui/material';
import { CreateMemberStepOne } from './step-1';
import { CreateMemberStepTwo } from './step-2';
import { CreateMemberStepThree } from './step-3';
import { createContext, useMemo, useState } from 'react';
import { CreateMemberStepFour } from './step-4';
import { CreateMemberStepFive } from './step-5';
import { MemberModel } from '@/models/member.model';
import { Vehicel } from '@/components/formular/interface';
import CheckIcon from '@mui/icons-material/Check';
import CancelIcon from '@mui/icons-material/Cancel';
interface DialogCreateMemberProps {
    close: () => void;
    fecthData: () => void;
}

export const DialogCreateMember = (props: DialogCreateMemberProps) => {
    const { close, fecthData } = props;
    const [activeStep, setActiveStep] = useState<number>(0);
    const [memberChoose, setMemberChooose] = useState<MemberModel | null>(null);
    const [phoneChoose, setPhoneChoose] = useState<{ value: string; isExist: boolean } | null>(
        null
    );
    const [cardIdChoose, setCardIdChoose] = useState<{
        cardNumber: string | null;
        cardData: any;
    }>({
        cardNumber: null,
        cardData: null,
    });
    const [vehicelChoose, setVehicelChoose] = useState<Vehicel | null>(null);

    const steps = [
        {
            label: 'Tìm kiếm',
            keyData: 'SEARCH',
            display: (
                <CreateMemberStepOne
                    changeStep={(v) => setActiveStep(v)}
                    changePhoneChoose={(p) => setPhoneChoose(p)}
                />
            ),
        },

        {
            label: 'Liên kết/Tạo mới thành viên',
            keyData: 'TASKINFOR',
            display: (
                <CreateMemberStepTwo
                    changeStep={(v) => setActiveStep(v)}
                    phoneChoose={phoneChoose}
                    fecthData={fecthData}
                    changeMember={(m: MemberModel | null) => setMemberChooose(m)}
                />
            ),
        },
        {
            label: 'Liên kết phương tiện',
            keyData: 'ADD-vehicle',
            display: (
                <CreateMemberStepThree
                    changeStep={(v) => setActiveStep(v)}
                    memberChoose={memberChoose}
                    fecthData={fecthData}
                    changeVehicel={(v: Vehicel | null) => setVehicelChoose(v)}
                />
            ),
        },
        {
            label: (
                <>
                    Kiểm tra mã thẻ{' '}
                    {/* <span style={{ fontSize: '18x', fontWeight: 300, color: '#f85959' }}>
                        (ít nhất 8 ký tự)
                    </span> */}
                </>
            ),
            keyData: 'CHECK-CARD-ID',
            display: (
                <CreateMemberStepFour
                    changeStep={(v) => setActiveStep(v)}
                    changeCardChoose={(c: { cardNumber: string | null; cardData: any }) => {
                        setCardIdChoose(c);
                        setActiveStep(4);
                    }}
                />
            ),
        },
        {
            label: cardIdChoose.cardData ? 'Cập nhật thẻ tháng' : 'Tạo mới thẻ tháng',
            keyData: 'ADD-CARD',
            display: (
                <CreateMemberStepFive
                    changeStep={(v) => {
                        setActiveStep(v);
                    }}
                    cardIdChoose={cardIdChoose}
                    memberChoose={memberChoose}
                    fecthData={() => {
                        close();
                        fecthData();
                    }}
                    vehicelChoose={vehicelChoose}
                />
            ),
        },
    ];

    const StepContent = () => {
        const currentStep = steps[activeStep];

        if (currentStep) {
            return currentStep.display;
        } else {
            return (
                <Stack>
                    <Typography>unknow Step</Typography>
                </Stack>
            );
        }
    };

    // console.log(steps[activeStep]);

    return (
        <Stack
            sx={{
                position: 'fixed',
                top: 0,
                bottom: 0,
                left: 0,
                right: 0,
                justifyContent: 'center',
                alignItems: 'center',
                zIndex: 10,
            }}
        >
            <Stack
                sx={{
                    position: 'absolute',
                    top: 0,
                    bottom: 0,
                    left: 0,
                    right: 0,
                    backgroundColor: '#55595D26',
                    zIndex: 2,
                }}
                onClick={() => close()}
            />
            <Stack
                sx={{
                    width: '600px',
                    height: 'fit-content',
                    backgroundColor: '#fff',
                    zIndex: 2,
                    boxShadow: 'rgba(0, 0, 0, 0.1) 0px 4px 12px',
                    borderRadius: '5px',
                    padding: '20px',
                }}
            >
                <Stack sx={{ marginBottom: '40px' }} direction="row" alignItems="center">
                    <Typography sx={{ fontWeight: 600, fontSize: '20px', flex: 1 }}>
                        {steps[activeStep].label}
                    </Typography>
                    <CancelIcon
                        sx={{ color: '#ff304f', cursor: 'pointer' }}
                        onClick={() => close()}
                    />
                </Stack>

                <Stack direction="row" sx={{ width: '100%' }} justifyContent="center">
                    {steps.map((stepx, key) => (
                        <Stack key={stepx.keyData} direction="row" alignItems="center">
                            <Tooltip title={stepx.label}>
                                <Stack
                                    sx={{
                                        backgroundColor: key <= activeStep ? '#007DC0' : '#55595D',
                                        width: '25px',
                                        height: '25px',
                                        borderRadius: '50%',
                                        border: '2px solid white',
                                        transition: 'all ease .3s',
                                        boxShadow:
                                            'rgba(50, 50, 93, 0.25) 0px 2px 5px -1px, rgba(0, 0, 0, 0.3) 0px 1px 3px -1px;',
                                    }}
                                    justifyContent="center"
                                    alignItems="center"
                                >
                                    {key < activeStep ? (
                                        <CheckIcon sx={{ color: '#fff', fontSize: '14px' }} />
                                    ) : (
                                        <Typography
                                            sx={{
                                                color: '#fff',
                                                fontWeight: 600,
                                                fontSize: '12px',
                                            }}
                                        >
                                            {key + 1}
                                        </Typography>
                                    )}
                                </Stack>
                            </Tooltip>

                            {steps.length !== key + 1 ? (
                                <Stack
                                    sx={{
                                        transition: 'all ease .3s',
                                        height: '1px',
                                        backgroundColor: key < activeStep ? '#007DC0' : '#55595D',
                                        width: '50px',
                                        margin: '0px 5px',
                                    }}
                                />
                            ) : (
                                <></>
                            )}

                            {/* <Typography sx={{ fontWeight: 400, fontSize: '14px' }}>
                                {stepx.label}
                            </Typography> */}
                        </Stack>
                    ))}
                </Stack>

                <StepContent />
            </Stack>
        </Stack>
    );
};
