import { StyledOutlinedInput } from '@/components/common/style-component';
import { Vehicel } from '@/components/formular/interface';
import { MemberModel } from '@/models/index';
import {
    CardMedia,
    IconButton,
    InputLabel,
    MenuItem,
    Select,
    Stack,
    Tooltip,
    Typography,
    Checkbox,
    Button,
    CircularProgress,
} from '@mui/material';
import Image from 'next/image';
import { useEffect, useMemo, useState } from 'react';
import ImageIcon from '@mui/icons-material/Image';
import { showSnackbarWithClose } from '@/hooks/useSnackbarWithClose';
import { useAppSelector } from '@/hooks/useReudx';
import { cardApi } from '@/api/card-api';
import { memberVehicleApi } from '@/api/member-vehicle-api';
import { AutoCompleteVehicel } from '@/components/common/input/autocomplete-vehicel';
import { MemberVehicleModel } from '@/models/member.vehicle.model';

interface CreateMemberStepFourProps {
    changeStep: (step: number) => void;
    memberChoose: MemberModel | null;
    vehicelChoose: Vehicel | null;
    cardIdChoose: { cardNumber: string | null; cardData: any };
    fecthData: () => void;
}

export const CreateMemberStepFive = (props: CreateMemberStepFourProps) => {
    const { changeStep, memberChoose, vehicelChoose, cardIdChoose, fecthData } = props;

    const parkingChoose = useAppSelector((state) => state.parking.choose);
    const [idCard, setIdCard] = useState(
        cardIdChoose?.cardData?.IdCard ? cardIdChoose?.cardData?.IdCard : ''
    );
    const [typeAuthen, setTypeAuthen] = useState<'CARD' | 'FACE'>('CARD');
    const [isCardElevator, setIsCardElevator] = useState(
        cardIdChoose.cardData ? cardIdChoose.cardData.IsCardElevator : false
    );
    const [isCardParking, setIsCardParking] = useState(
        cardIdChoose.cardData ? cardIdChoose.cardData.IsCardParking : false
    );
    // const [cardNumber, setCardNumber] = useState('');
    const [faceImage, setFaceImage] = useState<File | null>(null);
    const [description, setDescription] = useState('');
    const [vehicel, setVehicle] = useState<MemberVehicleModel | null>(null);
    const [loading, setLoading] = useState(false);
    // const renderImage = useMemo(
    //     () => (
    //         <CardMedia
    //             sx={{ minHeight: 300, objectFit: 'cover' }}
    //             image={
    //                 faceImage
    //                     ? URL.createObjectURL(faceImage)
    //                     : '/images/default_background_company.png'
    //             }
    //             title="green iguana"
    //         />
    //     ),
    //     [faceImage]
    // );

    const handleCreateCard = () => {
        if (!memberChoose) {
            return;
        }

        if (typeAuthen === 'CARD') {
            if (Boolean(cardIdChoose?.cardNumber?.trim())) {
                if (cardIdChoose?.cardNumber && cardIdChoose?.cardNumber.trim().length < 8) {
                    showSnackbarWithClose('Mã thẻ phải ít nhất 8 ký tự', {
                        variant: 'error',
                    });
                    return;
                }
            } else {
                showSnackbarWithClose('Mã thẻ không được để trống', {
                    variant: 'error',
                });
                return;
            }
        }

        if (!parkingChoose) {
            return;
        }

        if (!isCardElevator && !isCardParking) {
            showSnackbarWithClose('Bạn chưa chọn mục tiêu sử dụng', {
                variant: 'error',
            });
            return;
        }

        if (isCardParking && !vehicel) {
            showSnackbarWithClose('Bạn chưa chọn phương tiện', {
                variant: 'error',
            });
            return;
        }

        if (!isCardElevator && !isCardParking) {
            showSnackbarWithClose('Bạn phải chọn ít nhất một mục tiêu sử dụng.', {
                variant: 'error',
            });
            return;
        }

        const formData = new FormData();

        if (idCard) {
            formData.append('IdCard', idCard);
        }

        formData.append('MemberId', memberChoose.ID);
        formData.append('ParkingId', parkingChoose.ID);
        formData.append('Description', description);
        formData.append('TypeAuthen', typeAuthen);

        if (typeAuthen === 'CARD') {
            if (cardIdChoose.cardNumber) {
                formData.append('CardNumber', cardIdChoose.cardNumber);
            } else {
                showSnackbarWithClose('Bạn chưa nhập mã thẻ!.', { variant: 'error' });
                return;
            }
        }

        // if (typeAuthen === 'FACE' && faceImage) {
        //     if (faceImage) {
        //         formData.append('files', faceImage, faceImage.name);
        //     } else {
        //         showSnackbarWithClose('Bạn cần chọn một tấm ảnh!.', { variant: 'error' });
        //         return;
        //     }
        // }

        formData.append('IsCardElevator', isCardElevator.toString());
        formData.append('IsCardParking', isCardParking.toString());

        if (isCardParking && vehicel) {
            formData.append('MemberVehicleId', vehicel.ID);
        }

        if (formData) {
            if (cardIdChoose.cardData) {
                formData.append('ID', cardIdChoose.cardData.ID);
                setLoading(true);
                cardApi
                    .updateCard(formData)
                    .then((res) => {
                        fecthData();
                    })
                    .catch((error) => {
                        if (Array.isArray(error?.response?.data?.message)) {
                            error?.response?.data?.message.forEach((item: any) => {
                                showSnackbarWithClose(item, {
                                    variant: 'error',
                                });
                            });
                        } else {
                            showSnackbarWithClose(
                                error?.response ? error.response.data?.message : error.message,
                                {
                                    variant: 'error',
                                }
                            );
                        }
                    })
                    .finally(() => {
                        setLoading(false);
                    });
            } else {
                cardApi
                    .createCard(formData)
                    .then((res) => {
                        fecthData();
                    })
                    .catch((error) => {
                        if (Array.isArray(error?.response?.data?.message)) {
                            error?.response?.data?.message.forEach((item: any) => {
                                showSnackbarWithClose(item, {
                                    variant: 'error',
                                });
                            });
                        } else {
                            showSnackbarWithClose(
                                error?.response ? error.response.data?.message : error.message,
                                {
                                    variant: 'error',
                                }
                            );
                        }
                    })
                    .finally(() => {
                        setLoading(false);
                    });
            }
        }
    };

    useEffect(() => {
        if (memberChoose && parkingChoose) {
            memberVehicleApi.getMemberVehicleByIdMemberAndParking(parkingChoose.ID, {
                ID: memberChoose.ID,
                Current: 0,
                Limit: 1000,
                TextSearch: '',
            });
        }
    }, [memberChoose, parkingChoose]);

    return (
        <Stack
            sx={{
                padding: '10px 0px',
                maxHeight: '70vh',
                overflow: 'auto',
            }}
        >
            <Stack sx={{ padding: '10px', gap: '10px', height: '100%' }}>
                {memberChoose ? (
                    <Stack
                        direction="row"
                        sx={{
                            padding: '5px 10px',
                            borderRadius: '5px',
                            width: '100%',
                            gap: '10px',
                            boxShadow:
                                'rgba(50, 50, 93, 0.25) 0px 2px 5px -1px, rgba(0, 0, 0, 0.3) 0px 1px 3px -1px',
                        }}
                        alignItems="center"
                    >
                        <Image
                            src="/default-user.jpg"
                            style={{
                                borderRadius: '50%',
                                boxShadow:
                                    'rgba(0, 0, 0, 0.12) 0px 1px 3px, rgba(0, 0, 0, 0.24) 0px 1px 2px',
                            }}
                            width={50}
                            height={50}
                            alt="photo"
                        />
                        <Stack>
                            <Typography sx={{ fontWeight: 500, fontSize: '14px' }}>
                                {memberChoose.Name}
                            </Typography>
                            <Typography
                                sx={{
                                    color: '#17b978',
                                    fontSize: '12px',
                                    fontWeight: 700,
                                }}
                            >
                                Đã tồn tại trong bãi xe này
                            </Typography>
                        </Stack>
                    </Stack>
                ) : (
                    <></>
                )}
                {parkingChoose && isCardParking ? (
                    <AutoCompleteVehicel
                        setValue={function (value: MemberVehicleModel | null): void {
                            setVehicle(value);
                        }}
                        parkingId={parkingChoose.ID}
                        value={vehicel}
                        memberId={memberChoose?.ID}
                    />
                ) : (
                    <></>
                )}

                <Stack>
                    <InputLabel>Loại xác thực</InputLabel>
                    <Select
                        labelId="demo-simple-select-label"
                        fullWidth
                        size="small"
                        sx={{
                            borderRadius: '10px',
                        }}
                        value={typeAuthen}
                        onChange={(e: any) => {
                            setTypeAuthen(e.target.value);
                        }}
                    >
                        <MenuItem value={'CARD'}>Thẻ từ</MenuItem>
                        {/* <MenuItem value={'FACE'}>Gương mặt</MenuItem> */}
                    </Select>
                </Stack>
                {typeAuthen === 'CARD' && (
                    <Tooltip
                        title={
                            'Dãy số từ 8 số, chỉ có thể kiểm tra thông qua việc quét bằng máy đọc'
                        }
                    >
                        <Stack>
                            <InputLabel>Mã thẻ*</InputLabel>
                            <StyledOutlinedInput
                                autoComplete="off"
                                defaultValue={cardIdChoose.cardNumber}
                                disabled
                                // value={cardNumber}
                                // onChange={(e) => {
                                //     setCardNumber(e.target.value);
                                // }}
                                size="small"
                                fullWidth
                            />
                        </Stack>
                    </Tooltip>
                )}
                {typeAuthen === 'CARD' ? (
                    <Stack>
                        <InputLabel>Số thẻ ngoài</InputLabel>
                        <StyledOutlinedInput
                            autoComplete="off"
                            value={idCard}
                            onChange={(e) => {
                                setIdCard(e.target.value);
                            }}
                            size="small"
                            fullWidth
                        />
                    </Stack>
                ) : (
                    <></>
                )}
                {typeAuthen === 'FACE' && (
                    <Stack>
                        <Typography sx={{ fontSize: '12px', fontStyle: 'italic' }}>
                            * Hình ảnh: Chụp 1 người, rõ mặt
                        </Typography>

                        <Stack
                            sx={{
                                position: 'relative',
                                width: '80%',
                                aspectRatio: '16/9',
                                left: '10%',
                            }}
                        >
                            {/* {renderImage} */}

                            <Image
                                src={
                                    faceImage
                                        ? URL.createObjectURL(faceImage)
                                        : '/images/default_background_company.png'
                                }
                                style={{ objectFit: 'cover' }}
                                fill
                                alt="face-image"
                            />

                            <Tooltip title="Thêm ảnh">
                                <IconButton
                                    sx={{
                                        position: 'absolute',
                                        zIndex: 3,
                                        bottom: '15px',
                                        right: '15px',
                                        backgroundColor: 'rgba(217, 217, 217, 0.6)',
                                        color: '#fff',
                                        boxShadow: '0 0 5px rgba(0, 0, 0, 0.2)',
                                    }}
                                    component="label"
                                >
                                    <input
                                        hidden
                                        accept="image/*"
                                        type="file"
                                        onChange={(e: any) => {
                                            if (!e.target.files[0]) return;
                                            setFaceImage(e.target.files[0]);
                                        }}
                                        autoComplete="off"
                                    />
                                    <ImageIcon />
                                </IconButton>
                            </Tooltip>
                        </Stack>
                    </Stack>
                )}
                <Typography>Mục tiêu sử dụng :</Typography>
                <Stack direction="row" alignItems="center">
                    <Checkbox
                        size="small"
                        checked={isCardElevator}
                        onChange={(e) => {
                            setIsCardElevator(e.target.checked);
                        }}
                    />
                    <Typography sx={{ fontSize: '14px', fontWeight: 600 }}>
                        Dùng cho phân tầng thang máy.
                    </Typography>
                </Stack>
                <Stack direction="row" alignItems="center">
                    <Checkbox
                        size="small"
                        disabled={!vehicelChoose}
                        checked={isCardParking}
                        onChange={(e) => {
                            setIsCardParking(e.target.checked);
                        }}
                    />

                    <Typography
                        sx={{
                            fontSize: '14px',
                            fontWeight: 600,
                            color: vehicelChoose ? '#000' : '#55595D',
                        }}
                    >
                        Dùng cho bãi xe.
                    </Typography>
                </Stack>
                <Stack>
                    <InputLabel>Mô tả</InputLabel>
                    <StyledOutlinedInput
                        autoComplete="off"
                        value={description}
                        onChange={(e) => {
                            setDescription(e.target.value);
                        }}
                        size="small"
                        fullWidth
                        multiline
                        rows={4}
                    />
                </Stack>
                <Stack sx={{ flex: 1 }} />
                <Stack direction="row" sx={{ gap: '10px' }} justifyContent="flex-end">
                    {!loading ? (
                        <Stack
                            sx={{
                                width: 'fit-content',
                                backgroundColor: '#55595D',
                                borderRadius: '5px',
                                padding: '5px 20px',
                                cursor: 'pointer',
                                transition: 'all ease .5s',
                                '&:hover ': { boxShadow: 'rgba(0, 0, 0, 0.24) 0px 3px 8px' },
                            }}
                            alignItems="center"
                            onClick={() => {
                                changeStep(3);
                            }}
                        >
                            <Typography sx={{ fontSize: '14px', fontWeight: 700, color: '#fff' }}>
                                Quay về
                            </Typography>
                        </Stack>
                    ) : (
                        <></>
                    )}

                    <Stack
                        sx={{
                            width: '100px',
                            backgroundColor: '#007DC0',
                            borderRadius: '5px',
                            padding: '5px 20px',
                            cursor: 'pointer',
                            '&:hover ': { boxShadow: 'rgba(0, 0, 0, 0.24) 0px 3px 8px' },
                        }}
                        onClick={() => handleCreateCard()}
                        justifyContent="center"
                        alignItems="center"
                    >
                        {loading ? (
                            <CircularProgress
                                size={20}
                                sx={{
                                    color: '#fff',
                                    ml: '10px',
                                }}
                            />
                        ) : (
                            <Typography sx={{ fontSize: '14px', fontWeight: 700, color: '#fff' }}>
                                {cardIdChoose.cardData ? 'Cập nhật' : 'Tạo mới'}
                            </Typography>
                        )}
                    </Stack>
                </Stack>
            </Stack>
        </Stack>
    );
};
