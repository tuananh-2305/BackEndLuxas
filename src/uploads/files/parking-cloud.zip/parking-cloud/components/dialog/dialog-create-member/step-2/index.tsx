import { useAppSelector } from '@/hooks/useReudx';
import { Stack } from '@mui/material';
import { CreateView } from './create-member';
import { LinkingView } from './link-member';
import { useEffect } from 'react';
import { MemberModel } from '@/models/index';

interface CreateMemberStepTwoProps {
    changeStep: (step: number) => void;
    phoneChoose: { value: string; isExist: boolean } | null;
    changeMember: (m: MemberModel | null) => void;
    fecthData: () => void;
}

export const CreateMemberStepTwo = (props: CreateMemberStepTwoProps) => {
    const { changeStep, phoneChoose, changeMember, fecthData } = props;

    useEffect(() => {
        if (!phoneChoose) {
            changeStep(0);
        }
    }, [changeStep, phoneChoose]);

    return phoneChoose?.isExist ? (
        <LinkingView
            changeStep={changeStep}
            phoneChoose={phoneChoose}
            fecthData={fecthData}
            changeMember={changeMember}
        />
    ) : (
        <CreateView
            changeStep={changeStep}
            phoneChoose={phoneChoose}
            changeMember={changeMember}
            fecthData={fecthData}
        />
    );
};
