import { memberApi } from '@/api/index';
import AutoCompoleteMemberType from '@/components/common/input/autocomplete-member-type';
import { StyledOutlinedInput, StyledSelectInput } from '@/components/common/style-component';
import { useAppSelector } from '@/hooks/index';
import { showSnackbarWithClose } from '@/hooks/useSnackbarWithClose';
import { MemberCreatePayload, MemberModel, MemberTypeModel } from '@/models/index';
import { isValidEmail } from '@/ultis/global-func';
import { CircularProgress, InputLabel, MenuItem, Stack, Typography } from '@mui/material';
import { DatePicker } from '@mui/x-date-pickers';
import { useState } from 'react';

interface CreateViewProps {
    changeStep: (step: number) => void;
    phoneChoose: { value: string; isExist: boolean } | null;
    changeMember: (m: MemberModel | null) => void;
    fecthData: () => void;
}
export const CreateView = (props: CreateViewProps) => {
    const { changeStep, phoneChoose, changeMember, fecthData } = props;
    const parkingChoose = useAppSelector((state) => state.parking.choose);

    const [address, setAddress] = useState('');
    const [dobTime, setDobTime] = useState<Date | null>(null);
    const [gender, setGender] = useState<string>('');
    const [name, setName] = useState<string>('');
    const [description, setDescription] = useState('');
    const [password, setPassword] = useState('');
    const [email, setEmail] = useState('');
    const [memberType, setMemberType] = useState<MemberTypeModel | null>(null);
    const [citizenIdentification, setCitizenIdentification] = useState('');
    const [loading, setLoading] = useState(false);
    const [step, setStep] = useState(1);

    if (!parkingChoose || !phoneChoose || !phoneChoose.value || phoneChoose.isExist) {
        changeStep(0);
        return <></>;
    }

    const handleCreateMember = async () => {
        if (!memberType) {
            showSnackbarWithClose(`Vui lòng chọn loại khách hàng/cư dân.`, { variant: 'error' });
            return;
        }
        if (!name || !name.trim()) {
            showSnackbarWithClose(`Tên khách hàng/cư dân không được để trống`, {
                variant: 'error',
            });
            return;
        }
        if (!address || !address.trim()) {
            showSnackbarWithClose(`Địa chỉ không được để trống`, {
                variant: 'error',
            });
            return;
        }
        if (email && !isValidEmail(email)) {
            showSnackbarWithClose(`Email không chuẩn định dạng.`, {
                variant: 'error',
            });
            return;
        }
        let payload: MemberCreatePayload = {
            Name: name.trim(),
            ParkingId: parkingChoose.ID,
            MemberTypeId: memberType.ID,
            Address: address.trim(),
            Gender: gender,
            Description: description,
            Password: password,
            DOB: dobTime,
            Phone: phoneChoose.value,
        };

        if (email) {
            payload.Email = email;
        }

        if (citizenIdentification) {
            payload.CitizenIdentification = citizenIdentification;
        }

        setLoading(true);
        // memberApi
        //     .createMember(payload)
        //     .then((res) => {
        //         changeStep(2);
        //         fecthData();
        //         changeMember(res.data);
        //     })
        //     .catch((error) => {
        //         if (Array.isArray(error?.response?.data?.message)) {
        //             error?.response?.data?.message.forEach((item: any) => {
        //                 showSnackbarWithClose(item, {
        //                     variant: 'error',
        //                 });
        //             });
        //         } else {
        //             showSnackbarWithClose(
        //                 error?.response ? error.response.data?.message : error.message,
        //                 {
        //                     variant: 'error',
        //                 }
        //             );
        //         }
        //     })
        //     .finally(() => {
        //         setLoading(false);
        //     });
    };

    return (
        <Stack sx={{ height: '450px', padding: '20px' }}>
            <Stack justifyContent="center" sx={{ height: '100%', gap: '10px' }}>
                {step === 1 ? (
                    <>
                        <AutoCompoleteMemberType
                            setValue={setMemberType}
                            parkingId={parkingChoose.ID}
                            value={memberType}
                        />
                        <Stack>
                            <InputLabel>CCCD/CMND</InputLabel>
                            <StyledOutlinedInput
                                autoComplete="off"
                                value={citizenIdentification}
                                onChange={(e) => {
                                    setCitizenIdentification(e.target.value);
                                }}
                                size="small"
                                fullWidth
                                type={'text'}
                            />
                        </Stack>
                        <Stack>
                            <InputLabel required>Họ tên</InputLabel>
                            <StyledOutlinedInput
                                autoComplete="off"
                                value={name}
                                onChange={(e) => {
                                    setName(e.target.value);
                                }}
                                size="small"
                                fullWidth
                                type={'text'}
                            />
                        </Stack>

                        <Stack>
                            <InputLabel>Mật khẩu</InputLabel>
                            <StyledOutlinedInput
                                autoComplete="off"
                                value={password}
                                onChange={(e) => {
                                    setPassword(e.target.value);
                                }}
                                size="small"
                                fullWidth
                                type={'text'}
                            />
                        </Stack>
                    </>
                ) : (
                    <></>
                )}

                {step === 2 ? (
                    <>
                        <Stack>
                            <InputLabel>Email</InputLabel>
                            <StyledOutlinedInput
                                autoComplete="off"
                                value={email}
                                onChange={(e) => {
                                    setEmail(e.target.value);
                                }}
                                size="small"
                                fullWidth
                                type={'text'}
                            />
                        </Stack>
                        <Stack direction="row" sx={{ gap: '10px' }}>
                            <Stack sx={{ flex: 1 }}>
                                <InputLabel>Ngày sinh</InputLabel>
                                <DatePicker
                                    format="dd/MM/yyyy"
                                    slotProps={{
                                        textField: {
                                            size: 'small',
                                            fullWidth: true,
                                            disabled: true,
                                        },
                                    }}
                                    value={dobTime}
                                    maxDate={new Date(new Date().getTime() - 24 * 60 * 60 * 1000)}
                                    onChange={(newValue: any) => {
                                        if (newValue) {
                                            setDobTime(newValue);
                                        }
                                    }}
                                    sx={{
                                        '& .MuiInputBase-root': {
                                            borderRadius: '10px',
                                        },
                                    }}
                                />
                            </Stack>

                            <Stack sx={{ flex: 1 }}>
                                <InputLabel id="provinces">Giới tính</InputLabel>
                                <StyledSelectInput
                                    labelId="demo-simple-select-label"
                                    value={gender}
                                    onChange={(e: any) => {
                                        setGender(e.target.value);
                                    }}
                                    variant="outlined"
                                    fullWidth
                                    size="small"
                                >
                                    <MenuItem value={'MALE'}>Nam</MenuItem>
                                    <MenuItem value={'FEMALE'}>Nữ</MenuItem>
                                    <MenuItem value={'ANOTHER'}>Khác</MenuItem>
                                </StyledSelectInput>
                            </Stack>
                        </Stack>
                        <Stack>
                            <InputLabel>Địa chỉ *</InputLabel>
                            <StyledOutlinedInput
                                autoComplete="off"
                                value={address}
                                onChange={(e) => {
                                    setAddress(e.target.value);
                                }}
                                size="small"
                                fullWidth
                                type={'text'}
                            />
                        </Stack>
                        <Stack>
                            <InputLabel>Mô tả</InputLabel>
                            <StyledOutlinedInput
                                autoComplete="off"
                                value={description}
                                onChange={(e) => {
                                    setDescription(e.target.value);
                                }}
                                size="small"
                                fullWidth
                                multiline
                                rows={4}
                            />
                        </Stack>
                    </>
                ) : (
                    <></>
                )}
            </Stack>

            <Stack
                direction="row"
                sx={{ gap: '20px', width: '100%', marginTop: '20px' }}
                justifyContent="flex-end"
            >
                {loading ? (
                    <></>
                ) : (
                    <Stack
                        sx={{
                            width: 'fit-content',
                            backgroundColor: '#55595D',
                            borderRadius: '5px',
                            padding: '5px 20px',
                            cursor: 'pointer',
                            transition: 'all ease .5s',
                            '&:hover ': { boxShadow: 'rgba(0, 0, 0, 0.24) 0px 3px 8px' },
                        }}
                        alignItems="center"
                        onClick={() => {
                            if (step === 1) {
                                changeStep(0);
                            } else {
                                setStep(1);
                            }
                        }}
                    >
                        <Typography sx={{ fontSize: '14px', fontWeight: 700, color: '#fff' }}>
                            Quay về
                        </Typography>
                    </Stack>
                )}

                {step === 1 ? (
                    <Stack
                        sx={{
                            wwidth: 'fit-content',
                            backgroundColor: '#007DC0',
                            borderRadius: '5px',
                            padding: '5px 20px',
                            cursor: 'pointer',
                            '&:hover ': { boxShadow: 'rgba(0, 0, 0, 0.24) 0px 3px 8px' },
                        }}
                        onClick={() => {
                            if (!memberType) {
                                showSnackbarWithClose(`Vui lòng chọn loại khách hàng/cư dân.`, {
                                    variant: 'error',
                                });
                                return;
                            }
                            if (!name || !name.trim()) {
                                showSnackbarWithClose(`Tên khách hàng/cư dân không được để trống`, {
                                    variant: 'error',
                                });
                                return;
                            }

                            setStep(2);
                        }}
                        justifyContent="center"
                        alignItems="center"
                    >
                        <Typography sx={{ fontSize: '14px', fontWeight: 700, color: '#fff' }}>
                            Tiếp tục
                        </Typography>
                    </Stack>
                ) : (
                    <></>
                )}

                {step === 2 ? (
                    <Stack
                        sx={{
                            backgroundColor: '#007DC0',
                            width: '180px',
                            borderRadius: '5px',
                            padding: '5px 20px',
                            cursor: 'pointer',
                            '&:hover ': { boxShadow: 'rgba(0, 0, 0, 0.24) 0px 3px 8px' },
                        }}
                        onClick={() => {
                            if (!loading) {
                                handleCreateMember();
                            }
                        }}
                        justifyContent="center"
                        alignItems="center"
                    >
                        {loading ? (
                            <CircularProgress
                                size={20}
                                sx={{
                                    color: '#fff',
                                    ml: '10px',
                                }}
                            />
                        ) : (
                            <Typography sx={{ fontSize: '14px', fontWeight: 700, color: '#fff' }}>
                                Tạo mới thành viên
                            </Typography>
                        )}
                    </Stack>
                ) : (
                    <></>
                )}
            </Stack>
        </Stack>
    );
};
