import { showSnackbarWithClose } from '@/hooks/useSnackbarWithClose';
import { validatePhoneNumber } from '@/ultis/index';
import { Button, CircularProgress, Stack, TextField, Typography } from '@mui/material';
import { useContext, useEffect, useState } from 'react';
import { memberApi } from '@/api/index';
import { useDebouncedValue } from '@mantine/hooks';
import Image from 'next/image';
import { MemberModel } from '@/models/index';
import { useAppSelector } from '@/hooks/useReudx';

interface CreateMemberStepOneProps {
    changeStep: (step: number) => void;
    // phoneChoose: string;
    changePhoneChoose: (p: { value: string; isExist: boolean }) => void;
    // changeMemberChooose: (m: MemberModel | null) => void;
}
export const CreateMemberStepOne = (props: CreateMemberStepOneProps) => {
    const { changeStep, changePhoneChoose } = props;
    const parkingChoose = useAppSelector((state) => state.parking.choose);
    const [phone, setPhone] = useState('');
    const [phoneDebounced] = useDebouncedValue(phone, 500);
    const [error, setError] = useState('');
    const [member, setMember] = useState<MemberModel | null>(null);
    const [loading, setLoading] = useState(false);

    useEffect(() => {
        if (phoneDebounced && parkingChoose) {
            if (validatePhoneNumber(phoneDebounced)) {
                setLoading(true);
                memberApi
                    .searchMemberByPhone(phoneDebounced, parkingChoose?.ID)
                    .then((res) => {
                        const { data } = res;
                        if (data) {
                            setMember(data);
                            setError('');
                        } else {
                            setError('');
                            setMember(null);
                        }
                    })
                    .catch((err) => {
                        if (err?.response) {
                            if (Array.isArray(err?.response?.data?.message)) {
                                setError(err?.response?.data?.message[0]);
                            } else {
                                setError(err?.response ? err.response.data?.message : err.message);
                            }
                            setMember(null);
                        }
                    })
                    .finally(() => {
                        setLoading(false);
                    });

                return;
            } else {
                setError('Số điện thoại không hợp lệ');
                setMember(null);
            }
        } else {
            setError('');
            setMember(null);
        }
    }, [parkingChoose, phoneDebounced]);

    return (
        <Stack sx={{ height: '300px', padding: '10px' }} alignItems="center">
            <Stack
                sx={{ width: '80%', gap: '5px' }}
                flex={1}
                justifyContent="center"
                alignItems="flex-start"
            >
                <Typography sx={{ fontWeight: 600, fontSize: '14px' }}>
                    Kiểm tra số điện thoại
                </Typography>
                <TextField
                    size="small"
                    fullWidth
                    required
                    value={phone}
                    placeholder="Nhập số điện thoại"
                    onChange={(e) => {
                        const { value } = e.target;
                        setPhone(value.trim());
                    }}
                />

                {!loading ? (
                    <>
                        {error ? (
                            <Typography
                                sx={{
                                    fontWeight: 500,
                                    fontSize: '12px',
                                    color: '#e41749',
                                    fontStyle: 'italic',
                                }}
                            >
                                {error}
                            </Typography>
                        ) : (
                            <></>
                        )}
                        {validatePhoneNumber(phoneDebounced) && !member && !error ? (
                            <Typography
                                sx={{
                                    fontWeight: 500,
                                    fontSize: '12px',
                                    color: '#2cb978',
                                    fontStyle: 'italic',
                                }}
                            >
                                Số điện thoại chưa được sử dụng
                            </Typography>
                        ) : (
                            <></>
                        )}
                        {member ? (
                            <Stack
                                direction="row"
                                sx={{
                                    padding: '5px 10px',
                                    borderRadius: '5px',
                                    width: '100%',
                                    gap: '10px',
                                    boxShadow:
                                        'rgba(50, 50, 93, 0.25) 0px 2px 5px -1px, rgba(0, 0, 0, 0.3) 0px 1px 3px -1px',
                                }}
                                alignItems="center"
                            >
                                <Image
                                    src="/default-user.jpg"
                                    style={{
                                        borderRadius: '50%',
                                        boxShadow:
                                            'rgba(0, 0, 0, 0.12) 0px 1px 3px, rgba(0, 0, 0, 0.24) 0px 1px 2px',
                                    }}
                                    width={50}
                                    height={50}
                                    alt="photo"
                                />
                                <Stack>
                                    <Typography sx={{ fontWeight: 500, fontSize: '14px' }}>
                                        {member.Name}
                                    </Typography>
                                    <Typography
                                        sx={{
                                            color: member.IsExist ? '#ff304f' : '#ffd615',
                                            fontSize: '12px',
                                            fontWeight: 700,
                                        }}
                                    >
                                        {member.IsExist
                                            ? 'Đã tồn tại trong bãi xe này'
                                            : 'Đã có thông tin, nhấn liên kết thành viên để tiếp tục'}
                                    </Typography>
                                </Stack>
                            </Stack>
                        ) : (
                            <></>
                        )}
                    </>
                ) : (
                    <Typography>Đang kiểm tra...</Typography>
                )}
            </Stack>

            <Stack sx={{ width: '100%' }} direction="row-reverse">
                {error ? (
                    <Button
                        size="small"
                        variant="contained"
                        color="warning"
                        disabled
                        sx={{ width: '180px' }}
                        fullWidth
                    >
                        {'Không hợp lệ'}
                    </Button>
                ) : (
                    <></>
                )}

                {loading && !error ? (
                    <Button
                        size="small"
                        variant="contained"
                        color="secondary"
                        sx={{ width: '180px' }}
                    >
                        <CircularProgress
                            size={24}
                            sx={{
                                color: '#fff',
                                ml: '10px',
                            }}
                        />
                    </Button>
                ) : (
                    <></>
                )}

                {!loading && !error ? (
                    <Button
                        size="small"
                        variant="contained"
                        color="info"
                        sx={{ width: '180px' }}
                        disabled={Boolean(
                            !validatePhoneNumber(phone) || (member && member.IsExist)
                        )}
                        fullWidth
                        onClick={() => {
                            changeStep(1);
                            changePhoneChoose({
                                value: phoneDebounced,
                                isExist: Boolean(member),
                            });
                        }}
                    >
                        {member ? 'Liên kết thành viên' : 'Tạo mới thành viên'}
                    </Button>
                ) : (
                    <></>
                )}
            </Stack>
        </Stack>
    );
};
