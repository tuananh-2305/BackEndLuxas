import { memberApi } from '@/api/member-api';
import AutoCompoleteMemberType from '@/components/common/input/autocomplete-member-type';
import InputUploadImage from '@/components/common/input/input-upload-image';
import {
    StyleButton,
    StyledOutlinedInput,
    StyledSelectInput,
} from '@/components/common/style-component';
import { showSnackbarWithClose } from '@/hooks/useSnackbarWithClose';
import { MemberUpdatePayload, MemberTypeModel, MemberModel } from '@/models/index';
import { handleCompressImage, isValidEmail, theme } from '@/ultis/index';
import {
    Dialog,
    DialogActions,
    DialogContent,
    DialogTitle,
    InputLabel,
    MenuItem,
    Stack,
    TextField,
    useMediaQuery,
} from '@mui/material';
import Grid2 from '@mui/material/Unstable_Grid2';
import { DatePicker } from '@mui/x-date-pickers';
import { enqueueSnackbar } from 'notistack';
import { useEffect, useRef, useState } from 'react';
import { ComfirmCloseDialog } from '../dialog-comfirm-close';

export interface IDialogUpdateMemberProps {
    open: boolean;
    handleClose: () => void;
    // idParking: string;
    handleReload?: () => void;
    item: MemberModel;
}
const BACKEND_DOMAIN = process.env.NEXT_PUBLIC_SERVER_PARKING_DOMAIN;

export default function DialogUpdateMember(props: IDialogUpdateMemberProps) {
    const { open, handleClose, item, handleReload } = props;

    const nameDialog = 'khách hàng/cư dân';

    const fullScreen = useMediaQuery(theme.breakpoints.down('md'));
    const [phone, setPhone] = useState('');
    const [password, setPassword] = useState('');
    const [rePassword, setRePassword] = useState('');
    const [name, setName] = useState('');
    const [email, setEmail] = useState('');
    const [address, setAddress] = useState('');
    const [description, setDescription] = useState('');
    const [memberType, setMemberType] = useState<MemberTypeModel | null>(null);
    const [dobTime, setDobTime] = useState<Date | null>(null);
    const [citizenIdentification, setCitizenIdentification] = useState('');
    const [gender, setGender] = useState<string>('');
    const [avatar, setAvatar] = useState<File | null>(null);
    const fileInputRef = useRef<HTMLInputElement>(null);
    const [openComfirm, setOpenComfirm] = useState(false);
    // console.log(item);
    const handleUpdateMember = async () => {
        if (!name || name.trim() === '') {
            showSnackbarWithClose(`Tên ${nameDialog} không được để trống`, { variant: 'error' });
        }
        if (!phone) {
            showSnackbarWithClose('Vui lòng nhập số điện thoại', { variant: 'error' });
        }

        if (!memberType) {
            showSnackbarWithClose(`Vui lòng chọn loại ${nameDialog}`, { variant: 'error' });
        }
        if (!address || !address.trim()) {
            showSnackbarWithClose('Vui lòng nhập địa chỉ', { variant: 'error' });
            return;
        }
        if ((password || rePassword) && password !== rePassword) {
            showSnackbarWithClose('Mật khẩu không khớp', { variant: 'error' });
            return;
        }

        if (email && !isValidEmail(email)) {
            showSnackbarWithClose(`Email không chuẩn định dạng.`, {
                variant: 'error',
            });
            return;
        }

        const phoneRegex = /^(0|\+84)(\d{9}|\d{10})$/;
        if (phone && !phoneRegex.test(phone)) {
            showSnackbarWithClose('Số điện thoại không hợp lệ', { variant: 'error' });
            return;
        }

        if (!name || name.trim() === '' || (!phone && !email) || !memberType) return;

        const payload = new FormData();
        payload.append('ID', item.ID);
        payload.append('DOB', dobTime?.toISOString() || '');
        payload.append('Name', name.trim());
        if (phone) {
            payload.append('Phone', phone.trim());
        }

        if (email) {
            payload.append('Email', email?.trim());
        }

        if (citizenIdentification) {
            payload.append('CitizenIdentification', citizenIdentification?.trim());
        }

        payload.append('Address', address?.trim());
        payload.append('Gender', gender);
        payload.append('Description', description);
        if (password) {
            payload.append('Password', password);
        }
        payload.append('MemberParkingId', item?.MemberParkingId);
        if (avatar) {
            const imageCompress = await handleCompressImage(avatar);
            payload.append('files', imageCompress, avatar.name);
        }

        if (memberType) {
            payload.append('MemberTypeId', memberType.ID);
        }
        try {
            const { data } = await memberApi.updateMember(payload);
            showSnackbarWithClose(`Cập nhật ${nameDialog} thành công`, { variant: 'success' });
            handleReload && handleReload();
            handleClose();
        } catch (error: any) {
            if (Array.isArray(error?.response?.data?.message)) {
                error?.response?.data?.message.forEach((item: any) => {
                    showSnackbarWithClose(item, {
                        variant: 'error',
                    });
                });
            } else {
                showSnackbarWithClose(
                    error?.response ? error.response.data?.message : error.message,
                    {
                        variant: 'error',
                    }
                );
            }
        }
    };

    useEffect(() => {
        if (open) {
            setName(item.Name);
            setPhone(item.Phone);
            setEmail(item.Email);
            setAddress(item.Address || '');
            setDescription(item.Description || '');
            setMemberType(item.MemberTypeId || null);
            setCitizenIdentification(item?.CitizenIdentification ? item.CitizenIdentification : '');
            if (item.DOB) {
                setDobTime(new Date(item.DOB));
            } else {
                setDobTime(null);
            }
            setGender(item.Gender || '');
            setRePassword('');
            setPassword('');
        }
    }, [open]);

    return (
        <Dialog
            fullScreen={fullScreen}
            open={open}
            onClose={() => setOpenComfirm(true)}
            aria-labelledby="responsive-dialog-title"
            sx={{
                '& .MuiPaper-root': {
                    md: { minWidth: '600px', borderRadius: '16px' },
                },
            }}
        >
            <DialogTitle>{`Chỉnh sửa thông tin ${nameDialog}`}</DialogTitle>
            <DialogContent>
                <Stack py={2} spacing={2}>
                    <Stack direction={'row'} spacing={2} alignItems={'center'}>
                        <InputUploadImage
                            avatar={avatar}
                            setAvatar={setAvatar}
                            urlInit={item.Avatar ? BACKEND_DOMAIN + item.Avatar : undefined}
                            fileInputRef={fileInputRef}
                        />
                        <Stack flex={1} spacing={2}>
                            <Stack component={'form'}>
                                <InputLabel required>Họ tên</InputLabel>
                                <StyledOutlinedInput
                                    autoComplete="off"
                                    value={name}
                                    onChange={(e) => {
                                        setName(e.target.value);
                                    }}
                                    size="small"
                                    fullWidth
                                />
                            </Stack>
                            <Stack direction={'row'}>
                                <StyleButton
                                    sx={{
                                        backgroundColor: 'rgba(120, 198, 231, 1)',
                                        color: 'white',
                                        '&:hover': {
                                            backgroundColor: 'rgba(120, 198, 231, 0.8)',
                                        },
                                    }}
                                    onClick={() => {
                                        if (fileInputRef.current) {
                                            fileInputRef.current.click();
                                        }
                                    }}
                                >
                                    Cập nhật ảnh đại diện
                                </StyleButton>
                            </Stack>
                        </Stack>
                    </Stack>

                    {item.ParkingId?.ID && (
                        <AutoCompoleteMemberType
                            setValue={setMemberType}
                            parkingId={item.ParkingId?.ID}
                            value={memberType}
                        />
                    )}

                    <Grid2 component={'form'} container>
                        <Grid2 xs={12} sm={6} pr={1}>
                            <InputLabel>Số điện thoại</InputLabel>
                            <StyledOutlinedInput
                                autoComplete="off"
                                value={phone}
                                onChange={(e) => {
                                    setPhone(e.target.value);
                                }}
                                size="small"
                                fullWidth
                            />
                        </Grid2>
                        <Grid2 component={'form'} xs={12} sm={6} pl={1}>
                            <InputLabel>Email</InputLabel>
                            <StyledOutlinedInput
                                autoComplete="off"
                                value={email}
                                onChange={(e) => {
                                    setEmail(e.target.value);
                                }}
                                size="small"
                                fullWidth
                            />
                        </Grid2>
                    </Grid2>

                    <Grid2 container>
                        <Grid2 component={'form'} xs={12} sm={6} pr={1}>
                            <InputLabel>Mật khẩu</InputLabel>
                            <StyledOutlinedInput
                                autoComplete="off"
                                value={password}
                                onChange={(e) => {
                                    setPassword(e.target.value);
                                }}
                                size="small"
                                fullWidth
                                type="password"
                            />
                        </Grid2>

                        <Grid2 component={'form'} xs={12} sm={6} pl={1} autoComplete="off">
                            <InputLabel>Nhập lại mật khẩu</InputLabel>
                            <StyledOutlinedInput
                                autoComplete="off"
                                value={rePassword}
                                onChange={(e) => {
                                    setRePassword(e.target.value);
                                }}
                                size="small"
                                fullWidth
                                type="password"
                            />
                        </Grid2>
                    </Grid2>

                    <Grid2 container>
                        <Grid2 component={'form'} xs={12} sm={6} pr={0.5}>
                            <InputLabel>Ngày sinh</InputLabel>
                            <DatePicker
                                format="dd/MM/yyyy"
                                slotProps={{
                                    textField: {
                                        size: 'small',
                                        disabled: true,
                                    },
                                }}
                                maxDate={new Date(new Date().getTime() - 24 * 60 * 60 * 1000)}
                                value={dobTime}
                                onChange={(newValue) => {
                                    setDobTime(newValue);
                                }}
                                sx={{
                                    '& .MuiInputBase-root': {
                                        borderRadius: '10px',
                                    },
                                }}
                            />
                        </Grid2>
                        <Grid2 component={'form'} xs={12} sm={6} pl={0.5}>
                            <InputLabel id="provinces">Giới tính</InputLabel>
                            <StyledSelectInput
                                labelId="demo-simple-select-label"
                                value={gender}
                                onChange={(e: any) => {
                                    setGender(e.target.value);
                                }}
                                variant="outlined"
                                fullWidth
                                size="small"
                            >
                                <MenuItem value={'MALE'}>Nam</MenuItem>
                                <MenuItem value={'FEMALE'}>Nữ</MenuItem>
                                <MenuItem value={'ANOTHER'}>Khác</MenuItem>
                            </StyledSelectInput>
                        </Grid2>
                    </Grid2>

                    <Stack direction="row" sx={{ gap: '10px' }}>
                        <Stack component={'form'} sx={{ flex: 1 }}>
                            <InputLabel>Địa chỉ *</InputLabel>
                            <StyledOutlinedInput
                                autoComplete="off"
                                value={address}
                                onChange={(e) => {
                                    setAddress(e.target.value);
                                }}
                                size="small"
                                fullWidth
                                type={'text'}
                            />
                        </Stack>
                        <Stack component={'form'} sx={{ flex: 1 }}>
                            <InputLabel>CCCD/CMND</InputLabel>
                            <StyledOutlinedInput
                                autoComplete="off"
                                value={citizenIdentification}
                                onChange={(e) => {
                                    setCitizenIdentification(e.target.value);
                                }}
                                size="small"
                                fullWidth
                                type={'text'}
                            />
                        </Stack>
                    </Stack>

                    <Stack component={'form'}>
                        <InputLabel>Mô tả</InputLabel>
                        <StyledOutlinedInput
                            autoComplete="off"
                            value={description}
                            onChange={(e) => {
                                setDescription(e.target.value);
                            }}
                            size="small"
                            fullWidth
                            multiline
                            rows={4}
                        />
                    </Stack>
                </Stack>
            </DialogContent>
            <DialogActions
                sx={{
                    px: 3,
                    pb: 3,
                }}
            >
                <StyleButton variant="contained" onClick={handleUpdateMember}>
                    Cập nhật
                </StyleButton>
            </DialogActions>
            {openComfirm ? (
                <ComfirmCloseDialog
                    close={() => setOpenComfirm(false)}
                    action={() => {
                        setOpenComfirm(false);
                        handleClose();
                    }}
                />
            ) : (
                <></>
            )}
        </Dialog>
    );
}
