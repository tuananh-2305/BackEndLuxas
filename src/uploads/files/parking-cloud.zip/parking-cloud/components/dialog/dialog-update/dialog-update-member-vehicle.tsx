import { cardApi } from '@/api/card-api';
import { keyRoleApi } from '@/api/key-role-api';
import { MemberModel } from '@/models/index';
import { hasSpecialCharsOrWhitespace, theme } from '@/ultis/index';
import {
    Dialog,
    DialogActions,
    DialogContent,
    DialogTitle,
    FormControl,
    InputLabel,
    Select,
    SelectChangeEvent,
    Stack,
    useMediaQuery,
} from '@mui/material';
import { enqueueSnackbar } from 'notistack';
import { useEffect, useState } from 'react';
import { vehicleTypeApi } from '@/api/vehicle-type-api';
import { useAppSelector } from '@/hooks/useReudx';
import MenuItem from '@mui/material/MenuItem';
import {
    MemberVehicleCreatePayload,
    MemberVehicleModel,
    MemberVehicleUpdatePayload,
} from '@/models/member.vehicle.model';
import { memberVehicleApi } from '@/api/member-vehicle-api';
import { Vehicel } from '@/components/formular/interface';
import { StyleButton, StyledOutlinedInput } from '@/components/common/style-component';
import { showSnackbarWithClose } from '@/hooks/useSnackbarWithClose';
import dayjs from 'dayjs';
import { DatePicker } from '@mui/x-date-pickers';
import { ComfirmCloseDialog } from '../dialog-comfirm-close';

export interface IDialogUpdateMemberVehicleProps {
    open: boolean;
    handleClose: () => void;
    handleReload?: () => void;
    data: MemberVehicleModel;
}

export default function DialogUpdateMemberVehicle(props: IDialogUpdateMemberVehicleProps) {
    const { open, handleClose, handleReload, data } = props;
    const [keyRoles, setKeyRoles] = useState([]);
    const [plateNumber, setPlateNumber] = useState('');
    const [color, setColor] = useState('');
    const [vehicleBrand, setVehicleBrand] = useState('');
    const [description, setDescription] = useState('');
    const [vehicleTypeId, setVehicleTypeId] = useState<string>(''); // list vehicle type of parking
    const [listVehicle, setListVehicle] = useState<Vehicel[]>([]); // list vehicle of member
    const nameDialog = 'phương tiện';

    const fullScreen = useMediaQuery(theme.breakpoints.down('md'));
    const [isHiddenPlateNumber, setIsHiddenPlateNumber] = useState<boolean>(false);
    const [dateExpire, setDateExpire] = useState<Date | null>(dayjs().endOf('month').toDate());
    const [openComfirm, setOpenComfirm] = useState(false);
    //

    // useEffect(() => {
    //     if (!listVehicle.find((item) => item.ID === vehicleTypeId)?.IsPlateNumber) {
    //         setIsHiddenPlateNumber(false);
    //     } else {
    //         setIsHiddenPlateNumber(true);
    //     }
    // }, [vehicleTypeId]);
    useEffect(() => {
        if (!data.ParkingId?.ID) return;

        vehicleTypeApi.getVehicleTypes().then((res) => {
            setListVehicle(res.data);
        });
    }, [data.ParkingId?.ID]);

    useEffect(() => {
        if (open) {
            // console.log(!!data.VehicleTypeId?.IsPlateNumber);
            setPlateNumber(data.PlateNumber);
            setColor(data.VehicleColor);
            setVehicleBrand(data.VehicleBrand);
            setDescription(data.Description);
            setVehicleTypeId(data.VehicleTypeId?.ID || '');
            setIsHiddenPlateNumber(!!data.VehicleTypeId?.IsPlateNumber);
            if (data.ExpirationDate) setDateExpire(new Date(data.ExpirationDate));
        }
    }, [open]);

    const handleUpdate = async () => {
        if (vehicleTypeId === '') {
            showSnackbarWithClose('Loại xe không được để trống', {
                variant: 'error',
            });
            return;
        }
        if (isHiddenPlateNumber && !plateNumber) {
            showSnackbarWithClose('Biển số không được để trống', {
                variant: 'error',
            });
            return;
        }
        if (!dateExpire) {
            showSnackbarWithClose('Chưa chọn ngày hết hạn', {
                variant: 'error',
            });
            return;
        }

        const payload: MemberVehicleUpdatePayload = {
            VehicleBrand: vehicleBrand,
            VehicleColor: color,
            PlateNumber: plateNumber,
            VehicleTypeId: vehicleTypeId,
            Description: description,
            ID: data.ID,
            ExpirationDate: dateExpire,
        };

        try {
            await memberVehicleApi.updateMemberVehicle(payload);
            showSnackbarWithClose(`Cập nhật ${nameDialog} thành công`, {
                variant: 'success',
            });
            handleReload && handleReload();
            handleClose();
        } catch (error: any) {
            if (Array.isArray(error?.response?.data?.message)) {
                error?.response?.data?.message.forEach((item: any) => {
                    showSnackbarWithClose(item, {
                        variant: 'error',
                    });
                });
            } else {
                showSnackbarWithClose(
                    error?.response ? error.response.data?.message : error.message,
                    {
                        variant: 'error',
                    }
                );
            }
        }
    };
    return (
        <Dialog
            fullScreen={fullScreen}
            open={open}
            onClose={() => setOpenComfirm(true)}
            aria-labelledby="responsive-dialog-title"
            sx={{
                '& .MuiPaper-root': {
                    md: { minWidth: '500px', borderRadius: '16px' },
                },
            }}
        >
            <DialogTitle>{`Cập nhật ${nameDialog}`}</DialogTitle>
            <DialogContent>
                <Stack py={2} spacing={2}>
                    {/* <AutoCompoleteMember setValue={setMember} parkingId={idMember} /> */}
                    <Stack>
                        <InputLabel id="type" required>
                            Loại xe
                        </InputLabel>
                        <Select
                            labelId="type"
                            id="demo-simple-select-districts"
                            size="small"
                            sx={{
                                borderRadius: '10px',
                            }}
                            onChange={(event: SelectChangeEvent) => {
                                setVehicleTypeId(event.target.value);
                                if (
                                    !listVehicle.find((item) => item.ID === event.target.value)
                                        ?.IsPlateNumber
                                ) {
                                    setIsHiddenPlateNumber(false);
                                } else {
                                    setIsHiddenPlateNumber(true);
                                }
                            }}
                            value={vehicleTypeId}
                        >
                            {listVehicle?.map((item, index) => (
                                <MenuItem value={item.ID} key={index}>
                                    {item.Name}
                                </MenuItem>
                            ))}
                        </Select>
                    </Stack>
                    {isHiddenPlateNumber && (
                        <Stack>
                            <InputLabel>Biển số xe*</InputLabel>
                            <StyledOutlinedInput
                                autoComplete="off"
                                value={plateNumber}
                                onChange={(e) => {
                                    const { value } = e.target;

                                    setPlateNumber(value.toUpperCase());
                                }}
                                size="small"
                                fullWidth
                            />
                        </Stack>
                    )}
                    <Stack>
                        <InputLabel required>Ngày hết hạn phương tiện</InputLabel>
                        <DatePicker
                            format="dd/MM/yyyy"
                            slotProps={{
                                textField: {
                                    size: 'small',
                                },
                            }}
                            value={dateExpire}
                            minDate={new Date()}
                            onChange={(newValue) => {
                                setDateExpire(newValue);
                            }}
                            sx={{
                                '& .MuiInputBase-root': {
                                    borderRadius: '10px',
                                },
                            }}
                        />
                    </Stack>
                    <Stack>
                        <InputLabel>Hiệu xe</InputLabel>
                        <StyledOutlinedInput
                            autoComplete="off"
                            size="small"
                            fullWidth
                            value={vehicleBrand}
                            onChange={(e) => {
                                setVehicleBrand(e.target.value);
                            }}
                        />
                    </Stack>
                    <Stack>
                        <InputLabel>Màu</InputLabel>
                        <StyledOutlinedInput
                            autoComplete="off"
                            size="small"
                            fullWidth
                            value={color}
                            onChange={(e) => {
                                setColor(e.target.value);
                            }}
                        />
                    </Stack>
                    <Stack>
                        <InputLabel>Mô tả</InputLabel>
                        <StyledOutlinedInput
                            autoComplete="off"
                            value={description}
                            onChange={(e) => {
                                setDescription(e.target.value);
                            }}
                            size="small"
                            label="Mô tả"
                            fullWidth
                            multiline
                            rows={4}
                        />
                    </Stack>
                </Stack>
            </DialogContent>
            <DialogActions
                sx={{
                    px: 3,
                    pb: 3,
                }}
            >
                <StyleButton variant="contained" onClick={handleUpdate}>
                    Cập nhật
                </StyleButton>
            </DialogActions>
            {openComfirm ? (
                <ComfirmCloseDialog
                    close={() => setOpenComfirm(false)}
                    action={() => {
                        setOpenComfirm(false);
                        handleClose();
                    }}
                />
            ) : (
                <></>
            )}
        </Dialog>
    );
}
