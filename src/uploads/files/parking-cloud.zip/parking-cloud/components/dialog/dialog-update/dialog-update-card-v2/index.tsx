import { cardApi } from '@/api/card-api';
import ImageNextjs from '@/components/common/image';
import AutoCompoleteMember from '@/components/common/input/autocomplete-member';
import TextFieldForm from '@/components/common/input/text-field-form/text-field-form';
import TextFieldFormSelect, {
    OptionSelect,
} from '@/components/common/input/text-field-form/text-field-form-select';
import { SelectVehicle } from '@/components/common/select/case-vehicel-list-update';
import FormCheckbox from '@/components/settings/member/create/form-info-card/form-checkbox';
import ScanCard from '@/components/settings/member/create/widget/scan-crd';
import { showSnackbarWithClose } from '@/hooks/useSnackbarWithClose';
import { CardModel, MemberModel } from '@/models/index';
import { MemberVehicleModel } from '@/models/member.vehicle.model';
import { Validator } from '@/ultis/validate';
import CloseRoundedIcon from '@mui/icons-material/CloseRounded';
import { Button, Dialog, DialogActions, Grid, InputLabel, Stack, Typography } from '@mui/material';
import { useState } from 'react';
import styles from './style.module.css';
const authenTyppeList: OptionSelect[] = [
    {
        id: 'CARD',
        label: 'Thẻ từ',
    },
];
export interface SimpleDialogProps {
    open: boolean;
    handleClose: () => void;
    handleReload?: () => void;
    item: CardModel;
    isElevator?: boolean;
}

export function DialogUpdateCard(props: SimpleDialogProps) {
    const { handleClose, open, item, handleReload, isElevator } = props;

    const [formCard, setFormCard] = useState<any>({
        id: item?.ID ?? '',
        vehicleType: item?.MemberVehicleId ?? '',
        typeAuthen: 'CARD',
        idCard: item?.IdCard ?? '',
        cardNumber: item?.CardNumber ?? '',
        isCardElevator: item?.IsCardElevator ?? '',
        isCardParking: item?.IsCardParking ?? '',
        memberId: item?.MemberId ?? null,
        description: item?.Description ?? '',
    });

    const [formCardErr, setFormCardErr] = useState<any>({
        vehicleType: null,
        typeAuthen: null,
        idCard: null,
        cardTarget: null,
        cardNumber: null,
    });

    const handleInputChange = (key: string, value: any) => {
        if (key === 'memberId') {
            setFormCard({ ...formCard, ['memberId']: value, ['vehicleType']: '' });
        } else {
            setFormCard({ ...formCard, [key]: value });
            setFormCardErr({ ...formCardErr, [key]: null });
        }
    };

    const checkValidate = () => {
        // Initialize a flag to track if there are validation errors
        let hasError = false;

        // Initialize an error object to store validation messages
        let error = {
            ...formCardErr,
            vehicleType: Validator.checkNotEmpty(formCard.vehicleType?.ID ?? ''),
            typeAuthen: Validator.checkNotEmpty(formCard.typeAuthen),
            idCard: Validator.checkNotEmpty(formCard.idCard),
            // cardNumber: Validator.checkNotEmpty(formCard.cardNumber),
            cardTarget:
                !formCard.isCardElevator && !formCard.isCardParking
                    ? 'Chưa chọn mục đích sự dụng'
                    : null,
        };

        // If the card is not for parking, reset the vehicleType error
        if (!formCard.isCardParking) {
            error.vehicleType = null;
        }

        // Check if any validation error exists and set the hasError flag accordingly
        if (
            error.typeAuthen !== null ||
            error.cardNumber !== null ||
            error.idCard !== null ||
            error.vehicleType != null ||
            error.cardTarget != null
        ) {
            hasError = true;
        }

        // Update the formCardErr state with the error object
        setFormCardErr(error);

        // Return true if there are no validation errors, otherwise return false
        return !hasError;
    };

    const handleSubmit = async () => {
        if (!checkValidate()) {
            return;
        }

        const formData = new FormData();
        formData.append('ID', item.ID);
        formData.append('MemberId', formCard.memberId?.ID ?? '');
        formData.append('ParkingId', item?.ParkingId?.ID);
        formData.append('Description', formCard.description ?? '');

        if (formCard.idCard != item.IdCard) {
            // console.log('idCard 2 : ', idCard);
            formData.append('IdCard', formCard.idCard);
        }
        if (formCard.vehicleType && formCard.isCardParking) {
            formData.append('MemberVehicleId', formCard.vehicleType?.ID);
        }

        formData.append('IsCardParking', formCard.isCardParking.toString());
        formData.append('IsCardElevator', formCard.isCardElevator.toString());

        if (formCard.cardNumber != item.CardNumber) {
            formData.append('CardNumber', formCard.cardNumber);
        }

        try {
            await cardApi.updateCard(formData);
            showSnackbarWithClose(`Cập nhật thẻ thành công`, {
                variant: 'success',
            });
            handleReload && handleReload();
            handleClose();
        } catch (error: any) {
            if (Array.isArray(error?.response?.data?.message)) {
                error?.response?.data?.message.forEach((item: any) => {
                    showSnackbarWithClose(item, {
                        variant: 'error',
                    });
                });
            } else {
                showSnackbarWithClose(
                    error?.response ? error.response.data?.message : error.message,
                    {
                        variant: 'error',
                    }
                );
            }
        }
    };

    return (
        <Dialog onClose={handleClose} open={open}>
            <Stack className={styles.container}>
                <Stack className={styles.closeBtn} onClick={handleClose}>
                    <CloseRoundedIcon className={styles.closeIcon} />
                </Stack>
                <Stack className={styles.titleBox}>
                    <ImageNextjs
                        path="/icons/create_icon.svg"
                        sx={{ width: '40px', height: '40px' }}
                    />
                    <Typography className={styles.titleText}>
                        {isElevator ? 'Chỉnh sửa thẻ thang máy' : 'Chỉnh sửa thẻ tháng'}
                    </Typography>
                </Stack>
                <Stack className={styles.contentBox}>
                    <Grid container spacing={2}>
                        <Grid item xs={12}>
                            <FormCheckbox
                                onChange={function (name: string, value: boolean): void {
                                    handleInputChange(name, value);
                                }}
                                isCardElevator={formCard.isCardElevator}
                                isCardParking={formCard.isCardParking}
                                textError={formCardErr.cardTarget}
                                label={'1. Mục đích sử dụng'}
                                isElevator
                            />
                        </Grid>
                        <Grid item xs={12}>
                            <AutoCompoleteMember
                                setValue={(value: MemberModel | null) => {
                                    handleInputChange('memberId', value);
                                    // handleInputChange('vehicleType', '');
                                }}
                                parkingId={item?.ParkingId?.ID}
                                value={formCard.memberId}
                            />
                        </Grid>

                        {formCard.isCardParking && (
                            <Grid item xs={12}>
                                <SelectVehicle
                                    value={formCard.vehicleType}
                                    setValue={(v: MemberVehicleModel | null) => {
                                        handleInputChange('vehicleType', v);
                                    }}
                                    textError={formCardErr.vehicleType}
                                    memberId={formCard.memberId?.ID}
                                    parkingId={item.ParkingId.ID}
                                    isParking={formCard.isCardParking}
                                />
                            </Grid>
                        )}

                        <Grid item xs={12} lg={6}>
                            <TextFieldFormSelect
                                value={formCard.typeAuthen}
                                label={`${formCard.isCardParking ? '4' : '3'}. Loại xác thực `}
                                required
                                placeholder="Chọn loại xác thực"
                                name="typeAuthen"
                                onChange={function (event: any): void {
                                    const { name, value } = event.target;
                                    handleInputChange(name, value);
                                }}
                                options={authenTyppeList}
                                textError={formCardErr.typeAuthen}
                            />
                        </Grid>
                        <Grid item xs={12} lg={6}>
                            <TextFieldForm
                                lable={`${formCard.isCardParking ? '5' : '4'}. Số thẻ ngoài`}
                                placeholder="Nhập số thẻ"
                                name="idCard"
                                required
                                value={formCard.idCard}
                                onChange={function (event: any): void {
                                    const { name, value } = event.target;
                                    handleInputChange(name, value);
                                }}
                                textError={formCardErr.idCard}
                            />
                        </Grid>
                        <Grid item xs={12}>
                            <InputLabel
                                sx={{ fontSize: 14, fontWeight: 400, color: '#55595D', mb: '6px' }}
                            >
                                {formCard.isCardParking ? '6' : '5'}. Xác nhận mã thẻ
                                <Typography
                                    component={'span'}
                                    sx={{
                                        color: '#E42727',
                                        fontSize: 13,
                                        display: 'inline-block',
                                    }}
                                >
                                    (✶)
                                </Typography>
                            </InputLabel>
                            <ScanCard
                                value={formCard.cardNumber}
                                textError={formCardErr.cardNumber}
                                formCard={formCard}
                                handleInputChange={handleInputChange}
                                setFormCardErr={setFormCardErr}
                                formCardErr={formCardErr}
                                formCardList={[]}
                                initData={{
                                    CardAndVehicle: [
                                        {
                                            Authentication: {
                                                ID: item?.ID,
                                                CardNumber: item?.CardNumber,
                                            },
                                        },
                                    ],
                                }}
                            />
                        </Grid>
                        <Grid item xs={12}>
                            <TextFieldForm
                                lable={'Ghi chú'}
                                placeholder="Ghi chú"
                                value={formCard.description}
                                name="description"
                                onChange={function (event: any): void {
                                    const { name, value } = event.target;
                                    handleInputChange(name, value);
                                }}
                                textError={formCardErr.description}
                                row={3}
                                multiline
                            />
                        </Grid>
                    </Grid>
                </Stack>
            </Stack>
            <DialogActions className={styles.dialogAction}>
                <Button className={styles.cancelBtn} variant="contained" onClick={handleClose}>
                    Hủy
                </Button>
                <Button
                    className={styles.submitBtn}
                    variant="contained"
                    onClick={handleSubmit}
                    autoFocus
                >
                    Lưu
                </Button>
            </DialogActions>
        </Dialog>
    );
}
