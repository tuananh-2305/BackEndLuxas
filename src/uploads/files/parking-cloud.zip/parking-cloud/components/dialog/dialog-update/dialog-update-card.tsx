import { cardApi } from '@/api/card-api';
import { keyRoleApi } from '@/api/key-role-api';
import AutoCompoleteMember from '@/components/common/input/autocomplete-member';
import { StyleButton, StyledOutlinedInput } from '@/components/common/style-component';
import { useAppSelector } from '@/hooks/index';
import { showSnackbarWithClose } from '@/hooks/useSnackbarWithClose';
import { CardModel, CardUpdatePayload, MemberModel } from '@/models/index';
import { hasSpecialCharsOrWhitespace, theme } from '@/ultis/index';
import {
    Card,
    CardMedia,
    Dialog,
    DialogActions,
    DialogContent,
    DialogTitle,
    IconButton,
    InputLabel,
    MenuItem,
    Select,
    Stack,
    Tooltip,
    useMediaQuery,
    Checkbox,
    Typography,
} from '@mui/material';
import { DatePicker } from '@mui/x-date-pickers';
import { useEffect, useMemo, useState } from 'react';
import { ComfirmCloseDialog } from '../dialog-comfirm-close';
import ImageIcon from '@mui/icons-material/Image';
import { MemberVehicleModel } from '@/models/member.vehicle.model';
import { AutoCompleteVehicel } from '@/components/common/input/autocomplete-vehicel';
export interface IDialogUpdateCardProps {
    open: boolean;
    handleClose: () => void;
    handleReload?: () => void;
    item: CardModel;
}

export default function DialogUpdateCard(props: IDialogUpdateCardProps) {
    const { open, handleClose, handleReload, item } = props;

    const [keyRoles, setKeyRoles] = useState([]);
    const [cardNumber, setCardNumber] = useState('');
    const [description, setDescription] = useState('');
    const [member, setMember] = useState<MemberModel | null>(null);
    const [dateExpire, setDateExpire] = useState<Date | null>(null);
    const [typeAuthen, setTypeAuthen] = useState<'CARD' | 'FACE'>('CARD');
    const [openComfirm, setOpenComfirm] = useState(false);

    const [isCardElevator, setIsCardElevator] = useState(item.IsCardElevator);
    const [isCardParking, setIsCardParking] = useState(item.IsCardParking);
    const [faceImage, setFaceImage] = useState<File | null>(null);
    const [vehicel, setVehicel] = useState<MemberVehicleModel | null>(null);
    const [idCard, setIdCard] = useState(item?.IdCard ? item.IdCard : '');

    const fullScreen = useMediaQuery(theme.breakpoints.down('md'));
    useEffect(() => {
        keyRoleApi.getKeyRole().then((res) => {
            setKeyRoles(res.data);
        });
    }, []);

    // reset name and checked when close dialog
    useEffect(() => {
        if (open) {
            setCardNumber(item.CardNumber);
            setDescription(item.Description);
            // console.log('test test test tes : ', item);
            if (item?.MemberId) {
                setMember(item.MemberId);
            } else {
                setMember(null);
            }
            // setVehicel(item.MemberVehicleId);
            if (item.ExpirationDate) setDateExpire(new Date(item.ExpirationDate));
            setFaceImage(null);
            setTypeAuthen(item.TypeAuthen as 'CARD' | 'FACE');
        }
    }, [item, open]);

    useEffect(() => {
        //default checked
        if (keyRoles.length === 0) return;
    }, [keyRoles]);

    const handleUpdate = async () => {
        // if (cardNumber === '' || cardNumber.trim() === '') {
        //     showSnackbarWithClose('Mã thẻ không được để trống', {
        //         variant: 'error',
        //     });
        // }

        if (typeAuthen === 'CARD') {
            if (Boolean(cardNumber?.trim())) {
                if (cardNumber && cardNumber.trim().length < 8) {
                    showSnackbarWithClose('Mã thẻ phải ít nhất 8 ký tự', {
                        variant: 'error',
                    });
                    return;
                }
            } else {
                showSnackbarWithClose('Mã thẻ không được để trống', {
                    variant: 'error',
                });
                return;
            }
        }

        // if (!dateExpire) {
        //     showSnackbarWithClose('Chưa chọn ngày hết hạn', {
        //         variant: 'error',
        //     });
        // }
        if (!member) {
            showSnackbarWithClose('Bạn chưa chọn cư dân cho thẻ này.', {
                variant: 'error',
            });
            return;
        }

        if (!isCardParking && !isCardElevator) {
            showSnackbarWithClose('Chưa chọn hình thức sử dụng.', {
                variant: 'error',
            });
            return;
        }

        if (isCardParking && !vehicel) {
            showSnackbarWithClose('Chưa chọn loại xe', {
                variant: 'error',
            });
            return;
        }
        // const payload: CardUpdatePayload = {
        //     ID: item.ID,
        //     CardNumber: cardNumber.trim(),
        //     MemberId: member.ID,
        //     Description: description,
        //     ExpirationDate: dateExpire,
        // };

        const formData = new FormData();
        formData.append('ID', item.ID);
        formData.append('MemberId', member.ID);
        formData.append('ParkingId', item.ParkingId.ID);
        formData.append('Description', description);

        if (idCard) {
            // console.log('idCard 2 : ', idCard);
            formData.append('IdCard', idCard);
        }
        if (vehicel && isCardParking) {
            formData.append('MemberVehicleId', vehicel.ID);
        }

        formData.append('IsCardParking', isCardParking.toString());
        formData.append('IsCardElevator', isCardElevator.toString());
        if (dateExpire) {
            formData.append('ExpirationDate', dateExpire?.toString());
        }
        formData.append('TypeAuthen', typeAuthen);

        if (typeAuthen === 'CARD') {
            if (cardNumber) {
                formData.append('CardNumber', cardNumber);
            } else {
                showSnackbarWithClose('Bạn chưa nhập mã thẻ!.', { variant: 'error' });
                return;
            }
        }

        if (typeAuthen === 'FACE' && faceImage) {
            if (faceImage) {
                formData.append('files', faceImage, faceImage.name);
            } else {
                showSnackbarWithClose('Bạn cần chọn một tấm ảnh!.', { variant: 'error' });
                return;
            }
        }

        try {
            await cardApi.updateCard(formData);
            showSnackbarWithClose(`Cập nhật thẻ thành công`, {
                variant: 'success',
            });
            handleReload && handleReload();
            handleClose();
        } catch (error: any) {
            if (Array.isArray(error?.response?.data?.message)) {
                error?.response?.data?.message.forEach((item: any) => {
                    showSnackbarWithClose(item, {
                        variant: 'error',
                    });
                });
            } else {
                showSnackbarWithClose(
                    error?.response ? error.response.data?.message : error.message,
                    {
                        variant: 'error',
                    }
                );
            }
        }
    };

    const renderImage = useMemo(
        () => (
            <CardMedia
                sx={{ height: 300 }}
                image={
                    faceImage
                        ? URL.createObjectURL(faceImage)
                        : item.FaceImage
                        ? `/service/${item.FaceImage}`
                        : '/images/default_background_company.png'
                }
                title="green iguana"
            />
        ),
        [faceImage]
    );

    return (
        <Dialog
            fullScreen={fullScreen}
            open={open}
            onClose={() => setOpenComfirm(true)}
            aria-labelledby="responsive-dialog-title"
            sx={{
                '& .MuiPaper-root': {
                    md: { minWidth: '500px', borderRadius: '16px' },
                },
            }}
        >
            <DialogTitle>{`Cập nhật thẻ`}</DialogTitle>
            <DialogContent>
                <Stack py={2} spacing={2}>
                    <AutoCompoleteMember
                        setValue={(value: MemberModel | null) => {
                            setVehicel(null);
                            setMember(value);
                        }}
                        parkingId={item.ParkingId.ID}
                        value={member}
                    />
                    <Typography>Hình thức :</Typography>
                    <Stack direction="row" justifyContent="center">
                        <Stack direction="row" flex={1} alignItems="center">
                            <Checkbox
                                size="small"
                                checked={isCardElevator}
                                onChange={(e) => setIsCardElevator(e.target.checked)}
                            />
                            <Typography sx={{ textTransform: 'capitalize' }}>thang máy</Typography>
                        </Stack>
                        <Stack direction="row" flex={1} alignItems="center">
                            <Checkbox
                                size="small"
                                checked={isCardParking}
                                onChange={(e) => setIsCardParking(e.target.checked)}
                            />

                            <Typography sx={{ textTransform: 'capitalize' }}>bãi xe</Typography>
                        </Stack>
                    </Stack>
                    {isCardParking ? (
                        <AutoCompleteVehicel
                            setValue={function (value: MemberVehicleModel | null): void {
                                setVehicel(value);
                            }}
                            memberId={member?.ID}
                            parkingId={item.ParkingId.ID}
                            value={vehicel}
                        />
                    ) : (
                        <></>
                    )}

                    <Tooltip title="Dãy số in bên ngoài thẻ vật lý có thể kiểm tra trực tiếp trên thẻ">
                        <Stack>
                            <InputLabel>Số thẻ ngoài</InputLabel>
                            <StyledOutlinedInput
                                autoComplete="off"
                                value={idCard}
                                onChange={(e) => {
                                    setIdCard(e.target.value);
                                }}
                                size="small"
                                fullWidth
                            />
                        </Stack>
                    </Tooltip>

                    <Stack>
                        <InputLabel>Loại xác thực</InputLabel>
                        <Select
                            labelId="demo-simple-select-label"
                            fullWidth
                            size="small"
                            sx={{
                                borderRadius: '10px',
                            }}
                            value={typeAuthen}
                            onChange={(e: any) => {
                                setTypeAuthen(e.target.value);
                            }}
                        >
                            <MenuItem value={'CARD'}>Thẻ từ</MenuItem>
                            {/* <MenuItem value={'FACE'}>Gương mặt</MenuItem> */}
                        </Select>
                    </Stack>
                    {typeAuthen === 'CARD' && (
                        <Tooltip
                            title={
                                'Dãy số từ 8 số, chỉ có thể kiểm tra thông qua việc quét bằng máy đọc'
                            }
                        >
                            <Stack>
                                <InputLabel>Mã thẻ*</InputLabel>
                                <StyledOutlinedInput
                                    autoComplete="off"
                                    value={cardNumber}
                                    onChange={(e) => {
                                        const { value } = e.target;

                                        if (!hasSpecialCharsOrWhitespace(value)) {
                                            setCardNumber(e.target.value);
                                        }
                                    }}
                                    size="small"
                                    fullWidth
                                />
                            </Stack>
                        </Tooltip>
                    )}
                    {typeAuthen === 'FACE' && (
                        <Card sx={{ maxWidth: 345, position: 'relative' }}>
                            {renderImage}
                            {/* <CardMedia
                                sx={{ height: 300 }}
                                image={
                                    faceImage
                                        ? URL.createObjectURL(faceImage)
                                        : item.FaceImage
                                        ? `/service/${item.FaceImage}`
                                        : '/images/default_background_company.png'
                                }
                                title="green iguana"
                            /> */}
                            <Tooltip title="Thêm ảnh">
                                <IconButton
                                    sx={{
                                        position: 'absolute',
                                        zIndex: 3,
                                        bottom: '15px',
                                        right: '15px',
                                        backgroundColor: 'rgba(217, 217, 217, 0.6)',
                                        color: '#fff',
                                        boxShadow: '0 0 5px rgba(0, 0, 0, 0.2)',
                                    }}
                                    component="label"
                                >
                                    <input
                                        hidden
                                        autoComplete="off"
                                        accept="image/*"
                                        type="file"
                                        onChange={(e: any) => {
                                            if (!e.target.files[0]) return;
                                            setFaceImage(e.target.files[0]);
                                        }}
                                    />
                                    <ImageIcon />
                                </IconButton>
                            </Tooltip>
                        </Card>
                    )}
                    {/* <Stack>
                        <InputLabel required>Ngày hết hạn</InputLabel>
                        <DatePicker
                            format="dd/MM/yyyy"
                            slotProps={{
                                textField: {
                                    size: 'small',
                                },
                            }}
                            value={dateExpire}
                            // minDate={new Date()}
                            onChange={(newValue) => {
                                setDateExpire(newValue);
                            }}
                            sx={{
                                '& .MuiInputBase-root': {
                                    borderRadius: '10px',
                                },
                            }}
                        />
                    </Stack> */}

                    <Stack>
                        <InputLabel>Mô tả</InputLabel>
                        <StyledOutlinedInput
                            autoComplete="off"
                            value={description || ''}
                            onChange={(e) => {
                                setDescription(e.target.value);
                            }}
                            size="small"
                            fullWidth
                            multiline
                            rows={4}
                        />
                    </Stack>
                </Stack>
            </DialogContent>
            <DialogActions
                sx={{
                    px: 3,
                    pb: 3,
                }}
            >
                <StyleButton variant="contained" onClick={handleUpdate}>
                    Cập nhật
                </StyleButton>
            </DialogActions>
            {openComfirm ? (
                <ComfirmCloseDialog
                    close={() => setOpenComfirm(false)}
                    action={() => {
                        setOpenComfirm(false);
                        handleClose();
                    }}
                />
            ) : (
                <></>
            )}
        </Dialog>
    );
}
