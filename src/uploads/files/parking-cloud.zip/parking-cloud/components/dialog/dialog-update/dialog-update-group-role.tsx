import { KeyRoleItemMenuModel } from '@/models/index';
import { convertToSlug, theme } from '@/ultis/index';
import {
    Dialog,
    DialogActions,
    DialogContent,
    DialogTitle,
    InputLabel,
    Stack,
    Typography,
    useMediaQuery,
} from '@mui/material';
import Grid2 from '@mui/material/Unstable_Grid2';
import { enqueueSnackbar } from 'notistack';
import { useEffect, useState } from 'react';

import { groupRoleApi } from '@/api/index';
import ListRole from '@/components/common/list-check/list-role';
import { StyleButton, StyledOutlinedInput } from '@/components/common/style-component';
import { useAppSelector } from '@/hooks/index';
import { RoleModel } from '@/models/group.role.model';
import { showSnackbarWithClose } from '@/hooks/useSnackbarWithClose';
import { ComfirmCloseDialog } from '../dialog-comfirm-close';

export interface IDialogUpdateGroupRoleProps {
    open: boolean;
    handleClose: () => void;
    handleReload?: () => void;
    role: RoleModel;
}

export default function DialogUpdateGroupRole(props: IDialogUpdateGroupRoleProps) {
    const { open, handleClose, handleReload, role } = props;
    const [keyRoles, setKeyRoles] = useState([]);
    const [name, setName] = useState('');
    const [key, setKey] = useState('');
    const [description, setDescription] = useState('');

    const nameDialog = 'nhóm quyền';
    const [checked, setChecked] = useState<KeyRoleItemMenuModel[]>([]);
    const idCustomer = useAppSelector((state) => state.common.profile?.CustomerId?.ID);
    const [openComfirm, setOpenComfirm] = useState(false);

    const fullScreen = useMediaQuery(theme.breakpoints.down('md'));
    const handleSetChecked = (checkedItem: KeyRoleItemMenuModel) => {
        const updatedChecked = checked.map((item) => {
            if (checkedItem.IsInsert || checkedItem.IsUpdate || checkedItem.IsDelete) {
                checkedItem.IsRead = true;
            }
            if (item.KeyRoleId === checkedItem.KeyRoleId) {
                return {
                    ...checkedItem,
                };
            }
            return item;
        });
        setChecked(updatedChecked);
    };

    // handle reset checked
    const handleResetChecked = () => {
        setChecked(
            keyRoles.map((item: any) => {
                return {
                    KeyRoleId: item.ID,
                    Name: item.Name,
                    IsCloud: item.IsCloud,
                    IsDelete: false,
                    IsUpdate: false,
                    IsRead: false,
                    IsInsert: false,
                };
            })
        );
    };
    // reset name and checked when close dialog
    useEffect(() => {
        if (open) {
            setName(role.Name);
            handleResetChecked();
            setKey(role.Key);
            setDescription(role.Description || '');
            if (role.ID) {
                groupRoleApi.getGroupRoleById(role.ID).then((res) => {
                    if (res.data) {
                        const { SystemRole } = res.data;
                        setChecked(
                            SystemRole.map((item: any) => ({
                                Name: item?.KeyRoleId?.Name,
                                IsDelete: item?.IsDelete,
                                IsUpdate: item?.IsUpdate,
                                IsRead: item?.IsRead,
                                IsInsert: item?.IsInsert,
                                KeyRoleId: item?.KeyRoleId?.ID,
                                IsCloud: item?.KeyRoleId?.IsCloud,
                            }))
                        );
                    }
                });
            }
        }
    }, [open, role.ID]);
    useEffect(() => {
        //default checked
        if (keyRoles.length === 0) return;
        handleResetChecked();
    }, [keyRoles]);
    const handleCreate = async () => {
        if (name === '' || name.trim() === '') {
            showSnackbarWithClose('Tên nhóm quyền không được để trống', {
                variant: 'error',
            });
            return;
        }

        try {
            const payload: any = {
                Name: name.trim(),
                Key: key,
                SystemRole: checked,
                CustomerId: idCustomer,
                Description: description,
                ID: role.ID,
            };
            await groupRoleApi.updateGroupRole(payload);
            showSnackbarWithClose(`Cập nhật ${nameDialog} thành công`, {
                variant: 'success',
            });
            handleReload && handleReload();
            handleClose();
        } catch (error: any) {
            if (Array.isArray(error?.response?.data?.message)) {
                error?.response?.data?.message.forEach((item: any) => {
                    showSnackbarWithClose(item, {
                        variant: 'error',
                    });
                });
            } else {
                showSnackbarWithClose(
                    error?.response ? error.response.data?.message : error.message,
                    {
                        variant: 'error',
                    }
                );
            }
        }
    };
    return (
        <Dialog
            fullScreen={fullScreen}
            open={open}
            onClose={() => setOpenComfirm(true)}
            aria-labelledby="responsive-dialog-title"
            sx={{
                '& .MuiPaper-root': {
                    md: { minWidth: '500px', borderRadius: '16px' },
                },
            }}
        >
            <DialogTitle>{`Cập nhật ${nameDialog}`}</DialogTitle>
            <DialogContent>
                <Stack py={2} spacing={2}>
                    <Grid2 container spacing={2}>
                        <Grid2 xs={6} sm={9}>
                            <Stack>
                                <InputLabel>Tên nhóm quyền*</InputLabel>
                                <StyledOutlinedInput
                                    autoComplete="off"
                                    value={name}
                                    onChange={(e) => {
                                        setName(e.target.value);
                                        setKey(
                                            e.target.value
                                                ? convertToSlug(
                                                      e.target.value
                                                  ).toLocaleUpperCase() +
                                                      '_' +
                                                      new Date().getTime()
                                                : ''
                                        );
                                    }}
                                    size="small"
                                    fullWidth
                                />
                            </Stack>
                        </Grid2>
                        <Grid2 xs={6} sm={3}>
                            <Stack>
                                <InputLabel>Key*</InputLabel>
                                <StyledOutlinedInput
                                    autoComplete="off"
                                    value={key}
                                    onChange={(e) => {
                                        setKey(e.target.value);
                                    }}
                                    size="small"
                                    fullWidth
                                    disabled
                                />
                            </Stack>
                        </Grid2>
                    </Grid2>

                    <Grid2 container spacing={2}>
                        <Grid2 xs={12} sm={6}>
                            <Stack spacing={1}>
                                <Typography variant="subtitle2">Client</Typography>
                                {checked
                                    .filter((item) => {
                                        return !item.IsCloud;
                                    })
                                    .map((item: KeyRoleItemMenuModel, index) => (
                                        <ListRole
                                            key={index}
                                            keyRoleItem={item}
                                            handleSetCHecked={handleSetChecked}
                                        />
                                    ))}
                            </Stack>
                        </Grid2>
                        <Grid2 xs={12} sm={6}>
                            <Stack spacing={1}>
                                <Typography variant="subtitle2">Cloud</Typography>
                                {checked
                                    .filter((item) => {
                                        return item.IsCloud;
                                    })
                                    .map((item: KeyRoleItemMenuModel, index) => (
                                        <ListRole
                                            key={index}
                                            keyRoleItem={item}
                                            handleSetCHecked={handleSetChecked}
                                        />
                                    ))}
                            </Stack>
                        </Grid2>
                    </Grid2>
                    <Stack>
                        <InputLabel>Mô tả</InputLabel>
                        <StyledOutlinedInput
                            autoComplete="off"
                            value={description}
                            onChange={(e) => {
                                setDescription(e.target.value);
                            }}
                            size="small"
                            label="Mô tả"
                            fullWidth
                            multiline
                            rows={4}
                        />
                    </Stack>
                </Stack>
            </DialogContent>
            <DialogActions
                sx={{
                    px: 3,
                    pb: 3,
                }}
            >
                <StyleButton variant="contained" onClick={handleCreate}>
                    Cập nhật
                </StyleButton>
            </DialogActions>
            {openComfirm ? (
                <ComfirmCloseDialog
                    close={() => setOpenComfirm(false)}
                    action={() => {
                        setOpenComfirm(false);
                        handleClose();
                    }}
                />
            ) : (
                <></>
            )}
        </Dialog>
    );
}
