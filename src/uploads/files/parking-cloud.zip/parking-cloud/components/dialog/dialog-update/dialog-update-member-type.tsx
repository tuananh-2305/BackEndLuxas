import { memberTypeApi } from '@/api/member-type-api';
import { StyleButton, StyledOutlinedInput } from '@/components/common/style-component';
import { useAppSelector } from '@/hooks/useReudx';
import { showSnackbarWithClose } from '@/hooks/useSnackbarWithClose';
import { MemberTypeModel } from '@/models/member.type.model';
import { theme } from '@/ultis/index';
import {
    Dialog,
    DialogActions,
    DialogContent,
    DialogTitle,
    InputLabel,
    Stack,
    useMediaQuery,
} from '@mui/material';
import { enqueueSnackbar } from 'notistack';
import { useEffect, useState } from 'react';
import { ComfirmCloseDialog } from '../dialog-comfirm-close';

export interface IDialogUpdateMemberTypeProps {
    open: boolean;
    handleReload: () => void;
    handleClose: () => void;
    item: MemberTypeModel;
}

export default function DialogUpdateMemberType(props: IDialogUpdateMemberTypeProps) {
    const { open, handleClose, handleReload, item } = props;
    const fullScreen = useMediaQuery(theme.breakpoints.down('md'));
    const [name, setName] = useState<string>('');
    const [description, setDescription] = useState<string>('');
    const chooose = useAppSelector((state) => state.parking.choose);
    const [openComfirm, setOpenComfirm] = useState(false);

    const handleUpdateMemberType = async () => {
        const nameDialog = 'loại cư dân';

        if (!name || name.trim() === '') {
            showSnackbarWithClose(`Tên ${nameDialog} không được để trống`, { variant: 'error' });
            return;
        }

        if (!chooose) {
            showSnackbarWithClose(`Vui lòng chọn bãi đỗ xe`, { variant: 'error' });
            return;
        }

        memberTypeApi
            .updateMemberType({
                ID: item.ID,
                Name: name.trim(),
                Description: description,
            })
            .then(() => {
                handleReload();
                showSnackbarWithClose(`Cập nhật ${nameDialog} thành công`, { variant: 'success' });
                handleClose();
            })
            .catch((error) => {
                if (Array.isArray(error?.response?.data?.message)) {
                    error?.response?.data?.message.forEach((item: any) => {
                        showSnackbarWithClose(item, {
                            variant: 'error',
                        });
                    });
                } else {
                    showSnackbarWithClose(
                        error?.response ? error.response.data?.message : error.message,
                        {
                            variant: 'error',
                        }
                    );
                }
            });
    };
    useEffect(() => {
        if (open) {
            setName(item.Name);
            setDescription(item.Description || '');
        }
    }, [open]);

    return (
        <Dialog
            fullScreen={fullScreen}
            open={open}
            onClose={() => setOpenComfirm(true)}
            aria-labelledby="responsive-dialog-title"
            sx={{
                '& .MuiPaper-root': {
                    md: { minWidth: '500px', borderRadius: '16px' },
                },
            }}
        >
            <DialogTitle>{'Chỉnh sửa loại khách'}</DialogTitle>
            <DialogContent>
                <Stack py={2} spacing={2}>
                    <Stack>
                        <InputLabel required>Tên</InputLabel>
                        <StyledOutlinedInput
                            autoComplete="off"
                            value={name}
                            onChange={(e) => {
                                setName(e.target.value);
                            }}
                            size="small"
                            fullWidth
                        />
                    </Stack>
                    <Stack>
                        <InputLabel>Mô tả</InputLabel>
                        <StyledOutlinedInput
                            autoComplete="off"
                            value={description}
                            onChange={(e) => {
                                setDescription(e.target.value);
                            }}
                            size="small"
                            fullWidth
                            multiline
                            rows={4}
                        />
                    </Stack>
                </Stack>
            </DialogContent>
            <DialogActions
                sx={{
                    px: 3,
                    pb: 3,
                }}
            >
                <StyleButton variant="contained" onClick={handleUpdateMemberType}>
                    Cập nhật
                </StyleButton>
            </DialogActions>
            {openComfirm ? (
                <ComfirmCloseDialog
                    close={() => setOpenComfirm(false)}
                    action={() => {
                        setOpenComfirm(false);
                        handleClose();
                    }}
                />
            ) : (
                <></>
            )}
        </Dialog>
    );
}
