import { customerApi } from '@/api/customer-api';
import { companyApi } from '@/api/index';
import InputAddress from '@/components/common/input/input-address';
import InputUploadImage from '@/components/common/input/input-upload-image';
import { StyleButton, StyledOutlinedInput } from '@/components/common/style-component';
import { showSnackbarWithClose } from '@/hooks/useSnackbarWithClose';
import { CompanyModel, CustomerModel } from '@/models/index';
import { handleCompressImage, theme } from '@/ultis/index';
import {
    Dialog,
    DialogActions,
    DialogContent,
    DialogTitle,
    InputLabel,
    MenuItem,
    Select,
    Stack,
    useMediaQuery,
} from '@mui/material';
import { enqueueSnackbar } from 'notistack';
import { useEffect, useState } from 'react';
import { ComfirmCloseDialog } from '../dialog-comfirm-close';
const BACKEND_DOMAIN = process.env.NEXT_PUBLIC_SERVER_PARKING_DOMAIN;

export interface IDialogUpdateCustomerProps {
    open: boolean;
    handleClose: () => void;
    handleReload?: () => void;
    customer: CustomerModel;
}

const ITEM_HEIGHT = 48;
const ITEM_PADDING_TOP = 8;

export default function DialogUpdateCustomer(props: IDialogUpdateCustomerProps) {
    const { open, handleClose, handleReload, customer } = props;
    const fullScreen = useMediaQuery(theme.breakpoints.down('md'));
    const [phone, setPhone] = useState('');
    const [name, setName] = useState('');
    const [email, setEmail] = useState('');
    const [avatar, setAvatar] = useState<File | null>(null);
    const [company, setCompany] = useState('');
    const [province, setProvince] = useState<string>('');
    const [district, setDistrict] = useState<string>('');
    const [ward, setWard] = useState<string>('');
    const [address, setAddress] = useState<string>('');
    const [listCompany, setListCompany] = useState<CompanyModel[]>([]);
    const [isFetchAddressFirst, setIsFetchAddressFirst] = useState<boolean>(false);
    const [totalRecords, setTotalRecords] = useState<number>(0);
    const [openComfirm, setOpenComfirm] = useState(false);

    const handleUpdateCustomer = async () => {
        if (!name || name.trim() === '') {
            showSnackbarWithClose('Vui lòng nhập họ tên', { variant: 'error' });
            return;
        }
        if (!phone || phone.trim() === '') {
            showSnackbarWithClose('Vui lòng nhập số điện thoại', { variant: 'error' });
            return;
        }
        // const payload = {
        //     PhoneNumber: phone,
        //     FullName: name,
        //     Email: email,
        // };
        // form data
        const payload = new FormData();
        payload.append('ID', customer.ID);

        payload.append('PhoneNumber', phone.trim());
        payload.append('FullName', name.trim());
        if (email) payload.append('Email', email.trim());

        if (avatar) {
            const imageCompress = await handleCompressImage(avatar);
            payload.append('files', imageCompress, avatar.name);
        }
        payload.append('CompanyId', company);
        payload.append('Province', province);
        payload.append('District', district);
        payload.append('Wards', ward);
        payload.append('Address', address.trim());
        try {
            const { data } = await customerApi.updateCustomer(payload);
            showSnackbarWithClose('Cập nhật người dùng thành công', { variant: 'success' });
            handleReload && handleReload();
            handleClose();
        } catch (error: any) {
            if (Array.isArray(error?.response?.data?.message)) {
                error?.response?.data?.message.forEach((item: any) => {
                    showSnackbarWithClose(item, {
                        variant: 'error',
                    });
                });
            } else {
                showSnackbarWithClose(
                    error?.response ? error.response.data?.message : error.message,
                    {
                        variant: 'error',
                    }
                );
            }
        }
    };
    useEffect(() => {
        if (open) {
            setName(customer.FullName);
            setPhone(customer.PhoneNumber);
            setEmail(customer.Email || '');
            setAvatar(null);
            setCompany(customer.CompanyId?.ID || '');
            setProvince(customer.Province || '');
            setDistrict(customer.District || '');
            setWard(customer.Wards || '');
            setAddress(customer.Address || '');
            setIsFetchAddressFirst(true);
            companyApi.getAllCompany({ Current: 0, Limit: 10, TextSearch: '' }).then((res) => {
                if (res.data) {
                    setListCompany(res.data?.Data);
                    setTotalRecords(res.data?.Total);
                }
            });
        } else {
            setIsFetchAddressFirst(false);
        }
    }, [open]);
    const MenuProps = {
        PaperProps: {
            style: {
                maxHeight: ITEM_HEIGHT * 4.5 + ITEM_PADDING_TOP,
                width: 250,
            },
            onScroll: (e: any) => {
                if (
                    e.currentTarget.scrollHeight - e.currentTarget.scrollTop ===
                    e.currentTarget.clientHeight
                ) {
                    if (totalRecords > listCompany.length) {
                        companyApi
                            .getAllCompany({
                                TextSearch: '',
                                Current: listCompany.length,
                                Limit: 10,
                            })
                            .then((res) => {
                                const { data } = res;
                                const newData = [...listCompany, ...data.Data];
                                setListCompany(newData);
                            });
                    }
                }
            },
        },
    };
    return (
        <Dialog
            fullScreen={fullScreen}
            open={open}
            onClose={() => setOpenComfirm(true)}
            aria-labelledby="responsive-dialog-title"
            sx={{
                '& .MuiDialog-paper': {
                    minWidth: '600px',
                    borderRadius: '16px',
                },
            }}
        >
            <DialogTitle>{'Chỉnh sửa thông tin khách hàng'}</DialogTitle>
            <DialogContent>
                <Stack py={2} spacing={2}>
                    <InputUploadImage
                        avatar={avatar}
                        setAvatar={setAvatar}
                        urlInit={customer.Avatar ? BACKEND_DOMAIN + customer.Avatar : undefined}
                    />
                    <Stack>
                        <InputLabel required>Họ tên</InputLabel>
                        <StyledOutlinedInput
                            autoComplete="off"
                            value={name}
                            onChange={(e) => {
                                setName(e.target.value);
                            }}
                            size="small"
                            fullWidth
                        />
                    </Stack>

                    <Stack>
                        <InputLabel required>Số điện thoại</InputLabel>
                        <StyledOutlinedInput
                            value={phone}
                            onChange={(e) => {
                                setPhone(e.target.value);
                            }}
                            size="small"
                            fullWidth
                        />
                    </Stack>
                    <Stack>
                        <InputLabel>Email</InputLabel>
                        <StyledOutlinedInput
                            autoComplete="off"
                            value={email}
                            onChange={(e) => {
                                setEmail(e.target.value);
                            }}
                            size="small"
                            fullWidth
                        />
                    </Stack>
                    <Stack>
                        <InputLabel>Công ty</InputLabel>
                        <Select
                            fullWidth
                            size="small"
                            sx={{
                                borderRadius: '10px',
                            }}
                            value={company}
                            onChange={(e) => setCompany(e.target.value as string)}
                            MenuProps={MenuProps}
                        >
                            {listCompany &&
                                listCompany.map((item, index) => (
                                    <MenuItem key={index} value={item.ID}>
                                        {item.Name}
                                    </MenuItem>
                                ))}
                        </Select>
                    </Stack>

                    <InputAddress
                        selectedProvince={province}
                        selectedDistrict={district}
                        selectedWard={ward}
                        setSelectedProvince={setProvince}
                        setSelectedDistrict={setDistrict}
                        setSelectedWard={setWard}
                        isFetchAddressFirst={isFetchAddressFirst}
                    />

                    <Stack>
                        <InputLabel>Địa chỉ</InputLabel>
                        <StyledOutlinedInput
                            autoComplete="off"
                            value={address}
                            onChange={(e) => {
                                setAddress(e.target.value);
                            }}
                            size="small"
                            fullWidth
                        />
                    </Stack>
                </Stack>
            </DialogContent>
            <DialogActions
                sx={{
                    px: 3,
                    pb: 3,
                }}
            >
                <StyleButton variant="contained" onClick={handleUpdateCustomer}>
                    Cập nhật
                </StyleButton>
            </DialogActions>
            {openComfirm ? (
                <ComfirmCloseDialog
                    close={() => setOpenComfirm(false)}
                    action={() => {
                        setOpenComfirm(false);
                        handleClose();
                    }}
                />
            ) : (
                <></>
            )}
        </Dialog>
    );
}
