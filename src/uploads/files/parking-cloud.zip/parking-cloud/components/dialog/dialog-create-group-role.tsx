import { groupRoleApi } from '@/api/index';
import { keyRoleApi } from '@/api/key-role-api';
import { useAppSelector } from '@/hooks/index';
import { KeyRoleItemMenuModel } from '@/models/index';
import { convertToSlug, theme } from '@/ultis/index';
import {
    Dialog,
    DialogActions,
    DialogContent,
    DialogTitle,
    InputLabel,
    Stack,
    Typography,
    useMediaQuery,
} from '@mui/material';
import Grid2 from '@mui/material/Unstable_Grid2';
import { enqueueSnackbar } from 'notistack';
import { useEffect, useState } from 'react';
import ListRole from '../common/list-check/list-role';
import { StyledOutlinedInput } from '../common/style-component';
import { StyleButton } from '../common/style-component/button';
import { showSnackbarWithClose } from '@/hooks/useSnackbarWithClose';
import { LoadingButton } from '@mui/lab';
import { ComfirmCloseDialog } from './dialog-comfirm-close';

export interface IDialogAddGroupRoleProps {
    open: boolean;
    handleClose: () => void;
    handleReload?: () => void;
}

export default function DialogAddGroupRole(props: IDialogAddGroupRoleProps) {
    const { open, handleClose, handleReload } = props;
    const [keyRoles, setKeyRoles] = useState([]);
    const [name, setName] = useState('');
    const [key, setKey] = useState('');
    const [description, setDescription] = useState('');
    const [loading, setLoading] = useState(false);

    const nameDialog = 'nhóm quyền';
    const [checked, setChecked] = useState<KeyRoleItemMenuModel[]>([]);
    const idCustomer = useAppSelector((state) => state.common.profile?.CustomerId?.ID);
    const [openComfirm, setOpenComfirm] = useState(false);

    const fullScreen = useMediaQuery(theme.breakpoints.down('md'));
    useEffect(() => {
        keyRoleApi.getKeyRole().then((res) => {
            setKeyRoles(res.data);
        });
    }, []);
    const handleSetChecked = (checkedItem: KeyRoleItemMenuModel) => {
        const updatedChecked = checked.map((item) => {
            if (item.KeyRoleId === checkedItem.KeyRoleId) {
                if (checkedItem.IsInsert || checkedItem.IsUpdate || checkedItem.IsDelete) {
                    checkedItem.IsRead = true;
                }
                return {
                    ...checkedItem,
                };
            }
            return item;
        });
        setChecked(updatedChecked);
    };

    // handle reset checked
    const handleResetChecked = () => {
        setChecked(
            keyRoles.map((item: any) => {
                return {
                    KeyRoleId: item.ID,
                    Name: item.Name.trim(),
                    IsCloud: item.IsCloud,
                    IsDelete: false,
                    IsUpdate: false,
                    IsRead: false,
                    IsInsert: false,
                };
            })
        );
    };
    // reset name and checked when close dialog
    useEffect(() => {
        if (!open) {
            setName('');
            handleResetChecked();
        }
    }, [open]);
    useEffect(() => {
        //default checked
        if (keyRoles.length === 0) return;
        handleResetChecked();
    }, [keyRoles]);
    const handleCreate = async () => {
        if (name === '') {
            showSnackbarWithClose('Tên nhóm quyền không được để trống', {
                variant: 'error',
            });
            return;
        }

        setLoading(true);
        const payload: any = {
            Name: name,
            Key: key,
            SystemRole: checked,
            CustomerId: idCustomer,
            Description: description,
        };
        groupRoleApi
            .createGroupRole(payload)
            .then(() => {
                showSnackbarWithClose(`Tạo ${nameDialog} thành công`, {
                    variant: 'success',
                });
                handleReload && handleReload();
                handleClose();
            })
            .catch((error) => {
                if (Array.isArray(error?.response?.data?.message)) {
                    error?.response?.data?.message.forEach((item: any) => {
                        showSnackbarWithClose(item, {
                            variant: 'error',
                        });
                    });
                } else {
                    showSnackbarWithClose(
                        error?.response ? error.response.data?.message : error.message,
                        {
                            variant: 'error',
                        }
                    );
                }
            })
            .finally(() => {
                setTimeout(() => {
                    setLoading(false);
                }, 1000);
            });
    };
    return (
        <Dialog
            fullScreen={fullScreen}
            open={open}
            onClose={() => {
                if (name) {
                    setOpenComfirm(true);
                } else {
                    handleClose();
                }
            }}
            aria-labelledby="responsive-dialog-title"
            sx={{
                '& .MuiPaper-root': {
                    md: { minWidth: '500px', borderRadius: '16px' },
                },
            }}
        >
            <DialogTitle>{`Tạo ${nameDialog} mới`}</DialogTitle>
            <DialogContent>
                <Stack py={2} spacing={2}>
                    <Grid2 container spacing={2}>
                        <Grid2 xs={6} sm={9}>
                            <Stack>
                                <InputLabel>Tên nhóm quyền*</InputLabel>
                                <StyledOutlinedInput
                                    value={name}
                                    autoComplete="off"
                                    onChange={(e) => {
                                        setName(e.target.value);
                                        setKey(
                                            e.target.value
                                                ? convertToSlug(
                                                      e.target.value
                                                  ).toLocaleUpperCase() +
                                                      '_' +
                                                      new Date().getTime()
                                                : ''
                                        );
                                    }}
                                    size="small"
                                    fullWidth
                                />
                            </Stack>
                        </Grid2>
                        <Grid2 xs={6} sm={3}>
                            <Stack>
                                <InputLabel>Key*</InputLabel>
                                <StyledOutlinedInput
                                    autoComplete="off"
                                    value={key}
                                    onChange={(e) => {
                                        setKey(e.target.value);
                                    }}
                                    size="small"
                                    fullWidth
                                    disabled
                                />
                            </Stack>
                        </Grid2>
                    </Grid2>

                    <Grid2 container spacing={2}>
                        <Grid2 xs={12} sm={6}>
                            <Stack spacing={1}>
                                <Typography variant="subtitle2">Client</Typography>
                                {checked
                                    .filter((item) => {
                                        return !item.IsCloud;
                                    })
                                    .map((item: KeyRoleItemMenuModel, index) => (
                                        <ListRole
                                            key={index}
                                            keyRoleItem={item}
                                            handleSetCHecked={handleSetChecked}
                                        />
                                    ))}
                            </Stack>
                        </Grid2>
                        <Grid2 xs={12} sm={6}>
                            <Stack spacing={1}>
                                <Typography variant="subtitle2">Cloud</Typography>
                                {checked
                                    .filter((item) => {
                                        return item.IsCloud;
                                    })
                                    .map((item: KeyRoleItemMenuModel, index) => (
                                        <ListRole
                                            key={index}
                                            keyRoleItem={item}
                                            handleSetCHecked={handleSetChecked}
                                        />
                                    ))}
                            </Stack>
                        </Grid2>
                    </Grid2>
                    <Stack>
                        <InputLabel>Mô tả</InputLabel>
                        <StyledOutlinedInput
                            autoComplete="off"
                            value={description}
                            onChange={(e) => {
                                setDescription(e.target.value);
                            }}
                            size="small"
                            label="Mô tả"
                            fullWidth
                            multiline
                            rows={4}
                        />
                    </Stack>
                </Stack>
            </DialogContent>

            <DialogActions
                sx={{
                    px: 3,
                    pb: 3,
                }}
            >
                <LoadingButton
                    sx={{
                        color: '#fff',
                        padding: '10px 30px',
                        backgroundColor: '#FFB862',
                        borderRadius: '10px',
                        '&:hover': {
                            backgroundColor: 'rgba(255, 184, 98, 0.9)',
                        },
                    }}
                    loading={loading}
                    onClick={() => handleCreate()}
                >
                    <Typography sx={{ color: '#fff', fontSize: '14px', fontWeight: '700' }}>
                        Tạo mới
                    </Typography>
                </LoadingButton>
            </DialogActions>
            {openComfirm ? (
                <ComfirmCloseDialog
                    close={() => setOpenComfirm(false)}
                    action={() => {
                        setOpenComfirm(false);
                        handleClose();
                    }}
                />
            ) : (
                <></>
            )}
        </Dialog>
    );
}
