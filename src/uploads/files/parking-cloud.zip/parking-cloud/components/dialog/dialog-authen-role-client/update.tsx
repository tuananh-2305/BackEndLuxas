import { AuthenKeyApi, KeyClientApi, parkingApi } from '@/api/index';
import TextFieldForm from '@/components/common/input/text-field-form/text-field-form';
import { useAppSelector } from '@/hooks/index';
import { showSnackbarWithClose } from '@/hooks/useSnackbarWithClose';
import {
    AuthenRoleClientInterface,
    AuthenRoleClientItem,
    ParkingModel,
} from '@/models/authen-role-client';
import {
    Checkbox,
    FormControlLabel,
    FormGroup,
    Grid,
    InputLabel,
    MenuItem,
    Select,
    Stack,
    useTheme,
} from '@mui/material';
import Button from '@mui/material/Button';
import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import DialogTitle from '@mui/material/DialogTitle';
import InputBase from '@mui/material/InputBase';
import { styled } from '@mui/material/styles';
import { useEffect, useState } from 'react';
import { ComfirmCloseDialog } from '../dialog-comfirm-close';
export interface IDialogUpdateAuthenRoleClientProps {
    open: boolean;
    handleClose: () => void;
    handleReload: () => void;
    item: AuthenRoleClientItem;
}
const BootstrapInput = styled(InputBase)(({ theme }) => ({
    '& .MuiInputBase-input': {
        borderRadius: 4,
        position: 'relative',
        backgroundColor: '#fff',
        borderColor: theme.palette.primary.main,
        borderWidth: '1px',
        borderStyle: 'solid',
        fontSize: 16,
        padding: '8px 26px 8px 12px',
        transition: theme.transitions.create(['border-color', 'box-shadow']),
        '&:focus': {
            borderRadius: 4,
            borderColor: theme.palette.primary.main,
        },
    },
}));

export default function DialogUpdateAuthenRoleClient(props: IDialogUpdateAuthenRoleClientProps) {
    const { handleClose, handleReload, item } = props;
    const parkingChoose = useAppSelector((state) => state.parking.choose);
    const [openComfirm, setOpenComfirm] = useState(false);
    //
    const [name, setName] = useState('');
    const [cardNumber, setCardNumber] = useState('');
    const [parking, setParking] = useState<string>('');
    const [parkingList, setParkingList] = useState<ParkingModel[]>([]);
    const [keyRoleClientList, setkeyRoleClientList] = useState<AuthenRoleClientInterface[]>([]);
    const [keyRoleClientCheckList, setkeyRoleClientCheckList] = useState<any[]>([]);
    // console.log(item);
    useEffect(() => {
        if (item) {
            setName(item.Name);
            setCardNumber(item.CardNumber);
            setParking(item.ParkingId?.ID ?? '');
            setkeyRoleClientCheckList(item.SystemRole);
        }
    }, []);

    const handleChangeParking = (event: any) => {
        setParking(event.target.value);
    };

    const getAllParking = async () => {
        await parkingApi.getAllParking().then((res) => {
            setParkingList(res.data);
        });
    };

    const getKeyRoleClient = async () => {
        await KeyClientApi.getKeyClient().then((res) => {
            var data = res.data.map((value: AuthenRoleClientInterface) => {
                var ids = item.SystemRole.map((v) => v.KeySettingId?.ID);
                var index = ids.indexOf(value.ID);

                return {
                    ...value,
                    IsUse: index != -1 ? item.SystemRole[index].IsUse : false,
                };
            });

            setkeyRoleClientList(data);
        });
    };

    const handleChangeAuthenKey = (event: any) => {
        var id = event.target.value;

        var arr = [...keyRoleClientList];
        var ids = arr.map((v) => v.ID);
        var index = ids.indexOf(id);

        if (index != -1) {
            arr[index].IsUse = event.target.checked;
            setkeyRoleClientList(arr);
        }
    };

    // KeyClientApi
    useEffect(() => {
        getAllParking();
        getKeyRoleClient();
    }, []);
    const submit = () => {
        if (!parkingChoose) {
            return;
        }
        if (!name || name.trim() === '') {
            showSnackbarWithClose('Vui lòng nhập tên', {
                variant: 'error',
            });
            return;
        }
        if (!cardNumber || cardNumber.trim() === '') {
            showSnackbarWithClose('Vui lòng nhập số thẻ', {
                variant: 'error',
            });
            return;
        }
        if (!parking || parking.trim() === '') {
            showSnackbarWithClose('Vui lòng chọn bãi xe', {
                variant: 'error',
            });
            return;
        }
        const payload = {
            KeyRoleClientId: keyRoleClientCheckList
                .map((v) => {
                    const index = keyRoleClientList.filter(
                        (item) => item.ID === v.KeyRoleClientId?.ID
                    );
                    if (index.length > 0 && index[0].IsUse !== v.IsUse) {
                        return {
                            ID: v.ID,
                            IsUse: index[0].IsUse,
                        };
                    }
                    return null;
                })
                .filter((item) => item !== null),
            Name: name,
            CardNumber: cardNumber,
            ParkingId: parking,
            ID: item.ID,
        };

        AuthenKeyApi.updateKeyClient(payload)
            .then(() => {
                showSnackbarWithClose('Cập nhật thành công', {
                    variant: 'success',
                });
                handleClose();
                handleReload();
            })
            .catch((error) => {
                if (Array.isArray(error?.response?.data?.message)) {
                    error?.response?.data?.message.forEach((item: any) => {
                        showSnackbarWithClose(item, {
                            variant: 'error',
                        });
                    });
                } else {
                    showSnackbarWithClose(
                        error?.response ? error.response.data?.message : error.message,
                        {
                            variant: 'error',
                        }
                    );
                }
            });
    };
    const theme = useTheme();
    return (
        <Dialog
            open={props.open}
            onClose={handleClose}
            aria-labelledby="alert-dialog-title"
            aria-describedby="alert-dialog-description"
            maxWidth={'sm'}
            fullWidth
        >
            <DialogTitle id="alert-dialog-title">{'Cập nhật quyền cấu hình bãi xe'}</DialogTitle>
            <DialogContent>
                <TextFieldForm
                    lable={'Tên'}
                    value={name}
                    onChange={(e) => {
                        const { value } = e.target;
                        setName(value);
                    }}
                />
                <Stack sx={{ py: '5px' }} />
                <TextFieldForm
                    lable={'Số thẻ'}
                    value={cardNumber}
                    onChange={(e) => {
                        const { value } = e.target;
                        setCardNumber(value);
                    }}
                />
                {/* parking */}
                <Stack sx={{ my: '15px' }}>
                    <InputLabel id="demo-select-small-label">Bãi xe</InputLabel>
                    <Select
                        labelId="demo-select-small-label"
                        id="demo-select-small"
                        value={parking}
                        onChange={handleChangeParking}
                        input={<BootstrapInput />}
                    >
                        {parkingList.length > 0 &&
                            parkingList.map((item: ParkingModel, index) => {
                                return (
                                    <MenuItem key={index} value={item.ID}>
                                        {item.Name}
                                    </MenuItem>
                                );
                            })}
                    </Select>
                </Stack>

                {/* keyRoleClientList  */}
                <FormGroup>
                    <InputLabel id="demo-select-small-label">Key client</InputLabel>
                    <Grid container>
                        {keyRoleClientList &&
                            keyRoleClientList.length > 0 &&
                            keyRoleClientList.map((item: AuthenRoleClientInterface, index) => {
                                return (
                                    <Grid item xs={6} key={index}>
                                        <FormControlLabel
                                            control={
                                                <Checkbox
                                                    value={item.ID}
                                                    checked={item.IsUse}
                                                    sx={{
                                                        color: '#55595D90',
                                                    }}
                                                />
                                            }
                                            label={item.Name}
                                            onChange={handleChangeAuthenKey}
                                            sx={{
                                                color: '#55595D',
                                            }}
                                        />
                                    </Grid>
                                );
                            })}
                    </Grid>
                </FormGroup>
            </DialogContent>

            {/* action */}
            <DialogActions sx={{ gap: '10px', mr: '20px', mb: '10px' }}>
                <Button
                    onClick={handleClose}
                    variant="contained"
                    sx={{
                        background: '#CDD2D1',
                        ':hover': {
                            background: '#DBE8E1',
                        },
                        fontSize: '14px',
                        fontWeight: '500',
                        borderRadius: '6px',
                        textTransform: 'revert-layer',
                    }}
                >
                    Hủy
                </Button>
                <Button
                    onClick={submit}
                    variant="contained"
                    sx={{
                        background: '#007DC0',
                        ':hover': {
                            background: '#009FD0',
                        },
                        fontSize: '14px',
                        fontWeight: '500',
                        textTransform: 'revert-layer',
                        borderRadius: '6px',
                    }}
                    autoFocus
                >
                    Cập nhật
                </Button>
            </DialogActions>
            {openComfirm ? (
                <ComfirmCloseDialog
                    close={() => setOpenComfirm(false)}
                    action={() => {
                        setOpenComfirm(false);
                        handleClose();
                    }}
                />
            ) : (
                <></>
            )}
        </Dialog>
    );
}
