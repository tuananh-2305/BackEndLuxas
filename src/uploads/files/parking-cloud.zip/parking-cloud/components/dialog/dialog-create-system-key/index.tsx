import { systemRoleApi } from '@/api/key-system-role';
import TextFieldForm from '@/components/common/input/text-field-form/text-field-form';
import { useAppSelector } from '@/hooks/useReudx';
import { showSnackbarWithClose } from '@/hooks/useSnackbarWithClose';
import {
    Button,
    Checkbox,
    Dialog,
    DialogActions,
    DialogContent,
    DialogTitle,
    Stack,
    Typography,
} from '@mui/material';
import { useState } from 'react';
import { ComfirmCloseDialog } from '../dialog-comfirm-close';

export interface IDialogCreateKeySystemCloud {
    open: boolean;
    handleClose: () => void;
    handleReload: () => void;
}

export const DialogCreateKeySystemCloud = (props: IDialogCreateKeySystemCloud) => {
    const { handleClose, handleReload } = props;
    const parkingChoose = useAppSelector((state) => state.parking.choose);
    const [name, setName] = useState('');
    const [keyWork, setKeyWork] = useState('');
    const [isValue, setIsValue] = useState(false);
    const [openComfirm, setOpenComfirm] = useState(false);

    const submit = () => {
        if (!parkingChoose) {
            return;
        }
        if (!name || name.trim() === '') {
            showSnackbarWithClose('Vui lòng nhập tên', {
                variant: 'error',
            });
            return;
        }
        if (!keyWork || keyWork.trim() === '') {
            showSnackbarWithClose('Vui lòng nhập key', {
                variant: 'error',
            });
            return;
        }

        const payload: {
            Name: string;
            KeyWord: string;
            IsValue: boolean;
        } = {
            KeyWord: keyWork,
            Name: name,
            IsValue: isValue,
        };

        systemRoleApi
            .createRole(payload)
            .then(() => {
                showSnackbarWithClose('Tạo mới thành công', {
                    variant: 'success',
                });
                setName('');
                setKeyWork('');
                handleClose();
                handleReload();
            })
            .catch((error) => {
                if (Array.isArray(error?.response?.data?.message)) {
                    error?.response?.data?.message.forEach((item: any) => {
                        showSnackbarWithClose(item, {
                            variant: 'error',
                        });
                    });
                } else {
                    showSnackbarWithClose(
                        error?.response ? error.response.data?.message : error.message,
                        {
                            variant: 'error',
                        }
                    );
                }
            });
    };

    return (
        <Dialog
            open={props.open}
            onClose={handleClose}
            aria-labelledby="alert-dialog-title"
            aria-describedby="alert-dialog-description"
            maxWidth={'sm'}
            fullWidth
        >
            <DialogTitle id="alert-dialog-title">Tạo mới key system</DialogTitle>
            <DialogContent>
                <Stack sx={{ gap: '10px' }}>
                    <TextFieldForm
                        lable={'Tên'}
                        value={name}
                        onChange={(e) => {
                            const { value } = e.target;
                            setName(value);
                        }}
                    />

                    <TextFieldForm
                        lable={'Key'}
                        value={keyWork}
                        onChange={(e) => {
                            const { value } = e.target;
                            setKeyWork(value);
                        }}
                    />

                    <Stack direction="row" alignItems="center">
                        <Checkbox
                            size="small"
                            color="info"
                            checked={isValue}
                            onChange={(e) => {
                                const { checked } = e.target;

                                setIsValue(checked);
                            }}
                        />
                        <Typography>Loại chuỗi</Typography>
                    </Stack>
                </Stack>
            </DialogContent>
            <DialogActions sx={{ gap: '10px', mr: '20px', mb: '10px' }}>
                <Button
                    onClick={handleClose}
                    variant="contained"
                    sx={{
                        background: '#CDD2D1',
                        ':hover': {
                            background: '#DBE8E1',
                        },
                        fontSize: '14px',
                        fontWeight: '500',
                        borderRadius: '6px',
                        textTransform: 'revert-layer',
                    }}
                >
                    Hủy
                </Button>
                <Button
                    onClick={submit}
                    variant="contained"
                    sx={{
                        background: '#007DC0',
                        ':hover': {
                            background: '#009FD0',
                        },
                        fontSize: '14px',
                        fontWeight: '500',
                        textTransform: 'revert-layer',
                        borderRadius: '6px',
                    }}
                    autoFocus
                >
                    Tạo mới
                </Button>
            </DialogActions>
            {openComfirm ? (
                <ComfirmCloseDialog
                    close={() => setOpenComfirm(false)}
                    action={() => {
                        setOpenComfirm(false);
                        handleClose();
                    }}
                />
            ) : (
                <></>
            )}
        </Dialog>
    );
};
