import KeyboardArrowDownIcon from '@mui/icons-material/KeyboardArrowDown';
import { Stack, Typography, TextField, Popover } from '@mui/material';
import { useRef, useState } from 'react';
import { CasePaymentSelect } from './case-payment-select';
import { useAppSelector } from '@/hooks/useReudx';
import { memberApi } from '@/api/member-api';
import { formatVNDversion2 } from '@/ultis/global-func';
import { PAYMENT_METHOD } from '@/constants/global';

interface DialogPaymentHistoryProps {
    close: () => void;
    item: any;
    option: 'upComing' | 'history';
}
export const DialogPaymentHistory = (props: DialogPaymentHistoryProps) => {
    const { close, item, option } = props;

    const choose = useAppSelector((state) => state.parking.choose);
    const [description, setDescripton] = useState('');
    const [casePay, setCasePay] = useState<'MONEY' | 'MOMO' | 'NAPAS'>('MONEY');
    // console.log('data : ', item);
    return (
        <Stack
            sx={{ position: 'fixed', top: '0', bottom: '0', left: '0', right: '0', zIndex: 10 }}
            alignItems="center"
            justifyContent="center"
        >
            <Stack
                sx={{
                    position: 'absolute',
                    width: '100%',
                    height: '100%',
                    backgroundColor: '#55595D90',
                    zIndex: 2,
                }}
                onClick={() => close()}
            />

            <Stack
                sx={{
                    position: 'absolute',
                    zIndex: 3,
                    width: '400px',
                    height: 'fit-content',
                    backgroundColor: '#fff',
                    borderRadius: '10px',
                    boxShadow: '0px 4px 4px 0px rgba(0, 0, 0, 0.25)',
                    padding: '25px',
                    gap: '20px',
                }}
            >
                <Stack>
                    <Typography sx={{ color: '#55595D', fontSize: '14px' }}>
                        {choose?.Name}
                    </Typography>
                    <Typography
                        sx={{
                            color: '#55595D',
                            fontSize: '12px',
                            fontStyle: 'italic',
                            fontWeight: 300,
                        }}
                    >
                        {choose?.Address ? `(${choose?.Address})` : ''}
                    </Typography>
                </Stack>
                <Stack sx={{ border: '1px dashed #D9D9D9' }} />
                <Stack direction="row" justifyContent="space-between">
                    <Typography sx={{ color: '#55595D', fontSize: '13px' }}>
                        Tên khách hàng
                    </Typography>
                    <Typography sx={{ fontSize: '13px' }}>{item.MemberName}</Typography>
                </Stack>
                <Stack direction="row" justifyContent="space-between">
                    <Typography sx={{ color: '#55595D', fontSize: '13px' }}>Biển số</Typography>
                    <Typography sx={{ fontSize: '13px' }}>{item.PlateNumber}</Typography>
                </Stack>

                {item.VehicleTypeId ? (
                    <Stack direction="row" justifyContent="space-between">
                        <Typography sx={{ color: '#55595D', fontSize: '13px' }}>Loại xe</Typography>
                        <Typography sx={{ fontSize: '13px' }}>
                            {item.VehicleTypeId?.Name}
                        </Typography>
                    </Stack>
                ) : (
                    <></>
                )}

                <Stack direction="row" justifyContent="space-between">
                    <Typography sx={{ color: '#55595D', fontSize: '13px' }}>Lý do</Typography>
                    <Typography sx={{ fontSize: '13px' }}>Thanh toán phí gửi xe tháng</Typography>
                </Stack>
                <Stack direction="row" justifyContent="space-between">
                    <Typography sx={{ color: '#55595D', fontSize: '13px' }}>Số tiền</Typography>
                    <Typography sx={{ fontSize: '13px' }}>
                        {`${formatVNDversion2(item.MonthlyPrice)} VNĐ`}
                    </Typography>
                </Stack>

                {option === 'history' ? (
                    <Stack direction="row" justifyContent="space-between">
                        <Typography sx={{ color: '#55595D', fontSize: '13px' }}>
                            Phương thức thanh toán
                        </Typography>
                        <Typography sx={{ fontSize: '13px' }}>
                            {PAYMENT_METHOD.filter((v) => v.key === casePay)[0].value}
                        </Typography>
                    </Stack>
                ) : (
                    <></>
                )}

                {option === 'history' ? (
                    <Stack direction="row" justifyContent="space-between">
                        <Typography sx={{ color: '#55595D', fontSize: '13px' }}>Mô tả</Typography>
                        <Typography sx={{ fontSize: '13px' }}>{description}</Typography>
                    </Stack>
                ) : (
                    <></>
                )}

                <Stack
                    sx={{
                        width: '100%',
                        padding: '20px',
                        borderRadius: '10px',
                        border: '1px dashed #D9D9D9',
                    }}
                >
                    <Typography
                        sx={{
                            fontWeight: 700,
                            fontSize: '36px',
                            textAlign: 'center',
                            textShadow: '0px 4px 4px 0px rgba(0, 0, 0, 0.25)',
                            color: '#55595D',
                        }}
                    >
                        {`${formatVNDversion2(item.MonthlyPrice)} VNĐ`}
                    </Typography>
                </Stack>

                {option === 'upComing' ? (
                    <>
                        <CasePaymentSelect
                            casePay={casePay}
                            change={(casePay) => setCasePay(casePay)}
                        />
                        <TextField
                            multiline
                            rows={3}
                            placeholder="Mô tả giao dịch"
                            onChange={(e) => {
                                const { value } = e.target;
                                setDescripton(value);
                            }}
                        />

                        <Stack
                            sx={{
                                backgroundColor: '#FFB862',
                                padding: '10px',
                                filter: 'drop-shadow(0px 2px 2px rgba(0, 0, 0, 0.25))',
                                borderRadius: '10px',
                                cursor: 'pointer',
                            }}
                            justifyContent="center"
                            alignItems="center"
                            onClick={() => {
                                memberApi
                                    .createPayment({
                                        MemberId: item.MemberId,
                                        PaymentMethods: casePay,
                                        Description: description,
                                        PlateNumber: item.PlateNumber,
                                        TotalMoney: item.MonthlyPrice,
                                    })
                                    .then(() => {
                                        window.location.reload();
                                    });
                            }}
                        >
                            <Typography
                                sx={{
                                    textTransform: 'uppercase',
                                    fontWeight: 700,
                                    fontSize: '14px',
                                    color: '#fff',
                                    borderRadius: '10px',
                                }}
                            >
                                Xác nhận
                            </Typography>
                        </Stack>
                    </>
                ) : (
                    <></>
                )}
            </Stack>
        </Stack>
    );
};
