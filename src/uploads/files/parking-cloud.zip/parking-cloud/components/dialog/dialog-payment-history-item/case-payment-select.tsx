import { Popover, Stack, Typography } from '@mui/material';
import KeyboardArrowDownIcon from '@mui/icons-material/KeyboardArrowDown';
import { useRef, useState } from 'react';
import { PAYMENT_METHOD } from '@/constants/global';

interface CasePaymentSelectProps {
    casePay: 'MONEY' | 'MOMO' | 'NAPAS';
    change: (casePay: 'MONEY' | 'MOMO' | 'NAPAS') => void;
}

export const CasePaymentSelect = (props: CasePaymentSelectProps) => {
    const { casePay, change } = props;
    const [open, setOpen] = useState(false);
    const choose = PAYMENT_METHOD.filter((v) => v.key === casePay);
    const ref = useRef<HTMLDivElement | null>(null);
    return (
        <Stack>
            <Stack
                ref={ref}
                direction="row"
                sx={{
                    padding: '10px',
                    border: '1px solid #D9D9D9',
                    borderRadius: '5px',
                    marginTop: '30px',
                    cursor: 'pointer',
                }}
                onClick={() => setOpen(true)}
                alignItems="center"
            >
                <Typography sx={{ flex: 1, fontSize: '13px' }}>
                    {choose.length === 0 ? 'Hãy chọn một cách thanh toán.' : choose[0].value}
                </Typography>
                <KeyboardArrowDownIcon />
            </Stack>
            <Popover
                open={open}
                anchorEl={ref.current}
                onClose={() => setOpen(false)}
                anchorOrigin={{
                    vertical: 'bottom',
                    horizontal: 'left',
                }}
            >
                <Stack sx={{ width: ref.current?.clientWidth }}>
                    {PAYMENT_METHOD.filter((v) => v.key !== 'ALL').map((v) => {
                        return (
                            <Stack
                                key={`choode-${v.key}`}
                                sx={{
                                    cursor: 'pointer',
                                    '&:hover ': {
                                        transition: 'all ease .3s',
                                        backgroundColor: '#d9d9d980',
                                    },
                                }}
                                onClick={() => {
                                    change(v.key as 'MONEY' | 'MOMO' | 'NAPAS');
                                    setOpen(false);
                                }}
                            >
                                <Typography sx={{ p: 2 }}>{v.value}</Typography>
                            </Stack>
                        );
                    })}
                </Stack>
            </Popover>
        </Stack>
    );
};
