import { deviceApi } from '@/api/index';
import { DeviceCreatePayload, DeviceImeiModel } from '@/models/index';
import { theme } from '@/ultis/index';
import {
    CircularProgress,
    Dialog,
    DialogActions,
    DialogContent,
    DialogTitle,
    InputLabel,
    Stack,
    useMediaQuery,
} from '@mui/material';
import { enqueueSnackbar } from 'notistack';
import { useEffect, useState } from 'react';
import AutoCompoleteImei from '../common/input/autocomplete-imei';
import { StyledOutlinedInput } from '../common/style-component';
import { StyleButton } from '../common/style-component/button';
import { showSnackbarWithClose } from '@/hooks/useSnackbarWithClose';
import { useAppDispatch } from '@/hooks/index';
import { createDevice } from '@/redux/index';
import { green } from '@mui/material/colors';
import { ComfirmCloseDialog } from './dialog-comfirm-close';

export interface IDialogCreateDeviceProps {
    open: boolean;
    handleClose: () => void;
    handleReload?: () => void;
    parkingId: string;
}

export default function DialogCreateDevice(props: IDialogCreateDeviceProps) {
    const { open, handleClose, handleReload, parkingId } = props;
    const fullScreen = useMediaQuery(theme.breakpoints.down('md'));
    const [name, setName] = useState<string>('');
    const [description, setDescription] = useState<string>('');
    const [port, setPort] = useState<number | null>(null);
    const [imei, setImei] = useState<DeviceImeiModel | null>(null);
    const [isLoadingButton, setIsLoadingButton] = useState(false);
    const [openComfirm, setOpenComfirm] = useState(false);
    //reset data when open dialog
    const dispatch = useAppDispatch();

    useEffect(() => {
        if (!open) {
            setName('');
            setDescription('');
            setImei(null);
            setPort(0);
        }
    }, [open]);
    const handleCreateDevice = async () => {
        if (!name || name.trim() === '') {
            showSnackbarWithClose('Tên không được để trống', { variant: 'error' });
            return;
        }

        if (!imei || !imei?.ID) {
            showSnackbarWithClose('Imei không được để trống', { variant: 'error' });
            return;
        }
        if (!port) {
            showSnackbarWithClose('Port không được để trống', { variant: 'error' });
            return;
        }
        setIsLoadingButton(true);
        const payload: DeviceCreatePayload = {
            Name: name.trim(),
            Description: description,
            Imei: imei.ID,
            ParkingId: parkingId,
            // IpAddress: idAdress,
            IsServer: false,
            Port: port.toString(),
        };

        try {
            const { data } = await deviceApi.createDevice(payload);
            const action = createDevice({ data: data });
            dispatch(action);
            showSnackbarWithClose('Tạo thiết bị thành công', { variant: 'success' });
            handleReload && handleReload();
            handleClose();
        } catch (error: any) {
            if (Array.isArray(error?.response?.data?.message)) {
                error?.response?.data?.message.forEach((item: any) => {
                    showSnackbarWithClose(item, {
                        variant: 'error',
                    });
                });
            } else {
                showSnackbarWithClose(
                    error?.response ? error.response.data?.message : error.message,
                    {
                        variant: 'error',
                    }
                );
            }
        }
        setTimeout(() => {
            setIsLoadingButton(false);
        }, 1000);
    };
    return (
        <Dialog
            fullScreen={fullScreen}
            open={open}
            onClose={() => {
                if (name || description || imei || port) {
                    setOpenComfirm(true);
                } else {
                    handleClose();
                }
            }}
            aria-labelledby="responsive-dialog-title"
            sx={{
                '& .MuiPaper-root': {
                    md: { minWidth: '500px', borderRadius: '16px' },
                },
            }}
        >
            <DialogTitle>{'Tạo thiết bị'}</DialogTitle>
            <DialogContent>
                <Stack py={2} spacing={2}>
                    <Stack>
                        <InputLabel required>Tên</InputLabel>
                        <StyledOutlinedInput
                            autoComplete="off"
                            value={name}
                            onChange={(e) => {
                                setName(e.target.value);
                            }}
                            size="small"
                            fullWidth
                        />
                    </Stack>

                    {/* 
                    <InputIP
                        onChange={(value) => {
                            setIdAddress(value);
                        }}
                        setIsValidateIp={setIsValidateIp}
                    /> */}

                    <AutoCompoleteImei setValue={setImei}></AutoCompoleteImei>
                    <Stack>
                        <InputLabel required>port</InputLabel>
                        <StyledOutlinedInput
                            autoComplete="off"
                            value={port}
                            onChange={(e) => {
                                setPort(parseInt(e.target.value));
                            }}
                            type="number"
                            size="small"
                        />
                    </Stack>
                    <Stack>
                        <InputLabel>Mô tả</InputLabel>
                        <StyledOutlinedInput
                            autoComplete="off"
                            value={description}
                            onChange={(e) => {
                                setDescription(e.target.value);
                            }}
                            size="small"
                            fullWidth
                            multiline
                            rows={4}
                        />
                    </Stack>
                </Stack>
            </DialogContent>
            <DialogActions
                sx={{
                    px: 3,
                    pb: 3,
                }}
            >
                <Stack sx={{ m: 1, position: 'relative' }}>
                    <StyleButton
                        variant="contained"
                        onClick={handleCreateDevice}
                        disabled={isLoadingButton}
                    >
                        Tạo mới
                    </StyleButton>
                    {isLoadingButton && (
                        <CircularProgress
                            size={24}
                            sx={{
                                color: green[500],
                                position: 'absolute',
                                top: '50%',
                                left: '50%',
                                marginTop: '-12px',
                                marginLeft: '-12px',
                            }}
                        />
                    )}
                </Stack>
            </DialogActions>
            {openComfirm ? (
                <ComfirmCloseDialog
                    close={() => setOpenComfirm(false)}
                    action={() => {
                        setOpenComfirm(false);
                        handleClose();
                    }}
                />
            ) : (
                <></>
            )}
        </Dialog>
    );
}
