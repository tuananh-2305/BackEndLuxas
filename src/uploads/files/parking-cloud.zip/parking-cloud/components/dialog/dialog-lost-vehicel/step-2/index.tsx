import { Stack, Typography } from '@mui/material';
import Image from 'next/image';

interface ICreateLostVehicelComplete {
    close: () => void;
}

export const CreateLostVehicelComplete = (props: ICreateLostVehicelComplete) => {
    const { close } = props;
    return (
        <>
            <Stack sx={{ position: 'relative' }} justifyContent="flex-end">
                <Image src="/icons/impotant-orange.svg" width={30} height={30} alt="photo" />
                <Image src="/icons/car.svg" width={108} height={70} alt="car-icons" />
            </Stack>

            <Typography
                sx={{
                    color: '#323232',
                    fontSize: '22px',
                    fontStyle: 'normal',
                    fontWeight: 600,
                    lineHeight: 'normal',
                    marginTop: '19px',
                    marginBottom: '32px',
                }}
            >
                Đã ghi nhận mất phương tiện
            </Typography>

            <Stack
                sx={{
                    width: '140px',
                    padding: '12px 16px',
                    gap: '10px',
                    flexShrink: 0,
                    borderRadius: '6px',
                    background: '#007DC0',
                    cursor: 'pointer',
                }}
                justifyContent="center"
                alignItems="center"
                onClick={() => close()}
            >
                <Typography
                    sx={{
                        color: '#FFF',
                        fontSize: '14px',
                        fontStyle: 'normal',
                        fontWeight: 500,
                        lineHeight: 'normal',
                    }}
                >
                    Thoát
                </Typography>
            </Stack>
        </>
    );
};
