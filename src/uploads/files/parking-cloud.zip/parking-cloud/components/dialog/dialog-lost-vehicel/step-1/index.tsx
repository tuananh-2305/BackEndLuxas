import { Stack, Typography } from '@mui/material';
import Image from 'next/image';
import { TableCheckCardOrVehicel } from './table-check';
import { useEffect, useState } from 'react';
import { useAppSelector } from '@/hooks';
import { historyInOutApi } from '@/api/index';
import { memberVehicleApi } from '@/api/member-vehicle-api';
import { showSnackbarWithClose } from '@/hooks/useSnackbarWithClose';

export interface IRow {
    member: {
        image: string | null;
        name: string;
        address: string;
        type: string;
    };
    card: {
        ID: string;
        numberInSide: string;
        numberOutSide: string;
    } | null;
    vehicel: {
        ID: string;
        plateNumber: string;
        type: string;
        brand: string;
        color: string;
        startDate: string;
        endDate: string;
    } | null;
}

interface ICreateLostVehicelAction {
    item: IRow;
    toComplete: () => void;
}

export const CreateLostVehicelAction = (props: ICreateLostVehicelAction) => {
    const { item, toComplete } = props;

    const [isOnParking, setIsOnParking] = useState<boolean | 'unset'>(false);
    const parkingChoose = useAppSelector((state) => state.parking.chooseDashboard);
    const rolekey = useAppSelector((state) => state.common.roleKey);
    const keylist = rolekey.map((v): { value: string | boolean; key: string } => {
        if (v.KeySettingId.IsValue) {
            return {
                key: v.KeySettingId.KeyWord,
                value: v.Value,
            };
        } else {
            return {
                key: v.KeySettingId.KeyWord,
                value: v.IsUse,
            };
        }
    });

    const [imageIn, setImageIn] = useState<{
        after: string | null;
        before: string | null;
        TimeIn: string | null;
    }>({
        after: null,
        before: null,
        TimeIn: null,
    });

    useEffect(() => {
        if (!item?.card?.numberInSide) {
            return;
        }

        if (!parkingChoose) {
            return;
        }

        historyInOutApi
            .checkByCardNumberAndParkingId({
                ParkingId: parkingChoose.ID,
                Data: [item.card.numberInSide],
            })
            .then((res) => {
                const { data } = res;
                if (data.length === 0) {
                    setIsOnParking(false);
                } else {
                    setIsOnParking(true);

                    if (parkingChoose.ID && item.vehicel) {
                        historyInOutApi
                            .findManyHistoryByVehicelId(parkingChoose.ID, [item.vehicel?.ID])
                            .then((res) => {
                                const { data } = res;

                                if (data.length !== 0) {
                                    setImageIn({
                                        after: data[0].ImageAfterIn,
                                        before: data[0].ImageBeforeIn,
                                        TimeIn: data[0].TimeIn,
                                    });
                                }
                            });
                    }
                }
            });
    }, [item?.card?.numberInSide, parkingChoose]);

    return (
        <>
            <Image src="/icons/impotant-orange.svg" width={60} height={60} alt="photo" />

            <Stack
                sx={{
                    display: 'flex',
                    gap: '6px',
                    marginTop: '16px',
                    marginBottom: '32px',
                }}
            >
                <Typography
                    sx={{
                        color: '#323232',
                        fontSize: '22px',
                        fontStyle: 'normal',
                        fontWeight: '600',
                        lineHeight: 'normal',
                        textAlign: 'center',
                    }}
                >
                    Bạn có chắc chắn muốn báo mất phương tiện này?
                </Typography>
                <Typography sx={{ textAlign: 'center' }}>
                    Phương tiện sẽ bị khóa vĩnh viễn sau khi nhấn “Tiếp tục”
                </Typography>
            </Stack>

            <Stack sx={{ display: 'flex', gap: '6px' }}>
                <Stack sx={{ display: 'flex', gap: '8px' }} direction="row">
                    <Typography
                        sx={{
                            color: '#AFAFAF',
                            fontSize: '16px',
                            fontStyle: 'normal',
                            fontWeight: 400,
                            lineHeight: '20px',
                        }}
                    >
                        Biển số:
                    </Typography>
                    <Typography
                        sx={{
                            color: '#55595D',
                            fontSize: '16px',
                            fontStyle: 'normal',
                            fontWeight: 500,
                            lineHeight: 'normal',
                        }}
                    >
                        {item.vehicel?.plateNumber}
                    </Typography>
                </Stack>
                <Stack sx={{ display: 'flex', gap: '8px' }} direction="row">
                    <Typography
                        sx={{
                            color: '#AFAFAF',
                            fontSize: '16px',
                            fontStyle: 'normal',
                            fontWeight: 400,
                            lineHeight: '20px',
                        }}
                    >
                        Khách hàng:
                    </Typography>
                    <Typography>{item.member.name}</Typography>
                </Stack>
            </Stack>

            <TableCheckCardOrVehicel
                item={item}
                isOnParking={isOnParking}
                caseRemove={'vehicel'}
                imageIn={imageIn}
            />

            <Stack
                sx={{
                    display: 'flex',
                    width: '140px',
                    padding: '12px 16px',
                    justifyContent: 'center',
                    alignItems: 'center',
                    gap: '10px',
                    flexShrink: 0,
                    backgroundColor: '#007DC0',
                    cursor: 'pointer',
                    marginTop: '30px',
                    borderRadius: '6px',
                }}
                onClick={async () => {
                    if (!parkingChoose) {
                        return;
                    }
                    try {
                        await memberVehicleApi.makeResportLostVehicleV2({
                            Address: item.member.address,
                            Description: '',
                            ParkingId: parkingChoose?.ID,
                            PlateNumber: item.vehicel?.plateNumber,
                            VehicleBrand: item.vehicel?.brand,
                            VehicleColor: item.vehicel?.color,
                            VehicleType: item.vehicel?.type,
                        });
                        toComplete();
                    } catch (error: any) {
                        if (Array.isArray(error?.response?.data?.message)) {
                            error?.response?.data?.message.forEach((item: any) => {
                                showSnackbarWithClose(item, {
                                    variant: 'error',
                                });
                            });
                        } else {
                            showSnackbarWithClose(
                                error?.response ? error.response.data?.message : error.message,
                                {
                                    variant: 'error',
                                }
                            );
                        }
                    }
                }}
            >
                <Typography
                    sx={{
                        color: '#FFF',
                        fontSize: '14px',
                        fontStyle: 'normal',
                        fontWeight: 500,
                        lineHeight: 'normal',
                    }}
                >
                    Tiếp tục
                </Typography>
            </Stack>
        </>
    );
};
