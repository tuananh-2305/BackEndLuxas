import { Stack } from '@mui/material';
import { CreateLostVehicelAction } from './step-1';
import { CreateLostVehicelComplete } from './step-2';
import { useState } from 'react';
import Image from 'next/image';
import { useAppSelector } from '@/hooks';
import { MiniCloseDialog } from './mini-close-dialog';

export interface IRow {
    member: {
        image: string | null;
        name: string;
        address: string;
        type: string;
    };
    card: {
        ID: string;
        numberInSide: string;
        numberOutSide: string;
    } | null;
    vehicel: {
        ID: string;
        plateNumber: string;
        type: string;
        brand: string;
        color: string;
        startDate: string;
        endDate: string;
    } | null;
}

interface IDialogListVehicelAction {
    close: () => void;
    item: IRow;
}

export const DialogLostVehicelAction = (props: IDialogListVehicelAction) => {
    const { close, item } = props;

    const [caseView, setCaseView] = useState<'action' | 'result'>('action');
    const [comfirm, setComfirm] = useState(false);

    return (
        <>
            <Stack
                sx={{
                    display: 'flex',
                    position: 'fixed',
                    height: '100vh',
                    width: '100vw',
                    top: 0,
                    left: 0,
                    zIndex: 100,
                }}
                justifyContent="center"
                alignItems="center"
            >
                <Stack
                    sx={{ width: '100%', height: '100%', backgroundColor: '#80808040' }}
                    onClick={() => {
                        if (caseView === 'action') {
                            setComfirm(true);
                        } else {
                            close();
                        }
                    }}
                />

                <Stack
                    sx={{
                        position: 'absolute',
                        backgroundColor: '#fff',
                        display: 'flex',
                        width: '646px',
                        height: '423px',
                        borderRadius: '11px',
                        padding: '24px',
                    }}
                    alignItems="center"
                    justifyContent="center"
                >
                    <Image
                        src="/icons/x-gray.svg"
                        style={{
                            position: 'absolute',
                            top: '24px',
                            right: '24px',
                            cursor: 'pointer',
                        }}
                        onClick={() => {
                            if (caseView === 'action') {
                                setComfirm(true);
                            } else {
                                close();
                            }
                        }}
                        width={24}
                        height={24}
                        alt="photo"
                    />

                    {caseView === 'action' ? (
                        <CreateLostVehicelAction
                            item={item}
                            toComplete={() => setCaseView('result')}
                        />
                    ) : (
                        <></>
                    )}
                    {caseView === 'result' ? (
                        <CreateLostVehicelComplete close={() => close()} />
                    ) : (
                        <></>
                    )}
                </Stack>
            </Stack>
            {comfirm ? (
                <MiniCloseDialog confirm={() => close()} close={() => setComfirm(false)} />
            ) : (
                <></>
            )}
        </>
    );
};
