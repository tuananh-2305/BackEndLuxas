import { authApi } from '@/api/index';
import { AccountCreatePayload, CustomerModel } from '@/models/index';
import { theme } from '@/ultis/index';
import {
    CircularProgress,
    Dialog,
    DialogActions,
    DialogContent,
    DialogTitle,
    FormControlLabel,
    Stack,
    Switch,
    TextField,
    useMediaQuery,
} from '@mui/material';
import { enqueueSnackbar } from 'notistack';
import { useEffect, useState } from 'react';
import { StyleButton } from '../common/style-component/button';
import { showSnackbarWithClose } from '@/hooks/useSnackbarWithClose';
import { green } from '@mui/material/colors';
import { ComfirmCloseDialog } from './dialog-comfirm-close';

export interface IDialogCreateAccountProps {
    open: boolean;
    handleClose: () => void;
    handleReload?: () => void;
    customerModel: CustomerModel;
}

export default function DialogCreateAccount(props: IDialogCreateAccountProps) {
    const { open, handleClose, handleReload, customerModel } = props;
    const fullScreen = useMediaQuery(theme.breakpoints.down('md'));
    // const [customer, setCustomer] = useState<CustomerModel[]>([]);
    const [openAuto, setOpenAuto] = useState(false);
    // const loading = openAuto && customer.length === 0;
    // const [value, setValue] = React.useState<CustomerModel | null>(null);
    const [password, setPassword] = useState<string>('');
    const [phone, setPhone] = useState<string>('');
    const [name, setName] = useState<string>('');
    const [userName, setUserName] = useState<string>('');
    // const [isAdmin, setIsAdmin] = useState<boolean>(false);
    // const [isLoginCloud, setIsLoginCloud] = useState<boolean>(true);
    const [email, setEmail] = useState<string>();
    const [isLoadingButton, setIsLoadingButton] = useState(false);
    const [openComfirm, setOpenComfirm] = useState(false);
    //reset data when open dialog

    useEffect(() => {
        if (!open) {
            // setValue(null);
            setName('');
            setPassword('');
            setPhone('');
            // setIsAdmin(false);
            // setIsLoginCloud(true);
            setEmail('');
            setIsLoadingButton(false);
        }
    }, [open]);

    const handleCreate = async () => {
        let isValidate = true;
        // if (!value) {
        //     showSnackbarWithClose('Vui lòng chọn khách hàng', { variant: 'error' });
        //     isValidate = false;
        // }
        if (!password && password.trim() === '') {
            showSnackbarWithClose('Vui lòng nhập mật khẩu', { variant: 'error' });
            isValidate = false;
        }

        const regex = /[a-zA-Z]/;

        if (!regex.test(userName)) {
            showSnackbarWithClose('Tài khoản phải chứa ít nhất 1 ký tự', { variant: 'error' });
            isValidate = false;
        }

        if (userName.length < 6) {
            showSnackbarWithClose('Tài khoản phải có độ dài ít nhất 6', {
                variant: 'error',
            });
            isValidate = false;
        }

        // if (!phone && phone.trim() === '') {
        //     showSnackbarWithClose('Vui lòng nhập số điện thoại', { variant: 'error' });
        //     isValidate = false;
        // }
        if (isValidate === false) return;
        setIsLoadingButton(true);

        const payload: AccountCreatePayload = {
            IsAdmin: true,
            IsLoginCloud: true,
            Name: customerModel.FullName,
            Password: password,
            CustomerId: customerModel.ID,
            Phone: customerModel.PhoneNumber,
            IsActive: true,
            UserName: userName,
        };
        if (customerModel.Email) payload.Email = customerModel.Email;

        try {
            const { data } = await authApi.register(payload);
            // console.log(data);
            showSnackbarWithClose('Tạo tài khoản thành công', {
                variant: 'success',
            });
            handleReload && handleReload();
            handleClose();
        } catch (error: any) {
            if (Array.isArray(error?.response?.data?.message)) {
                error?.response?.data?.message.forEach((item: any) => {
                    showSnackbarWithClose(item, {
                        variant: 'error',
                    });
                });
            } else {
                showSnackbarWithClose(
                    error?.response ? error.response.data?.message : error.message,
                    {
                        variant: 'error',
                    }
                );
            }
        }
        setTimeout(() => {
            setIsLoadingButton(false);
        }, 1000);
    };
    return (
        <Dialog
            fullScreen={fullScreen}
            open={open}
            onClose={() => {
                if (name || phone || password || email) setOpenComfirm(true);
                else handleClose();
            }}
            aria-labelledby="responsive-dialog-title"
            sx={{
                '& .MuiPaper-root': {
                    md: { minWidth: '500px', borderRadius: '16px' },
                },
            }}
        >
            <DialogTitle>{'Tạo tài khoản ' + customerModel.FullName}</DialogTitle>
            <DialogContent>
                <Stack py={2} gap={1}>
                    {/* <TextField
                        value={name}
                        onChange={(e) => {
                            setName(e.target.value);
                        }}
                        size="small"
                        label="Tên*"
                        variant="outlined"
                        fullWidth
                    /> */}
                    {/* <TextField
                        value={phone}
                        onChange={(e) => {
                            setPhone(e.target.value);
                        }}
                        size="small"
                        label="Số điện thoại*"
                        variant="outlined"
                        fullWidth
                    /> */}

                    {/* <FormControlLabel
                        control={
                            <Switch
                                checked={isAdmin}
                                onChange={(e) => setIsAdmin(e.target.checked)}
                            />
                        }
                        label="Là admin"
                    />
                    <FormControlLabel
                        control={
                            <Switch
                                checked={isLoginCloud}
                                onChange={(e) => setIsLoginCloud(e.target.checked)}
                            />
                        }
                        label="Login cloud"
                    /> */}

                    <Stack sx={{ gap: 2 }}>
                        <TextField
                            value={userName}
                            onChange={(e) => {
                                const { value } = e.target;
                                if (!value.includes(' ')) {
                                    setUserName(e.target.value);
                                }
                            }}
                            size="small"
                            label="Tài Khoản*"
                            variant="outlined"
                            autoComplete="off"
                            fullWidth
                            type="text"
                        />

                        <TextField
                            value={password}
                            onChange={(e) => {
                                setPassword(e.target.value);
                            }}
                            size="small"
                            label="Mật khẩu*"
                            variant="outlined"
                            autoComplete="off"
                            fullWidth
                            type="password"
                        />
                    </Stack>

                    {/* <TextField
                        value={email}
                        onChange={(e) => {
                            setEmail(e.target.value);
                        }}
                        size="small"
                        label="Email"
                        variant="outlined"
                        fullWidth
                    /> */}
                </Stack>
            </DialogContent>
            <DialogActions
                sx={{
                    px: 3,
                    pb: 3,
                }}
            >
                <Stack sx={{ m: 1, position: 'relative' }}>
                    <StyleButton
                        variant="contained"
                        onClick={handleCreate}
                        disabled={isLoadingButton}
                    >
                        Tạo mới
                    </StyleButton>
                    {isLoadingButton && (
                        <CircularProgress
                            size={24}
                            sx={{
                                color: green[500],
                                position: 'absolute',
                                top: '50%',
                                left: '50%',
                                marginTop: '-12px',
                                marginLeft: '-12px',
                            }}
                        />
                    )}
                </Stack>
            </DialogActions>
            {openComfirm ? (
                <ComfirmCloseDialog
                    close={() => setOpenComfirm(false)}
                    action={() => {
                        setOpenComfirm(false);
                        handleClose();
                    }}
                />
            ) : (
                <></>
            )}
        </Dialog>
    );
}
