import { customerApi } from '@/api/customer-api';
import { parkingApi } from '@/api/index';
import { useAppDispatch, useAppSelector } from '@/hooks/useReudx';
import { CustomerModel, ParkingCreatePayload } from '@/models/index';
import { addParking } from '@/redux/index';
import { theme } from '@/ultis/index';
import {
    Autocomplete,
    Dialog,
    DialogActions,
    DialogContent,
    DialogTitle,
    InputLabel,
    Stack,
    TextField,
    useMediaQuery,
} from '@mui/material';
import CircularProgress from '@mui/material/CircularProgress';
import { enqueueSnackbar } from 'notistack';
import React, { useEffect, useState } from 'react';
import InputAddress from '../common/input/input-address';
import { StyledOutlinedInput } from '../common/style-component';
import { StyleButton } from '../common/style-component/button';
import { showSnackbarWithClose } from '@/hooks/useSnackbarWithClose';
import { green } from '@mui/material/colors';
import { ComfirmCloseDialog } from './dialog-comfirm-close';
import { systemRoleApi } from '@/api/key-system-role';
export interface IDialogCreateParkingProps {
    open: boolean;
    handleClose: () => void;
    handleReload?: () => void;
}

export default function DialogCreateParking(props: IDialogCreateParkingProps) {
    const { open, handleClose, handleReload } = props;
    const fullScreen = useMediaQuery(theme.breakpoints.down('md'));
    const [name, setName] = useState<string>('');
    const [address, setAddress] = useState<string>('');
    const [description, setDescription] = useState<string>('');
    const [customer, setCustomer] = useState<CustomerModel[]>([]);
    const [openAuto, setOpenAuto] = useState(false);
    const loading = openAuto && customer.length === 0;
    const [value, setValue] = React.useState<CustomerModel | null>(null);
    const [province, setProvince] = useState<string>('');
    const [district, setDistrict] = useState<string>('');
    const [ward, setWard] = useState<string>('');
    const [capacity, setCapacity] = useState<number>(0);
    const profile = useAppSelector((state) => state.common?.profile);
    const [isLoadingButton, setIsLoadingButton] = useState(false);
    const [openComfirm, setOpenComfirm] = useState(false);
    //reset data when open dialog

    const dispatch = useAppDispatch();

    useEffect(() => {
        let active = true;
        if (!loading) {
            return undefined;
        }
        if (open) {
            const fetchDataCustomer = async () => {
                const { data } = await customerApi.getCustomers({
                    Current: 0,
                    Limit: 100000,
                    TextSearch: '',
                });
                setCustomer(data ? data.Data : []);
            };
            fetchDataCustomer();
        }
        return () => {
            active = false;
        };
    }, [loading]);
    useEffect(() => {
        if (!open) {
            setValue(null);
            setName('');
            setAddress('');
            setDescription('');
            setCustomer([]);
            setProvince('');
            setDistrict('');
            setWard('');
            setIsLoadingButton(false);
        }
    }, [open]);
    const handleCreateParking = async () => {
        if (!name || name.trim() === '') {
            showSnackbarWithClose('Tên bãi xe không được để trống', { variant: 'error' });
            return;
        }
        if (!value || !value?.ID) {
            showSnackbarWithClose('Khách hàng không được để trống', { variant: 'error' });
            return;
        }
        setIsLoadingButton(true);
        const payload: ParkingCreatePayload = {
            Name: name.trim(),
            Address: address.trim(),
            Description: description,
            CustomerId: value.ID,
            Province: province,
            District: district,
            Ward: ward,
            Capacity: capacity,
        };

        try {
            const { data: parkingRes } = await parkingApi.createParking(payload);

            const { data: roles } = await systemRoleApi.allRole();

            await systemRoleApi.createGroupRole(
                parkingRes.ID,
                roles.map((v: any) => {
                    const r = {
                        KeySettingId: v.ID,
                        IsUse: true,
                        Value: '',
                    };
                    return r;
                })
            );

            if (parkingRes?.CustomerId?.ID == profile?.CustomerId?.ID) {
                const action = addParking({ parking: parkingRes });
                dispatch(action);
            }
            // console.log(data);
            showSnackbarWithClose('Tạo bãi xe thành công', { variant: 'success' });
            handleReload && handleReload();
            handleClose();
        } catch (error: any) {
            if (Array.isArray(error?.response?.data?.message)) {
                error?.response?.data?.message.forEach((item: any) => {
                    showSnackbarWithClose(item, {
                        variant: 'error',
                    });
                });
            } else {
                showSnackbarWithClose(
                    error?.response ? error.response.data?.message : error.message,
                    {
                        variant: 'error',
                    }
                );
            }
        }
        setTimeout(() => {
            setIsLoadingButton(false);
        }, 1000);
    };
    return (
        <Dialog
            fullScreen={fullScreen}
            open={open}
            onClose={() => {
                if (name || address || description || value || province || district || ward) {
                    setOpenComfirm(true);
                } else {
                    handleClose();
                }
            }}
            aria-labelledby="responsive-dialog-title"
            sx={{
                '& .MuiPaper-root': {
                    md: { minWidth: '600px', borderRadius: '16px' },
                },
            }}
        >
            <DialogTitle>{'Tạo bãi xe mới'}</DialogTitle>
            <DialogContent>
                <Stack py={2} spacing={2}>
                    <Stack>
                        <InputLabel required>Tên</InputLabel>
                        <StyledOutlinedInput
                            autoComplete="off"
                            value={name}
                            onChange={(e) => {
                                setName(e.target.value);
                            }}
                            size="small"
                            fullWidth
                        />
                    </Stack>
                    <Stack>
                        <InputLabel required>Khách hàng</InputLabel>
                        <Autocomplete
                            size="small"
                            onChange={(event: any, newValue: CustomerModel | null) => {
                                setValue(newValue);
                            }}
                            isOptionEqualToValue={(option: any, value) => option.ID === value?.ID}
                            onOpen={() => {
                                setOpenAuto(true);
                            }}
                            onClose={() => {
                                setOpenAuto(false);
                            }}
                            getOptionLabel={(option) => option.FullName}
                            options={customer}
                            renderInput={(params) => (
                                <TextField
                                    {...params}
                                    InputProps={{
                                        ...params.InputProps,
                                        endAdornment: (
                                            <React.Fragment>
                                                {loading ? (
                                                    <CircularProgress color="inherit" size={20} />
                                                ) : null}
                                                {params.InputProps.endAdornment}
                                            </React.Fragment>
                                        ),
                                    }}
                                    sx={{
                                        '& .MuiInputBase-root': {
                                            borderRadius: '10px',
                                        },
                                    }}
                                />
                            )}
                        />
                    </Stack>
                    <Stack>
                        <InputLabel>Công suất tối đa</InputLabel>
                        <StyledOutlinedInput
                            autoComplete="off"
                            value={capacity}
                            onChange={(e) => {
                                setCapacity(parseInt(e.target.value));
                            }}
                            size="small"
                            fullWidth
                            type="number"
                        />
                    </Stack>
                    <InputAddress
                        selectedProvince={province}
                        selectedDistrict={district}
                        selectedWard={ward}
                        setSelectedProvince={setProvince}
                        setSelectedDistrict={setDistrict}
                        setSelectedWard={setWard}
                    />
                    <Stack>
                        <InputLabel>Địa chỉ</InputLabel>
                        <StyledOutlinedInput
                            autoComplete="off"
                            value={address}
                            onChange={(e) => {
                                setAddress(e.target.value);
                            }}
                            size="small"
                            fullWidth
                        />
                    </Stack>
                    <Stack>
                        <InputLabel>Mô tả</InputLabel>
                        <StyledOutlinedInput
                            autoComplete="off"
                            value={description}
                            onChange={(e) => {
                                setDescription(e.target.value);
                            }}
                            size="small"
                            fullWidth
                            multiline
                            rows={4}
                        />
                    </Stack>
                </Stack>
            </DialogContent>
            <DialogActions
                sx={{
                    px: 3,
                    pb: 3,
                }}
            >
                <Stack sx={{ m: 1, position: 'relative' }}>
                    <StyleButton
                        variant="contained"
                        onClick={handleCreateParking}
                        disabled={isLoadingButton}
                    >
                        Tạo mới
                    </StyleButton>
                    {isLoadingButton && (
                        <CircularProgress
                            size={24}
                            sx={{
                                color: green[500],
                                position: 'absolute',
                                top: '50%',
                                left: '50%',
                                marginTop: '-12px',
                                marginLeft: '-12px',
                            }}
                        />
                    )}
                </Stack>
            </DialogActions>
            {openComfirm ? (
                <ComfirmCloseDialog
                    close={() => setOpenComfirm(false)}
                    action={() => {
                        setOpenComfirm(false);
                        handleClose();
                    }}
                />
            ) : (
                <></>
            )}
        </Dialog>
    );
}
