import {
    Button,
    Dialog,
    DialogActions,
    DialogContent,
    DialogContentText,
    DialogTitle,
    SxProps,
    Theme,
} from '@mui/material';
import * as React from 'react';

export interface IDialogAlertProps {
    open: boolean;
    handleClose: () => void;
    title: string;
    content: string;
    type: 'success' | 'error' | 'warning' | 'info';
    handleConfirm?: () => void;
    sx?: SxProps<Theme>;
}

export default function DialogAlert(props: IDialogAlertProps) {
    const { open, handleClose, title, content, type, handleConfirm } = props;
    return (
        <Dialog
            open={open}
            onClose={handleClose}
            aria-labelledby="alert-dialog-title"
            aria-describedby="alert-dialog-description"
            sx={{
                '& .MuiDialog-paper': {
                    borderRadius: '16px',
                },
            }}
        >
            <DialogTitle id="alert-dialog-title">{title}</DialogTitle>
            <DialogContent>
                <DialogContentText id="alert-dialog-description">{content}</DialogContentText>
            </DialogContent>
            <DialogActions
                sx={{
                    px: 3,
                    pb: 3,
                }}
            >
                <Button onClick={handleClose} autoFocus>
                    Đóng
                </Button>
                <Button onClick={handleConfirm} variant="contained" color={type}>
                    Đồng ý
                </Button>
            </DialogActions>
        </Dialog>
    );
}
