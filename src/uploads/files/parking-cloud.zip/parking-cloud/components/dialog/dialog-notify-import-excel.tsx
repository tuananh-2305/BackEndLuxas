import {
    Dialog,
    DialogActions,
    DialogContent,
    DialogTitle,
    Stack,
    Typography,
    useMediaQuery,
} from '@mui/material';
import React from 'react';
import { theme } from '@/ultis/index';
import { StyleButton } from '../common/style-component';
import { title } from 'process';

export interface IDialogNotifyImportExcelProps {
    open: boolean;
    handleClose: () => void;
    data: any[];
    title: string;
}

export default function DialogNotifyImportExcel(props: IDialogNotifyImportExcelProps) {
    const fullScreen = useMediaQuery(theme.breakpoints.down('md'));
    return (
        <Dialog
            fullScreen={fullScreen}
            open={props.open}
            onClose={props.handleClose}
            aria-labelledby="responsive-dialog-title"
            sx={{
                '& .MuiPaper-root': {
                    md: { minWidth: '500px', borderRadius: '16px' },
                },
            }}
            maxWidth="lg"
        >
            <DialogTitle>{'Thông báo import lỗi'}</DialogTitle>
            <DialogContent>
                <Stack sx={{ width: '100%', flexDirection: 'row' }}>
                    <Typography sx={{ fontWeight: 'bold', width: '200px' }}>
                        {props.title}
                    </Typography>
                    <Typography sx={{ fontWeight: 'bold', width: '400px' }}>Lỗi</Typography>
                </Stack>
                <Stack sx={{ maxHeight: '60vh', overflow: 'auto' }}>
                    {props.data.map((item, index) => {
                        return (
                            <Stack
                                key={index}
                                sx={{
                                    width: '100%',
                                    flexDirection: 'row',
                                    borderBottom: '1px solid #E0E0E0',
                                    padding: '10px 0px',
                                    bgcolor: index % 2 === 0 ? '#F5F5F5' : '#FFF',
                                }}
                            >
                                <Typography sx={{ width: '200px' }}>{item[props.title]}</Typography>
                                <Typography sx={{ width: '400px' }}>{item['Error']}</Typography>
                            </Stack>
                        );
                    })}
                </Stack>
            </DialogContent>
            <DialogActions
                sx={{
                    px: 3,
                    pb: 3,
                }}
            >
                <StyleButton variant="contained" onClick={props.handleClose}>
                    Đóng
                </StyleButton>
            </DialogActions>
        </Dialog>
    );
}
