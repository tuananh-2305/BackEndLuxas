import { historyInOutApi } from '@/api/index';
import SelectTypeVehicle from '@/components/common/input/select-type-vehicle';
import { StyleButton, StyledOutlinedInput } from '@/components/common/style-component';
import { useAppSelector } from '@/hooks/index';
import { showSnackbarWithClose } from '@/hooks/useSnackbarWithClose';
import { HistoryModel } from '@/models/parking.model';
import {
    checkRoleIsAdminOrSupperAdmin,
    formatMoney,
    getNameAddress,
    showAddress,
} from '@/ultis/global-func';
import { theme } from '@/ultis/theme';
import BorderColorIcon from '@mui/icons-material/BorderColor';
import HistoryIcon from '@mui/icons-material/History';
import MenuOpenIcon from '@mui/icons-material/MenuOpen';
import ZoomOutMapIcon from '@mui/icons-material/ZoomOutMap';
import {
    Checkbox,
    Collapse,
    Dialog,
    DialogContent,
    Divider,
    FormControlLabel,
    IconButton,
    InputLabel,
    Stack,
    Tooltip,
    Typography,
    useMediaQuery,
} from '@mui/material';
import moment from 'moment';
import Image from 'next/image';
import { useEffect, useState } from 'react';
import DialogHistoryLog from './dialog-history-log';
import InfoItem from './info-item';
const BACKEND_DOMAIN = process.env.NEXT_PUBLIC_SERVER_PARKING_DOMAIN;

export interface IDialogDetailHistoryProps {
    open: boolean;
    handleClose: () => void;
    data: HistoryModel | undefined;
    isUpdateDetail?: boolean;
}

export default function DialogDetailHistory({
    open,
    handleClose,
    data,
    isUpdateDetail,
}: IDialogDetailHistoryProps) {
    const fullScreen = useMediaQuery(theme.breakpoints.down('md'));
    const id = data?.ID.split('-');
    const [openDrawer, setOpenDrawer] = useState(false);
    const [idTypeVehicle, setIdTypeVehicle] = useState<string | null>(null);
    const [priceEdit, setPriceEdit] = useState<string>('');
    const parkingChoose = useAppSelector((state) => state.parking.chooseDashboard);
    const profile = useAppSelector((state) => state.common.profile);
    const [reason, setReason] = useState<string>('');
    const [isShowLogHistory, setIsShowLogHistory] = useState<boolean>(false);
    const [isSaveHistory, setIsSaveHistory] = useState<boolean>(true);
    useEffect(() => {
        if (!isUpdateDetail) return;
        if (data?.VehicleTypeId) {
            setIdTypeVehicle(data?.VehicleTypeId?.ID);
        }
    }, [data?.ID]);
    useEffect(() => {
        if (!open) {
            setOpenDrawer(false);
            setReason('');
            setPriceEdit(data?.Price || '0');
            setIsSaveHistory(true);
        }
    }, [open]);
    useEffect(() => {
        if (!isUpdateDetail) {
            setIsSaveHistory(true);
        }
    }, [isUpdateDetail]);
    useEffect(() => {
        if (!isUpdateDetail) return;
        if (!parkingChoose || !data || !idTypeVehicle || !data?.CodeCardOut) return;
        const payload = {
            ParkingId: parkingChoose.ID,
            VehicleTypeId: idTypeVehicle,
            TimeOut: data?.TimeOut,
            TimeIn: data?.TimeIn,
        };
        historyInOutApi
            .checkPrice(payload)
            .then((res) => {
                setPriceEdit(res.data);
            })
            .catch((err) => {
                setPriceEdit('0');
            });
    }, [data?.ID, idTypeVehicle, parkingChoose]);
    const handleUpdate = async () => {
        // if (!name) {
        //     showSnackbarWithClose('Vui lòng nhập tên bãi xe', { variant: 'error' });
        //     return;
        // }
        let isValidate = true;
        if (!data?.ID) {
            showSnackbarWithClose('Vui lòng chọn lịch sử', { variant: 'error' });
            isValidate = false;
        }
        if (!idTypeVehicle) {
            showSnackbarWithClose('Vui lòng chọn loại xe', { variant: 'error' });
            isValidate = false;
        }
        if (data?.CodeCardOut && !priceEdit) {
            showSnackbarWithClose('Vui lòng nhập giá', { variant: 'error' });
            isValidate = false;
        }
        if (parseInt(priceEdit) > 2147483646) {
            showSnackbarWithClose('Giá không thể lớn hơn 2147483646', { variant: 'error' });
            isValidate = false;
        }
        if (!reason || reason.trim().length == 0) {
            showSnackbarWithClose('Vui lòng nhập lý do', { variant: 'error' });
            isValidate = false;
        }
        if (!isValidate) return;

        const payload = {
            ID: data?.ID || '',
            IdVehicleType: idTypeVehicle || '',
            Price: data?.CodeCardOut ? priceEdit : '0',
            Description: reason,
            IsSaveHistory: isSaveHistory,
        };
        try {
            const { data } = await historyInOutApi.updatePriceOrVehicleType(payload);
            showSnackbarWithClose('Cập nhật lịch sử  thành công', { variant: 'success' });
            // handleReload && handleReload();
            handleClose();
        } catch (error: any) {
            if (Array.isArray(error?.response?.data?.message)) {
                error?.response?.data?.message.forEach((item: any) => {
                    showSnackbarWithClose(item, {
                        variant: 'error',
                    });
                });
            } else {
                showSnackbarWithClose(
                    error?.response ? error.response.data?.message : error.message,
                    {
                        variant: 'error',
                    }
                );
            }
        }
    };
    const handleCloseDetail = () => {
        handleClose();
    };
    return (
        <Dialog
            fullScreen={fullScreen}
            open={open}
            onClose={handleCloseDetail}
            aria-labelledby="responsive-dialog-title"
            maxWidth={'lg'}
        >
            <DialogContent>
                {data?.ID && (
                    <DialogHistoryLog
                        open={isShowLogHistory}
                        handleClose={() => {
                            setIsShowLogHistory(false);
                        }}
                        idHistory={data?.ID}
                    />
                )}

                <Stack sx={{ flexDirection: 'row' }} gap={2}>
                    <Stack
                        sx={{
                            borderRadius: '10px',
                            border: '1px solid #D9D9D9',
                            boxSizing: 'border-box',
                            width: '360px',
                            justifyContent: 'space-between',
                        }}
                    >
                        <Stack sx={{ m: 2 }} spacing={2}>
                            <Stack>
                                <Typography sx={{ fontWeight: 600, fontSize: '14px' }}>
                                    {data?.ParkingId?.Name}
                                </Typography>
                                <Typography
                                    sx={{ fontSize: '12px', fontWeight: 300, fontStyle: 'italic' }}
                                >
                                    {data?.ParkingId?.Address || data?.ParkingId?.Ward
                                        ? `(${showAddress(
                                              data?.ParkingId?.Address || '',
                                              getNameAddress(data?.ParkingId?.Ward),
                                              getNameAddress(data?.ParkingId?.District),
                                              getNameAddress(data?.ParkingId?.Province)
                                          )})`
                                        : '...'}
                                </Typography>
                            </Stack>
                            <Divider sx={{ border: '1px dashed #D9D9D9' }} />
                            <InfoItem
                                title={'Mã vé'}
                                content={
                                    id
                                        ? id[0].toUpperCase() +
                                          '****' +
                                          id[id?.length - 1].toUpperCase()
                                        : '...'
                                }
                            />
                            <InfoItem
                                title={'Số thẻ ngoài'}
                                content={data?.IdCard ? data?.IdCard : '...'}
                            />
                            <InfoItem
                                title={'Mã thẻ'}
                                content={data?.CodeCardIn ? data?.CodeCardIn : '...'}
                            />
                            <InfoItem
                                title={'Tên khách hàng'}
                                content={data?.MemberId ? data?.MemberId?.Name : '...'}
                            />
                            <InfoItem
                                title={'Địa chỉ phòng'}
                                content={data?.Address ? `${data?.Address}` : '...'}
                            />
                            <InfoItem
                                title={'Biển số'}
                                content={data?.PlateNumberIn ? data?.PlateNumberIn : '...'}
                            />
                            <InfoItem
                                title={'Loại xe'}
                                content={data?.VehicleTypeId ? data?.VehicleTypeId?.Name : '...'}
                            />
                            <InfoItem title={'Vị trí'} content={'...'} />
                            <InfoItem
                                title={'Thời gian vào'}
                                content={
                                    data?.TimeIn
                                        ? moment(data?.TimeIn).format('HH:mm DD-MM-YYYY')
                                        : '...'
                                }
                            />
                            <InfoItem
                                title={'Thời gian ra'}
                                content={
                                    data?.TimeOut
                                        ? moment(data?.TimeOut).format('HH:mm DD-MM-YYYY')
                                        : '...'
                                }
                            />
                        </Stack>
                        <Stack
                            sx={{ m: 2, borderRadius: '10px', border: '1px dashed #D9D9D9' }}
                            spacing={2}
                        >
                            <Typography
                                sx={{
                                    fontWeight: 700,
                                    fontSize: '36px',
                                    textAlign: 'center',
                                    textShadow: '0px 4px 4px rgba(0, 0, 0, 0.25)',
                                }}
                            >
                                {formatMoney(data?.Price || 0)}
                            </Typography>
                        </Stack>
                    </Stack>
                    <Stack spacing={2}>
                        <Stack spacing={2}>
                            <Stack
                                direction={'row'}
                                justifyContent={'space-between'}
                                alignItems={'center'}
                            >
                                <Stack>
                                    <Typography sx={{ fontWeight: 400, fontSize: '14px' }}>
                                        Hình ảnh vào bãi
                                    </Typography>
                                    <Typography sx={{ fontWeight: 400, fontSize: '13px' }}>
                                        {data?.TimeIn
                                            ? moment(data?.TimeIn).format('HH:mm DD-MM-YYYY')
                                            : '...'}
                                    </Typography>
                                </Stack>
                                <Stack alignItems={'flex-end'} direction={'row'} gap={2}>
                                    {checkRoleIsAdminOrSupperAdmin(profile) && (
                                        <Tooltip title="Lịch sử chỉnh sửa">
                                            <IconButton
                                                sx={{
                                                    boxShadow: '0px 2px 2px rgba(0, 0, 0, 0.25)',
                                                }}
                                                onClick={() => {
                                                    setIsShowLogHistory(true);
                                                }}
                                                size={'small'}
                                            >
                                                <HistoryIcon />
                                            </IconButton>
                                        </Tooltip>
                                    )}

                                    {isUpdateDetail &&
                                        checkRoleIsAdminOrSupperAdmin(profile) &&
                                        data?.CodeCardOut && (
                                            <Tooltip title="Sửa lịch sử">
                                                <IconButton
                                                    sx={{
                                                        backgroundColor: '#067DC0',
                                                        color: '#fff',
                                                        '&:hover': {
                                                            backgroundColor:
                                                                'rgba(6, 125, 192, 0.8)',
                                                        },
                                                        boxShadow:
                                                            '0px 2px 2px rgba(0, 0, 0, 0.25)',
                                                    }}
                                                    onClick={() => {
                                                        setOpenDrawer(!openDrawer);
                                                    }}
                                                    size={'small'}
                                                >
                                                    {openDrawer ? (
                                                        <MenuOpenIcon />
                                                    ) : (
                                                        <BorderColorIcon fontSize={'small'} />
                                                    )}
                                                </IconButton>
                                            </Tooltip>
                                        )}
                                </Stack>
                            </Stack>
                            <Stack sx={{ flexDirection: 'row' }} gap={2}>
                                <Stack
                                    sx={{
                                        background: 'black',
                                        position: 'relative',
                                    }}
                                >
                                    <Image
                                        src={
                                            data?.ImageAfterIn
                                                ? BACKEND_DOMAIN + data?.ImageAfterIn
                                                : '/logo/ORYZA-white.png'
                                        }
                                        width={270}
                                        height={190}
                                        alt={'Ảnh vào 1'}
                                    />

                                    <Tooltip title="Xem ảnh phóng lớn">
                                        <Stack
                                            sx={{
                                                position: 'absolute',
                                                bottom: '10px',
                                                right: '10px',
                                                backgroundColor: '#fff',
                                                padding: '5px',
                                                borderRadius: '50%',
                                                cursor: 'pointer',
                                                boxShadow: 'rgba(0, 0, 0, 0.24) 0px 3px 8px',
                                            }}
                                            onClick={() => {
                                                if (data?.ImageAfterIn) {
                                                    window.open(
                                                        BACKEND_DOMAIN + data?.ImageAfterIn,
                                                        '_blank'
                                                    );
                                                }
                                            }}
                                        >
                                            <ZoomOutMapIcon sx={{ fontSize: '16px' }} />
                                        </Stack>
                                    </Tooltip>
                                </Stack>
                                <Stack
                                    sx={{
                                        background: 'black',
                                        position: 'relative',
                                    }}
                                >
                                    <Image
                                        src={
                                            data?.ImageBeforeIn
                                                ? BACKEND_DOMAIN + data?.ImageBeforeIn
                                                : '/logo/ORYZA-white.png'
                                        }
                                        width={270}
                                        height={190}
                                        alt={'Ảnh vào 2'}
                                    />

                                    <Tooltip title="Xem ảnh phóng lớn">
                                        <Stack
                                            sx={{
                                                position: 'absolute',
                                                bottom: '10px',
                                                right: '10px',
                                                backgroundColor: '#fff',
                                                padding: '5px',
                                                borderRadius: '50%',
                                                cursor: 'pointer',
                                                boxShadow: 'rgba(0, 0, 0, 0.24) 0px 3px 8px',
                                            }}
                                            onClick={() => {
                                                if (data?.ImageBeforeIn) {
                                                    window.open(
                                                        BACKEND_DOMAIN + data?.ImageBeforeIn,
                                                        '_blank'
                                                    );
                                                }
                                            }}
                                        >
                                            <ZoomOutMapIcon sx={{ fontSize: '16px' }} />
                                        </Stack>
                                    </Tooltip>
                                </Stack>
                            </Stack>
                        </Stack>
                        <Stack spacing={2}>
                            <Stack>
                                <Typography sx={{ fontWeight: 400, fontSize: '14px' }}>
                                    Hình ảnh ra bãi
                                </Typography>
                                <Typography sx={{ fontWeight: 400, fontSize: '13px' }}>
                                    {data?.TimeOut
                                        ? moment(data?.TimeOut).format('HH:mm DD-MM-YYYY')
                                        : '...'}
                                </Typography>
                            </Stack>
                            <Stack sx={{ flexDirection: 'row' }} gap={2}>
                                <Stack sx={{ background: 'black', position: 'relative' }}>
                                    <Image
                                        src={
                                            data?.ImageAfterOut
                                                ? BACKEND_DOMAIN + data?.ImageAfterOut
                                                : '/logo/ORYZA-white.png'
                                        }
                                        width={270}
                                        height={190}
                                        alt={'Ảnh ra 1'}
                                    />
                                    <Tooltip title="Xem ảnh phóng lớn">
                                        <Stack
                                            sx={{
                                                position: 'absolute',
                                                bottom: '10px',
                                                right: '10px',
                                                backgroundColor: '#fff',
                                                padding: '5px',
                                                borderRadius: '50%',
                                                cursor: 'pointer',
                                                boxShadow: 'rgba(0, 0, 0, 0.24) 0px 3px 8px',
                                            }}
                                            onClick={() => {
                                                if (data?.ImageAfterOut) {
                                                    window.open(
                                                        BACKEND_DOMAIN + data?.ImageAfterOut,
                                                        '_blank'
                                                    );
                                                }
                                            }}
                                        >
                                            <ZoomOutMapIcon sx={{ fontSize: '16px' }} />
                                        </Stack>
                                    </Tooltip>
                                </Stack>
                                <Stack sx={{ background: 'black', position: 'relative' }}>
                                    <Image
                                        src={
                                            data?.ImageBeforeOut
                                                ? BACKEND_DOMAIN + data?.ImageBeforeOut
                                                : '/logo/ORYZA-white.png'
                                        }
                                        width={270}
                                        height={190}
                                        alt={'Ảnh ra 2'}
                                    />

                                    <Tooltip title="Xem ảnh phóng lớn">
                                        <Stack
                                            sx={{
                                                position: 'absolute',
                                                bottom: '10px',
                                                right: '10px',
                                                backgroundColor: '#fff',
                                                padding: '5px',
                                                borderRadius: '50%',
                                                cursor: 'pointer',
                                                boxShadow: 'rgba(0, 0, 0, 0.24) 0px 3px 8px',
                                            }}
                                            onClick={() => {
                                                if (data?.ImageBeforeOut) {
                                                    window.open(
                                                        BACKEND_DOMAIN + data?.ImageBeforeOut,
                                                        '_blank'
                                                    );
                                                }
                                            }}
                                        >
                                            <ZoomOutMapIcon sx={{ fontSize: '16px' }} />
                                        </Stack>
                                    </Tooltip>
                                </Stack>
                            </Stack>
                        </Stack>
                    </Stack>
                    {isUpdateDetail && (
                        <Collapse orientation="horizontal" in={openDrawer}>
                            <Stack
                                sx={{
                                    minWidth: '200px',
                                    gap: '10px',
                                    height: '100%',
                                }}
                                px={1}
                            >
                                <Typography>Chỉnh sửa lịch sử</Typography>

                                <Stack gap={2}>
                                    <SelectTypeVehicle
                                        idTypeVehicle={idTypeVehicle}
                                        setIdTypeVehicle={setIdTypeVehicle}
                                    />
                                    {data?.CodeCardOut && (
                                        <Stack>
                                            <InputLabel required>Số tiền chỉnh sửa </InputLabel>
                                            <StyledOutlinedInput
                                                autoComplete="off"
                                                value={priceEdit}
                                                onChange={(e) => {
                                                    const value = e.target.value;
                                                    // Loại bỏ các ký tự không phải số và thập phân
                                                    const sanitizedValue = value.replace(
                                                        /[^0-9]/g,
                                                        ''
                                                    );

                                                    // Cập nhật giá trị trong trường nhập liệu
                                                    setPriceEdit(sanitizedValue);
                                                }}
                                                size="small"
                                                fullWidth
                                                type="text" // Để tránh trình duyệt hiển thị mũi tên số lên và xuống
                                                inputProps={{
                                                    min: 0,
                                                }}
                                            />
                                        </Stack>
                                    )}
                                    <Stack>
                                        <InputLabel required>Lý do</InputLabel>
                                        <StyledOutlinedInput
                                            autoComplete="off"
                                            value={reason}
                                            onChange={(e) => {
                                                setReason(e.target.value);
                                            }}
                                            size="small"
                                            fullWidth
                                            multiline
                                            rows={4}
                                        />
                                    </Stack>
                                    {profile?.IsSupperAdmin && (
                                        <FormControlLabel
                                            sx={{
                                                '& .MuiFormControlLabel-label': {
                                                    fontSize: '14px',
                                                    fontWeight: 'bold',
                                                    color: '#55595D',
                                                },
                                                '& .MuiCheckbox-root': {
                                                    color: '#55595D',
                                                },
                                            }}
                                            control={<Checkbox size="small" defaultChecked />}
                                            label="Lưu lịch sử chỉnh sửa"
                                            value={isSaveHistory}
                                            onChange={(e: any) =>
                                                setIsSaveHistory(e.target.checked)
                                            }
                                        />
                                    )}
                                </Stack>
                                <Stack
                                    sx={{
                                        marginTop: 'auto',
                                    }}
                                    justifyContent={'flex-end'}
                                >
                                    <StyleButton variant="contained" onClick={handleUpdate}>
                                        Cập nhật
                                    </StyleButton>
                                </Stack>
                            </Stack>
                        </Collapse>
                    )}
                </Stack>
            </DialogContent>
        </Dialog>
    );
}
