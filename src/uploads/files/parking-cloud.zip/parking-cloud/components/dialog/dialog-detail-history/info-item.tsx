import { Stack, Typography } from '@mui/material';
import React from 'react';

export interface IInfoItemProps {
    title: string;
    content: string;
}

export default function InfoItem({ title, content }: IInfoItemProps) {
    return (
        <Stack sx={{ flexDirection: 'row', justifyContent: 'space-between' }}>
            <Typography sx={{ fontWeight: 400, fontSize: '13px' }}>{title}</Typography>
            <Typography sx={{ fontWeight: 400, fontSize: '14px' }}>{content}</Typography>
        </Stack>
    );
}
