import {
    Chip,
    Paper,
    Stack,
    Typography,
    Table,
    TableBody,
    TableCell,
    TableContainer,
    TableHead,
    TableRow,
    Pagination,
    PaginationItem,
} from '@mui/material';
import SyncIcon from '@mui/icons-material/Sync';
import RowTableHistoryLog from './row-table-history-log';
import { HistoryLogModel } from '@/models/index';
import { SettingEmptyComponent } from '@/components/settings/empty';
import { useState } from 'react';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import ArrowForwardIcon from '@mui/icons-material/ArrowForward';
import { theme } from '@/ultis/theme';
interface TableMemberHistoryActionProps {
    data: HistoryLogModel[];
    maxPage: number;
    page: number;
    setPage: (page: number) => void;
}

export const TableMemberHistoryAction = (props: TableMemberHistoryActionProps) => {
    const { data, maxPage, setPage, page } = props;

    return (
        <TableContainer
            sx={{
                flex: 1,
                display: 'flex',
                flexDirection: 'column',
                justifyContent: 'space-between',
                alignItems: 'center',
                p: 2,
                gap: 2,
            }}
        >
            <Table
                sx={{
                    minWidth: 750,
                    '& th': {
                        padding: '10px',
                    },
                    maxWidth: 750,
                }}
                size="small"
            >
                <TableHead>
                    <TableRow>
                        <TableCell
                            sx={{
                                fontSize: '14px',
                                fontWeight: 600,
                                padding: '10px 0px',
                                flex: 1,
                            }}
                        >
                            Nội dung
                        </TableCell>
                        <TableCell
                            align="left"
                            sx={{
                                fontSize: '14px',
                                fontWeight: 600,
                                padding: '10px 0px',
                                flex: 1,
                                width: '25%',
                            }}
                        >
                            Lý do
                        </TableCell>
                        <TableCell
                            align="left"
                            sx={{
                                fontSize: '14px',
                                fontWeight: 600,
                                padding: '10px 0px',
                                width: '20%',
                            }}
                        >
                            Ngày thực hiện
                        </TableCell>
                        <TableCell
                            align="left"
                            sx={{
                                fontSize: '14px',
                                fontWeight: 600,
                                padding: '10px 0px',
                                width: '20%',
                            }}
                        >
                            Người thực hiện
                        </TableCell>
                    </TableRow>
                </TableHead>
                <TableBody>
                    {data.map((row, index) => (
                        <RowTableHistoryLog key={index} data={row} />
                    ))}
                </TableBody>
            </Table>
            {!data || data?.length === 0 ? (
                <SettingEmptyComponent />
            ) : (
                <Pagination
                    count={maxPage}
                    page={
                        page?.toString() && page?.toString() !== 'undefined'
                            ? parseInt(page?.toString())
                            : 1
                    }
                    onChange={(event, page) => {
                        setPage(page);
                    }}
                    renderItem={(item) => (
                        <PaginationItem
                            components={{ previous: ArrowBackIcon, next: ArrowForwardIcon }}
                            {...item}
                            shape="rounded"
                            sx={{
                                borderRadius: '4px',
                                border: '1px solid #DFE3E8',
                                '&.Mui-selected': {
                                    background: '#fff',
                                    border: '1px solid #067DC0',
                                    color: '#067DC0',
                                },

                                color: theme.palette.text.primary,
                            }}
                        />
                    )}
                    sx={{
                        py: 2,
                    }}
                />
            )}
        </TableContainer>
    );
};
