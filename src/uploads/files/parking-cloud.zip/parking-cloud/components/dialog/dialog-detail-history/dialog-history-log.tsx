import { historyInOutApi } from '@/api/history-in-out-api';
import { PaginationIDPayload } from '@/models/config.model';
import { Dialog, DialogContent, DialogTitle, useMediaQuery, useTheme } from '@mui/material';
import { useEffect, useMemo, useState } from 'react';
import { TableMemberHistoryAction } from './table-history-log';
import { HistoryLogModel } from '@/models/parking.model';
import { SIZE_PAGE } from '@/ultis/index';

export interface IDialogHistoryLogProps {
    open: boolean;
    handleClose: () => void;
    idHistory: string;
}

export default function DialogHistoryLog(props: IDialogHistoryLogProps) {
    const { open, handleClose, idHistory } = props;
    const theme = useTheme();
    const fullScreen = useMediaQuery(theme.breakpoints.down('md'));
    const [data, setData] = useState<HistoryLogModel[]>([]);
    const [page, setPage] = useState(1);
    const [total, setTotal] = useState(0);
    const currentPage = useMemo(() => {
        return page && !Number.isNaN(Number(page)) && Number.isInteger(Number(page))
            ? Number(page) - 1
            : 0;
    }, [page]);
    const maxPage = useMemo(() => {
        const sizePage = total === 0 ? 0 : Math.ceil(total / SIZE_PAGE);
        if (typeof window !== 'undefined' && currentPage > sizePage - 1) {
            setPage(1);
        }
        return sizePage;
    }, [total]);

    useEffect(() => {
        if (!idHistory) return;
        const payload: PaginationIDPayload = {
            ID: idHistory,
            Current: currentPage * SIZE_PAGE,
            Limit: SIZE_PAGE,
            TextSearch: '',
        };
        historyInOutApi
            .getLogHistoryEdit(payload)
            .then((res) => {
                const { Data, Total } = res.data;
                setData(Data);
                setTotal(Total);
            })
            .catch((err) => {
                console.log(err);
            });
    }, [idHistory, currentPage]);
    return (
        <Dialog
            fullScreen={fullScreen}
            open={open}
            onClose={handleClose}
            aria-labelledby="responsive-dialog-title"
            maxWidth={'lg'}
        >
            <DialogTitle>{'Lịch sử chỉnh sửa'}</DialogTitle>
            <DialogContent>
                <TableMemberHistoryAction
                    data={data}
                    maxPage={maxPage}
                    setPage={setPage}
                    page={page}
                />
            </DialogContent>
        </Dialog>
    );
}
