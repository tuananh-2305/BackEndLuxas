import {
    Avatar,
    Box,
    Button,
    Fade,
    MenuItem,
    Stack,
    TableCell,
    TableRow,
    Tooltip,
    Typography,
    useTheme,
} from '@mui/material';
import { useRouter } from 'next/router';
import { HistoryLogModel, ParkingModel } from '@/models/parking.model';
import DeleteOutlinedIcon from '@mui/icons-material/DeleteOutlined';
import BorderColorOutlinedIcon from '@mui/icons-material/BorderColorOutlined';
import { DeviceImeiModel, DeviceModel } from '@/models/index';
import CustomizedMenus from '@/components/common/menu/menu';
import { getDateTime } from '@/ultis/global-func';

const BACKEND_DOMAIN = process.env.NEXT_PUBLIC_SERVER_PARKING_DOMAIN;

export interface IRowTableHistoryLogProps {
    data: HistoryLogModel;
}

export default function RowTableHistoryLog(props: IRowTableHistoryLogProps) {
    const { data } = props;
    return (
        <TableRow
            sx={{
                '&:last-child td, &:last-child th': { border: 0 },
                '&:not(:last-child)': { marginBottom: '10px' },
            }}
        >
            <TableCell>
                <Tooltip title={data?.Content}>
                    <Box
                        sx={{
                            display: '-webkit-box',
                            WebkitLineClamp: 2,
                            WebkitBoxOrient: 'vertical',
                            overflow: 'hidden',
                            textOverflow: 'ellipsis',
                        }}
                    >
                        {data?.Content}
                    </Box>
                </Tooltip>
            </TableCell>
            <TableCell>
                <Tooltip title={data?.Description}>
                    <Box
                        sx={{
                            display: '-webkit-box',
                            WebkitLineClamp: 2,
                            WebkitBoxOrient: 'vertical',
                            overflow: 'hidden',
                            textOverflow: 'ellipsis',
                        }}
                    >
                        {data?.Description}{' '}
                    </Box>
                </Tooltip>
            </TableCell>
            <TableCell>{getDateTime(data?.CreatedAt)}</TableCell>
            <TableCell>{data?.UserCreate?.Name}</TableCell>
        </TableRow>
    );
}
