import { deviceApi } from '@/api/index';
import { useAppDispatch } from '@/hooks/index';
import { showSnackbarWithClose } from '@/hooks/useSnackbarWithClose';
import { DeviceCreatePayload, DeviceImeiModel } from '@/models/index';
import { createDevice } from '@/redux/index';
import { theme } from '@/ultis/index';
import {
    CircularProgress,
    Dialog,
    DialogActions,
    DialogContent,
    DialogTitle,
    Divider,
    InputLabel,
    Stack,
    Tooltip,
    Typography,
    useMediaQuery,
} from '@mui/material';
import { green } from '@mui/material/colors';
import { useEffect, useState } from 'react';
import { ComfirmCloseDialog } from '../dialog-comfirm-close';
import { StyleButton, StyledOutlinedInput } from '@/components/common/style-component';
import AutoCompoletePaymentMethod from '@/components/common/input/auto-complete-payment-mothod';
import {
    BillingInfoCreatePayload,
    BillingInfoModel,
    BillingInfoUpdatePayload,
} from '@/models/billing.info.model';
import { billingInfoApi } from '@/api/billing-info-api';

export interface IDialogUpdateBillingInfoProps {
    open: boolean;
    handleClose: () => void;
    handleReload?: () => void;
    dataUpdate: BillingInfoModel | null;
}

export default function DialogUpdateBillingInfo(props: IDialogUpdateBillingInfoProps) {
    const { open, handleClose, handleReload, dataUpdate } = props;
    const fullScreen = useMediaQuery(theme.breakpoints.down('md'));
    const [name, setName] = useState<string>(dataUpdate?.Name || '');
    const [code, setCode] = useState<string>(dataUpdate?.Code || '');
    const [isLoadingButton, setIsLoadingButton] = useState(false);
    const [openComfirm, setOpenComfirm] = useState(false);
    const [casePay, setCasePay] = useState(dataUpdate?.PaymentMethods || 'MOMO');
    const [nameAccountBank, setNameAccountBank] = useState<string>('');
    const [numberBank, setNumberBank] = useState<string>('');
    const [addressBank, setAddressBank] = useState<string>('');
    const [apiKey, setApiKey] = useState<string>('');
    const [clientId, setClientId] = useState<string>('');

    useEffect(() => {
        if (!open) {
            setName('');
            setCode('');
            setCasePay('MOMO');
            setAddressBank('');
            setNameAccountBank('');
            setNumberBank('');
            setApiKey('');
            setClientId('');
        } else {
            setName(dataUpdate?.Name || '');
            setCode(dataUpdate?.Code || '');
            setCasePay(dataUpdate?.PaymentMethods || 'MOMO');
            setAddressBank(dataUpdate?.AddressBank || '');
            setNameAccountBank(dataUpdate?.NameAccountBank || '');
            setNumberBank(dataUpdate?.NumberBank || '');
            setApiKey(dataUpdate?.ApiKey || '');
            setClientId(dataUpdate?.ClientId || '');
        }
    }, [open]);
    const handleCreateDevice = async () => {
        if (!dataUpdate) {
            showSnackbarWithClose('Có lỗi xảy ra', { variant: 'error' });
            return;
        }
        if (!name || name.trim() === '') {
            showSnackbarWithClose('Tên không được để trống', { variant: 'error' });
            return;
        }

        if (!casePay) {
            showSnackbarWithClose('Phương thức không được để trống', { variant: 'error' });
            return;
        }
        if (!code) {
            showSnackbarWithClose('Mã code không được để trống', { variant: 'error' });
            return;
        }
        if (!nameAccountBank) {
            showSnackbarWithClose('Tên tài khoản thanh toán không được để trống', {
                variant: 'error',
            });
            return;
        }
        if (!numberBank) {
            showSnackbarWithClose('Số tài khoản thanh toán không được để trống', {
                variant: 'error',
            });
            return;
        }
        if (!addressBank) {
            showSnackbarWithClose('Chi nhánh không được để trống', { variant: 'error' });
            return;
        }
        if (casePay == 'NAPAS') {
            if (!apiKey.trim()) {
                showSnackbarWithClose('Api key không được để trống', { variant: 'error' });
                return;
            }
            if (!clientId.trim()) {
                showSnackbarWithClose('Client id không được để trống', { variant: 'error' });
                return;
            }
        }
        setIsLoadingButton(true);
        const payload: BillingInfoUpdatePayload = {
            ID: dataUpdate.ID,
            Name: name.trim(),
            Code: code.trim(),
            PaymentMethods: casePay,
            NameAccountBank: nameAccountBank.trim(),
            NumberBank: numberBank.trim(),
            AddressBank: addressBank.trim(),
            ApiKey: apiKey.trim(),
            ClientId: clientId.trim(),
        };

        try {
            const { data } = await billingInfoApi.update(payload);
            handleReload && handleReload();
            handleClose();
        } catch (error: any) {
            if (Array.isArray(error?.response?.data?.message)) {
                error?.response?.data?.message.forEach((item: any) => {
                    showSnackbarWithClose(item, {
                        variant: 'error',
                    });
                });
            } else {
                showSnackbarWithClose(
                    error?.response ? error.response.data?.message : error.message,
                    {
                        variant: 'error',
                    }
                );
            }
        }
        setTimeout(() => {
            setIsLoadingButton(false);
        }, 1000);
    };
    return (
        <Dialog
            fullScreen={fullScreen}
            open={open}
            onClose={() => {
                if (name || code || casePay) {
                    setOpenComfirm(true);
                } else {
                    handleClose();
                }
            }}
            aria-labelledby="responsive-dialog-title"
            sx={{
                '& .MuiPaper-root': {
                    md: { minWidth: '500px', borderRadius: '16px' },
                },
            }}
        >
            <DialogTitle>{'Tạo phương thức thanh toán'}</DialogTitle>
            <DialogContent>
                <Stack py={2} spacing={2}>
                    <AutoCompoletePaymentMethod
                        setValue={setCasePay}
                        value={casePay}
                    ></AutoCompoletePaymentMethod>
                    <Stack>
                        <InputLabel required>Số tài khoản</InputLabel>
                        <StyledOutlinedInput
                            autoComplete="off"
                            value={numberBank}
                            onChange={(e) => {
                                setNumberBank(e.target.value);
                            }}
                            size="small"
                            fullWidth
                        />
                    </Stack>
                    <Stack>
                        <InputLabel required>Tên chủ tài khoản</InputLabel>
                        <StyledOutlinedInput
                            autoComplete="off"
                            value={nameAccountBank}
                            onChange={(e) => {
                                setNameAccountBank(e.target.value);
                            }}
                            size="small"
                            fullWidth
                        />
                    </Stack>

                    <Stack>
                        <InputLabel required>Chi nhánh</InputLabel>
                        <StyledOutlinedInput
                            autoComplete="off"
                            value={addressBank}
                            onChange={(e) => {
                                setAddressBank(e.target.value);
                            }}
                            size="small"
                            fullWidth
                        />
                    </Stack>
                    <Divider></Divider>
                    <Stack>
                        <InputLabel required>Tên</InputLabel>
                        <StyledOutlinedInput
                            autoComplete="off"
                            value={name}
                            onChange={(e) => {
                                setName(e.target.value);
                            }}
                            size="small"
                            fullWidth
                        />
                    </Stack>

                    <Stack>
                        <InputLabel required>Mã Code</InputLabel>
                        <StyledOutlinedInput
                            autoComplete="off"
                            value={code}
                            onChange={(e) => {
                                setCode(e.target.value);
                            }}
                            size="small"
                            fullWidth
                        />
                        <Typography
                            sx={{ fontSize: '10px', color: '#F95959', pt: 0.5 }}
                        >{`*Lưu ý code QR: thay đổi giá trị: Tiền => _TOTAL_PRICE_ và Nội dung => _DESCRIPTION_PLATENUMBER_`}</Typography>
                    </Stack>

                    {casePay == 'NAPAS' && (
                        <>
                            <Stack>
                                <InputLabel>Mã Api</InputLabel>
                                <StyledOutlinedInput
                                    autoComplete="off"
                                    value={apiKey}
                                    onChange={(e) => {
                                        setApiKey(e.target.value);
                                    }}
                                    size="small"
                                    fullWidth
                                />
                            </Stack>
                            <Stack>
                                <InputLabel>Mã khách hàng</InputLabel>
                                <StyledOutlinedInput
                                    autoComplete="off"
                                    value={clientId}
                                    onChange={(e) => {
                                        setClientId(e.target.value);
                                    }}
                                    size="small"
                                    fullWidth
                                />
                            </Stack>{' '}
                        </>
                    )}
                </Stack>
            </DialogContent>
            <DialogActions
                sx={{
                    px: 3,
                    pb: 3,
                }}
            >
                <Stack sx={{ m: 1, position: 'relative' }}>
                    <StyleButton
                        variant="contained"
                        onClick={handleCreateDevice}
                        disabled={isLoadingButton}
                    >
                        Cập nhật
                    </StyleButton>
                    {isLoadingButton && (
                        <CircularProgress
                            size={24}
                            sx={{
                                color: green[500],
                                position: 'absolute',
                                top: '50%',
                                left: '50%',
                                marginTop: '-12px',
                                marginLeft: '-12px',
                            }}
                        />
                    )}
                </Stack>
            </DialogActions>
            {openComfirm ? (
                <ComfirmCloseDialog
                    close={() => setOpenComfirm(false)}
                    action={() => {
                        setOpenComfirm(false);
                        handleClose();
                    }}
                />
            ) : (
                <></>
            )}
        </Dialog>
    );
}
