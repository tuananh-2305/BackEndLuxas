import { authApi } from '@/api/auth-api';
import { useAppSelector } from '@/hooks/index';
import { EmployeeCreatePayload, EmployeeModel } from '@/models/employee.model';
import { theme } from '@/ultis/index';
import {
    Box,
    Checkbox,
    CircularProgress,
    Dialog,
    DialogActions,
    DialogContent,
    DialogTitle,
    FormControlLabel,
    InputLabel,
    MenuItem,
    Select,
    Stack,
    useMediaQuery,
} from '@mui/material';
import Grid2 from '@mui/material/Unstable_Grid2';
import { enqueueSnackbar } from 'notistack';
import { useEffect, useState } from 'react';
import { StyleButton } from '../common/style-component/button';
import { StyledOutlinedInput } from '../common/style-component/input';
import { showSnackbarWithClose } from '@/hooks/useSnackbarWithClose';
import { green } from '@mui/material/colors';
import { ComfirmCloseDialog } from './dialog-comfirm-close';

export interface IDialogCreateEmployeeProps {
    open: boolean;
    handleClose: () => void;
    handleReload?: () => void;
    dataUpdate?: EmployeeModel | null;
}
const regex = /[a-zA-Z]/;

export default function DialogCreateEmployee(props: IDialogCreateEmployeeProps) {
    const { open, handleClose, handleReload, dataUpdate } = props;
    const nameDialog = 'nhân viên';
    const fullScreen = useMediaQuery(theme.breakpoints.down('md'));
    const [phone, setPhone] = useState('');
    const [name, setName] = useState('');
    const [email, setEmail] = useState('');
    const [pass, setPass] = useState<string>('');
    const [rePass, setRePass] = useState<string>('');
    const [avatar, setAvatar] = useState<File | null>(null);
    const [userName, setUserName] = useState<string>('');
    const [isLoginCloud, setIsLoginCloud] = useState(false);
    const [isStaffManagement, setIsStaffManagement] = useState(false);
    const [isDecentralizedAccess, setIsDecentralizedAccess] = useState(false);
    const [isActive, setIsActive] = useState(0);
    const [gender, setGender] = useState('Nữ');
    const { profile } = useAppSelector((state) => state.common);
    const [isLoadingButton, setIsLoadingButton] = useState(false);
    const [openComfirm, setOpenComfirm] = useState(false);

    const handleCreateEmployee = async () => {
        if (!name) {
            showSnackbarWithClose(`Tên ${nameDialog} không được để trống`, { variant: 'error' });
            return;
        }
        if (!phone) {
            showSnackbarWithClose('Vui lòng nhập số điện thoại', { variant: 'error' });
            return;
        }
        if (!pass) {
            showSnackbarWithClose('Vui lòng nhập mật khẩu', { variant: 'error' });
            return;
        } else if (pass !== rePass) {
            showSnackbarWithClose('Nhập lại mật khẩu không chính xác', { variant: 'error' });
            return;
        }
        if (!profile?.CustomerId?.ID) {
            showSnackbarWithClose(
                'Xảy ra lỗi đăng nhập, Vui lòng tải lại trang hoặc đăng nhập lại!',
                {
                    variant: 'error',
                }
            );
            return;
        }

        if (!regex.test(userName.trim())) {
            showSnackbarWithClose('Tài khoản phải chứa ít nhất 1 ký tự', { variant: 'error' });
            return;
        }

        if (userName.trim().length < 6) {
            showSnackbarWithClose('Tài khoản phải có độ dài ít nhất 6', {
                variant: 'error',
            });
            return;
        }

        if (!name || !phone || !pass || !rePass) return;
        setIsLoadingButton(true);
        const payload: EmployeeCreatePayload = {
            Name: name.trim(),
            CustomerId: profile?.CustomerId?.ID || '',
            IsDecentralizedAccess: isDecentralizedAccess,
            Phone: phone,
            IsLoginCloud: isLoginCloud,
            IsStaffManagement: isStaffManagement,
            Password: pass,
            IsActive: isActive === 1 ? true : false,
            Gender: gender,
            UserName: userName,
        };
        if (email && email.trim()) {
            payload.Email = email.trim();
        }
        try {
            await authApi.register(payload);
            showSnackbarWithClose(`Tạo ${nameDialog} thành công`, { variant: 'success' });
            handleReload && handleReload();
            handleClose();
        } catch (error: any) {
            if (Array.isArray(error?.response?.data?.message)) {
                error?.response?.data?.message.forEach((item: any) => {
                    showSnackbarWithClose(item, {
                        variant: 'error',
                    });
                });
            } else {
                showSnackbarWithClose(
                    error?.response ? error.response.data?.message : error.message,
                    {
                        variant: 'error',
                    }
                );
            }
        }
        setTimeout(() => {
            setIsLoadingButton(false);
        }, 1000);
    };

    const handleUpdateEmployee = async () => {
        if (!name) {
            showSnackbarWithClose(`Tên ${nameDialog} không được để trống`, { variant: 'error' });
            return;
        }
        if (!phone) {
            showSnackbarWithClose('Vui lòng nhập số điện thoại', { variant: 'error' });
            return;
        }
        if (!profile?.CustomerId?.ID) {
            showSnackbarWithClose(
                'Xảy ra lỗi đăng nhập, Vui lòng tải lại trang hoặc đăng nhập lại!',
                {
                    variant: 'error',
                }
            );
            return;
        }

        if (!regex.test(userName.trim())) {
            showSnackbarWithClose('Tài khoản phải chứa ít nhất 1 ký tự', {
                variant: 'error',
            });
            return;
        }

        if (userName.trim().length < 6) {
            showSnackbarWithClose('Tài khoản phải có độ dài ít nhất 6', {
                variant: 'error',
            });
            return;
        }

        if (!name || !phone) return;
        const payload: EmployeeCreatePayload = {
            Name: name,
            CustomerId: profile?.CustomerId?.ID || '',
            IsDecentralizedAccess: isDecentralizedAccess,
            Phone: phone,
            IsLoginCloud: isLoginCloud,
            IsStaffManagement: isStaffManagement,
            IsActive: isActive === 1 ? true : false,
            Gender: gender,
            Password: '',
            UserName: userName,
            ID: dataUpdate?.ID,
        };
        if (email) {
            payload.Email = email;
        }
        if (pass) {
            if (pass !== rePass) {
                showSnackbarWithClose('Nhập lại mật khẩu không chính xác', { variant: 'error' });
                return;
            }
            payload.Password = pass;
        }
        try {
            await authApi.updateByAdmin(payload);
            showSnackbarWithClose(`Chỉnh sửa ${nameDialog} thành công`, { variant: 'success' });
            handleReload && handleReload();
            handleClose();
        } catch (error: any) {
            if (Array.isArray(error?.response?.data?.message)) {
                error?.response?.data?.message.forEach((item: any) => {
                    showSnackbarWithClose(item, {
                        variant: 'error',
                    });
                });
            } else {
                showSnackbarWithClose(
                    error?.response ? error.response.data?.message : error.message,
                    {
                        variant: 'error',
                    }
                );
            }
        }
    };
    useEffect(() => {
        if (dataUpdate) {
            setName(dataUpdate.Name);
            setPhone(dataUpdate.Phone);

            setUserName(dataUpdate.UserName ? dataUpdate.UserName : '');
            setEmail(dataUpdate.Email ? dataUpdate.Email : '');
            setGender(dataUpdate.Gender ? dataUpdate.Gender : 'Nữ');
            setIsLoginCloud(dataUpdate.IsLoginCloud ? dataUpdate.IsLoginCloud : false);
            setIsStaffManagement(
                dataUpdate.IsStaffManagement ? dataUpdate.IsStaffManagement : false
            );
            setIsDecentralizedAccess(
                dataUpdate.IsDecentralizedAccess ? dataUpdate.IsDecentralizedAccess : false
            );
            setIsActive(dataUpdate.IsActive ? 1 : 0);
        }
    }, [dataUpdate]);

    useEffect(() => {
        if (!open) {
            setName('');
            setPhone('');
            setEmail('');
            setPass('');
            setRePass('');
            setAvatar(null);
            setIsLoginCloud(false);
            setIsStaffManagement(false);
            setIsDecentralizedAccess(false);
            setIsActive(0);
            setIsLoadingButton(false);
            setUserName('');
        }
    }, [open]);
    return (
        <Dialog
            fullScreen={fullScreen}
            open={open}
            onClose={() => {
                if (name || phone || email || pass || rePass) {
                    setOpenComfirm(true);
                } else {
                    handleClose();
                }
            }}
            aria-labelledby="responsive-dialog-title"
            sx={{
                '& .MuiPaper-root': {
                    md: { minWidth: '500px', borderRadius: '16px' },
                },
            }}
        >
            <DialogTitle>
                {dataUpdate ? `Chỉnh sửa ${nameDialog}` : `Tạo ${nameDialog} mới`}
            </DialogTitle>
            <DialogContent>
                <Stack py={2} spacing={2}>
                    {/* <InputUploadImage avatar={avatar} setAvatar={setAvatar} /> */}
                    <Stack>
                        <InputLabel>Họ và tên*</InputLabel>
                        <StyledOutlinedInput
                            autoComplete="off"
                            value={name}
                            onChange={(e: any) => {
                                setName(e.target.value);
                            }}
                            size="small"
                        />
                    </Stack>
                    <Stack>
                        <InputLabel>Tài khoản*</InputLabel>
                        <StyledOutlinedInput
                            autoComplete="off"
                            value={userName}
                            onChange={(e: any) => {
                                const { value } = e.target;
                                if (!value.includes(' ')) {
                                    setUserName(e.target.value);
                                }
                            }}
                            size="small"
                        />
                    </Stack>
                    <Grid2 container>
                        <Grid2 xs={12} sm={6} pr={0.5}>
                            <Stack>
                                <InputLabel>Email</InputLabel>
                                <StyledOutlinedInput
                                    autoComplete="off"
                                    value={email}
                                    onChange={(e) => {
                                        setEmail(e.target.value);
                                    }}
                                    size="small"
                                    fullWidth
                                    type={'email'}
                                />
                            </Stack>
                        </Grid2>
                        <Grid2 xs={12} sm={6} pl={0.5}>
                            <Stack>
                                <InputLabel>Số điện thoại*</InputLabel>
                                <StyledOutlinedInput
                                    autoComplete="off"
                                    value={phone}
                                    onChange={(e) => {
                                        setPhone(e.target.value);
                                    }}
                                    size="small"
                                    fullWidth
                                />
                            </Stack>
                        </Grid2>
                    </Grid2>

                    <Grid2 container>
                        <Grid2 xs={12} sm={6} pr={0.5}>
                            <Stack>
                                <InputLabel>Mật khẩu*</InputLabel>
                                <StyledOutlinedInput
                                    autoComplete="off"
                                    value={pass}
                                    onChange={(e) => {
                                        setPass(e.target.value);
                                    }}
                                    size="small"
                                    fullWidth
                                    type="password"
                                />
                            </Stack>
                        </Grid2>
                        <Grid2 xs={12} sm={6} pl={0.5}>
                            <Stack>
                                <InputLabel>Nhập lại mật khẩu*</InputLabel>
                                <StyledOutlinedInput
                                    value={rePass}
                                    autoComplete="off"
                                    onChange={(e) => {
                                        setRePass(e.target.value);
                                    }}
                                    size="small"
                                    fullWidth
                                    type="password"
                                />
                            </Stack>
                        </Grid2>
                    </Grid2>
                    <Stack alignItems={'center'}>
                        <Box
                            sx={{
                                borderBottom: '2px dashed #E0E0E0',
                                width: '280px',
                                py: 1,
                            }}
                        ></Box>
                    </Stack>
                    <Grid2 container>
                        <Grid2 xs={12} sm={6} pl={0.5}>
                            <Stack>
                                <InputLabel>Giới tính</InputLabel>
                                <Select
                                    labelId="demo-simple-select-label"
                                    fullWidth
                                    size="small"
                                    sx={{
                                        borderRadius: '10px',
                                    }}
                                    value={gender}
                                    onChange={(e) => setGender(e.target.value as string)}
                                >
                                    <MenuItem value={'Nữ'}>Nữ</MenuItem>
                                    <MenuItem value={'Nam'}>Nam</MenuItem>
                                    <MenuItem value={'Khác'}>Khác</MenuItem>
                                </Select>
                            </Stack>
                        </Grid2>
                        <Grid2 xs={12} sm={6} pl={0.5}>
                            <Stack>
                                <InputLabel>Kích hoạt tài khoản</InputLabel>
                                <Select
                                    labelId="demo-simple-select-label"
                                    fullWidth
                                    size="small"
                                    sx={{
                                        borderRadius: '10px',
                                    }}
                                    value={isActive}
                                    onChange={(e) => {
                                        setIsActive(e.target.value as number);
                                    }}
                                >
                                    <MenuItem value={0}>Chưa kích hoạt</MenuItem>
                                    <MenuItem value={1}>Đã kích hoạt</MenuItem>
                                </Select>
                            </Stack>
                        </Grid2>
                    </Grid2>
                    <Grid2 container>
                        <Grid2 xs={12} sm={12} pr={0.5}>
                            <Stack>
                                <FormControlLabel
                                    control={
                                        <Checkbox
                                            checked={isLoginCloud}
                                            onChange={(
                                                event: React.ChangeEvent<HTMLInputElement>
                                            ) => {
                                                setIsLoginCloud(event.target.checked);
                                                if (!event.target.checked) {
                                                    setIsStaffManagement(false);
                                                    setIsDecentralizedAccess(false);
                                                }
                                            }}
                                        />
                                    }
                                    label="Đăng nhập Cloud"
                                />
                                <Stack sx={{ pl: 5 }}>
                                    <FormControlLabel
                                        control={
                                            <Checkbox
                                                checked={isStaffManagement}
                                                onChange={(
                                                    event: React.ChangeEvent<HTMLInputElement>
                                                ) =>
                                                    setIsStaffManagement(
                                                        isLoginCloud ? event.target.checked : false
                                                    )
                                                }
                                                disabled={!isLoginCloud}
                                            />
                                        }
                                        label="Quản trị nhân viên"
                                    />
                                    <FormControlLabel
                                        control={
                                            <Checkbox
                                                checked={isDecentralizedAccess}
                                                onChange={(
                                                    event: React.ChangeEvent<HTMLInputElement>
                                                ) =>
                                                    setIsDecentralizedAccess(
                                                        isLoginCloud ? event.target.checked : false
                                                    )
                                                }
                                                disabled={!isLoginCloud}
                                            />
                                        }
                                        label="Truy cập phân quyền"
                                    />
                                </Stack>
                            </Stack>
                        </Grid2>
                    </Grid2>
                </Stack>
            </DialogContent>
            <DialogActions
                sx={{
                    px: 3,
                    pb: 3,
                }}
            >
                {dataUpdate ? (
                    <StyleButton variant="contained" onClick={handleUpdateEmployee}>
                        Cập nhật
                    </StyleButton>
                ) : (
                    <Stack sx={{ m: 1, position: 'relative' }}>
                        <StyleButton
                            variant="contained"
                            onClick={handleCreateEmployee}
                            disabled={isLoadingButton}
                        >
                            Tạo mới
                        </StyleButton>
                        {isLoadingButton && (
                            <CircularProgress
                                size={24}
                                sx={{
                                    color: green[500],
                                    position: 'absolute',
                                    top: '50%',
                                    left: '50%',
                                    marginTop: '-12px',
                                    marginLeft: '-12px',
                                }}
                            />
                        )}
                    </Stack>
                )}
            </DialogActions>
            {openComfirm ? (
                <ComfirmCloseDialog
                    close={() => setOpenComfirm(false)}
                    action={() => {
                        setOpenComfirm(false);
                        handleClose();
                    }}
                />
            ) : (
                <></>
            )}
        </Dialog>
    );
}
