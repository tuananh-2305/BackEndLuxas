import {
    Pagination,
    PaginationItem,
    Paper,
    Stack,
    Table,
    TableBody,
    TableContainer,
    TableFooter,
    TableRow,
    useTheme,
} from '@mui/material';
import React, { useEffect, useRef, useState } from 'react';

import { ParkingModel } from '@/models/parking.model';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import ArrowForwardIcon from '@mui/icons-material/ArrowForward';
import { columnsCustomer, headerData, headerImei } from '@/mocks/header-mock';
import { CustomerModel, DeviceImeiModel } from '@/models/index';
import HeaderTable from '@/components/table/header-table';
import RowTableCustomer from './row-table-customer';
import { CustomerInterface } from '@/redux/index';
import DialogUpdateCustomer from '../dialog/dialog-update/dialog-update-customer';

export interface TableCustomerDataProps {
    data: CustomerInterface[];
    handleReload: () => void;
}

export default function TableCustomerData(props: TableCustomerDataProps) {
    const { data, handleReload } = props;
    const [openDialogUpdate, setOpenDialogUpdate] = useState(false);
    const [itemHandle, setItemHandle] = useState<CustomerModel>();

    return (
        <TableContainer
            sx={{
                flex: 1,
                display: 'flex',
                flexDirection: 'column',
                justifyContent: 'space-between',
                alignItems: 'center',
            }}
        >
            <Table
                sx={{
                    borderCollapse: 'separate',
                    borderSpacing: '0 10px',
                }}
            >
                <HeaderTable headerData={columnsCustomer} />
                {itemHandle && (
                    <DialogUpdateCustomer
                        open={openDialogUpdate}
                        handleClose={() => {
                            setOpenDialogUpdate(false);
                            setItemHandle(undefined);
                        }}
                        customer={itemHandle}
                        handleReload={handleReload}
                    />
                )}
                <TableBody
                    sx={{
                        maxHeight: '200px',
                        overflow: 'auto',
                        '& td': {
                            background: 'rgba(217, 217, 217, 0.2)',
                        },
                        'td:first-of-type': {
                            borderTopLeftRadius: '10px',
                            borderBottomLeftRadius: '10px',
                        },
                        'td:last-of-type': {
                            borderTopRightRadius: '10px',
                            borderBottomRightRadius: '10px',
                        },
                    }}
                >
                    {data?.map((c) => (
                        <RowTableCustomer
                            key={`card-type-${c?.ID}`}
                            data={c}
                            handleEdit={(item) => {
                                setItemHandle(item);
                                setOpenDialogUpdate(true);
                            }}
                            fetchData={handleReload}
                        />
                    ))}
                </TableBody>
            </Table>

            {/* <Pagination
                count={6}
                onChange={(event, value) => setPage(value.toString())}
                renderItem={(item) => (
                    <PaginationItem
                        components={{ previous: ArrowBackIcon, next: ArrowForwardIcon }}
                        {...item}
                        shape="rounded"
                        sx={{
                            borderRadius: '4px',
                            border: '1px solid #DFE3E8',
                            '&.Mui-selected': {
                                background: '#fff',
                                border: '1px solid #067DC0',
                                color: '#067DC0',
                            },

                            color: theme.palette.text.primary,
                        }}
                    />
                )}
                sx={{
                    py: 2,
                }}
            /> */}
        </TableContainer>
    );
}
