import { customerApi } from '@/api/customer-api';
import { CustomerModel, CustomerUpdatePayload } from '@/models/index';
import { getNameAddress, showAddress } from '@/ultis/index';
import { MenuItem, Stack, TableCell, TableRow, Typography } from '@mui/material';
import { enqueueSnackbar } from 'notistack';
import { useState } from 'react';
import { AvatarCustom } from '../common';
import ActionTable from '../common/action-table/action-table';
import DialogCreateAccount from '../dialog/dialog-create-account';
import { showSnackbarWithClose } from '@/hooks/useSnackbarWithClose';
const BACKEND_DOMAIN = process.env.NEXT_PUBLIC_SERVER_PARKING_DOMAIN;

export interface IRowTableCustomerProps {
    data: CustomerModel;
    fetchData?: () => void;
    handleEdit?: (item: CustomerModel) => void;
}

export default function RowTableCustomer(props: IRowTableCustomerProps) {
    const { data, fetchData, handleEdit } = props;
    const [openDialogCreate, setOpenDialogCreate] = useState(false);

    const handleDelete = () => {
        const payload: CustomerUpdatePayload = {
            ID: data.ID,
            IsDelete: true,
        };
        customerApi
            .deleteCustomer(data.ID)
            .then((res) => {
                if (res.data) {
                    fetchData && fetchData();
                    showSnackbarWithClose('Xóa thành công', { variant: 'success' });
                }
            })
            .catch((error) => {
                if (Array.isArray(error?.response?.data?.message)) {
                    error?.response?.data?.message.forEach((item: any) => {
                        showSnackbarWithClose(item, {
                            variant: 'error',
                        });
                    });
                } else {
                    showSnackbarWithClose(
                        error?.response ? error.response.data?.message : error.message,
                        {
                            variant: 'error',
                        }
                    );
                }
            });
    };
    return (
        <TableRow
            sx={{
                '&:last-child td, &:last-child th': { border: 0 },
                '&:not(:last-child)': { marginBottom: '10px' },
            }}
        >
            <DialogCreateAccount
                open={openDialogCreate}
                handleClose={() => setOpenDialogCreate(false)}
                handleReload={fetchData}
                customerModel={data}
            ></DialogCreateAccount>
            {/* <TableCell scope="row">{data.ID}</TableCell> */}
            <TableCell>
                <Stack direction={'row'} spacing={1} alignItems={'center'}>
                    <AvatarCustom
                        src={data.Avatar ? BACKEND_DOMAIN + data.Avatar : ''}
                        type="circle"
                        size={40}
                        alt={data?.FullName}
                    />
                    <Stack justifyContent={'space-between'}>
                        <Typography variant="body2">{data.FullName}</Typography>
                    </Stack>
                </Stack>
            </TableCell>
            <TableCell>{data.PhoneNumber}</TableCell>
            <TableCell>{data.Email}</TableCell>
            <TableCell>{!data?.CompanyId?.IsDelete ? data?.CompanyId?.Name : ''}</TableCell>
            <TableCell>
                {showAddress(
                    data?.Address || '',
                    getNameAddress(data?.Wards),
                    getNameAddress(data?.District),
                    getNameAddress(data?.Province)
                )}
            </TableCell>
            {/* <TableCell>{data.Status}</TableCell> */}
            <TableCell>
                <ActionTable
                    size={'small'}
                    sx={{ width: '100%' }}
                    onDelete={handleDelete}
                    onEdit={() => {
                        handleEdit && handleEdit(data);
                    }}
                    onSync={data.IsUpdate || data.IsInsert ? () => {} : undefined}
                >
                    {!data.IsUserLogin && (
                        <MenuItem
                            sx={{ color: 'black' }}
                            onClick={() => {
                                setOpenDialogCreate(true);
                            }}
                        >
                            Cấp tài khoản
                        </MenuItem>
                    )}

                    {/* <MenuItem sx={{ color: 'black' }}>Thêm thành viên</MenuItem> */}
                </ActionTable>
            </TableCell>
        </TableRow>
    );
}
