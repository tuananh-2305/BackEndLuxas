import {
    Avatar,
    Card,
    CardHeader,
    Checkbox,
    Collapse,
    Divider,
    List,
    ListItemText,
    Stack,
    Typography,
} from '@mui/material';
import { memo, useState } from 'react';
import { ExpandMoreCustom, ListItem } from '../style-component';
import { ItemMenuModel, KeyRoleItemMenuModel } from '@/models/index';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
const BACKEND_DOMAIN = process.env.NEXT_PUBLIC_SERVER_PARKING_DOMAIN;
export interface IListRoleComponentProps {
    keyRoleItem: KeyRoleItemMenuModel;
    handleSetCHecked: (keyRoleItem: KeyRoleItemMenuModel) => void;
}

const ListRole = ({ keyRoleItem, handleSetCHecked }: IListRoleComponentProps) => {
    const checkAll =
        keyRoleItem.IsDelete && keyRoleItem.IsUpdate && keyRoleItem.IsRead && keyRoleItem.IsInsert;

    const handleToggleAll = () => {
        if (checkAll) {
            // new KeyRoleItemMenuModel();
            // and set all value to false
            const newKeyRoleItem = {
                ...keyRoleItem,
                IsDelete: false,
                IsUpdate: false,
                IsRead: false,
                IsInsert: false,
            };
            handleSetCHecked(newKeyRoleItem);
        } else {
            // new KeyRoleItemMenuModel();
            // and set all value to true
            const newKeyRoleItem = {
                ...keyRoleItem,
                IsDelete: true,
                IsUpdate: true,
                IsRead: true,
                IsInsert: true,
            };
            handleSetCHecked(newKeyRoleItem);
        }
    };
    const [expanded, setExpanded] = useState(false);
    const handleExpandClick = () => {
        setExpanded(!expanded);
    };
    const checkSome =
        keyRoleItem.IsDelete || keyRoleItem.IsUpdate || keyRoleItem.IsRead || keyRoleItem.IsInsert;
    return (
        <Stack sx={{ backgroundColor: 'rgba(217, 217, 217, 0.5)', borderRadius: '4px' }}>
            <Stack direction={'row'} alignItems={'center'}>
                <Checkbox
                    onClick={handleToggleAll}
                    checked={checkAll}
                    indeterminate={!checkAll && checkSome}
                    // disabled={items.length === 0}
                    inputProps={{
                        'aria-label': 'all items selected',
                    }}
                />
                <Typography variant="subtitle1">{keyRoleItem.Name}</Typography>
                <ExpandMoreCustom
                    expand={expanded}
                    onClick={handleExpandClick}
                    aria-expanded={expanded}
                    aria-label="show more"
                >
                    <ExpandMoreIcon />
                </ExpandMoreCustom>
            </Stack>
            <Collapse in={expanded} timeout="auto" unmountOnExit>
                <List
                    sx={{
                        bgcolor: 'transparent',
                        overflow: 'auto',
                        p: 1,

                        overflowY: 'auto',
                    }}
                    dense
                    component="div"
                    role="list"
                >
                    <ListItem
                        role="listitem"
                        onClick={() => {
                            handleSetCHecked({
                                ...keyRoleItem,
                                IsRead: !keyRoleItem.IsRead,
                            });
                        }}
                    >
                        <Checkbox checked={keyRoleItem.IsRead} tabIndex={-1} disableRipple />
                        <ListItemText
                            primary={'Xem'}
                            sx={{
                                '& .MuiListItemText-primary': {
                                    // color: '#abb4d2',
                                },
                                cursor: 'pointer',
                            }}
                        />
                    </ListItem>
                    <ListItem
                        role="listitem"
                        onClick={() => {
                            handleSetCHecked({
                                ...keyRoleItem,
                                IsInsert: !keyRoleItem.IsInsert,
                            });
                        }}
                    >
                        <Checkbox checked={keyRoleItem.IsInsert} tabIndex={-1} disableRipple />
                        <ListItemText
                            primary={'Thêm mới'}
                            sx={{
                                '& .MuiListItemText-primary': {
                                    // color: '#abb4d2',
                                },
                                cursor: 'pointer',
                            }}
                        />
                    </ListItem>
                    <ListItem
                        role="listitem"
                        onClick={() => {
                            handleSetCHecked({
                                ...keyRoleItem,
                                IsUpdate: !keyRoleItem.IsUpdate,
                            });
                        }}
                    >
                        <Checkbox checked={keyRoleItem.IsUpdate} tabIndex={-1} disableRipple />
                        <ListItemText
                            primary={'Cập nhật'}
                            sx={{
                                '& .MuiListItemText-primary': {
                                    // color: '#abb4d2',
                                },
                                cursor: 'pointer',
                            }}
                        />
                    </ListItem>
                    <ListItem
                        role="listitem"
                        onClick={() => {
                            handleSetCHecked({
                                ...keyRoleItem,
                                IsDelete: !keyRoleItem.IsDelete,
                            });
                        }}
                    >
                        <Checkbox checked={keyRoleItem.IsDelete} tabIndex={-1} disableRipple />
                        <ListItemText
                            primary={'Xóa'}
                            sx={{
                                '& .MuiListItemText-primary': {
                                    // color: '#abb4d2',
                                },
                                cursor: 'pointer',
                            }}
                        />
                    </ListItem>
                </List>
            </Collapse>
        </Stack>
    );
};
export default ListRole;
