import {
    Avatar,
    Card,
    CardHeader,
    Checkbox,
    Collapse,
    Divider,
    List,
    ListItemText,
    Stack,
    Typography,
} from '@mui/material';
import { memo, useState } from 'react';
import { ExpandMoreCustom, ListItem } from '../style-component';
import { ItemMenuModel } from '@/models/index';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
const BACKEND_DOMAIN = process.env.NEXT_PUBLIC_SERVER_PARKING_DOMAIN;
export interface IUserListComponentProps {
    // title: string;
    items: ItemMenuModel[];
    checked: ItemMenuModel[];
    setChecked: (checked: ItemMenuModel[]) => void;
    isAvatar?: boolean;
    title?: string;
}

const ListMulti = ({ checked, items, setChecked, isAvatar, title }: IUserListComponentProps) => {
    function intersectionUser(a: readonly ItemMenuModel[], b: readonly ItemMenuModel[]) {
        return a.filter((item) => b.findIndex((i) => i.ID === item.ID) !== -1);
    }
    function notUser(a: readonly ItemMenuModel[], b: readonly ItemMenuModel[]) {
        return a.filter((item) => b.findIndex((i) => i.ID === item.ID) === -1);
    }
    function unionUser(a: readonly ItemMenuModel[], b: readonly ItemMenuModel[]) {
        return [...a, ...notUser(b, a)];
    }
    const handleToggle = (value: ItemMenuModel) => () => {
        const currentIndex = checked.findIndex((item: ItemMenuModel) => item.ID === value.ID);
        const newChecked = [...checked];

        if (currentIndex === -1) {
            newChecked.push(value);
        } else {
            newChecked.splice(currentIndex, 1);
        }
        setChecked(newChecked);
    };
    const numberOfChecked = (items: readonly ItemMenuModel[]) =>
        intersectionUser(checked, items).length;

    const handleToggleAll = (items: readonly ItemMenuModel[]) => () => {
        if (numberOfChecked(items) === items.length) {
            setChecked(notUser(checked, items));
        } else {
            setChecked(unionUser(checked, items));
        }
    };

    const [expanded, setExpanded] = useState(false);
    const handleExpandClick = () => {
        setExpanded(!expanded);
    };
    return (
        <Stack sx={{ backgroundColor: 'rgba(217, 217, 217, 0.5)', borderRadius: '4px' }}>
            <Stack direction={'row'} alignItems={'center'}>
                <Checkbox
                    onClick={handleToggleAll(items)}
                    checked={numberOfChecked(items) === items.length && items.length !== 0}
                    indeterminate={
                        numberOfChecked(items) !== items.length && numberOfChecked(items) !== 0
                    }
                    disabled={items.length === 0}
                    inputProps={{
                        'aria-label': 'all items selected',
                    }}
                />
                <Typography variant="subtitle1">{title}</Typography>
                <ExpandMoreCustom
                    expand={expanded}
                    onClick={handleExpandClick}
                    aria-expanded={expanded}
                    aria-label="show more"
                >
                    <ExpandMoreIcon />
                </ExpandMoreCustom>
            </Stack>
            <Collapse in={expanded} timeout="auto" unmountOnExit>
                <List
                    sx={{
                        bgcolor: 'transparent',
                        overflow: 'auto',
                        p: 1,

                        overflowY: 'auto',
                    }}
                    dense
                    component="div"
                    role="list"
                >
                    {items.map((value: ItemMenuModel, index) => {
                        const labelId = `transfer-list-all-item-${value.ID}-label`;
                        return (
                            <ListItem
                                key={value.ID + index}
                                role="listitem"
                                onClick={handleToggle(value)}
                            >
                                <Checkbox
                                    checked={
                                        checked.findIndex((item) => item.ID === value.ID) !== -1
                                    }
                                    tabIndex={-1}
                                    disableRipple
                                    inputProps={{
                                        'aria-labelledby': labelId,
                                    }}
                                />
                                {isAvatar && (
                                    <Avatar
                                        alt={value.Name}
                                        sx={{
                                            width: '32px',
                                            height: '32px',
                                            mr: 1,
                                            cursor: 'pointer',
                                        }}
                                        src={value.Avatar ? BACKEND_DOMAIN + value.Avatar : ''}
                                    />
                                )}

                                <ListItemText
                                    id={labelId}
                                    primary={value.Name}
                                    sx={{
                                        '& .MuiListItemText-primary': {
                                            // color: '#abb4d2',
                                        },
                                        cursor: 'pointer',
                                    }}
                                />
                            </ListItem>
                        );
                    })}
                </List>
            </Collapse>
        </Stack>
    );
};
export default ListMulti;
