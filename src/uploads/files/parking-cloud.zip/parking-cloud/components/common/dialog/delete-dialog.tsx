import * as React from 'react';
import Button from '@mui/material/Button';
import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import DialogContentText, { DialogContentTextTypeMap } from '@mui/material/DialogContentText';
import DialogTitle from '@mui/material/DialogTitle';
import { Avatar, Stack, TextField, Typography, useTheme } from '@mui/material';
import DeleteOutlineOutlinedIcon from '@mui/icons-material/DeleteOutlineOutlined';
import { OverridableComponent } from '@mui/material/OverridableComponent';
export interface IDeleteDialogProps {
    open: boolean;
    handleClose: (() => void) | undefined;
    textOption?: any;
    handleConfirm: () => void;
}

export default function DeleteDialog(props: IDeleteDialogProps) {
    const { handleClose } = props;
    const theme = useTheme();
    // chưa xong
    return (
        <Dialog
            open={props.open}
            aria-labelledby="alert-dialog-title"
            aria-describedby="alert-dialog-description"
            // maxWidth={'xs'}
            // fullWidth
            sx={{
                '& .MuiDialog-paper': {
                    borderRadius: '10px',
                    pb: '20px',
                },
            }}
        >
            <DialogTitle
                id="alert-dialog-title"
                sx={{
                    display: 'flex',
                    flexDirection: 'row',
                    justifyContent: 'center',
                    alignItems: 'center',
                }}
            >
                <Stack
                    sx={{
                        background: '#E42727',
                        borderRadius: '50%',
                        padding: '10px',
                        width: '28px',
                        height: '28px',
                        justifyContent: 'center',
                        alignItems: 'center',
                        fontSize: '20px',
                        fontWeight: '700',
                        color: '#323232',
                        mr: '10px',
                    }}
                >
                    <DeleteOutlineOutlinedIcon
                        sx={{ width: '18px', height: '18px', color: '#fff' }}
                    />
                </Stack>
                Xóa dữ liệu
            </DialogTitle>
            <DialogContent sx={{ maxWidth: '393px' }}>
                {props.textOption}
                {/* <DialogContentText
                    id="alert-dialog-description"
                    sx={{
                        fontSize: '14px',
                        fontWeight: '400',
                        color: '#E42727',
                        textAlign: 'center',
                        pb: '10px',
                    }}
                >
                    cư dân <strong>Phan Thanh Hải</strong> có 1 thẻ và 1 phương tiện
                </DialogContentText> */}
                <DialogContentText
                    id="alert-dialog-description"
                    sx={{
                        fontSize: '14px',
                        fontWeight: '400',
                        color: '#55595D',
                        textAlign: 'center',
                    }}
                >
                    Dữ liệu sẽ không thể phục hồi sau khi thực hiện hành động này, bạn có chắc chắn
                    xóa không?
                </DialogContentText>
            </DialogContent>
            <DialogActions sx={{ px: '10%', gap: '10px' }}>
                <Button
                    onClick={handleClose}
                    variant="contained"
                    sx={{
                        flex: 1,
                        background: '#CDD2D1',
                        ':hover': {
                            background: '#DBE8E1',
                        },
                        fontSize: '14px',
                        fontWeight: '500',
                        borderRadius: '6px',
                        textTransform: 'revert-layer',
                    }}
                >
                    Hủy
                </Button>
                <Button
                    onClick={props.handleConfirm}
                    variant="contained"
                    sx={{
                        flex: 1,
                        background: '#007DC0',
                        ':hover': {
                            background: '#009FD0',
                        },
                        fontSize: '14px',
                        fontWeight: '500',
                        textTransform: 'revert-layer',
                        borderRadius: '6px',
                    }}
                    autoFocus
                >
                    Xác nhận
                </Button>
            </DialogActions>
        </Dialog>
    );
}
