import React, { useEffect, useState } from 'react';
import QRCode from 'qrcode';
import { showSnackbarWithClose } from '@/hooks/useSnackbarWithClose';
interface QRCodeGeneratorProps {
    data: string;
    width: number;
}
export const QRCodeGenerator = (props: QRCodeGeneratorProps) => {
    const { data, width } = props;
    const [qrCodeURL, setQRCodeURL] = useState('');

    useEffect(() => {
        QRCode.toDataURL(data, { width })
            .then((qrCodeURL) => {
                setQRCodeURL(qrCodeURL);
            })
            .catch((error) => {
                if (Array.isArray(error?.response?.data?.message)) {
                    error?.response?.data?.message.forEach((item: any) => {
                        showSnackbarWithClose(item, {
                            variant: 'error',
                        });
                    });
                } else {
                    showSnackbarWithClose(
                        error?.response ? error.response.data?.message : error.message,
                        {
                            variant: 'error',
                        }
                    );
                }
            });
    }, [data, width]);

    return <div>{qrCodeURL && <img src={qrCodeURL} alt="QR Code" />}</div>;
};

// export default QRCodeGenerator;
