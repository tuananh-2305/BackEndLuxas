import Grid from '@mui/material/Unstable_Grid2'; // Grid version 2
import Box from '@mui/material/Box';
import InputLabel from '@mui/material/InputLabel';
import MenuItem from '@mui/material/MenuItem';
import FormControl from '@mui/material/FormControl';
import Select, { SelectChangeEvent } from '@mui/material/Select';
import { useEffect, useState } from 'react';
import { addressApi } from '@/api/address';
import { useAppSelector } from '@/hooks/useReudx';
import { getIDAddress } from '@/ultis/index';

export interface IInputAddressProps {
    selectedProvince: string;
    selectedDistrict: string;
    selectedWard: string;
    setSelectedProvince: (value: string) => void;
    setSelectedDistrict: (value: string) => void;
    setSelectedWard: (value: string) => void;
    isFetchAddressFirst?: boolean;
}

export default function InputAddress(props: IInputAddressProps) {
    const {
        selectedProvince,
        selectedDistrict,
        selectedWard,
        setSelectedProvince,
        setSelectedDistrict,
        setSelectedWard,
        isFetchAddressFirst,
    } = props;
    const provinces = useAppSelector((state) => state.common.provinces);
    const [districts, setDistricts] = useState([]);
    const [wards, setWards] = useState([]);

    const handleChangeProvince = (event: SelectChangeEvent) => {
        const provinceCode = event.target.value as string;
        setSelectedProvince(provinceCode);
        setSelectedDistrict('');
        setSelectedWard('');
        setDistricts([]);
        setWards([]);
        if (!provinceCode) return;
        addressApi.getDistricts(getIDAddress(provinceCode)).then((res) => {
            setDistricts(res.data);
        });
    };

    const handleChangeDistrict = (event: SelectChangeEvent) => {
        const districtCode = event.target.value as string;
        setSelectedWard('');
        setSelectedDistrict(districtCode);
        if (!districtCode) return;
        addressApi
            .getWards(getIDAddress(selectedProvince), getIDAddress(districtCode))
            .then((res) => {
                setWards(res.data);
            });
    };

    const handleChangeWard = (event: SelectChangeEvent) => {
        const wardCode = event.target.value as string;
        setSelectedWard(wardCode);
    };

    useEffect(() => {
        if (isFetchAddressFirst || selectedProvince) {
            if (!selectedProvince) return;
            addressApi.getDistricts(getIDAddress(selectedProvince)).then((res) => {
                setDistricts(res.data);
                if (selectedDistrict) {
                    addressApi
                        .getWards(getIDAddress(selectedProvince), getIDAddress(selectedDistrict))
                        .then((res) => {
                            setWards(res.data);
                        });
                }
            });
        }
    }, [isFetchAddressFirst, selectedProvince]);

    return (
        <Grid container spacing={1}>
            <Grid xs={12} sm={4}>
                <InputLabel id="provinces">Tỉnh/Thành phố</InputLabel>
                <Select
                    labelId="province"
                    id="demo-simple-select-province"
                    onChange={handleChangeProvince}
                    value={selectedProvince}
                    fullWidth
                    size="small"
                    sx={{
                        borderRadius: '10px',
                    }}
                    MenuProps={{
                        style: {
                            maxHeight: 48 * 4.5 + 8,
                            width: 250,
                        },
                    }}
                >
                    {provinces.map((province: any, index) => (
                        <MenuItem value={province.Code + '@@' + province.Name} key={index}>
                            {province.Name}
                        </MenuItem>
                    ))}
                </Select>
            </Grid>
            <Grid xs={12} sm={4}>
                <InputLabel id="districts">Quận/Huyện</InputLabel>
                <Select
                    labelId="districts"
                    id="demo-simple-select-districts"
                    onChange={handleChangeDistrict}
                    value={selectedDistrict}
                    fullWidth
                    size="small"
                    sx={{
                        borderRadius: '10px',
                    }}
                    MenuProps={{
                        style: {
                            maxHeight: 48 * 4.5 + 8,
                            width: 250,
                        },
                    }}
                >
                    {districts.map((district: any, index) => (
                        <MenuItem value={district.Code + '@@' + district.Name} key={index}>
                            {district.Name}
                        </MenuItem>
                    ))}
                </Select>
            </Grid>
            <Grid xs={12} sm={4}>
                <InputLabel id="wards">Xã/Phường</InputLabel>
                <Select
                    labelId="wards"
                    id="demo-simple-select-wards"
                    value={selectedWard}
                    onChange={handleChangeWard}
                    fullWidth
                    size="small"
                    sx={{
                        borderRadius: '10px',
                    }}
                    MenuProps={{
                        style: {
                            maxHeight: 48 * 4.5 + 8,
                            width: 250,
                        },
                    }}
                >
                    {wards.map((ward: any, index) => (
                        <MenuItem value={ward.Code + '@@' + ward.Name} key={index}>
                            {ward.Name}
                        </MenuItem>
                    ))}
                </Select>
            </Grid>
        </Grid>
    );
}
