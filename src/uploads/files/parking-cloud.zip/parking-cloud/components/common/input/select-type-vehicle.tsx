import { vehicleTypeApi } from '@/api/vehicle-type-api';
import { useAppSelector } from '@/hooks/index';
import { VehicelTypeModel } from '@/models/index';
import { InputLabel, MenuItem, Select, Stack } from '@mui/material';
import { useEffect, useState } from 'react';

export interface ISelectTypeVehicleProps {
    idTypeVehicle: string | null;
    setIdTypeVehicle: (id: string | null) => void;
}

export default function SelectTypeVehicle(props: ISelectTypeVehicleProps) {
    const { idTypeVehicle, setIdTypeVehicle } = props;
    const vehicleTypes = useAppSelector((state) => state.common.vehicleTypes);

    return (
        <Stack>
            <InputLabel required>Loại xe</InputLabel>
            <Select
                fullWidth
                size="small"
                sx={{
                    borderRadius: '10px',
                }}
                value={idTypeVehicle ? idTypeVehicle : ''}
                onChange={(e) => setIdTypeVehicle(e.target.value)}
            >
                {vehicleTypes.map((item, index) => (
                    <MenuItem value={item.ID} key={index}>
                        {item.Name}
                    </MenuItem>
                ))}
            </Select>
        </Stack>
    );
}
