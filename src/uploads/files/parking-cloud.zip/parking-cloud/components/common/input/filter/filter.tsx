import FilterListIcon from '@mui/icons-material/FilterList';
import SearchIcon from '@mui/icons-material/Search';
import { Chip, Stack, TextField } from '@mui/material';
import IconButton from '@mui/material/IconButton';
import Paper from '@mui/material/Paper';
import React, { useEffect, useRef, useState } from 'react';
import { PopupOption } from './popup';
import { PopupOptionDetail } from './popup-detail';

export interface IFilterInputProps {
    optionList: OptionInterface[];
    oldValue: OptionInterface[];
    onFilter: (v: OptionInterface[]) => void;
    open?: boolean;
    onClose?: () => void;
}

export interface OptionInterface {
    title: string;
    key: string;
    label?: string;
    type: TypeOption;
    options?: Options[];
    value: Options[];
}

export interface Options {
    title: string;
    key: string;
}

type TypeOption = 'TEXT' | 'RADIO' | 'CHECKBOX' | 'ONLY_TITLE';

export default function FilterInput(props: IFilterInputProps) {
    const { optionList, onFilter } = props;
    const [anchorEl, setAnchorEl] = React.useState<HTMLButtonElement | null>(null);
    const [anchorElDetail, setAnchorElDetail] = React.useState<HTMLButtonElement | null>(null);
    const searchRef = useRef(null);

    const [value, setValue] = useState<OptionInterface[]>([]);
    const [searchKey, setSearchKey] = useState('');
    const [itemChoose, setItemChoose] = useState<OptionInterface | null>(null);
    useEffect(() => {
        if (props.oldValue.length > 0) {
            setValue(props.oldValue);
        }
    }, []);

    /** * on Click option */
    const handleClickOption = (item: OptionInterface, option?: Options[]) => {
        if (option) {
            onSubmitDetailOption(option);
            setSearchKey('');
            setAnchorEl(null);
            return;
        }

        if (item.type != 'ONLY_TITLE') {
            // open detail popup
            setAnchorElDetail(searchRef.current);
            // save item choose
            setItemChoose(item);
        } else {
            var arr = [...value];
            arr.push(item);
            // save value (value show before textfield)
            setValue(arr);
        }
        // close popup
        setAnchorEl(null);
        props.onClose!();
    };

    /** * on remove option */
    const handleRemoveOption = (item: OptionInterface) => {
        var arr = [...value];
        // remove item
        const result = arr.filter((v) => v.key != item.key);
        setValue(result);

        // filter when item removed
        onFilter(result);
    };

    const handleChangeSearch = (event: any) => {
        var itemChoose = optionList[0];
        if (!Boolean(anchorEl)) {
            setAnchorEl(searchRef.current);
        }
        setItemChoose(itemChoose);
        setSearchKey(event.target.value);
    };

    /**
     * Handles the event when the user submits detailed options.
     *
     * @param {Options[]} item - An array containing options.
     */
    const onSubmitDetailOption = (item: Options[]) => {
        /**
         * The option() function processes creating a string of options based on the number of input options.
         * If there are at least 3 options, it will display the first three options and '+X other choices'.
         * If there are less than 3 options, it will display all the options.
         */
        const option = () => {
            if (item.length >= 3) {
                return `${item[0].title}, ${item[1].title}, +${item.length - 2} lựa chọn khác`;
            } else {
                return item.map((v) => v.title);
            }
        };

        var label = '';
        if (itemChoose?.type == 'TEXT') {
            label = `${itemChoose?.title} chứa "${option()}" `;
        } else {
            label = `${itemChoose?.title}: ${option()}`;
        }

        /**
         * Create a newItem object containing information about the new option.
         * Then, add this option to the arrFilter array.
         */
        var newItem: OptionInterface = {
            key: itemChoose?.key ?? '',
            title: itemChoose?.title ?? '',
            type: itemChoose?.type ?? 'TEXT',
            value: item,
            label: label,
            options: itemChoose?.options ?? [],
        };
        var arrFilter = value.filter((v) => v.key != newItem.key);
        arrFilter.push(newItem);

        // Update the value and call relevant callback functions.
        setValue(arrFilter);
        setAnchorElDetail(null);
        props.onClose!();
        setItemChoose(null);
        onFilter(arrFilter);
    };

    useEffect(() => {
        if (props.open == true) {
            setAnchorEl(searchRef.current);
        }
    }, [props.open]);

    return (
        <Paper
            component="form"
            onSubmit={(e) => {
                e.preventDefault();
                if (searchKey) {
                    var itemChoose = optionList[0];
                    handleClickOption(itemChoose, [{ key: '', title: searchKey }]);
                }
            }}
            sx={{
                display: 'flex',
                alignItems: 'center',
                minWidth: '400px',
                ml: '20px',
                boxShadow: 0,
                border: '1px solid #d9d9d9',
                borderRadius: '6px',
                width: '100%',
                height: '40px',
            }}
        >
            <IconButton
                onClick={() => setAnchorEl(searchRef.current)}
                sx={{
                    p: '10px',
                    width: '30px',
                    height: '30px',
                    ml: '5px',
                    zIndex: Boolean(anchorEl) ? 11 : 1,
                }}
                aria-label="menu"
            >
                <FilterListIcon />
            </IconButton>
            <Stack
                sx={{
                    flex: 1,
                    display: 'flex',
                    flexDirection: 'row',
                    alignItems: 'center',
                    zIndex: Boolean(anchorEl) ? 11 : 1,
                }}
            >
                <Stack
                    direction={'row'}
                    sx={{
                        flexWrap: 'wrap',
                        gap: '5px',
                        flex: 1,
                        alignItems: 'center',
                        justifyContent: 'center',
                    }}
                >
                    {value.length > 0 &&
                        value.map((item: OptionInterface, index) => {
                            return (
                                <Chip
                                    key={index}
                                    label={item.label}
                                    onDelete={() => {
                                        handleRemoveOption(item);
                                    }}
                                    onClick={(event: any) => {
                                        if (item.type != 'ONLY_TITLE') {
                                            setAnchorElDetail(event.currentTarget);
                                            setItemChoose(item);
                                        }
                                    }}
                                    sx={{
                                        maxWidth: '300px',
                                        whiteSpace: 'nowrap',
                                        overflow: 'hidden',
                                        textOverflow: 'ellipsis',
                                        height: '30px',
                                    }}
                                />
                            );
                        })}

                    <TextField
                        ref={searchRef}
                        onClick={() => setAnchorEl(searchRef.current)}
                        placeholder="Lọc - nhấn F2 để chọn nhanh"
                        size="small"
                        value={searchKey}
                        onChange={handleChangeSearch}
                        fullWidth
                        autoComplete="off"
                        sx={{
                            flex: 1,
                            '& .MuiOutlinedInput-root:hover': {
                                '& > fieldset': {
                                    borderColor: '#fff',
                                },
                            },
                            '& .MuiOutlinedInput-root': {
                                '& > fieldset': {
                                    borderColor: '#fff',
                                },
                                '&.Mui-focused fieldset': {
                                    borderColor: '#fff',
                                },
                            },
                            '& label.Mui-focused': {
                                color: '#fff',
                            },
                            marginTop: '0px',
                            height: '35px',
                        }}
                        inputProps={{
                            style: { fontSize: 13 },
                        }}
                    />
                </Stack>
            </Stack>
            <IconButton
                type="button"
                sx={{ p: '10px', width: '30px', height: '30px', mr: '5px' }}
                aria-label="search"
            >
                <SearchIcon />
            </IconButton>
            {Boolean(anchorEl) && (
                <PopupOption
                    open={Boolean(anchorEl)}
                    anchorEl={anchorEl}
                    onClose={() => {
                        setAnchorEl(null);
                        props.onClose!();
                    }}
                    options={optionList.filter((item1) => {
                        return !value.some((item2) => item1.key === item2.key);
                    })}
                    onClickOption={handleClickOption}
                    searchKey={searchKey}
                    value={value}
                />
            )}
            {Boolean(anchorElDetail) && (
                <PopupOptionDetail
                    open={Boolean(anchorElDetail)}
                    anchorEl={anchorElDetail}
                    onClose={() => {
                        setAnchorElDetail(null);
                        props.onClose!();
                    }}
                    item={itemChoose}
                    onSubmit={onSubmitDetailOption}
                />
            )}
        </Paper>
    );
}
// optionList example
// const optionList: OptionInterface[] = [
//     {
//         title: 'Bản quyền',
//         label: 'Bản quyền',
//         key: 'ban-quyen',
//         type: 'ONLY_TITLE',
//         value: [],
//     },
//     {
//         title: 'Chế độ hiển thị',
//         label: 'Chế độ hiển thị',
//         key: 'che-do-hien-thi',
//         type: 'CHECKBOX',
//         options: [
//             {
//                 title: 'option 1',
//                 key: 'option-1',
//             },
//             {
//                 title: 'option 2',
//                 key: 'option-2',
//             },
//             {
//                 title: 'option 3',
//                 key: 'option-3',
//             },
//             {
//                 title: 'option 5',
//                 key: 'option-5',
//             },
//         ],
//         value: [],
//     },
//     {
//         title: 'Giới hạn độ tuổi',
//         label: 'Giới hạn độ tuổi',
//         key: 'gioi-han',
//         type: 'RADIO',
//         options: [
//             {
//                 title: 'Trên 18',
//                 key: 'tren-18',
//             },
//             {
//                 title: 'không giới hạn',
//                 key: 'khong-gioi-han',
//             },
//         ],
//         value: [],
//     },
//     {
//         title: 'Mô tả',
//         label: 'Mô tả',
//         key: 'mo-ta',
//         type: 'TEXT',
//         value: [],
//     },
// ];
