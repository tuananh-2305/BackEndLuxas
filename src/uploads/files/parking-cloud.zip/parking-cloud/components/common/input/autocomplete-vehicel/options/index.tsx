import { Popover, Stack, Typography, TextField } from '@mui/material';
import { AvatarCustom } from '../../../avatar-next';
import { useCallback, useEffect, useState } from 'react';
import { memberApi } from '@/api/member-api';
import { MemberModel } from '@/models/member.model';
import { useDebouncedValue } from '@mantine/hooks';
import { MemberVehicleModel } from '@/models/member.vehicle.model';
import { PaginationIDPayload } from '@/models/config.model';
import { SIZE_PAGE } from '@/ultis/constant';
import { memberVehicleApi } from '@/api/member-vehicle-api';
import { useAppSelector } from '@/hooks/useReudx';

const BACKEND_DOMAIN = process.env.NEXT_PUBLIC_SERVER_PARKING_DOMAIN;
interface MemeberSelectOptionProps {
    parkingId: string;
    open: boolean;
    anhchor: HTMLDivElement | null;
    close: () => void;
    onSelect: (value: MemberVehicleModel | null) => void;
    memberId: string | undefined;
}
export const VehicelSelectOptions = (props: MemeberSelectOptionProps) => {
    const { parkingId, onSelect, open, anhchor, close, memberId } = props;

    const [data, setData] = useState<MemberVehicleModel[]>([]);
    const [loading, setLoading] = useState(false);
    const [total, setTotal] = useState(0);
    const [openOptions, setOpenOptions] = useState(false);
    const [search, setSearch] = useState('');
    const [debounced] = useDebouncedValue(search, 400);

    const loadVehicles = useCallback(
        (memberId: string | null, parkingId: string | undefined, search: string) => {
            if (!memberId || !parkingId) return;
            const payload: PaginationIDPayload = {
                Current: 0,
                Limit: 6,
                TextSearch: search,
                ID: memberId,
            };
            setLoading(true);
            memberVehicleApi
                .getMemberVehicleByIdMemberAndParking(parkingId, payload)
                .then((res) => {
                    const { Data, Total, Limit } = res.data;
                    setData(Data);
                    setTotal(Total);
                })
                .finally(() => {
                    setLoading(false);
                });
        },
        []
    );

    useEffect(() => {
        if (memberId) {
            loadVehicles(memberId, parkingId, debounced);
        }
    }, [debounced, loadVehicles, parkingId, memberId]);

    return (
        <Popover
            open={open}
            anchorEl={anhchor}
            onClose={() => close()}
            anchorOrigin={{
                vertical: 'bottom',
                horizontal: 'left',
            }}
        >
            <Stack
                sx={{
                    height: '400px',
                    backgroundColor: '#fff',
                    width: `${anhchor?.clientWidth}px`,
                    zIndex: 50,
                }}
            >
                <Stack sx={{ padding: '10px' }}>
                    <TextField
                        size="small"
                        placeholder="nhập thông tin cần tìm"
                        onChange={(e) => {
                            const { value } = e.target;
                            setSearch(value);
                        }}
                    />
                </Stack>
                {data.length !== 0 ? (
                    <Stack
                        sx={{ maxHeight: '100%', overflow: 'auto' }}
                        onScroll={(e) => {
                            if (
                                e.currentTarget.scrollHeight - e.currentTarget.scrollTop ===
                                e.currentTarget.clientHeight
                            ) {
                                if (memberId) {
                                    memberVehicleApi
                                        .getMemberVehicleByIdMemberAndParking(parkingId, {
                                            ID: memberId,
                                            Current: data.length,
                                            Limit: 10,
                                            TextSearch: debounced,
                                        })
                                        .then((res) => {
                                            const { data } = res;
                                            setData([...data, ...data.Data]);
                                            // setTotalRecords(data.Total);
                                        });
                                }
                            }
                        }}
                    >
                        {data.map((v) => {
                            return (
                                <Stack
                                    key={v.ID + v.ParkingId + v.UpdatedAt}
                                    direction="column"
                                    sx={{
                                        padding: '10px 20px',
                                        cursor: 'pointer',
                                        '&:hover ': {
                                            backgroundColor: '#ccc',
                                        },
                                    }}
                                    onClick={() => onSelect(v)}
                                >
                                    <Typography sx={{ fontSize: '14px', fontWeight: '500' }}>{`${
                                        v.VehicleTypeId?.Name
                                    } ${v?.PlateNumber ? `(${v?.PlateNumber})` : ''}`}</Typography>
                                    <Typography sx={{ fontSize: '12px', fontStyle: 'italic' }}>{`${
                                        v.VehicleBrand
                                    } ${v.VehicleBrand && v.VehicleColor ? '-' : ''} ${
                                        v.VehicleColor
                                    }`}</Typography>
                                </Stack>
                            );
                        })}
                    </Stack>
                ) : (
                    <Stack
                        sx={{ width: '100%', height: '100%' }}
                        justifyContent="center"
                        alignItems="center"
                    >
                        <Typography sx={{ fontWeight: 600, fontSize: '14px' }}>
                            Không có phương tiện cần tìm.
                        </Typography>
                    </Stack>
                )}
            </Stack>
        </Popover>
    );
};
