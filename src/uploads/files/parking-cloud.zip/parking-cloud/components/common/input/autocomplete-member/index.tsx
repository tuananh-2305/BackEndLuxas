import { memberApi } from '@/api/member-api';
import { MemberModel } from '@/models/member.model';
import CheckBoxIcon from '@mui/icons-material/CheckBox';
import CheckBoxOutlineBlankIcon from '@mui/icons-material/CheckBoxOutlineBlank';
import {
    Autocomplete,
    Checkbox,
    CircularProgress,
    InputLabel,
    Stack,
    TextField,
    Typography,
} from '@mui/material';
import React, { useEffect, useRef, useState } from 'react';
import { AvatarCustom } from '../../avatar-next';
import { MemeberSelectOption } from './options';
import HighlightOffIcon from '@mui/icons-material/HighlightOff';
export interface IAutoCompoleteMemberProps {
    setValue: (value: MemberModel | null) => void;
    parkingId: string;
    value: MemberModel | null;
    isNotRequired?: boolean;
}
const icon = <CheckBoxOutlineBlankIcon fontSize="small" />;
const checkedIcon = <CheckBoxIcon fontSize="small" />;
const BACKEND_DOMAIN = process.env.NEXT_PUBLIC_SERVER_PARKING_DOMAIN;

export default function AutoCompoleteMember(props: IAutoCompoleteMemberProps) {
    const { setValue, parkingId, value, isNotRequired } = props;

    const [openOptions, setOpenOptions] = useState(false);
    const ref = useRef<HTMLDivElement | null>(null);

    return (
        <Stack>
            <InputLabel sx={{ fontSize: 14, fontWeight: 400, color: '#55595D', mb: '6px' }}>
                2. Cư dân
            </InputLabel>
            <Stack sx={{ width: '100%' }}>
                <Stack
                    sx={{
                        padding: '8px 20px',
                        border: '1px solid #E3E5E5',
                        borderRadius: '6px',
                        cursor: 'pointer',
                        gap: '10px',
                    }}
                    alignItems="center"
                    direction="row"
                    ref={ref}
                >
                    {value ? (
                        <AvatarCustom
                            size={30}
                            src={value.Avatar ? BACKEND_DOMAIN + value.Avatar : ''}
                        />
                    ) : (
                        <></>
                    )}

                    <Typography
                        sx={{ fontSize: '14px', fontWeight: 500, flex: 1 }}
                        onClick={() => setOpenOptions(true)}
                    >
                        {value ? value.Name : 'Hãy chọn cư dân'}
                    </Typography>

                    {value && value.Name ? (
                        <HighlightOffIcon
                            sx={{ color: '#f85959' }}
                            onClick={() => setValue(null)}
                        />
                    ) : (
                        <></>
                    )}
                </Stack>

                <MemeberSelectOption
                    parkingId={parkingId}
                    open={openOptions}
                    anhchor={ref.current}
                    onSelect={(v) => {
                        setValue(v);
                        setOpenOptions(false);
                    }}
                    close={() => setOpenOptions(false)}
                />
            </Stack>
        </Stack>
    );
}
