import { Popover, Stack, Typography, TextField } from '@mui/material';
import { AvatarCustom } from '../../../avatar-next';
import { useEffect, useState } from 'react';
import { memberApi } from '@/api/member-api';
import { MemberModel } from '@/models/member.model';
import { useDebouncedValue } from '@mantine/hooks';

const BACKEND_DOMAIN = process.env.NEXT_PUBLIC_SERVER_PARKING_DOMAIN;
interface MemeberSelectOptionProps {
    parkingId: string;
    open: boolean;
    anhchor: HTMLDivElement | null;
    close: () => void;
    onSelect: (value: MemberModel | null) => void;
}

export const MemeberSelectOption = (props: MemeberSelectOptionProps) => {
    const { parkingId, onSelect, open, anhchor, close } = props;

    const [listSelect, setListSelect] = useState<MemberModel[]>([]);
    const [search, setSearch] = useState('');
    const [debounced] = useDebouncedValue(search, 400);

    useEffect(() => {
        memberApi
            .getMemberByParkingIdPaginate({
                ID: parkingId,
                Current: 0,
                Limit: 10,
                TextSearch: debounced,
            })
            .then((res) => {
                const { data } = res;
                if (data) {
                    setListSelect(data.Data);
                } else {
                    setListSelect([]);
                }
                // setTotalRecords(data.Total);
            });
    }, [parkingId, debounced]);

    useEffect(() => {
        if (!open) {
            memberApi
                .getMemberByParkingIdPaginate({
                    ID: parkingId,
                    Current: 0,
                    Limit: 10,
                    TextSearch: '',
                })
                .then((res) => {
                    const { data } = res;
                    setListSelect(data.Data);
                    // setTotalRecords(data.Total);
                });
        }
    }, [open, parkingId]);
    return (
        <Popover
            open={open}
            anchorEl={anhchor}
            onClose={() => close()}
            anchorOrigin={{
                vertical: 'bottom',
                horizontal: 'left',
            }}
        >
            <Stack
                sx={{
                    height: '400px',
                    backgroundColor: '#fff',
                    width: `${anhchor?.clientWidth}px`,
                    zIndex: 50,
                }}
            >
                <Stack sx={{ padding: '10px' }}>
                    <TextField
                        size="small"
                        placeholder="nhập thông tin cần tìm"
                        onChange={(e) => {
                            const { value } = e.target;
                            setSearch(value);
                        }}
                    />
                </Stack>

                <Stack
                    sx={{ maxHeight: '100%', overflow: 'auto' }}
                    onScroll={(e) => {
                        if (
                            e.currentTarget.scrollHeight - e.currentTarget.scrollTop ===
                            e.currentTarget.clientHeight
                        ) {
                            memberApi
                                .getMemberByParkingIdPaginate({
                                    ID: parkingId,
                                    Current: listSelect.length,
                                    Limit: 10,
                                    TextSearch: debounced,
                                })
                                .then((res) => {
                                    const { data } = res;
                                    setListSelect([...listSelect, ...data.Data]);
                                    // setTotalRecords(data.Total);
                                });
                        }
                    }}
                >
                    {listSelect.map((member) => {
                        return (
                            <Stack
                                key={member.ID + member.ParkingId + member.UpdatedAt}
                                direction="row"
                                sx={{
                                    padding: '10px 20px',
                                    cursor: 'pointer',
                                    gap: '10px',
                                    '&:hover ': {
                                        backgroundColor: '#ccc',
                                    },
                                }}
                                onClick={() => onSelect(member)}
                            >
                                <AvatarCustom
                                    size={40}
                                    src={member.Avatar ? BACKEND_DOMAIN + member.Avatar : ''}
                                />
                                <Stack>
                                    <Typography variant="body2">{member.Name}</Typography>
                                    <Typography sx={{ fontSize: '10px', fontStyle: 'italic' }}>
                                        {member.Phone ? member.Phone : member.Address}
                                    </Typography>
                                </Stack>
                            </Stack>
                        );
                    })}
                </Stack>
            </Stack>
        </Popover>
    );
};
