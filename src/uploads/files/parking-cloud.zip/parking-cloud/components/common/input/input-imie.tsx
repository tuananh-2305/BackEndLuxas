import * as React from 'react';

export interface IInpuImieProps {}

export default function InpuImie(props: IInpuImieProps) {
    return <div></div>;
}
