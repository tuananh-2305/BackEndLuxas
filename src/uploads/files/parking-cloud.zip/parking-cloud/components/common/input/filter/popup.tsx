import { List, ListItemButton, ListItemText, Popover, Popper, Stack } from '@mui/material';
import { OptionInterface, Options } from './filter';

export interface IPopupOptionProps {
    open: boolean;
    anchorEl: HTMLButtonElement | null;
    onClose: () => void;
    options: OptionInterface[];
    onClickOption: (v: any, option?: Options[]) => void;
    searchKey: string;
    value: OptionInterface[];
}

export function PopupOption(props: IPopupOptionProps) {
    const { onClose, options, onClickOption, searchKey, value } = props;
    const itemChoose = options[0];
    return (
        <>
            <Stack
                onClick={onClose}
                sx={{
                    background: 'transparent',
                    // background: 'grey',
                    position: 'absolute',
                    top: 0,
                    left: 0,
                    right: 0,
                    bottom: 0,
                    zIndex: 10,
                    display: props.open ? 'flex' : 'none',
                }}
            ></Stack>
            <Popper
                open={props.open}
                anchorEl={props.anchorEl}
                placement={'bottom-start'}
                // onClose={onClose}
                // anchorOrigin={{
                //     vertical: 'bottom',
                //     horizontal: 'left',
                // }}
                sx={{ zIndex: 11 }}
            >
                <List
                    sx={{
                        width: '100%',
                        minWidth: 250,
                        bgcolor: 'background.paper',
                        boxShadow: 'rgba(0, 0, 0, 0.35) 0px 5px 15px',
                    }}
                    component="nav"
                    aria-labelledby="nested-list-subheader"
                    disablePadding
                >
                    {searchKey ? (
                        <>
                            {value.length <= 0 ? (
                                <ListItemButton
                                    sx={{ py: '5px' }}
                                    onClick={() => {
                                        onClickOption(itemChoose, [{ key: '', title: searchKey }]);
                                    }}
                                >
                                    <ListItemText
                                        primary={`${itemChoose.title} chứa "${searchKey}"`}
                                    />
                                </ListItemButton>
                            ) : (
                                <ListItemButton sx={{ py: '5px' }}>
                                    <ListItemText primary={'không có bộ lọc nào khớp'} />
                                </ListItemButton>
                            )}
                        </>
                    ) : options.length > 0 ? (
                        options.map((item: OptionInterface, index: number) => {
                            return (
                                <ListItemButton
                                    onClick={() => {
                                        onClickOption(item);
                                    }}
                                    key={index}
                                    sx={{ py: '5px' }}
                                >
                                    <ListItemText primary={item.title} />
                                </ListItemButton>
                            );
                        })
                    ) : (
                        <ListItemButton sx={{ py: '5px' }}>
                            <ListItemText primary={'không có bộ lọc nào khớp'} />
                        </ListItemButton>
                    )}

                    {/* {options.length > 0 ? (
                        options.map((item: OptionInterface, index: number) => {
                            return (
                                <ListItemButton
                                    onClick={() => {
                                        onClickOption(item);
                                    }}
                                    key={index}
                                    sx={{ py: '5px' }}
                                >
                                    <ListItemText primary={item.title} />
                                </ListItemButton>
                            );
                        })
                    ) : (
                        <ListItemButton sx={{ py: '5px' }}>
                            <ListItemText primary={'không có bộ lọc nào khớp'} />
                        </ListItemButton>
                    )} */}
                </List>
            </Popper>
        </>
    );
}
