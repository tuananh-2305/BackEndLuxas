import { userParkingApi } from '@/api/index';
import CheckBoxIcon from '@mui/icons-material/CheckBox';
import CheckBoxOutlineBlankIcon from '@mui/icons-material/CheckBoxOutlineBlank';
import {
    Autocomplete,
    Checkbox,
    CircularProgress,
    InputLabel,
    Stack,
    TextField,
    Typography,
} from '@mui/material';
import React, { useEffect, useState } from 'react';
import { AvatarCustom } from '../avatar-next';
export interface IAutoCompoleteUserParkingProps {
    setValue: (value: any) => void;
    parkingId: string;
}
const icon = <CheckBoxOutlineBlankIcon fontSize="small" />;
const checkedIcon = <CheckBoxIcon fontSize="small" />;
const BACKEND_DOMAIN = process.env.NEXT_PUBLIC_SERVER_PARKING_DOMAIN;

export default function AutoCompoleteUserParking(props: IAutoCompoleteUserParkingProps) {
    const { setValue, parkingId } = props;
    const [openAuto, setOpenAuto] = useState(false);
    const [listSelect, setListSelect] = useState<any[]>([]);
    const loading = openAuto && listSelect.length === 0;

    useEffect(() => {
        let active = true;
        if (!loading) {
            return undefined;
        }
        if (openAuto) {
            const fetchDataCustomer = async () => {
                const { data } = await userParkingApi.getListUserCanCreateParking(parkingId);
                setListSelect(data);
            };
            fetchDataCustomer();
        }
        return () => {
            active = false;
        };
    }, [loading]);
    return (
        <Stack>
            <InputLabel required>Nhân viên</InputLabel>
            <Autocomplete
                size="small"
                onChange={(event: any, newValue: any | null) => {
                    if (newValue) setValue(newValue);
                }}
                isOptionEqualToValue={(option: any, value) => option.ID === value?.ID}
                onOpen={() => {
                    setOpenAuto(true);
                }}
                onClose={() => {
                    setOpenAuto(false);
                }}
                getOptionLabel={(option) => option.Name}
                options={listSelect}
                renderInput={(params) => (
                    <TextField
                        {...params}
                        InputProps={{
                            ...params.InputProps,
                            endAdornment: (
                                <React.Fragment>
                                    {loading ? (
                                        <CircularProgress color="inherit" size={20} />
                                    ) : null}
                                    {params.InputProps.endAdornment}
                                </React.Fragment>
                            ),
                        }}
                        sx={{
                            '& .MuiInputBase-root': {
                                borderRadius: '10px',
                            },
                        }}
                    />
                )}
                renderOption={(props, option: any, { selected }) => (
                    <li {...props}>
                        <Checkbox
                            icon={icon}
                            checkedIcon={checkedIcon}
                            style={{ marginRight: 8 }}
                            checked={selected}
                        />
                        <Stack direction={'row'} alignItems={'center'} spacing={1}>
                            <AvatarCustom
                                size={40}
                                src={option.Avatar ? BACKEND_DOMAIN + option.Avatar : ''}
                            />
                            <Stack>
                                <Typography variant="body2">{option.Name}</Typography>
                                <Typography variant="caption">{option.Phone}</Typography>
                            </Stack>
                        </Stack>
                    </li>
                )}
            />
        </Stack>
    );
}
