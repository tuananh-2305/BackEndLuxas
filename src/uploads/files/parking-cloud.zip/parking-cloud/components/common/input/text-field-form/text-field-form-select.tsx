import { FormLabel, Stack, Typography } from '@mui/material';
import InputLabel from '@mui/material/InputLabel';
import MenuItem from '@mui/material/MenuItem';
import Select from '@mui/material/Select';
import CloseIcon from '@mui/icons-material/Close';
import * as React from 'react';
import ArrowForwardIosIcon from '@mui/icons-material/ArrowForwardIos';
import ImageNextjs from '../../image';
import { ArrowIcon } from '../../icons/arrow-icon';

const Placeholder = ({ children }: any) => {
    return (
        <Typography
            sx={{
                fontSize: 16,
                fontWeight: 400,
                color: '#323232',
                opacity: 0.3,
            }}
        >
            {children}
        </Typography>
    );
};

export interface TextFieldFormSelectProps {
    value: string;
    label: string;
    placeholder?: string;
    onChange: (event: any) => void;
    options: OptionSelect[];
    name?: string;
    required?: boolean;
    color?: string;
    textError?: string;
    tabIndex?: number | undefined;
}
export interface OptionSelect {
    id: string;
    label: string;
    key?: string;
}

export default function TextFieldFormSelect(props: TextFieldFormSelectProps) {
    const { value, onChange, options, name, required, textError, placeholder, tabIndex } = props;
    const color = props.color ? props.color : textError ? '#E42727' : '#E3E5E5';

    return (
        <Stack>
            <InputLabel sx={{ fontSize: 14, fontWeight: 400, color: '#55595D', mb: '6px' }}>
                {props.label}{' '}
                <Typography
                    component={'span'}
                    sx={{
                        color: '#E42727',
                        fontSize: 13,
                        display: required ? 'inline-block' : 'none',
                    }}
                >
                    (✶)
                </Typography>
            </InputLabel>

            <Select
                value={value}
                onChange={onChange}
                displayEmpty
                size="small"
                name={name}
                renderValue={
                    value !== '' ? undefined : () => <Placeholder>{placeholder}</Placeholder>
                }
                IconComponent={(props) => <ArrowIcon {...props} />}
                tabIndex={props.tabIndex}
                sx={{
                    '& > fieldset': {
                        borderColor: color,
                        borderRadius: '6px',
                    },
                    '.MuiOutlinedInput-notchedOutline': {
                        borderColor: color,
                    },
                    '&.Mui-focused .MuiOutlinedInput-notchedOutline': {
                        borderColor: color,
                    },
                    '&:hover .MuiOutlinedInput-notchedOutline': {
                        borderColor: color,
                    },
                    height: '46px',
                    fontSize: '16px',
                    fontWeight: 400,
                    color: '#323232',
                    padding: '13px 0',
                    lineHeight: '20px',
                    ':focus': {
                        outlineColor: '#E3E5E5',
                    },
                }}
            >
                {options.length > 0 &&
                    options.map((item: OptionSelect) => {
                        return (
                            <MenuItem value={item.id} key={item.id}>
                                {item.label}
                            </MenuItem>
                        );
                    })}
            </Select>
            {textError && (
                <Stack direction={'row'} spacing={'5px'} sx={{ alignItems: 'center', mt: '4px' }}>
                    <Stack
                        sx={{
                            width: '13px',
                            height: '13px',
                            alignItems: 'center',
                            justifyContent: 'center',
                            background: '#E42727',
                            borderRadius: '50%',
                        }}
                    >
                        <CloseIcon sx={{ color: '#fff', fontSize: 10, fontWeight: 600 }} />
                    </Stack>
                    <Typography
                        sx={{
                            fontSize: 12,
                            fontWeight: 400,
                            color: '#E42727',
                        }}
                    >
                        {textError}
                    </Typography>
                </Stack>
            )}
        </Stack>
    );
}
