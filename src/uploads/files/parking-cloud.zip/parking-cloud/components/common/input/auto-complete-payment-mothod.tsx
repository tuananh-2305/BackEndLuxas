import { boxImeiApi } from '@/api/index';
import { DeviceImeiModel } from '@/models/device.imei.model';
import {
    Autocomplete,
    CircularProgress,
    InputLabel,
    MenuItem,
    Select,
    Stack,
    TextField,
} from '@mui/material';
import React, { useEffect, useState } from 'react';

export interface IAutoCompoletePaymentMethodProps {
    setValue: (value: any) => void;
    value: any;
}

export default function AutoCompoletePaymentMethod(props: IAutoCompoletePaymentMethodProps) {
    const { setValue, value } = props;
    const listSelect = [
        {
            ID: 'MOMO',
            Name: 'Momo',
        },
        {
            ID: 'VNPAY',
            Name: 'VNPay',
        },
        {
            ID: 'NAPAS',
            Name: 'Napas',
        },
    ];
    return (
        <Stack>
            <InputLabel required>Phương thức</InputLabel>
            <Select
                onChange={(event: any) => {
                    setValue(event.target.value);
                }}
                value={value}
                fullWidth
                size="small"
                sx={{
                    borderRadius: '10px',
                }}
                MenuProps={{
                    style: {
                        maxHeight: 48 * 4.5 + 8,
                        width: 250,
                    },
                }}
            >
                {listSelect.map((item: any, index) => (
                    <MenuItem value={item.ID} key={index}>
                        {item.Name}
                    </MenuItem>
                ))}
            </Select>
        </Stack>
    );
}
