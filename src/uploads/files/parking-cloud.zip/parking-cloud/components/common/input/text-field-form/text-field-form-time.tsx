import CloseIcon from '@mui/icons-material/Close';
import { InputLabel, Stack, Typography } from '@mui/material';
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs';
import { DatePicker } from '@mui/x-date-pickers/DatePicker';
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import dayjs, { Dayjs } from 'dayjs';
import 'dayjs/locale/vi';
import AdbIcon from '@mui/icons-material/Adb';
import ImageNextjs from '../../image';
export interface ITextFieldFormProps {
    value?: any;
    onChange?: any;
    lable: string;
    size?: 'small' | 'medium' | undefined;
    placeholder?: string;
    textError?: string;
    color?: string;
    required?: boolean;
    name?: string;
    maxDate?: Dayjs;
    minDate?: Dayjs;
    disabled?: boolean | undefined;
}

export default function TextFieldFormDate(props: ITextFieldFormProps) {
    const { value, onChange, lable, textError, required, name } = props;

    const color = props.color ? props.color : textError ? '#E42727' : '#E3E5E5';

    const onAnyTextFieldChanged = (e: any) => {
        if (!!e?.preventDefault) {
            e?.preventDefault();
            e?.stopPropagation();
        }
    };

    return (
        <Stack>
            <InputLabel sx={{ fontSize: 14, fontWeight: 400, color: '#55595D', mb: '6px' }}>
                {lable}{' '}
                <Typography
                    component={'span'}
                    sx={{
                        color: '#E42727',
                        fontSize: 13,
                        display: required ? 'inline-block' : 'none',
                    }}
                >
                    (✶)
                </Typography>
            </InputLabel>
            <LocalizationProvider dateAdapter={AdapterDayjs} adapterLocale="vi">
                <DatePicker
                    value={dayjs(value)}
                    onChange={onChange}
                    maxDate={props.maxDate}
                    minDate={props.minDate}
                    dayOfWeekFormatter={(d) => `${d}`}
                    disabled={props.disabled}
                    slots={{
                        openPickerIcon: () => (
                            <ImageNextjs
                                path="/icons/calendar_1_icon.svg"
                                sx={{
                                    width: '20px',
                                    height: '20px',
                                    alignItems: 'center',
                                    justifyContent: 'center',
                                }}
                            />
                        ),
                    }}
                    slotProps={{
                        textField: {
                            onBeforeInput: onAnyTextFieldChanged,
                            InputProps: {
                                size: props.size,
                                sx: {
                                    border: `1px solid ${color}`,
                                    borderRadius: '6px',
                                    // padding: '5px 12px',
                                    // fontSize: 14,
                                    height: '46px',
                                    fontSize: '16px',
                                    fontWeight: 400,
                                    color: '#323232',
                                    padding: '13px 16px',
                                    lineHeight: '20px',
                                },
                                disableUnderline: true,
                            },
                            variant: 'standard',
                        },
                    }}
                />
            </LocalizationProvider>
            {textError && (
                <Stack direction={'row'} spacing={'5px'} sx={{ alignItems: 'center', mt: '4px' }}>
                    <Stack
                        sx={{
                            width: '13px',
                            height: '13px',
                            alignItems: 'center',
                            justifyContent: 'center',
                            background: '#E42727',
                            borderRadius: '50%',
                        }}
                    >
                        <CloseIcon sx={{ color: '#fff', fontSize: 10, fontWeight: 600 }} />
                    </Stack>
                    <Typography
                        sx={{
                            fontSize: 12,
                            fontWeight: 400,
                            color: '#E42727',
                        }}
                    >
                        {textError}
                    </Typography>
                </Stack>
            )}
        </Stack>
    );
}
