import CloseIcon from '@mui/icons-material/Close';
import {
    Button,
    Checkbox,
    Divider,
    IconButton,
    List,
    ListItemButton,
    ListItemText,
    ListSubheader,
    Popover,
    Radio,
    Stack,
} from '@mui/material';
import { useEffect, useState } from 'react';
import { OptionInterface, Options } from './filter';
import TextFieldForm from '@/components/common/input/text-field-form/text-field-form';
export interface PopupOptionDetailProps {
    open: boolean;
    anchorEl: HTMLButtonElement | null;
    onClose: () => void;
    item: OptionInterface | null;
    onSubmit: (v: any) => void;
}

export function PopupOptionDetail(props: PopupOptionDetailProps) {
    const { onClose, item, onSubmit } = props;

    const [checked, setChecked] = useState<number[]>([]);
    const [textFieldValue, setTextFieldValue] = useState<string>('');
    /**
     * useEffect hook to handle component side-effects when 'item' prop changes.
     * It updates form fields based on the type of 'item'.
     */
    useEffect(() => {
        if (item?.type === 'TEXT') {
            // Handle side-effects for TEXT type.
            const checkData = (itemData: OptionInterface[]) => {
                if (itemData.length > 0) {
                    if (itemData[0].value.length > 0) {
                        // If 'item' contains data, set 'textFieldValue' to the first title.
                        return itemData[0]!.value[0]!.title;
                    }
                }
                return '';
            };
            setTextFieldValue(checkData([item]));
        } else {
            // Handle side-effects for other types (e.g., CHECKBOX or RADIO).
            if (item && item?.options && item?.options.length > 0) {
                var checklist: number[] = [];

                // Find the indices of selected options in 'item.options' and set 'checked' accordingly.
                item.value.forEach((v) => {
                    const index = item.options?.indexOf(v);
                    if (index !== -1) {
                        checklist.push(index ?? 0);
                    }
                });
                setChecked(checklist);
            }
        }
    }, [item]);

    /**
     * Handles the toggle event for a given value based on the item's type.
     *
     * @param {number} value - The value to toggle.
     */
    const handleToggle = (value: number) => {
        switch (item?.type) {
            case 'CHECKBOX':
                // For CHECKBOX type, toggle the checked state of the value.
                const currentIndex = checked.indexOf(value);
                const newChecked = [...checked];

                if (currentIndex === -1) {
                    // If the value is not already checked, add it to the checked list.
                    newChecked.push(value);
                } else {
                    // If the value is already checked, remove it from the checked list.
                    newChecked.splice(currentIndex, 1);
                }
                setChecked(newChecked);
                return;

            case 'RADIO':
                // For RADIO type, set the checked value to the selected value.
                setChecked([value]);
                break;

            default:
                // Handle other item types (if any) here.
                break;
        }
    };

    /**
     * Handles the form submission based on the item's type.
     */
    const handleSubmit = () => {
        if (item) {
            if (item.type === 'TEXT') {
                // For TEXT type, create an Options array with the entered text.
                var value: Options[] = [
                    {
                        key: '',
                        title: textFieldValue,
                    },
                ];
                if (textFieldValue !== '' && textFieldValue.trim()) {
                    // Only submit if the text field is not empty or contains only whitespace.
                    onSubmit(value);
                }
                setTextFieldValue(''); // Clear the text field value after submission.
            } else {
                // For other types, such as CHECKBOX or RADIO, gather selected options and submit.
                const result = checked.map((index) => item.options![index]);
                onSubmit(result);
                setChecked([]); // Clear the selected options after submission.
            }
        }
    };

    return (
        <Popover
            open={props.open}
            anchorEl={props.anchorEl}
            onClose={onClose}
            anchorOrigin={{
                vertical: 'bottom',
                horizontal: 'left',
            }}
            disableRestoreFocus
        >
            <List
                sx={{
                    width: '100%',
                    minWidth: 250,
                    bgcolor: 'background.paper',
                }}
                component="nav"
                aria-labelledby="nested-list-subheader"
                disablePadding
                subheader={
                    item && item.type != 'ONLY_TITLE' ? (
                        <Stack
                            direction={'row'}
                            sx={{
                                alignItems: 'center',
                                justifyContent: 'space-between',
                                pr: '10px',
                            }}
                        >
                            <ListSubheader sx={{ fontSize: '16px' }}>{item?.title}</ListSubheader>
                            <IconButton onClick={onClose}>
                                <CloseIcon />
                            </IconButton>
                        </Stack>
                    ) : (
                        <></>
                    )
                }
            >
                {item && item.type != 'ONLY_TITLE' && <Divider />}

                {item?.options && item.options.length > 0 ? (
                    item.options.map((value: Options, index: number) => {
                        return (
                            <ListItemButton
                                key={value.key}
                                onClick={() => {
                                    handleToggle(index);
                                }}
                                sx={{ py: '0px' }}
                            >
                                {item.type == 'CHECKBOX' ? (
                                    <Checkbox
                                        edge="start"
                                        size="small"
                                        checked={checked.indexOf(index) != -1}
                                    />
                                ) : item.type == 'RADIO' ? (
                                    <Radio
                                        edge="start"
                                        size="small"
                                        checked={checked.indexOf(index) != -1}
                                    />
                                ) : (
                                    <></>
                                )}

                                <ListItemText primary={value.title} />
                            </ListItemButton>
                        );
                    })
                ) : item?.type != 'TEXT' ? (
                    <ListItemButton sx={{ py: '5px' }}>
                        <ListItemText primary={'không có bộ lọc nào khớp'} />
                    </ListItemButton>
                ) : (
                    <Stack
                        component="form"
                        onSubmit={(e) => {
                            e.preventDefault();
                            if (textFieldValue != '' && textFieldValue.trim()) {
                                handleSubmit();
                            }
                        }}
                        sx={{ padding: '10px' }}
                    >
                        <TextFieldForm
                            lable="Chứa"
                            variant="standard"
                            placeholder="giá trị"
                            tabIndex={1}
                            value={textFieldValue}
                            onChange={(v) => setTextFieldValue(v.target.value)}
                        />
                    </Stack>
                )}
                {item && item.type != 'ONLY_TITLE' && <Divider />}
                {item && item.type != 'ONLY_TITLE' && (
                    <Stack direction={'row-reverse'} p={'5px'}>
                        <Button
                            onClick={handleSubmit}
                            variant="text"
                            sx={{
                                color: '#007DC0',
                            }}
                        >
                            Áp dụng
                        </Button>
                    </Stack>
                )}
            </List>
        </Popover>
    );
}
