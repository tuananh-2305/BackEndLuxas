import { memberTypeApi } from '@/api/member-type-api';
import { MemberTypeModel } from '@/models/member.type.model';
import {
    Autocomplete,
    CircularProgress,
    InputLabel,
    Stack,
    TextField,
    Typography,
} from '@mui/material';
import React, { useEffect, useState } from 'react';
import CloseIcon from '@mui/icons-material/Close';
import { ArrowIcon } from '../icons/arrow-icon';

export interface IAutoCompoleteMemberTypeProps {
    setValue: (value: MemberTypeModel | null) => void;
    parkingId: string;
    value: MemberTypeModel | null;
    placeholder?: string;
    label?: string;
    textError?: string;
}

export default function AutoCompoleteMemberType(props: IAutoCompoleteMemberTypeProps) {
    const { setValue, parkingId, value, placeholder, textError } = props;
    const color = props.textError ? '#E42727' : '#E3E5E5';
    const label = props.label ? props.label : 'Loại khách hàng ';

    const [openAuto, setOpenAuto] = useState(false);
    const [listSelect, setListSelect] = useState<MemberTypeModel[]>([]);
    const loading = openAuto && listSelect.length === 0;
    useEffect(() => {
        let active = true;
        if (!loading) {
            return undefined;
        }
        if (openAuto) {
            const fetchDataCustomer = async () => {
                const { data } = await memberTypeApi.getMemberTypeByParkingId({
                    ID: parkingId,
                    Current: 0,
                    Limit: 1000,
                });
                setListSelect(data?.Data);
            };
            fetchDataCustomer();
        }
        return () => {
            active = false;
        };
    }, [loading]);
    return (
        <Stack>
            <InputLabel sx={{ fontSize: 14, fontWeight: 400, color: '#55595D', mb: '6px' }}>
                {label}
                <Typography
                    component={'span'}
                    sx={{
                        color: '#E42727',
                        fontSize: 13,
                    }}
                >
                    (✶)
                </Typography>
            </InputLabel>
            <Autocomplete
                size="small"
                onChange={(event: any, newValue: MemberTypeModel | null) => {
                    setValue(newValue);
                }}
                value={value}
                isOptionEqualToValue={(option: any, value) => option.ID === value?.ID}
                onOpen={() => {
                    setOpenAuto(true);
                }}
                onClose={() => {
                    setOpenAuto(false);
                }}
                popupIcon={<ArrowIcon />}
                sx={{
                    '& .MuiAutocomplete-popupIndicator': {
                        transition: 'all .3s',
                    },
                }}
                getOptionLabel={(option) => option.Name}
                options={listSelect}
                renderInput={(params) => (
                    <TextField
                        {...params}
                        size="small"
                        placeholder={placeholder}
                        inputProps={{
                            ...params.inputProps,
                            tabIndex: 1,
                        }}
                        InputProps={{
                            ...params.InputProps,
                            endAdornment: (
                                <React.Fragment>
                                    {loading ? (
                                        <CircularProgress color="inherit" size={20} />
                                    ) : null}
                                    {params.InputProps.endAdornment}
                                </React.Fragment>
                            ),
                            style: {
                                // fontSize: 14,
                                // fontWeight: 400,
                                // color: '#323232',
                                fontSize: '16px',
                                fontWeight: 400,
                                color: '#323232',
                                // padding: '13px 16px',
                                lineHeight: '20px',
                                height: '46px',
                            },
                        }}
                        sx={{
                            '& .MuiOutlinedInput-root:hover': {
                                '& > fieldset': {
                                    borderColor: color,
                                },
                            },
                            '& .MuiOutlinedInput-root': {
                                '& > fieldset': {
                                    borderColor: color,
                                    borderRadius: '6px',
                                },
                                '&.Mui-focused fieldset': {
                                    borderColor: color,
                                },
                            },
                            '& label.Mui-focused': {
                                color: color,
                            },
                            p: 0,
                        }}
                    />
                )}
            />
            {textError && (
                <Stack direction={'row'} spacing={'5px'} sx={{ alignItems: 'center', mt: '4px' }}>
                    <Stack
                        sx={{
                            width: '13px',
                            height: '13px',
                            alignItems: 'center',
                            justifyContent: 'center',
                            background: '#E42727',
                            borderRadius: '50%',
                        }}
                    >
                        <CloseIcon sx={{ color: '#fff', fontSize: 10, fontWeight: 600 }} />
                    </Stack>
                    <Typography
                        sx={{
                            fontSize: 12,
                            fontWeight: 400,
                            color: '#E42727',
                        }}
                    >
                        {textError}
                    </Typography>
                </Stack>
            )}
        </Stack>
    );
}
