import CloseIcon from '@mui/icons-material/Close';
import { InputLabel, Stack, Typography } from '@mui/material';
import { DateField } from '@mui/x-date-pickers';
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs';
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import dayjs, { Dayjs } from 'dayjs';
import 'dayjs/locale/vi';
export interface ITextFieldFormProps {
    value?: any;
    onChange?: any;
    lable: string;
    size?: 'small' | 'medium' | undefined;
    placeholder?: string;
    textError?: string;
    color?: string;
    required?: boolean;
    name?: string;
    maxDate?: Dayjs;
    minDate?: Dayjs;
    disabled?: boolean | undefined;
    onError?: (v: any) => void;
    tabIndex?: number | undefined;
}

export default function TextFieldFormDateInput(props: ITextFieldFormProps) {
    const { value, onChange, lable, textError, required, name, onError, tabIndex } = props;

    const color = props.color ? props.color : textError ? '#E42727' : '#E3E5E5';

    const onAnyTextFieldChanged = (e: any) => {
        if (!!e?.preventDefault) {
            e?.preventDefault();
            e?.stopPropagation();
        }
    };
    return (
        <Stack>
            <InputLabel sx={{ fontSize: 14, fontWeight: 400, color: '#55595D', mb: '6px' }}>
                {lable}{' '}
                <Typography
                    component={'span'}
                    sx={{
                        color: '#E42727',
                        fontSize: 13,
                        display: required ? 'inline-block' : 'none',
                    }}
                >
                    (✶)
                </Typography>
            </InputLabel>
            <LocalizationProvider dateAdapter={AdapterDayjs} adapterLocale="vi">
                <DateField
                    value={dayjs(value) ?? null}
                    onChange={onChange}
                    inputProps={{ tabindex: props.tabIndex }}
                    slotProps={{
                        textField: {
                            InputProps: {
                                size: props.size,
                                sx: {
                                    border: `1px solid ${color}`,
                                    borderRadius: '6px',
                                    height: '46px',
                                    fontSize: '16px',
                                    fontWeight: 400,
                                    color: '#323232',
                                    padding: '13px 16px',
                                    lineHeight: '20px',
                                },
                                disableUnderline: true,
                            },
                            variant: 'standard',
                        },
                    }}
                />
                {/* <DateField
                    value={dayjs(value)}
                    onChange={onChange}
                    maxDate={props.maxDate}
                    minDate={props.minDate}
                    disabled={props.disabled}
                    slotProps={{
                        textField: {
                            onBeforeInput: onAnyTextFieldChanged,
                            InputProps: {
                                size: props.size,
                                sx: {
                                    border: `1px solid ${color}`,
                                    borderRadius: '6px',
                                    height: '46px',
                                    fontSize: '16px',
                                    fontWeight: 400,
                                    color: '#323232',
                                    padding: '13px 16px',
                                    lineHeight: '20px',
                                },
                                disableUnderline: true,
                            },
                            variant: 'standard',
                        },
                    }}
                /> */}
            </LocalizationProvider>
            {textError && (
                <Stack direction={'row'} spacing={'5px'} sx={{ alignItems: 'center', mt: '4px' }}>
                    <Stack
                        sx={{
                            width: '13px',
                            height: '13px',
                            alignItems: 'center',
                            justifyContent: 'center',
                            background: '#E42727',
                            borderRadius: '50%',
                        }}
                    >
                        <CloseIcon sx={{ color: '#fff', fontSize: 10, fontWeight: 600 }} />
                    </Stack>
                    <Typography
                        sx={{
                            fontSize: 12,
                            fontWeight: 400,
                            color: '#E42727',
                        }}
                    >
                        {textError}
                    </Typography>
                </Stack>
            )}
        </Stack>
    );
}
