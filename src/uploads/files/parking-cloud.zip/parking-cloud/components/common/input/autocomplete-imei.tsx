import { boxImeiApi } from '@/api/index';
import { DeviceImeiModel } from '@/models/device.imei.model';
import { Autocomplete, CircularProgress, InputLabel, Stack, TextField } from '@mui/material';
import React, { useEffect, useState } from 'react';

export interface IAutoCompoleteImeiProps {
    setValue: (value: DeviceImeiModel | null) => void;
}

export default function AutoCompoleteImei(props: IAutoCompoleteImeiProps) {
    const { setValue } = props;
    const [openAuto, setOpenAuto] = useState(false);
    const [listSelect, setListSelect] = useState<any[]>([]);
    const loading = openAuto && listSelect.length === 0;
    useEffect(() => {
        let active = true;
        if (!loading) {
            return undefined;
        }
        if (openAuto) {
            const fetchDataCustomer = async () => {
                const { data } = await boxImeiApi.findAllBoxImageNotLink();
                setListSelect(data);
            };
            fetchDataCustomer();
        }
        return () => {
            active = false;
        };
    }, [loading]);
    return (
        <Stack>
            <InputLabel required>Imei</InputLabel>
            <Autocomplete
                size="small"
                onChange={(event: any, newValue: DeviceImeiModel | null) => {
                    setValue(newValue);
                }}
                isOptionEqualToValue={(option: any, value) => option.ID === value?.ID}
                onOpen={() => {
                    setOpenAuto(true);
                }}
                onClose={() => {
                    setOpenAuto(false);
                }}
                getOptionLabel={(option) => `${option.Name} (${option.Imei})`}
                options={listSelect}
                renderInput={(params) => (
                    <TextField
                        {...params}
                        InputProps={{
                            ...params.InputProps,
                            endAdornment: (
                                <React.Fragment>
                                    {loading ? (
                                        <CircularProgress color="inherit" size={20} />
                                    ) : null}
                                    {params.InputProps.endAdornment}
                                </React.Fragment>
                            ),
                        }}
                        sx={{
                            '& .MuiInputBase-root': {
                                borderRadius: '10px',
                            },
                        }}
                    />
                )}
            />
        </Stack>
    );
}
