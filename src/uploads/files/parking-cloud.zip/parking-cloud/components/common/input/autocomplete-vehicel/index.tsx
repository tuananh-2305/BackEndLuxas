import { memberVehicleApi } from '@/api/member-vehicle-api';
import { PaginationIDPayload } from '@/models/config.model';
import { MemberVehicleModel } from '@/models/member.vehicle.model';
import { SIZE_PAGE } from '@/ultis/constant';
import { Stack, Typography } from '@mui/material';
import { useCallback, useRef, useState } from 'react';
import { AvatarCustom } from '../../avatar-next';
import { VehicelSelectOptions } from './options';
import { MemberModel } from '@/models/index';

export interface IAutoCompoleteMemberProps {
    setValue: (value: MemberVehicleModel | null) => void;
    parkingId: string;
    value: MemberVehicleModel | null;
    isNotRequired?: boolean;
    memberId: string | undefined;
}

export const AutoCompleteVehicel = (props: IAutoCompoleteMemberProps) => {
    const { parkingId, setValue, value, isNotRequired, memberId } = props;

    const [openOptions, setOpenOptions] = useState(false);
    const ref = useRef<HTMLDivElement | null>(null);

    return (
        <Stack>
            <Typography>Phương tiện</Typography>
            <Stack sx={{ width: '100%' }}>
                <Stack
                    sx={{
                        padding: '10px 20px',
                        border: '1px solid black',
                        borderRadius: '10px',
                        cursor: 'pointer',
                        gap: '10px',
                    }}
                    alignItems="center"
                    direction="row"
                    onClick={() => setOpenOptions(true)}
                    ref={ref}
                >
                    <Typography sx={{ fontSize: '14px', fontWeight: 500 }}>
                        {value ? (
                            <>
                                <Typography sx={{ fontSize: '14px', fontWeight: '500' }}>{`${
                                    value.VehicleTypeId?.Name
                                } ${
                                    value?.PlateNumber ? `(${value?.PlateNumber})` : ''
                                }`}</Typography>
                                <Typography sx={{ fontSize: '12px', fontStyle: 'italic' }}>{`${
                                    value.VehicleBrand
                                } ${value.VehicleBrand && value.VehicleColor ? '-' : ''} ${
                                    value.VehicleColor
                                }`}</Typography>
                            </>
                        ) : (
                            'Hãy chọn loại phương tiện'
                        )}
                    </Typography>
                </Stack>

                <VehicelSelectOptions
                    parkingId={parkingId}
                    open={openOptions}
                    anhchor={ref.current}
                    memberId={memberId}
                    onSelect={(v) => {
                        setValue(v);
                        setOpenOptions(false);
                    }}
                    close={() => setOpenOptions(false)}
                />
            </Stack>
        </Stack>
    );
};
