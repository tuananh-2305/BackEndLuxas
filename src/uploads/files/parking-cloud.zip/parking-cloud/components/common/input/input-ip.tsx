import { FormControl, FormHelperText, OutlinedInput } from '@mui/material';
import Grid from '@mui/material/Unstable_Grid2'; // Grid version 2

import { useState } from 'react';

export interface IInputIPProps {
    onChange: (value: string) => void;
    setIsValidateIp?: (value: boolean) => void;
}

export default function InputIP(props: IInputIPProps) {
    const [ipParts, setIPParts] = useState(['', '', '', '']);

    const handleIPChange = (index: number, value: string) => {
        // check if value > 255 return 255
        if (value.length > 3) {
            value = value.slice(0, 3);
        }

        setIPParts((prevIPParts) => {
            const newIPParts = [...prevIPParts];
            newIPParts[index] = value;
            return newIPParts;
        });
        // check 4 ô thì setIsValidateIp
        props.onChange(ipParts.join('.'));
    };
    return (
        <>
            <FormControl variant="standard">
                <FormHelperText>IP*</FormHelperText>
                <Grid container spacing={1}>
                    {ipParts.map((part, index) => (
                        <Grid xs={3} key={index}>
                            <OutlinedInput
                                size="small"
                                type="number"
                                value={part}
                                onChange={(event) => {
                                    handleIPChange(index, event.target.value);
                                }}
                                inputProps={{
                                    pattern: '^(\\d{1,3}|)$',
                                    title: 'Vui lòng nhập số từ 0 đến 255',
                                    min: 0,
                                    max: 255,
                                }}
                            />
                        </Grid>
                    ))}
                </Grid>
            </FormControl>
        </>
    );
}
