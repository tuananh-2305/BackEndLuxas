import {
    IconButton,
    InputAdornment,
    InputLabel,
    Stack,
    TextField,
    TextFieldPropsSizeOverrides,
    Typography,
    useTheme,
} from '@mui/material';
import * as React from 'react';
import InfoOutlinedIcon from '@mui/icons-material/InfoOutlined';
import CheckIcon from '@mui/icons-material/Check';
import CloseIcon from '@mui/icons-material/Close';
import { Visibility, VisibilityOff } from '@mui/icons-material';
export interface ITextFieldFormProps {
    value?: unknown;
    onChange?: React.ChangeEventHandler<HTMLInputElement | HTMLTextAreaElement> | undefined;
    lable: string;
    type?: React.HTMLInputTypeAttribute | undefined;
    fullWidth?: boolean | undefined;
    size?: 'small' | 'medium' | undefined;
    variant?: 'outlined' | 'standard' | undefined;
    placeholder?: string;
    tabIndex?: number;
    textError?: string;
    color?: string;
    required?: boolean;
    row?: number;
    multiline?: boolean;
    name?: string;
    autoComplete?: string;
    disabled?: boolean;
    onBlur?: React.FocusEventHandler<HTMLInputElement | HTMLTextAreaElement> | undefined;
    isCheckBtn?: boolean;
    onClickCheckBtn?: () => void;
    height?: string;
    helpText?: string;
    endAdornment?: React.JSX.Element;
}

export default function TextFieldForm(props: ITextFieldFormProps) {
    const { value, onChange, lable, textError, required, name, disabled, helpText } = props;
    const type = props.type ?? 'text';
    const fullWidth = props.fullWidth ?? true;
    const size = props.size ?? 'small';
    const variant = props.variant ?? 'outlined';
    const color = props.color ? props.color : textError ? '#E42727' : '#E3E5E5';
    const theme = useTheme();
    return (
        <Stack sx={{ position: 'relative' }}>
            <InputLabel sx={{ fontSize: 14, fontWeight: 400, color: '#55595D', mb: '6px' }}>
                {lable}{' '}
                <Typography
                    component={'span'}
                    sx={{
                        color: '#E42727',
                        fontSize: 13,
                        display: required ? 'inline-block' : 'none',
                    }}
                >
                    (✶)
                </Typography>
            </InputLabel>
            <Stack sx={{ position: 'relative' }}>
                <TextField
                    name={name}
                    value={value}
                    onChange={onChange}
                    // tabIndex={props.tabIndex}
                    margin="dense"
                    id={`${name}-id`}
                    type={type}
                    fullWidth={fullWidth}
                    size={size}
                    variant={variant}
                    autoComplete={props.autoComplete ?? 'off'}
                    placeholder={props.placeholder}
                    rows={props.row ?? 1}
                    multiline={props.multiline ?? false}
                    disabled={disabled}
                    onBlur={props.onBlur}
                    aria-required="true"
                    sx={{
                        '& .MuiOutlinedInput-root:hover': {
                            '& > fieldset': {
                                borderColor: color,
                                transition: 'all 0.3s',
                            },
                        },
                        '& .MuiOutlinedInput-root': {
                            '& > fieldset': {
                                borderColor: color,
                                transition: 'all 0.3s',
                                borderRadius: '6px',
                                color: 'red',
                            },
                            '&.Mui-focused fieldset': {
                                borderColor: color,
                                transition: 'all 0.3s',
                            },
                        },
                        '& label.Mui-focused': {
                            color: color,
                        },
                        marginTop: '0px',
                        transition: 'all 0.3s',
                        '& input[type=number]': {
                            '-moz-appearance': 'textfield',
                        },
                        '& input[type=number]::-webkit-outer-spin-button': {
                            '-webkit-appearance': 'none',
                            margin: 0,
                        },
                        '& input[type=number]::-webkit-inner-spin-button': {
                            '-webkit-appearance': 'none',
                            margin: 0,
                        },
                        margin: 0,
                        padding: 0,
                    }}
                    InputProps={{
                        endAdornment: props.endAdornment,
                    }}
                    inputProps={{
                        tabIndex: props.tabIndex,
                        style: {
                            fontSize: '16px',
                            fontWeight: 400,
                            color: '#323232',
                            padding: !props.row ? '13px 16px' : undefined,
                            lineHeight: !props.row ? '20px' : undefined,
                            height: props.height ? props.height : !props.row ? '20px' : undefined,
                        },
                    }}
                />
                {props.isCheckBtn && (
                    <IconButton
                        onClick={props.onClickCheckBtn}
                        sx={{
                            width: '20px',
                            height: '20px',
                            position: 'absolute',
                            right: '5px',
                            borderRadius: '50%',
                            color: '#E42727',
                            bottom: '12px',
                        }}
                    >
                        <InfoOutlinedIcon />
                    </IconButton>
                )}
            </Stack>
            {textError && (
                <Stack direction={'row'} spacing={'5px'} sx={{ alignItems: 'center', mt: '4px' }}>
                    <Stack
                        sx={{
                            width: '13px',
                            height: '13px',
                            alignItems: 'center',
                            justifyContent: 'center',
                            background: '#E42727',
                            borderRadius: '50%',
                        }}
                    >
                        <CloseIcon sx={{ color: '#fff', fontSize: 10, fontWeight: 600 }} />
                    </Stack>
                    <Typography
                        sx={{
                            fontSize: 12,
                            fontWeight: 400,
                            color: '#E42727',
                        }}
                    >
                        {textError}
                    </Typography>
                </Stack>
            )}
            {helpText && (
                <Stack direction={'row'} spacing={'5px'} sx={{ alignItems: 'center', mt: '4px' }}>
                    <Stack
                        sx={{
                            width: '13px',
                            height: '13px',
                            alignItems: 'center',
                            justifyContent: 'center',
                            background: '#22AE68',
                            borderRadius: '50%',
                        }}
                    >
                        <CheckIcon sx={{ color: '#fff', fontSize: 10, fontWeight: 600 }} />
                    </Stack>
                    <Typography
                        sx={{
                            fontSize: 12,
                            fontWeight: 400,
                            color: '#22AE68',
                        }}
                    >
                        {helpText}
                    </Typography>
                </Stack>
            )}
        </Stack>
    );
}
