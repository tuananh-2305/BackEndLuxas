import { PhotoCamera } from '@mui/icons-material';
import { IconButton, Stack } from '@mui/material';
import { AvatarCustom } from '../avatar-next/avatar-custom';
import { useState } from 'react';

export interface IInputUploadBackgroundProps {
    avatar: File | null;
    setAvatar: (avatar: File) => void;
    urlInit?: string;
}

export default function InputUploadBackground(props: IInputUploadBackgroundProps) {
    const { avatar, setAvatar, urlInit } = props;
    const [url, setUrl] = useState<string>(urlInit || '');
    const handleUploadImage = (e: any) => {
        if (!e.target.files[0]) return;
        const file = e.target.files[0];
        setAvatar(file);
        setUrl(URL.createObjectURL(file));
    };
    return (
        <Stack
            direction={'column'}
            spacing={2}
            alignItems="center"
            justifyContent={'center'}
            sx={{
                minHeight: '300px',
                border: '1px dashed #abb4d2',
                background: url ? `url(${url}) center/cover` : '#f1f1f1',
            }}
            component="label"
        >
            <IconButton
                color="primary"
                aria-label="upload picture"
                component="label"
                size="large"
                sx={{
                    border: avatar ? '1px solid #abb4d2' : 'none',
                    mb: -1,
                    p: 0,
                }}
            >
                <input
                    hidden
                    autoComplete="off"
                    accept="image/*"
                    type="file"
                    onChange={handleUploadImage}
                />

                {!url && <PhotoCamera fontSize="large" sx={{ m: 1, fontSize: '80px' }} />}
            </IconButton>
        </Stack>
    );
}
