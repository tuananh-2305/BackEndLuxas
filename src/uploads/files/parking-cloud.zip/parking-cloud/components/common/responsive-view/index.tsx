import { Stack, Typography, useMediaQuery } from '@mui/material';
import Image from 'next/image';

export const ResponsiveView = () => {
    const matches = useMediaQuery('(min-width:600px)');
    return (
        <Stack
            sx={{
                width: '100vw',
                height: '100vh',
            }}
            justifyContent="center"
            alignItems="center"
            spacing={5}
        >
            <Image src="/logo/Oryza-logo.png" width={208} height={61} alt="logo-oryza" />
            <Typography sx={{ fontFamily: 'Good Timing', fontWeight: 700, fontSize: '36px' }}>
                Bãi Xe Thông Minh
            </Typography>
            <Stack
                sx={{
                    boxShadow: '0px 2px 2px rgba(0, 0, 0, 0.25)',
                    borderRadius: '15px',
                    backgroundColor: '#000000',
                    width: '54px',
                    height: '54px',
                    fontFamily: 'Good Timing',
                    fontSize: '24px',
                    color: '#FFFFFF',
                }}
                alignItems="center"
            >
                <Typography
                    sx={{
                        fontFamily: 'Good Timing',
                        fontSize: '24px',
                        color: '#FFFFFF',
                        height: 'fit-content',
                        display: 'block-inline',
                    }}
                >
                    p
                </Typography>
            </Stack>
            <Stack alignItems="center" spacing={3} direction={matches ? 'row' : 'column'}>
                <Image
                    src="/icons/googleplay.svg"
                    width={203.95}
                    height={59}
                    alt="google-play"
                    style={{ cursor: 'pointer' }}
                />
                <Image
                    src="/icons/appstore.svg"
                    width={203.95}
                    height={59}
                    alt="app-store"
                    style={{ cursor: 'pointer' }}
                />
            </Stack>
        </Stack>
    );
};
