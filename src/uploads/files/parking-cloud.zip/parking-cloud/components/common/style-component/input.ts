import { Badge, styled, Box, OutlinedInput, Select } from '@mui/material';
import { DatePicker } from '@mui/x-date-pickers';

export const StyledOutlinedInput = styled(OutlinedInput)(({ theme, color }: any) => ({
    borderRadius: '10px',
}));
export const StyledSelectInput = styled(Select)(({ theme, color }: any) => ({
    borderRadius: '10px',
}));
export const StyledDatePicker = styled(DatePicker)(({ theme, color }: any) => ({
    borderRadius: '10px',
}));
export const StyledOutlinedInputLogin = styled(OutlinedInput)(({ theme, color }: any) => ({
    borderRadius: '10px',
    backgroundColor: '#fff',
}));
