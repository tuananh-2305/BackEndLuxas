import { LoadingButton } from '@mui/lab';
import { styled, Button } from '@mui/material';

export const StyleButton = styled(LoadingButton)(({ theme, color }: any) => ({
    backgroundColor: '#FFB862',
    borderRadius: '10px',
    '&:hover': {
        backgroundColor: 'rgba(255, 184, 98, 0.9)',
    },
    padding: '8px 30px',
}));
export const StyleButtonSecondary = styled(LoadingButton)(({ theme, color }: any) => ({
    backgroundColor: '#78C6E7',
    borderRadius: '10px',
    '&:hover': {
        backgroundColor: 'rgb(120, 198, 231,0.9)',
    },
    padding: '8px 30px',
}));
