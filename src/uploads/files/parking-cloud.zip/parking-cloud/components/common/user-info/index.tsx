import { ListItem, ListItemAvatar, Avatar, ListItemText, Typography } from '@mui/material';
import * as React from 'react';

export interface IUserInfoProps {
    fullName: string;
    avatar?: string | undefined;
    textColor?: string;
}

export function UserInfo(props: IUserInfoProps) {
    const { avatar, fullName, textColor } = props;
    return (
        <ListItem disablePadding>
            <ListItemAvatar>
                <Avatar
                    alt={fullName}
                    src={avatar}
                    sx={{
                        border: '1px solid #CDD2D1',
                        width: '34px',
                        height: '34px',
                    }}
                />
            </ListItemAvatar>
            <ListItemText
                primary={
                    <Typography
                        sx={{
                            fontSize: { xs: 13, lg: 14 },
                            fontWeight: 500,
                            color: textColor ?? '#323232',
                        }}
                    >
                        {fullName}
                    </Typography>
                }
            />
        </ListItem>
    );
}
