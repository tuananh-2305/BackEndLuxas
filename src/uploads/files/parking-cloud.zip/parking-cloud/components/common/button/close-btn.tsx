// components/CloseButton.js
import React from 'react';
import CloseIcon from '@mui/icons-material/Close';
import { IconButton } from '@mui/material';

const CloseButton = ({ size }: any) => {
    return (
        <IconButton
            sx={{
                width: size ?? '20px',
                height: size ?? '20px',
                background: '#AFAFAF',
                borderRadius: '50%',
                color: '#fff',
                border: 'none',
                cursor: 'pointer',
                ':hover': {
                    color: '#fff',
                    background: '#AFAFAF90',
                },
                alignItems: 'center',
                justifyContent: 'center',
            }}
        >
            <CloseIcon sx={{ fontSize: 13 }} />
        </IconButton>
    );
};

export default CloseButton;
