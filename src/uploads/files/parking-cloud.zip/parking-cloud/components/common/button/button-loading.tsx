import { Box, CircularProgress, Fab, SxProps, Theme } from '@mui/material';
import { green } from '@mui/material/colors';
import SaveIcon from '@mui/icons-material/Save';
import { useState } from 'react';
import { alpha } from '@mui/material';

export interface IButtonLoadingProps {
    icon?: React.ReactNode;
    handleClick?: () => void;
    isloading?: boolean;
    sx?: SxProps<Theme>;
    // size?:string
    color?: string;
}

export default function ButtonLoading(props: IButtonLoadingProps) {
    const { icon, handleClick, isloading, sx, color } = props;
    // console.log(isloading);
    return (
        <Box sx={{ m: 1, position: 'relative' }}>
            <Fab
                aria-label="save"
                color="primary"
                sx={{
                    backgroundColor: color ? color : '#067DC0',
                    '&:hover': {
                        backgroundColor: alpha(color ? color : '#067DC0', 0.8),
                    },
                    ...sx,
                }}
                onClick={(e) => {
                    if (isloading) return;
                    handleClick && handleClick();
                }}
                size="medium"
            >
                {icon ? icon : <SaveIcon />}
            </Fab>
            {isloading && (
                <CircularProgress
                    size={60}
                    sx={{
                        color: green[500],
                        position: 'absolute',
                        top: -6,
                        left: -6,
                        zIndex: 1,
                    }}
                />
            )}
        </Box>
    );
}
