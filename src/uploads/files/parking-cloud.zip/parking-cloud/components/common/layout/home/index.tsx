import { MainLayoutFooterComponent, MainLayoutTopNavigation } from '@/components/product-langing';
import { LayoutProps } from '@/models/index';
import { Stack } from '@mui/material';
import { useRef, useState } from 'react';
import ArrowCircleUpIcon from '@mui/icons-material/ArrowCircleUp';
export interface IAdminLayoutProps {}

export default function HomeLayout({ children }: LayoutProps) {
    const [navColor, setNavColor] = useState<string>('unset');
    const ref = useRef<HTMLDivElement | null>(null);

    function scrollToTop() {
        if (ref?.current) {
            const currentPosition = ref.current.scrollTop;
            if (currentPosition > 0) {
                window.requestAnimationFrame(scrollToTop);
                ref.current.scrollTo(0, currentPosition - currentPosition / 10);
            }
        }
    }
    return (
        <Stack
            ref={ref}
            onMouseLeave={() => {
                const element = document.querySelector('.header-animation') as HTMLDivElement;
                if (element) {
                    element.style.opacity = '0';
                    element.style.visibility = 'hidden';
                }
            }}
            onScroll={(e) => {
                // const value =
                //     e.currentTarget.scrollHeight -
                //     e.currentTarget.scrollTop -
                //     e.currentTarget.clientHeight;
                if (e.currentTarget.scrollTop > 100) {
                    setNavColor('#ffffffaa');
                } else {
                    setNavColor('unset');
                }

                if (e.currentTarget.scrollTop > 200) {
                    const element = document.querySelector('#back_top') as HTMLDivElement;
                    if (element) {
                        element.style.opacity = '1';
                        element.style.visibility = 'visible';
                    }
                } else {
                    const element = document.querySelector('#back_top') as HTMLDivElement;
                    if (element) {
                        element.style.opacity = '0';
                        element.style.visibility = 'hidden';
                    }
                }

                // checkScrollHeight(value);
            }}
            sx={{
                overflowY: 'auto',
                height: '100vh',
                maxHeight: '100vh',
                overflowX: 'hidden',
                transition: 'all ease .5s',
            }}
        >
            <Stack>
                <MainLayoutTopNavigation color={navColor} />
                {children}
            </Stack>
            <MainLayoutFooterComponent />

            <Stack
                id="back_top"
                onClick={(e) => {
                    scrollToTop();
                }}
                sx={{
                    position: 'absolute',
                    right: '50px',
                    bottom: '20px',
                    cursor: 'pointer',
                    backgroundColor: '#000',
                    borderRadius: '50%',
                    transition: 'all ease .3s',
                    boxShadow:
                        'rgba(50, 50, 93, 0.25) 0px 13px 27px -5px, rgba(0, 0, 0, 0.3) 0px 8px 16px -8px',
                }}
            >
                <ArrowCircleUpIcon
                    sx={{
                        color: '#fff',
                        fontSize: '40px',
                    }}
                />
            </Stack>
        </Stack>
    );
}
