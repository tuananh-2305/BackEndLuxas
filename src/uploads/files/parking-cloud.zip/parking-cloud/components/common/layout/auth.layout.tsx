import { LayoutProps } from '@/models/index';
import { Box, Typography, Unstable_Grid2 as Grid, Stack } from '@mui/material';
import NextLink from 'next/link';
import { ReactNode } from 'react';
import Image from 'next/image';

export default function AuthLayout({ children }: LayoutProps) {
    return (
        <Stack
            component="main"
            sx={{
                flex: '1 1 auto',
                height: '100vh',
            }}
        >
            <Grid container sx={{ flex: 1 }}>
                <Grid
                    xs={12}
                    lg={6}
                    sx={{
                        backgroundColor: 'background.paper',
                        display: 'flex',
                        flexDirection: 'column',
                        position: 'relative',
                    }}
                >
                    <Box
                        component="header"
                        sx={{
                            left: 0,
                            p: 3,
                            position: 'fixed',
                            top: 0,
                            width: '100%',
                        }}
                    >
                        <Box
                            sx={{
                                display: 'inline-flex',
                                height: 32,
                                width: 32,
                            }}
                        >
                            {/* <Logo /> */}
                        </Box>
                    </Box>
                    {children}
                </Grid>
                <Grid
                    xs={12}
                    lg={6}
                    sx={{
                        alignItems: 'center',
                        background: 'radial-gradient(50% 50% at 50% 50%, #122647 0%, #090E23 100%)',
                        color: 'white',
                        display: 'flex',
                        justifyContent: 'center',
                        '& img': {
                            maxWidth: '100%',
                        },
                    }}
                >
                    <Stack sx={{ p: 3 }}>
                        <Typography
                            align="center"
                            color="inherit"
                            sx={{
                                fontSize: '24px',
                                lineHeight: '32px',
                                mb: 1,
                            }}
                            variant="h4"
                        >
                            Chào mừng{' '}
                            <Typography component={'span'} variant="h4" sx={{ color: '#15B79E' }}>
                                CLOUD
                            </Typography>
                        </Typography>
                        <Typography align="center" sx={{ mb: 3 }} variant="subtitle1">
                            Hệ thống quản lý bãi xe thông minh
                        </Typography>
                        <Stack flex={1}>
                            <Image
                                width={800}
                                height={800}
                                src="/assets/auth-illustration.svg"
                                alt="Picture of the author"
                                style={{
                                    objectPosition: 'center',
                                    width: '100%',
                                    height: '500px',
                                }}
                            ></Image>
                        </Stack>
                    </Stack>
                </Grid>
            </Grid>
        </Stack>
    );
}
