import { DashboardRightBarComponent, LeftDashBoardComponent } from '@/components/dashboard';
import { dashboardLayoutMock } from '@/mocks/index';
import { LayoutProps } from '@/models/index';
import { Stack, Tooltip, useMediaQuery } from '@mui/material';
import { createContext, useEffect, useRef, useState } from 'react';
import { MainLayout } from './main.layout';
import DashboardCustomizeIcon from '@mui/icons-material/DashboardCustomize';
import { useAppSelector } from '@/hooks/index';
import { useRouter } from 'next/router';

export interface IDashboardLayoutProps {}
export const ContextLayoutDashboard = createContext({
    maxHeight: 'unset',
    setOpenRightBar: (value: boolean) => {},
    setOpenDashboardBar: (value: boolean) => {},
    ref: dashboardLayoutMock,
    openDashboardBar: true,
});
export default function DashboardLayout({ children }: LayoutProps) {
    const [openRight, setOpenRightBar] = useState(false);
    const ref = useRef<HTMLDivElement | null>(null);
    const [openDashboardBar, setOpenDashboardBar] = useState(false);

    const profile = useAppSelector((state) => state.common.profile);
    const parkingChoose = useAppSelector((state) => state.parking.chooseDashboard);
    const router = useRouter();

    const vh = useAppSelector((state) => state.common.vh);
    const context = {
        maxHeight: vh,
        setOpenRightBar,
        setOpenDashboardBar,
        ref,
        openDashboardBar,
    };

    useEffect(() => {
        if (profile && parkingChoose) {
            if (
                !parkingChoose?.SystemRoleReport?.Read &&
                !profile.IsAdmin &&
                !profile.IsSupperAdmin
            ) {
                if (parkingChoose.SystemRoleSetting?.Read) {
                    router.replace('/menu/member?page=1');
                } else {
                    router.replace('/');
                }
            }
        }
    }, [parkingChoose, profile, router]);
    return (
        <MainLayout>
            <ContextLayoutDashboard.Provider value={context}>
                <Stack direction={'row'} sx={{ position: 'relative', height: '100%' }}>
                    <LeftDashBoardComponent
                        open={openDashboardBar}
                        close={() => setOpenDashboardBar(false)}
                    />

                    <Stack
                        sx={{
                            width: openDashboardBar ? '100vw - 350px' : '100vw',
                            height: '100%',
                        }}
                    >
                        {children}
                    </Stack>

                    <DashboardRightBarComponent
                        open={openRight}
                        close={() => setOpenRightBar(false)}
                    />

                    {/* <Tooltip title="Mở thanh công cụ phải.">
                        <Stack
                            onClick={() => setOpenRightBar(true)}
                            sx={{
                                position: 'fixed',
                                right: '15px',
                                bottom: '15px',
                                backgroundColor: '#55595D',
                                boxShadow: '0px 2px 2px rgba(0, 0, 0, 0.25)',
                                width: '50px',
                                height: '50px',
                                borderRadius: '25px',
                                cursor: 'pointer',
                            }}
                            justifyContent="center"
                            alignItems="center"
                        >
                            <DashboardCustomizeIcon sx={{ color: '#fff' }} />
                        </Stack>
                    </Tooltip> */}
                </Stack>
            </ContextLayoutDashboard.Provider>
        </MainLayout>
    );
}
