import { LayoutProps } from '@/models/common';
import { Box, Stack } from '@mui/material';
import SideNav from '../nav/side-nav';
import { useEffect, useState } from 'react';
import { useAppDispatch, useAppSelector } from '@/hooks/useReudx';
import { useRouter } from 'next/router';
import { authApi } from '@/api/index';
import { changeViewHeight, initRole } from '@/redux/index';
import { SeoPage } from '../seo/seo';
import { systemRoleApi } from '@/api/key-system-role';

export interface MainLayoutProps {}

export function MainLayout({ children }: LayoutProps) {
    const profile = useAppSelector((state) => state.common.profile);
    const dispatch = useAppDispatch();
    const viewPortHeight = useAppSelector((state) => state.common.vh);
    const parkingChoose = useAppSelector((state) => state.parking.chooseDashboard);
    useEffect(() => {
        const vh = Math.max(document.documentElement.clientHeight || 0, window.innerHeight || 0);
        const action = changeViewHeight({ vh: vh });
        dispatch(action);
    }, []);
    useEffect(() => {
        if (!profile) {
            authApi.getProfile().then((res) => {});
        }
    }, [profile]);

    useEffect(() => {
        if (!parkingChoose) {
            return;
        }

        systemRoleApi.groupRoleByParkingId(parkingChoose.ID).then((res) => {
            const action = initRole({ role: res.data });
            dispatch(action);
        });
    }, [dispatch, parkingChoose]);
    return (
        <Stack
            sx={{
                backgroundColor: '#55595D',
                width: '100%',
                height: `${viewPortHeight}px`,
                overflowX: 'hidden',
                padding: '0px',
            }}
            direction="row"
        >
            <SeoPage title={'Oryza'} />
            <SideNav />
            <Stack
                sx={{
                    width: 'calc(100% - 80px)',
                    backgroundColor: '#fff',
                    // borderRadius: '20px 0px 0px 20px',
                    overflow: 'hidden',
                    height: '100%',
                    zIndex: 20,
                }}
            >
                {children}
            </Stack>
        </Stack>
    );
}
