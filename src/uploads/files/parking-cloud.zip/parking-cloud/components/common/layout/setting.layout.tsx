import { LeftSetting } from '@/components/settings';
import { LayoutProps } from '@/models/index';
import { IconButton, Stack } from '@mui/material';
import { useEffect } from 'react';
import { MainLayout } from './main.layout';
import { parkingApi } from '@/api/index';
import { useAppDispatch, useAppSelector } from '@/hooks/index';
import { updateLeftbarOpen } from '@/redux/common';
import MenuOpenIcon from '@mui/icons-material/MenuOpen';
import { SIZE_lEFT_MENU } from '@/constants/global';

export interface ISettingLayoutProps {}

export default function SettingLayout({ children }: LayoutProps) {
    const openSettingBar = useAppSelector((state) => state.common.leftBarStateOpen.setting);

    return (
        <MainLayout>
            <Stack
                direction={'row'}
                sx={{
                    minHeight: '100%',
                    width: '100%',
                    overflow: 'auto',
                    position: 'relative',
                    maxHeight: `100vh`,
                }}
                justifyContent="center"
            >
                {openSettingBar ? <LeftSetting /> : <></>}
                <Stack
                    sx={{
                        // width: openSettingBar ? '100%' : `calc(100% - ${SIZE_lEFT_MENU}px)`,
                        flex: 1,
                    }}
                >
                    {children}
                </Stack>
            </Stack>
        </MainLayout>
    );
}
