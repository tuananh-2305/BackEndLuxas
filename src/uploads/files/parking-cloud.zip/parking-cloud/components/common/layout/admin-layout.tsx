import LeftMenuAdmin from '@/components/admin/left-menu';
import { LayoutProps } from '@/models/index';
import { IconButton, Stack } from '@mui/material';
import { MainLayout } from './main.layout';
import { useAppDispatch, useAppSelector } from '@/hooks/useReudx';
import MenuOpenIcon from '@mui/icons-material/MenuOpen';
import { updateLeftbarOpen } from '@/redux/index';
import { SIZE_lEFT_MENU } from '@/constants/global';

export interface IAdminLayoutProps {}

export default function AdminLayout({ children }: LayoutProps) {
    const openLeftbar = useAppSelector((state) => state.common.leftBarStateOpen.admin);

    return (
        <MainLayout>
            <Stack
                direction={'row'}
                sx={{ position: 'relative', minHeight: '100%' }}
                justifyContent="center"
            >
                {openLeftbar ? <LeftMenuAdmin /> : <></>}
                <Stack
                    sx={{
                        //  width: openLeftbar ? '100%' : `calc(100% - ${SIZE_lEFT_MENU}px)`
                        width: '100%',
                        height: '100%',
                    }}
                >
                    {children}
                </Stack>
            </Stack>
        </MainLayout>
    );
}
