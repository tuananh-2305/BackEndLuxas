import { generateURLWithQueryParams } from '@/ultis/global-func';
import KeyboardArrowLeftRoundedIcon from '@mui/icons-material/KeyboardArrowLeftRounded';
import { Stack, Typography } from '@mui/material';
import { useRouter } from 'next/navigation';

interface ISearchParamns {
    page: string | null;
    address: string | null;
    name: string | null;
    phone: string | null;
    cardNumberOutSide: string | null;
    plateno: string | null;
    cardNumberInSide: string | null;
}

interface ITableControlPagination {
    total: number;
    currentPage: number;
    currentCount: number;
    maxPage: number;
    searhParams?: ISearchParamns;
    basePath: string;
}
export const TableControlPagination = (props: ITableControlPagination) => {
    const { total, currentCount, currentPage, maxPage, searhParams, basePath } = props;
    const router = useRouter();

    const pageItem = (p: number) => {
        return (
            <Stack
                onClick={() => {
                    if (currentPage + 1 === p) {
                        return;
                    }

                    const url = generateURLWithQueryParams(basePath, {
                        ...(searhParams as any),
                        ['page']: p.toString(),
                    });

                    router.replace(url);
                }}
                sx={{
                    padding: '10px',
                    width: '36px',
                    height: '36px',
                    justifyContent: 'center',
                    alignItems: 'center',
                    gap: '10px',
                    cursor: 'pointer',
                    borderRadius: '8px',
                    transition: 'all ease .3s',
                    backgroundColor: currentPage + 1 === p ? '#007DC0' : 'transparent',
                    '&: hover ':
                        currentPage + 1 === p
                            ? {}
                            : {
                                  backgroundColor: '#AFAFAF',
                              },
                }}
            >
                <Typography
                    sx={{
                        color: currentPage + 1 === p ? '#fff' : '#323232',
                        fontSize: '16px',
                        fontStyle: 'normal',
                        fontWeight: 500,
                        lineHeight: 'normal',
                        userSelect: 'none',
                    }}
                >
                    {p}
                </Typography>
            </Stack>
        );
    };
    return (
        <Stack
            direction="row"
            alignItems="center"
            sx={{ padding: '23px', gap: '16px', width: '100%', position: 'relative' }}
            justifyContent="center"
        >
            <Stack
                sx={{ position: 'absolute', left: '16px', gap: '8px' }}
                direction="row"
                alignItems="center"
            >
                <Typography
                    sx={{
                        color: '#323232',
                        fontSize: '16px',
                        fontStyle: 'normal',
                        fontWeight: 700,
                        lineHeight: 'normal',
                    }}
                >
                    {currentCount}/{total}
                </Typography>
                <Typography
                    component="span"
                    sx={{
                        color: '#AFAFAF',
                        fontSize: '14px',
                        fontStyle: 'normal',
                        fontWeight: 400,
                        lineHeight: '140%',
                    }}
                >
                    dữ liệu
                </Typography>
            </Stack>

            <Stack
                sx={{
                    width: '36px',
                    height: '36px',
                    padding: '10px',
                    justifyContent: 'center',
                    alignitems: 'center',
                    gap: '10px',
                    flexShrink: 0,
                    userSelect: currentPage === 0 ? 'none' : 'initial',
                    borderRadius: '10px',
                    transition: 'all ease .3s',
                    cursor: 'pointer',
                    backgroundColor: currentPage === 0 ? '#F2F2F2' : '#78C6E7',

                    '&: hover ':
                        currentPage !== 0
                            ? {
                                  backgroundColor: '#007DC0',
                                  '& > *': {
                                      color: '#fff',
                                  },
                              }
                            : {},
                }}
                justifyContent="center"
                alignItems="center"
                onClick={() => {
                    if (currentPage === 0) {
                        return;
                    }
                    const url = generateURLWithQueryParams(basePath, {
                        ...(searhParams as any),
                        ['page']: currentPage.toString(),
                    });

                    router.replace(url);
                }}
            >
                <KeyboardArrowLeftRoundedIcon
                    sx={{ color: currentPage === 0 ? '#AFAFAF' : '#fff' }}
                />
            </Stack>

            <Stack
                direction="row"
                sx={{
                    padding: '8px 16px',
                    backgroundColor: '#F2F2F2',
                    gap: '8px',
                    borderRadius: '44px',
                }}
                alignItems="flex-end"
            >
                {currentPage > 2 ? (
                    <>
                        {pageItem(1)}
                        <Typography
                            sx={{
                                color: '#323232',
                                fontSize: '16px',
                                fontStyle: 'normal',
                                fontWeight: 500,
                                lineHeight: 'normal',
                                padding: '10px',
                            }}
                        >
                            ...
                        </Typography>
                    </>
                ) : (
                    <></>
                )}

                {currentPage - 1 > 0 ? pageItem(currentPage - 1) : <></>}
                {currentPage > 0 ? pageItem(currentPage) : <></>}
                {pageItem(currentPage + 1)}
                {currentPage + 2 <= maxPage ? pageItem(currentPage + 2) : <></>}
                {currentPage + 3 <= maxPage ? pageItem(currentPage + 3) : <></>}

                {currentPage < maxPage - 3 ? (
                    <>
                        <Typography
                            sx={{
                                color: '#323232',
                                fontSize: '16px',
                                fontStyle: 'normal',
                                fontWeight: 500,
                                lineHeight: 'normal',
                                padding: '10px',
                            }}
                        >
                            ...
                        </Typography>
                        {pageItem(maxPage)}
                    </>
                ) : (
                    <></>
                )}
            </Stack>

            <Stack
                sx={{
                    width: '36px',
                    height: '36px',
                    padding: '10px',
                    justifyContent: 'center',
                    alignitems: 'center',
                    gap: '10px',
                    flexShrink: 0,
                    borderRadius: '10px',
                    transition: 'all ease .3s',
                    cursor: 'pointer',
                    userSelect: currentPage === maxPage - 1 ? 'none' : 'initial',
                    backgroundColor: currentPage === maxPage - 1 ? '#F2F2F2' : '#78C6E7',
                    '&: hover ':
                        currentPage === maxPage - 1
                            ? {}
                            : {
                                  backgroundColor: '#007DC0',
                                  '& > *': {
                                      color: '#fff',
                                  },
                              },
                }}
                justifyContent="center"
                alignItems="center"
                onClick={() => {
                    const url = generateURLWithQueryParams(basePath, {
                        ...(searhParams as any),
                        ['page']: (currentPage + 2).toString(),
                    });

                    router.replace(url);
                }}
            >
                <KeyboardArrowLeftRoundedIcon
                    sx={{
                        color: currentPage === maxPage - 1 ? '#AFAFAF' : '#fff',
                        transform: 'rotate(180deg)',
                    }}
                />
            </Stack>
        </Stack>
    );
};
