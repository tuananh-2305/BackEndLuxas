import ImageNextjs from '@/components/common/image';
import KeyboardArrowDownIcon from '@mui/icons-material/KeyboardArrowDown';
import { ListItemText, MenuItem, Popover, Stack, Typography } from '@mui/material';
import * as React from 'react';
import { useState } from 'react';

export interface ISelectTypeDataOptionProps {
    onChange: (v: any) => void;
}

export default function SelectTypeDataOption(props: ISelectTypeDataOptionProps) {
    const { onChange } = props;
    const [anchorEl3, setAnchorEl3] = React.useState<HTMLButtonElement | null>(null);
    const open = Boolean(anchorEl3);
    const [option, setOption] = useState<'ALL' | 'Members' | 'Authentications' | 'MemberVehicles'>(
        'ALL'
    );
    const id = open ? 'simple-popover' : undefined;
    return (
        <>
            <Stack
                aria-describedby={id}
                onClick={(event: any) => setAnchorEl3(event.currentTarget)}
                sx={{
                    height: '40px',
                    padding: { md: '0 10px', lg: '0 20px' },
                    background: anchorEl3 == null ? '#fff' : '#F4FAFE',
                    alignItems: 'center',
                    justifyContent: 'center',
                    borderRadius: '6px',
                    cursor: 'pointer',
                    border: '1px solid #007DC0',
                    transition: 'all 0.35s ease-in-out',
                }}
                direction={'row'}
            >
                <Typography
                    sx={{
                        minWidth: '150px',
                        fontSize: { md: '12px', lg: '14px' },
                    }}
                >
                    {option == 'ALL'
                        ? 'Tất cả'
                        : option == 'Members'
                        ? 'Thông tin khách hàng'
                        : option == 'MemberVehicles'
                        ? 'Thông tin phương tiện'
                        : 'Thông tin thẻ tháng'}
                </Typography>
                <KeyboardArrowDownIcon
                    sx={{
                        width: '24px',
                        height: '24px',
                        transform: anchorEl3 == null ? 'rotate(0deg)' : 'rotate(-180deg)',
                        transition: 'all 0.35s ease-in-out',
                    }}
                />
            </Stack>
            <Popover
                id={id}
                open={open}
                anchorEl={anchorEl3}
                onClose={() => setAnchorEl3(null)}
                anchorOrigin={{
                    vertical: 'bottom',
                    horizontal: 'left',
                }}
                sx={{ mt: '10px' }}
            >
                {renderOption('Tất cả', 'ALL')}
                {renderOption('Thông tin khách hàng', 'Members')}
                {renderOption('Thông tin phương tiện', 'MemberVehicles')}
                {renderOption('Thông tin thẻ tháng', 'Authentications')}
            </Popover>
        </>
    );

    function renderOption(
        lable: string,
        value: 'ALL' | 'Members' | 'Authentications' | 'MemberVehicles'
    ) {
        return (
            <MenuItem
                onClick={() => {
                    setOption(value), setAnchorEl3(null);
                    onChange(value);
                }}
                selected={option == value}
                sx={{
                    '&.Mui-selected': {
                        backgroundColor: '#F4FAFE',
                        '&:hover': {
                            backgroundColor: '#F4FAFE',
                        },
                        transition: 'all .25s',
                    },
                    margin: '8px',
                    borderRadius: '6px',
                    minWidth: { md: '124px', lg: '174px' },
                    textTransform: 'capitalize',
                }}
            >
                <Typography
                    sx={{
                        fontWeight: 500,
                        fontSize: 14,
                    }}
                >
                    {lable}
                </Typography>
            </MenuItem>
        );
    }
}
