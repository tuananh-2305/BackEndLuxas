import { useAppSelector } from '@/hooks';
import { Stack, TableCell, TableHead, TableRow, Typography, useMediaQuery } from '@mui/material';
import Image from 'next/image';
interface ITableControlHead {
    isChooseAll: boolean;

    changeChooseAll: () => void;
}

export const TableControlHead = (props: ITableControlHead) => {
    const { changeChooseAll, isChooseAll } = props;
    const isMdScreen = useMediaQuery('(min-width:1350px)');
    const isSmScreen = useMediaQuery('(min-width:1350px)');

    const parkingChoose = useAppSelector((state) => state.parking.chooseDashboard);
    const profile = useAppSelector((state) => state.common.profile);

    return (
        <TableHead
            sx={{
                backgroundColor: '#E3E5E5',
                height: '40px',
                position: 'sticky',
                top: 0,
                zIndex: 2,
            }}
        >
            <TableRow>
                <TableCell align="center" sx={{ minWidth: '48px', padding: 'unset' }}>
                    {parkingChoose?.SystemRoleSetting?.Insert ||
                    parkingChoose?.SystemRoleSetting?.Update ||
                    parkingChoose?.SystemRoleSetting?.Delete ||
                    profile?.IsAdmin ||
                    profile?.IsSupperAdmin ? (
                        <Stack
                            sx={{ display: 'flex !important' }}
                            justifyContent="center"
                            alignItems="center"
                        >
                            <Stack
                                sx={{
                                    width: '16px',
                                    height: '16px',
                                    borderRadius: '4px',
                                    backgroundColor: isChooseAll ? '#007DC0' : '#fff',
                                    boxShadow:
                                        '0px 0px 0px 1px rgba(70, 79, 96, 0.16), 0px 1px 1px 0px rgba(0, 0, 0, 0.10)',
                                    cursor: 'pointer',
                                }}
                                justifyContent="center"
                                alignItems="center"
                                onClick={() => {
                                    changeChooseAll();
                                }}
                            >
                                <Image
                                    src="/icons/checked-white.svg"
                                    width={9}
                                    height={6}
                                    alt="checked"
                                />
                            </Stack>
                        </Stack>
                    ) : (
                        <></>
                    )}
                </TableCell>

                <TableCell align="center" sx={{ minWidth: '40px', padding: 'unset' }}>
                    <Typography
                        sx={{
                            color: '#55595D',
                            fontSize: '14px',
                            fontStyle: 'normal',
                            fontWeight: 500,
                            lineHeight: 'normal',
                        }}
                    >
                        #
                    </Typography>
                </TableCell>
                <TableCell
                    align="left"
                    sx={{
                        minWidth: '120px',
                        paddingLeft: '0px 0px 0px 16px',
                    }}
                >
                    <Typography
                        sx={{
                            color: '#55595D',
                            fontSize: '14px',
                            fontStyle: 'normal',
                            fontWeight: '500',
                            lineHeight: 'normal',
                        }}
                    >
                        BIỂN SỐ XE
                    </Typography>
                </TableCell>
                <TableCell
                    align="left"
                    sx={{
                        minWidth: '90px',
                        paddingLeft: '0px 0px 0px 16px',
                    }}
                >
                    <Typography
                        sx={{
                            color: '#55595D',
                            fontSize: '14px',
                            fontStyle: 'normal',
                            fontWeight: '500',
                            lineHeight: 'normal',
                        }}
                    >
                        LOẠI XE
                    </Typography>
                </TableCell>

                {isMdScreen ? (
                    <TableCell
                        align="left"
                        sx={{ minWidth: '100px', paddingLeft: '0px 0px 0px 16px' }}
                    >
                        <Typography
                            sx={{
                                color: '#55595D',
                                fontSize: '14px',
                                fontStyle: 'normal',
                                fontWeight: '500',
                                lineHeight: 'normal',
                            }}
                        >
                            HÃNG XE
                        </Typography>
                    </TableCell>
                ) : (
                    <></>
                )}

                <TableCell
                    align="left"
                    sx={{
                        minWidth: '100px',
                        paddingLeft: '0px 0px 0px 16px',
                    }}
                >
                    <Typography
                        sx={{
                            color: '#55595D',
                            fontSize: '14px',
                            fontStyle: 'normal',
                            fontWeight: '500',
                            lineHeight: 'normal',
                        }}
                    >
                        MÀU XE
                    </Typography>
                </TableCell>
                <TableCell
                    align="left"
                    sx={{
                        paddingLeft: '0px 0px 0px 16px',
                        minWidth: '200px',
                    }}
                >
                    <Typography
                        sx={{
                            color: '#55595D',
                            fontSize: '14px',
                            fontStyle: 'normal',
                            fontWeight: '500',
                            lineHeight: 'normal',
                        }}
                    >
                        KHÁCH HÀNG
                    </Typography>
                </TableCell>
                <TableCell
                    align="center"
                    sx={{
                        minWidth: '120px',
                        paddingLeft: '0px 0px 0px 16px',
                    }}
                >
                    <Stack sx={{ display: 'flex !important' }} justifyContent="center">
                        <Typography
                            sx={{
                                color: '#55595D',
                                fontSize: '14px',
                                fontStyle: 'normal',
                                fontWeight: '500',
                                lineHeight: 'normal',
                            }}
                        >
                            ĐỊA CHỈ
                        </Typography>
                    </Stack>
                </TableCell>
                {isSmScreen ? (
                    <TableCell
                        align="center"
                        sx={{
                            minWidth: '150px',
                            paddingLeft: '0px 0px 0px 16px',
                        }}
                    >
                        <Stack sx={{ display: 'flex !important' }} justifyContent="center">
                            <Typography
                                sx={{
                                    color: '#55595D',
                                    fontSize: '14px',
                                    fontStyle: 'normal',
                                    fontWeight: '500',
                                    lineHeight: 'normal',
                                }}
                            >
                                NGÀY ĐĂNG KÝ
                            </Typography>
                        </Stack>
                    </TableCell>
                ) : (
                    <></>
                )}

                <TableCell
                    align="center"
                    sx={{
                        minWidth: '150px',
                        paddingLeft: '0px 0px 0px 16px',
                    }}
                >
                    <Stack sx={{ display: 'flex !important' }} justifyContent="center">
                        <Typography
                            sx={{
                                color: '#55595D',
                                fontSize: '14px',
                                fontStyle: 'normal',
                                fontWeight: '500',
                                lineHeight: 'normal',
                            }}
                        >
                            NGÀY HẾT HẠN
                        </Typography>
                    </Stack>
                </TableCell>

                <TableCell sx={{ width: '40px', paddingLeft: '0px 0px 0px 16px' }}></TableCell>
                <TableCell sx={{ width: '60px', paddingLeft: '0px 0px 0px 16px' }}></TableCell>
            </TableRow>
        </TableHead>
    );
};
