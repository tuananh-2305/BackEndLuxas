import { formatNumber } from '@/ultis/global-func';
import KeyboardArrowRightRoundedIcon from '@mui/icons-material/KeyboardArrowRightRounded';
import MoreVertRoundedIcon from '@mui/icons-material/MoreVertRounded';
import SyncIcon from '@mui/icons-material/Sync';
import { Checkbox, Stack, TableCell, TableRow, Typography } from '@mui/material';
import Image from 'next/image';
import { IRow, MemberDetailComponent } from './member-detail';
import { RowActionComponent } from './row-action';
import { useMemo } from 'react';
import { useAppSelector } from '@/hooks';

const BACKEND_DOMAIN = process.env.NEXT_PUBLIC_SERVER_PARKING_DOMAIN;
interface ITableControlMemberRowComponent {
    item: any;
    index: number;
    isExpland: boolean;
    isChoose: boolean;
    changeQuickEditId: () => void;
    changeExpland: (id: string) => void;
    changeChoose: (id: string) => void;
    isEdit: boolean;
    reload: () => void;
}

export const TableControlMemberRowComponent = (props: ITableControlMemberRowComponent) => {
    const {
        item,
        index,
        changeExpland,
        isExpland,
        changeChoose,
        isChoose,
        changeQuickEditId,
        reload,
    } = props;

    const generatorTime = () => {
        const time = new Date(item.CreatedAt);
        return `${formatNumber(time.getDate())}/${formatNumber(time.getMonth() + 1)}/${formatNumber(
            time.getFullYear()
        )}`;
    };

    const parkingChoose = useAppSelector((state) => state.parking.chooseDashboard);
    const profile = useAppSelector((state) => state.common.profile);
    const dataTransform = useMemo((): IRow[] => {
        return item.CardAndVehicle.map((value: any): IRow => {
            const result: IRow = {
                member: {
                    name: item.Name,
                    image: item.Avatar,
                    address: item.address,
                    type: item.MemberTypeId.Name,
                },
                vehicel: {
                    ID: value.MemberVehicleId,
                    plateNumber: value.PlateNumber,
                    brand: value.Brand,
                    color: value.Color,
                    endDate: value.ExpirationDate,
                    startDate: value.CreatedAt,
                    type: value.Type,
                },
                card: {
                    ID: value.AuthenticationId,
                    numberInSide: value.CardNumber,
                    numberOutSide: value.IdCard,
                },
            };

            return result;
        });
    }, [item.Avatar, item.CardAndVehicle, item.MemberTypeId.Name, item.Name, item.address]);

    return (
        <>
            <TableRow
                sx={{
                    backgroundColor: () => {
                        if (isExpland) {
                            return '#78C6E7';
                        } else {
                            if (isChoose) {
                                return '#DAF2FF';
                            } else {
                                return '#fff';
                            }
                        }
                    },
                    border: '1px solid #E3E5E5 !important',
                    transition: 'all ease .3s',
                    // boxSizing: 'border-box',
                    '&:hover ':
                        isExpland || isChoose
                            ? {}
                            : {
                                  backgroundColor: '#DAF2FF',
                              },
                }}
            >
                <TableCell
                    align="center"
                    sx={{
                        width: '48px',
                        padding: 'unset',
                        position: 'relative',
                        '&:before ': isExpland
                            ? {
                                  content: '""',
                                  borderRadius: '0px 4px 4px 0px',
                                  backgroundColor: '#007DC0',
                                  top: 0,
                                  bottom: 0,
                                  width: '3px',
                                  left: 0,
                                  position: 'absolute',
                              }
                            : {},
                    }}
                >
                    {parkingChoose?.SystemRoleSetting?.Insert ||
                    parkingChoose?.SystemRoleSetting?.Update ||
                    parkingChoose?.SystemRoleSetting?.Delete ||
                    profile?.IsAdmin ||
                    profile?.IsSupperAdmin ? (
                        <Stack
                            sx={{ display: 'flex !important' }}
                            justifyContent="center"
                            alignItems="center"
                        >
                            <Stack
                                sx={{
                                    width: '16px',
                                    height: '16px',
                                    borderRadius: '4px',
                                    backgroundColor: isChoose ? '#007DC0' : '#fff',
                                    boxShadow:
                                        '0px 0px 0px 1px rgba(70, 79, 96, 0.16), 0px 1px 1px 0px rgba(0, 0, 0, 0.10)',
                                    cursor: 'pointer',
                                }}
                                justifyContent="center"
                                alignItems="center"
                                onClick={() => {
                                    changeChoose(item.ID);
                                }}
                            >
                                <Image
                                    src="/icons/checked-white.svg"
                                    width={9}
                                    height={6}
                                    alt="checked"
                                />
                            </Stack>
                        </Stack>
                    ) : (
                        <></>
                    )}
                </TableCell>

                <TableCell align="center" sx={{ width: '40px', padding: 'unset' }}>
                    <Stack
                        sx={{
                            border: '1px solid',
                            borderColor: isExpland ? '#fff' : '#808080',
                            borderRadius: '50%',
                            width: '20px',
                            height: '20px',
                            cursor: 'pointer',
                            rotate: isExpland ? '90deg' : '0deg',
                            transition: 'all ease .3s',
                        }}
                        justifyContent="center"
                        alignItems="center"
                        onClick={() => changeExpland(item.ID)}
                    >
                        <KeyboardArrowRightRoundedIcon
                            sx={{
                                fontSize: '16px',
                                color: isExpland ? '#fff' : '#808080',
                            }}
                        />
                    </Stack>
                </TableCell>
                <TableCell align="center" sx={{ width: '40px', padding: 'unset' }}>
                    <Typography
                        sx={{
                            color: isExpland ? '#fff' : '#323232',
                            fontSize: { xs: '14px', md: '16px' },
                            fontStyle: 'normal',
                            fontWeight: 400,
                            lineHeight: '20px',
                            width: '100%',
                            wordBreak: 'break-word',
                        }}
                    >
                        {index}
                    </Typography>
                </TableCell>
                <TableCell
                    align="left"
                    sx={{
                        width: {
                            // xs: 'calc(100% - 1048px)',
                            lg: 'unset',
                        },
                        paddingLeft: '0px 0px 0px 16px',
                    }}
                >
                    <Stack direction="row" alignItems="center" sx={{ gap: '8px' }}>
                        <Stack sx={{ position: 'relative' }}>
                            <Stack
                                sx={{
                                    position: 'relative',
                                    width: { xs: '28px', lg: '34px' },
                                    height: { xs: '28px', lg: '34px' },
                                }}
                            >
                                <Image
                                    src={
                                        item.Avatar
                                            ? BACKEND_DOMAIN + item.Avatar
                                            : '/static/avatar/user.PNG'
                                    }
                                    style={{
                                        objectFit: 'cover',
                                        borderRadius: '50%',
                                        border: '2px solid #CDD2D1',
                                    }}
                                    fill
                                    alt="photo"
                                />
                            </Stack>

                            <Stack
                                sx={{
                                    width: '10px',
                                    height: '10px',
                                    backgroundColor: '#008E47',
                                    border: '2px solid #CDD2D1',
                                    borderRadius: '50%',
                                    position: 'absolute',
                                    bottom: 0,
                                    right: 0,
                                }}
                            />
                        </Stack>

                        <Typography
                            sx={{
                                fontSize: { xs: '13px', lg: '14px' },
                                fontStyle: 'normal',
                                fontWeight: '500',
                                lineHeight: 'normal',
                                width: '100%',
                                wordBreak: 'break-word',
                                color: isExpland ? '#fff' : '#323232',
                            }}
                        >
                            {item.Name}
                        </Typography>
                    </Stack>
                </TableCell>
                <TableCell
                    align="left"
                    sx={{
                        // width: { xs: '200px', lg: 'unset' },
                        paddingLeft: '0px 0px 0px 16px',
                    }}
                >
                    <Typography
                        sx={{
                            color: isExpland ? '#fff' : '#323232',
                            fontSize: { xs: '13px', lg: '14px' },
                            fontStyle: 'normal',
                            fontWeight: '500',
                            lineHeight: 'normal',
                            width: '100%',
                            wordBreak: 'break-word',
                        }}
                    >
                        {item.MemberTypeId.Name}
                    </Typography>
                </TableCell>
                <TableCell
                    align="left"
                    sx={{
                        // width: { xs: '160px', lg: 'unset' },
                        paddingLeft: '0px 0px 0px 16px',
                    }}
                >
                    <Typography
                        sx={{
                            color: isExpland ? '#fff' : '#323232',
                            fontSize: { xs: '13px', lg: '14px' },
                            fontStyle: 'normal',
                            fontWeight: '500',
                            lineHeight: 'normal',
                            width: '100%',
                            wordBreak: 'break-word',
                        }}
                    >
                        {item.Address ? item.Address : 'Không có'}
                    </Typography>
                </TableCell>
                <TableCell
                    align="left"
                    sx={{
                        // width: { xs: '150px', lg: 'unset' },
                        display: { xs: 'none', lg: 'table-cell' },
                        paddingLeft: '0px 0px 0px 16px',
                    }}
                >
                    <Typography
                        sx={{
                            color: isExpland ? '#fff' : '#323232',
                            fontSize: { xs: '13px', lg: '14px' },
                            fontStyle: 'normal',
                            fontWeight: '500',
                            lineHeight: 'normal',
                            width: '100%',
                            wordBreak: 'break-word',
                        }}
                    >
                        {generatorTime()}
                    </Typography>
                </TableCell>
                <TableCell
                    align="center"
                    sx={{
                        // width: { xs: '130px', lg: 'unset' },
                        paddingLeft: '0px 0px 0px 16px',
                    }}
                >
                    <Typography
                        sx={{
                            color: isExpland ? '#fff' : '#323232',
                            fontSize: { xs: '13px', lg: '14px' },
                            fontStyle: 'normal',
                            fontWeight: '500',
                            lineHeight: 'normal',
                            width: '100%',
                            wordBreak: 'break-word',
                        }}
                    >
                        {item.CountAuthentication}
                    </Typography>
                </TableCell>
                <TableCell
                    align="center"
                    sx={{
                        // width: { xs: '160px', lg: 'unset' },
                        paddingLeft: '0px 0px 0px 16px',
                    }}
                >
                    <Stack
                        sx={{
                            width: '30px',
                            height: '30px',
                            gap: '10px',
                            borderRadius: '4px',
                            border: '1px solid  #F2F2F2',
                            backgroundColor: '#FFF',
                            margin: '0px auto',
                            cursor: 'pointer',
                            transition: 'all ease .3s',
                            position: 'relative',
                            '& > div ': {
                                transition: 'all ease .3s',
                                backgroundColor: '#fff',
                            },
                            '&:hover': {
                                backgroundColor: '#007DC0',
                                '&:hover ': {
                                    '& > div ': {
                                        opacity: 1,
                                        visibility: 'visible',
                                    },
                                },
                            },
                        }}
                        justifyContent="center"
                        alignItems="center"
                    >
                        <Typography
                            sx={{
                                color: '#323232',
                                fontSize: { xs: '13px', lg: '14px' },
                                fontStyle: 'normal',
                                fontWeight: '500',
                                lineHeight: 'normal',
                                width: '100%',
                                wordBreak: 'break-word',
                                '&:hover': {
                                    color: '#fff',
                                },
                            }}
                        >
                            {item.CountVehicle.Total}
                        </Typography>
                        {item.CountVehicle.Detail.length !== 0 ? (
                            <Stack
                                sx={{
                                    width: '10px',
                                    height: '10px',
                                    clipPath: 'polygon(100% 0, 0 50%, 100% 100%);',
                                    position: 'absolute',
                                    left: 'calc(100% + 22px)',
                                    zIndex: 10,
                                    opacity: 0,
                                    visibility: 'hidden',
                                }}
                            />
                        ) : (
                            <></>
                        )}

                        {item.CountVehicle.Detail.length !== 0 ? (
                            <Stack
                                sx={{
                                    position: 'absolute',
                                    left: 'calc(100% + 28px)',
                                    gap: '2px',
                                    padding: '8px 12px',
                                    zIndex: 10,
                                    borderRadius: '10px',
                                    opacity: 0,
                                    visibility: 'hidden',
                                }}
                            >
                                {item.CountVehicle.Detail.map(
                                    (v: { name: string; total: string }, k: number) => {
                                        return (
                                            <Stack
                                                key={`${v.name}-${k}`}
                                                direction="row"
                                                sx={{ whiteSpace: 'nowrap', gap: '6px' }}
                                                alignItems="center"
                                                justifyContent="center"
                                            >
                                                <Typography
                                                    sx={{
                                                        color: '#007DC0',
                                                        fontSize: '11px',
                                                        fontStyle: 'normal',
                                                        fontWeight: 600,
                                                        lineHeight: 'normal',
                                                    }}
                                                >
                                                    {v.total}
                                                </Typography>
                                                <Typography
                                                    sx={{
                                                        color: '#55595D',
                                                        fontSize: '11px',
                                                        fontStyle: 'normal',
                                                        fontWeight: 400,
                                                        lineHeight: '140%',
                                                    }}
                                                >
                                                    {v.name}
                                                </Typography>
                                            </Stack>
                                        );
                                    }
                                )}
                            </Stack>
                        ) : (
                            <></>
                        )}
                    </Stack>
                </TableCell>
                <TableCell sx={{ width: '40px', paddingLeft: '0px 0px 0px 16px' }}>
                    <Stack
                        sx={{ display: 'flex !important', width: '100%' }}
                        justifyContent="center"
                        alignItems="center"
                    >
                        {item.IsDelete | item.IsInsert | item.IsUpdate ? (
                            <SyncIcon
                                sx={{
                                    transform: 'scaleY(-1) rotate(-45deg)',
                                    color: isExpland ? '#007DC0' : '#CDD2D1',
                                    transition: 'all ease .5s',
                                    '&:hover ': !isExpland
                                        ? {
                                              color: '#808080',
                                          }
                                        : {},
                                }}
                            />
                        ) : (
                            <></>
                        )}
                    </Stack>
                </TableCell>
                <RowActionComponent
                    isExpland={isExpland}
                    reload={reload}
                    item={item}
                    changeQuickEditId={changeQuickEditId}
                />
            </TableRow>

            <MemberDetailComponent isExpland={isExpland} data={dataTransform} reload={reload} />
        </>
    );
};
