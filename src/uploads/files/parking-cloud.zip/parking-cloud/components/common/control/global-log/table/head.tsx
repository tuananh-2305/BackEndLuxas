import { TableCell, TableHead, TableRow, Typography } from '@mui/material';
interface ITableHeadGlobalLog {
    isExplandAll: boolean;

    changeExpladAll: () => void;
}

export const TableHeadGlobalLog = (props: ITableHeadGlobalLog) => {
    const { changeExpladAll, isExplandAll } = props;

    return (
        <TableHead
            sx={{
                backgroundColor: '#E3E5E5',
                height: '40px',
                position: 'sticky',
                top: -1,
                zIndex: 1,
            }}
        >
            <TableRow>
                <TableCell align="center" sx={{ width: '40px', padding: 'unset' }}>
                    <Typography
                        sx={{
                            color: '#55595D',
                            fontSize: '14px',
                            fontStyle: 'normal',
                            fontWeight: 500,
                            lineHeight: 'normal',
                        }}
                    >
                        #
                    </Typography>
                </TableCell>
                <TableCell
                    align="left"
                    sx={{
                        paddingLeft: '0px 0px 0px 16px',
                    }}
                >
                    <Typography
                        sx={{
                            color: '#55595D',
                            fontSize: '14px',
                            fontStyle: 'normal',
                            fontWeight: '500',
                            lineHeight: 'normal',
                        }}
                    >
                        LOẠI
                    </Typography>
                </TableCell>
                <TableCell
                    align="left"
                    sx={{
                        width: { xs: '200px', lg: 'unset' },
                        paddingLeft: '16px',
                    }}
                >
                    <Typography
                        sx={{
                            color: '#55595D',
                            fontSize: '14px',
                            fontStyle: 'normal',
                            fontWeight: '500',
                            lineHeight: 'normal',
                        }}
                    >
                        MÔ TẢ
                    </Typography>
                </TableCell>
                <TableCell
                    align="left"
                    sx={{ width: { xs: '160px', lg: 'unset' }, paddingLeft: '0px 0px 0px 16px' }}
                >
                    <Typography
                        sx={{
                            color: '#55595D',
                            fontSize: '14px',
                            fontStyle: 'normal',
                            fontWeight: '500',
                            lineHeight: 'normal',
                        }}
                    >
                        KHÁCH HÀNG
                    </Typography>
                </TableCell>
                <TableCell
                    align="left"
                    sx={{
                        // width: { xs: '150px', lg: 'unset' },
                        paddingLeft: '0px 0px 0px 16px',
                    }}
                >
                    <Typography
                        sx={{
                            color: '#55595D',
                            fontSize: '14px',
                            fontStyle: 'normal',
                            fontWeight: '500',
                            lineHeight: 'normal',
                        }}
                    >
                        THỜI GIAN THỰC HIỆN
                    </Typography>
                </TableCell>
                <TableCell
                    align="left"
                    sx={{
                        // width: { xs: '130px', lg: 'unset' },
                        paddingLeft: '0px 0px 0px 16px',
                    }}
                >
                    <Typography
                        sx={{
                            color: '#55595D',
                            fontSize: '14px',
                            fontStyle: 'normal',
                            fontWeight: '500',
                            lineHeight: 'normal',
                        }}
                    >
                        THỰC HIỆN BỞI TÀI KHOẢN
                    </Typography>
                </TableCell>
            </TableRow>
        </TableHead>
    );
};
