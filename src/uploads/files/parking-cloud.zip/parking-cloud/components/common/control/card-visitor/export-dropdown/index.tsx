import { cardApi } from '@/api/card-api';
import { memberApi } from '@/api/member-api';
import { useAppDispatch, useAppSelector } from '@/hooks';
import { showSnackbarWithClose } from '@/hooks/useSnackbarWithClose';
import { setLoadingGlobal } from '@/redux/index';
import { handleCallApiImport, handleDownloadFile } from '@/ultis/global-func';
import { Stack, Typography } from '@mui/material';
import Image from 'next/image';
import { useState } from 'react';
const BACKEND_DOMAIN = process.env.NEXT_PUBLIC_SERVER_PARKING_DOMAIN;

const CASE_ACTIVE = [
    // { key: 'import', display: 'nhập dữ liệu' },
    { key: 'export', display: 'xuất dữ liệu' },
    // { key: 'file', display: 'tải file mẫu' },
];

interface IExportDropdownComponent {
    reload: () => void;
}

export const ExportDropdownComponent = (props: IExportDropdownComponent) => {
    const { reload } = props;

    const [active, setActive] = useState(false);
    const [caseActive, setCaseActive] = useState<'import' | 'export' | 'file'>('export');

    const [openDialogNotifyImport, setOpenDialogNotifyImport] = useState(false);
    const [dataNotify, setDataNotify] = useState<any[]>([]);

    const parkingChoose = useAppSelector((state) => state.parking.chooseDashboard);
    const dispatch = useAppDispatch();

    const handleDownload = () => {
        if (parkingChoose?.ID) {
            cardApi
                .downloadCardGuest(parkingChoose?.ID)
                .then((res) => {
                    const url = `${BACKEND_DOMAIN}${res.data}`;
                    // window.open(url);
                    handleDownloadFile(url);
                })
                .catch((error) => {
                    if (Array.isArray(error?.response?.data?.message)) {
                        error?.response?.data?.message.forEach((item: any) => {
                            showSnackbarWithClose(item, {
                                variant: 'error',
                            });
                        });
                    } else {
                        showSnackbarWithClose(
                            error?.response ? error.response.data?.message : error.message,
                            {
                                variant: 'error',
                            }
                        );
                    }
                })
                .finally(() => {});
        }
    };

    const handleDownloadSampleFile = (parkingId: string) => {
        memberApi.downloadParkingMember(parkingId).then((res) => {
            const url = `${BACKEND_DOMAIN}${res.data}`;
            handleDownloadFile(url);
        });
    };

    const handleImport = (e: any) => {
        if (!parkingChoose) {
            return;
        }

        const action = setLoadingGlobal({ isLoadingGlobal: true });
        dispatch(action);
        handleCallApiImport(e, parkingChoose.ID, reload, memberApi.importParkingMember)
            .then((res) => {
                if (res && res.length > 0) {
                    setDataNotify(res);
                    setOpenDialogNotifyImport(true);
                }
            })
            .finally(() => {
                const actionEnd = setLoadingGlobal({ isLoadingGlobal: false });
                dispatch(actionEnd);
            });
    };

    return (
        <Stack
            sx={{
                width: 'fit-content',
                height: '32px',
                flexShrink: 0,
                transition: 'all ease .3s',
                backgroundColor: '#fff',
                borderRadius: '4px',
                position: 'relative',
            }}
            direction="row"
            alignItems="center"
            justifyContent="center"
        >
            <Stack
                sx={{ padding: '8px 4px', gap: '8px', marginRight: '12px' }}
                direction={'row'}
                alignItems="center"
                onClick={() => {
                    if (caseActive === 'export') {
                        handleDownload();
                    }

                    if (caseActive === 'file' && parkingChoose) {
                        handleDownloadSampleFile(parkingChoose.ID);
                    }

                    if (caseActive === 'import') {
                        if (!document.querySelector('#export-action')) {
                            const element = document.createElement('input');
                            element.id = 'export-action';
                            element.type = 'file';
                            element.accept =
                                '.csv, application/vnd.openxmlformats-officedocument.spreadsheetml.sheet, application/vnd.ms-excel';
                            element.onchange = (ev) => handleImport(ev);
                            element.click();
                        }
                    }
                }}
            >
                {caseActive === 'export' ? (
                    <Image src="/icons/import-blue.svg" width={24} height={24} alt="photo" />
                ) : (
                    <></>
                )}
                {caseActive === 'import' ? (
                    <Image src="/icons/export-blue.svg" width={16} height={16} alt="photo" />
                ) : (
                    <></>
                )}
                {caseActive === 'file' ? (
                    <Image src="/icons/file-down-blue.svg" width={20} height={20} alt="photo" />
                ) : (
                    <></>
                )}

                <Typography
                    sx={{
                        color: '#55595D',
                        fontSize: '14px',
                        fontStyle: 'normal',
                        fontWeight: 500,
                        lineHeight: 'normal',
                        cursor: 'pointer',
                        '&::first-letter': {
                            textTransform: 'capitalize',
                        },
                    }}
                >
                    {CASE_ACTIVE.find((v) => v.key === caseActive)?.display}
                </Typography>
            </Stack>

            <Stack
                sx={{
                    height: '100%',
                    aspectRatio: '1/1',
                    cursor: 'pointer',
                    transition: 'all ease .3s',
                    backgroundColor: active ? '#007DC0' : '#E3E5E5',
                    '& * ': {
                        transition: 'all ease .3s',
                    },
                }}
                justifyContent={'center'}
                alignItems="center"
                // onClick={() => setActive(!active)}
            >
                <svg
                    width="10"
                    height="8"
                    viewBox="0 0 10 8"
                    style={{ transform: active ? 'rotate(0deg)' : 'rotate(180deg)' }}
                    fill="none"
                    xmlns="http://www.w3.org/2000/svg"
                >
                    <path
                        d="M4.35996 0.969702C4.67086 0.596602 5.22626 0.571802 5.56976 0.895102L5.63996 0.969702L9.80526 5.9681C10.2369 6.486 9.90496 7.2602 9.25956 7.3295L9.16526 7.3345H0.834659C0.160459 7.3345 -0.221741 6.5839 0.138159 6.0437L0.194659 5.9681L4.35996 0.969702Z"
                        fill={active ? '#E3E5E5' : '#007DC0'}
                    />
                </svg>
            </Stack>

            <Stack
                sx={{
                    position: 'absolute',
                    width: '127px',
                    padding: '8px',
                    top: 'calc(100% + 4px)',
                    backgroundColor: '#fff',
                    zIndex: 3,
                    left: 0,
                    borderRadius: '4px',
                    transition: 'all ease .3s',
                    visibility: active ? 'visible' : 'hidden',
                    opacity: active ? 1 : 0,
                    gap: '4px',
                }}
            >
                {CASE_ACTIVE.filter((v) => v.key !== caseActive).map((c) => {
                    return (
                        <Stack
                            key={c.key}
                            sx={{
                                borderRadius: '4px',
                                padding: '4px',
                                cursor: 'pointer',
                                '&:hover ': {
                                    backgroundColor: '#F4FAFE',
                                    '& span ': { color: '#007DC0' },
                                },
                            }}
                            onClick={() => {
                                setCaseActive(c.key as any);
                                setActive(false);
                            }}
                        >
                            <Typography
                                component="span"
                                sx={{
                                    color: '#55595D',
                                    fontSize: '14px',
                                    fontStyle: 'normal',
                                    fontWeight: 400,
                                    lineHeight: '140%',
                                    '&::first-letter': {
                                        textTransform: 'capitalize',
                                    },
                                }}
                            >
                                {c.display}
                            </Typography>
                        </Stack>
                    );
                })}
            </Stack>
        </Stack>
    );
};
