interface ILayoutControlNavigationItem {
    display: string;
    url: string;
    hidden: boolean;
    icon: {
        default: string;
        active: string;
    };
}

export const LAYOUT_CONTROL_NAVIGATION_DATA: ILayoutControlNavigationItem[] = [
    {
        display: 'Khách hàng - Cư dân',
        hidden: false,
        url: '/menu/member',
        icon: { default: 'member-gray.svg', active: 'member-white.svg' },
    },
    {
        display: 'Khách hàng - Cư dân',
        hidden: true,
        url: '/settings/member/create',
        icon: { default: 'member-gray.svg', active: 'member-white.svg' },
    },
    {
        display: 'Khách hàng - Cư dân',
        hidden: true,
        url: '/menu/member/[id]',
        icon: { default: 'member-gray.svg', active: 'member-white.svg' },
    },
    {
        display: 'Thẻ tháng',
        hidden: false,
        url: '/menu/card',
        icon: { default: 'card-month-gray.svg', active: 'card-month-white.svg' },
    },
    {
        display: 'Thẻ thang máy',
        url: '/menu/elevator-card',
        hidden: false,
        icon: {
            default: 'card-elevator-gray.svg',
            active: 'card-elevator-white.svg',
        },
    },
    {
        display: 'Thẻ vãng lai',
        url: '/menu/visitor-card',
        hidden: false,
        icon: { default: 'card-guest-gray.svg', active: 'card-guest-white.svg' },
    },
    {
        display: 'Phương tiện',
        hidden: false,
        url: '/menu/vehicel',
        icon: { default: 'member-gray.svg', active: 'member-white.svg' },
    },
    {
        display: 'Lịch sử hoạt động',
        hidden: false,
        url: '/menu/global-history-log',
        icon: { default: 'histoty-gray.svg', active: 'history-white.svg' },
    },
];
