export const SEARCH_KEY: (
    | 'address'
    | 'plateno'
    | 'cardNumberInSide'
    | 'cardNumberOutSide'
    | 'name'
    | 'phone'
)[] = ['address', 'plateno', 'cardNumberInSide', 'cardNumberOutSide', 'name', 'phone'];

export const SEARCH_KEY_VALUE = {
    address: 'Địa chỉ',
    plateno: 'Biển số',
    cardNumberInSide: 'Mã thẻ trong',
    cardNumberOutSide: 'Mã thẻ ngoài',
    name: 'Tên cư dân',
    phone: 'Số điện thoại',
};
