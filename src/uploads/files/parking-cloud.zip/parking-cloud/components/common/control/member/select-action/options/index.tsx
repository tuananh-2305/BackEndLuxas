import { Stack, Typography } from '@mui/material';
import KeyboardArrowRightRoundedIcon from '@mui/icons-material/KeyboardArrowRightRounded';
import { useEffect, useState } from 'react';
import { memberApi } from '@/api/member-api';
import { useAppSelector } from '@/hooks';
import { handleDownloadFile } from '@/ultis/global-func';
import { showSnackbarWithClose } from '@/hooks/useSnackbarWithClose';
const BACKEND_DOMAIN = process.env.NEXT_PUBLIC_SERVER_PARKING_DOMAIN;

interface ISelectActionOptions {
    activex: boolean;
    idsChoose: string[];
}

export const SelectActionOptions = (props: ISelectActionOptions) => {
    const { activex, idsChoose } = props;

    const profile = useAppSelector((state) => state.common.profile);
    const parkingChoose = useAppSelector((state) => state.parking.chooseDashboard);
    const [active, setActive] = useState(false);

    useEffect(() => {
        if (!activex) {
            setActive(false);
        }
    }, [activex]);

    useEffect(() => {
        if (idsChoose.length === 0) {
            setActive(false);
        }
    }, [idsChoose]);

    const handleDownload = (key: 'ALL' | 'ELEVATOR' | 'CARDMONTH') => {
        if (!parkingChoose) {
            return;
        }

        if (idsChoose.length === 0) {
            return;
        }

        memberApi
            .exportDataForTargetMember({
                ParkingId: parkingChoose.ID,
                ListMember: idsChoose,
                Option: key,
            })
            .then(({ data }) => {
                const url = `${BACKEND_DOMAIN}${data}`;

                handleDownloadFile(url);
            })
            .catch((error) => {
                if (Array.isArray(error?.response?.data?.message)) {
                    error?.response?.data?.message.forEach((item: any) => {
                        showSnackbarWithClose(item, {
                            variant: 'error',
                        });
                    });
                } else {
                    showSnackbarWithClose(
                        error?.response ? error.response.data?.message : error.message,
                        {
                            variant: 'error',
                        }
                    );
                }
            });
        // .finally(() => {
        //     setLoadingExport(false);
        // });
    };

    return (
        <Stack
            sx={{
                width: '153px',
                padding: '6px 8px',
                gap: '10px',
                transition: 'all ease .3s',
                position: 'relative',

                '&:hover': active
                    ? {}
                    : {
                          backgroundColor: '#F4FAFE',
                      },
            }}
            direction="row"
            alignItems="center"
            justifyContent="space-between"
        >
            <Typography
                sx={{
                    color: '#55595D',
                    fontSize: '14px',
                    fontStyle: 'normal',
                    fontWeight: 500,
                    lineHeight: 'normal',
                }}
            >
                Xuất dữ liệu
            </Typography>

            <KeyboardArrowRightRoundedIcon onClick={() => setActive(!active)} />

            {active ? (
                <Stack
                    sx={{
                        position: 'absolute',
                        width: 'fit-content',
                        height: 'fit-content',
                        borderRadius: '6px',
                        backgroundColor: '#FFFFFF',
                        left: 'calc(100% + 12px)',
                        top: '-8px',
                        boxShadow: '0px 1px 10px 0px rgba(34, 34, 34, 0.10);',
                        padding: '8px',
                        gap: '8px',
                    }}
                >
                    <Stack
                        sx={{
                            padding: '8px',
                            transition: 'all ease .3s',
                            '&:hover ': {
                                backgroundColor: '#F4FAFE',
                            },
                        }}
                        onClick={() => handleDownload('ALL')}
                    >
                        <Typography
                            sx={{
                                color: '#55595D',
                                fontSize: '14px',
                                whiteSpace: 'nowrap',
                                fontStyle: 'normal',
                                fontWeight: 500,
                                lineHeight: 'normal',
                            }}
                        >
                            Xuất tất cả
                        </Typography>
                    </Stack>
                    <Stack
                        sx={{
                            padding: '8px',
                            transition: 'all ease .3s',
                            '&:hover ': {
                                backgroundColor: '#F4FAFE',
                            },
                        }}
                        onClick={() => handleDownload('CARDMONTH')}
                    >
                        <Typography
                            sx={{
                                color: '#55595D',
                                fontSize: '14px',
                                whiteSpace: 'nowrap',
                                fontStyle: 'normal',
                                fontWeight: 500,
                                lineHeight: 'normal',
                            }}
                        >
                            Xuất thẻ tháng
                        </Typography>
                    </Stack>
                    <Stack
                        sx={{
                            padding: '8px',
                            transition: 'all ease .3s',
                            '&:hover ': {
                                backgroundColor: '#F4FAFE',
                            },
                        }}
                    >
                        <Typography
                            sx={{
                                color: '#55595D',
                                fontSize: '14px',
                                whiteSpace: 'nowrap',
                                fontStyle: 'normal',
                                fontWeight: 500,
                                lineHeight: 'normal',
                            }}
                            onClick={() => handleDownload('ELEVATOR')}
                        >
                            Xuất thẻ thang máy
                        </Typography>
                    </Stack>
                </Stack>
            ) : (
                <></>
            )}
        </Stack>
    );
};
