import { Stack, Table, TableBody, TableContainer } from '@mui/material';
import { Dispatch, SetStateAction, useState } from 'react';
import { TableHeadGlobalLog } from './head';
import { TableRowGlobalLog } from './row';
import { GlobalHistoryLogModel } from '@/models/global-history-log.model';

interface IGlobalLogTable {
    data: GlobalHistoryLogModel[];
    reload: () => void;
    currentPage: number;
    idsExpland: string[];
    setIdsExpland: Dispatch<SetStateAction<string[]>>;
    w: number | undefined;
    openSearchOption: boolean;
}

export const GlobalLogTable = (props: IGlobalLogTable) => {
    const { data, currentPage, idsExpland, setIdsExpland, reload, w, openSearchOption } = props;
    w;

    const [quickEditItemId, setQuickEditItemId] = useState<any>(null);
    const isExplandAll = data.length !== 0 && idsExpland.length === data.length;

    return (
        <Stack
            sx={{
                width: '100%',
                zIndex: openSearchOption ? 0 : 2,
                overflow: 'auto',
                borderBottom: '1px solid #E3E5E5',
            }}
        >
            <TableContainer
                sx={{
                    width: '100%',
                    maxHeight: `${w || 0}px`,
                    overflowY: 'auto',
                    '&::-webkit-scrollbar': {
                        width: '4px',
                    },
                }}
            >
                <Table
                    sx={{
                        borderCollapse: 'collapse',
                    }}
                >
                    <TableHeadGlobalLog
                        isExplandAll={isExplandAll}
                        changeExpladAll={() => {
                            if (isExplandAll) {
                                setIdsExpland([]);
                            } else {
                                setIdsExpland(data.map((item) => item.ID));
                            }
                        }}
                    />

                    <TableBody
                        sx={{
                            zIndex: 0,
                            height: '100px',
                            maxHeight: '100px',
                            overflow: 'auto',
                            position: 'relative',
                            '&::-webkit-scrollbar': {
                                width: '2px',
                            },
                        }}
                    >
                        {data.map((item, index) => {
                            return (
                                <TableRowGlobalLog
                                    reload={() => reload()}
                                    key={item.ID}
                                    item={item}
                                    isEdit={quickEditItemId === item.ID}
                                    index={currentPage * 9 + index + 1}
                                    changeQuickEditId={() => {
                                        if (quickEditItemId === item.ID) {
                                            setQuickEditItemId(null);
                                        } else {
                                            setQuickEditItemId(item.ID);
                                        }
                                    }}
                                />
                            );
                        })}
                    </TableBody>
                </Table>
            </TableContainer>
        </Stack>
    );
};
