import { Stack, Table, TableBody, TableContainer } from '@mui/material';
import { Dispatch, SetStateAction, useRef, useState } from 'react';
import { TableControlCardHead } from './head';
import { TableControlCardRowComponent } from './row';
import { CardModel } from '@/models';

interface ICardControlTable {
    data: CardModel[];
    reload: () => void;
    currentPage: number;
    idsChoose: string[];
    setIdsChoose: Dispatch<SetStateAction<string[]>>;
    openSearchOption: boolean;
}

export const CardControlTable = (props: ICardControlTable) => {
    const { data, currentPage, idsChoose, setIdsChoose, reload, openSearchOption } = props;

    const [quickEditItemId, setQuickEditItemId] = useState<any>(null);
    const isChooseAll = data.length !== 0 && idsChoose.length === data.length;

    const ref = useRef<HTMLDivElement | null>(null);

    return (
        <Stack
            ref={ref}
            sx={{
                width: '100%',
                zIndex: openSearchOption ? 0 : 2,
                height: '100%',
                borderBottom: '1px solid #E3E5E5',
            }}
        >
            <TableContainer
                sx={{
                    maxHeight: `${ref.current?.clientHeight}px`,
                    '::-webkit-scrollbar-thumb': {
                        background: '#78C6E7',
                        ':hover': {
                            background: '#78C6E7',
                        },
                    },
                    ' ::-webkit-scrollbar': {
                        height: '8px',
                    },
                    height: '100%',
                }}
            >
                <Table
                    sx={{
                        borderCollapse: 'collapse',
                    }}
                >
                    <TableControlCardHead
                        isChooseAll={isChooseAll}
                        changeChooseAll={() => {
                            if (isChooseAll) {
                                setIdsChoose([]);
                            } else {
                                setIdsChoose(data.map((item) => item.ID));
                            }
                        }}
                    />

                    <TableBody
                        sx={{
                            maxHeight: `540px`,
                            zIndex: 0,
                            overflow: 'auto',
                            position: 'relative',
                            '&::-webkit-scrollbar': {
                                width: '2px',
                            },
                        }}
                    >
                        {data.map((item: CardModel, index) => {
                            return (
                                <TableControlCardRowComponent
                                    key={item.ID}
                                    index={currentPage * 9 + index + 1}
                                    data={item}
                                    isChoose={idsChoose.includes(item.ID)}
                                    changeChoose={(id: string) => {
                                        if (idsChoose.includes(id)) {
                                            setIdsChoose(idsChoose.filter((v) => v !== id));
                                        } else {
                                            setIdsChoose([...idsChoose, id]);
                                        }
                                    }}
                                    fetchData={reload}
                                />
                            );
                        })}
                    </TableBody>
                </Table>
            </TableContainer>
        </Stack>
    );
};
