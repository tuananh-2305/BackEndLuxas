export type SearchKeyCard =
    | 'address'
    | 'plateNumber'
    | 'cardNumber'
    | 'idCard'
    | 'name'
    | 'phone'
    | 'unset';

export const SEARCH_KEY: SearchKeyCard[] = [
    'cardNumber',
    'idCard',
    'plateNumber',
    'address',
    'name',
    'phone',
    'unset',
];

export const SEARCH_KEY_VALUE = {
    cardNumber: 'Mã thẻ trong',
    idCard: 'Mã thẻ ngoài',
    address: 'Địa chỉ',
    plateNumber: 'Biển số',
    name: 'Tên cư dân',
    phone: 'Số điện thoại',
};
