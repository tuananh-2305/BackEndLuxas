import { historyInOutApi, memberApi } from '@/api/index';
import { useAppSelector } from '@/hooks';
import { Stack, Typography } from '@mui/material';
import { useEffect, useMemo, useState } from 'react';
import Image from 'next/image';
import { TableCheckCard } from './table-check';
import { showSnackbarWithClose } from '@/hooks/useSnackbarWithClose';
interface IRemoveAllMemberComfirmDialog {
    close: () => void;
    reload: () => void;
    totalCard: number;
    listMemberParkingId: string[];
    totalVehicel: number;
    membersChoose: any[];
}

export const RemoveAllMemberComfirmDialog = (props: IRemoveAllMemberComfirmDialog) => {
    const { close, membersChoose, reload, totalVehicel, totalCard, listMemberParkingId } = props;

    const [check, setCheck] = useState<string[]>([]);
    const parkingChoose = useAppSelector((state) => state.parking.chooseDashboard);

    const memberCardAndVehicel = useMemo(() => {
        return membersChoose.reduce((oldValue, currentValue) => {
            return [...oldValue, ...currentValue.CardAndVehicle];
        }, []);
    }, [membersChoose]);

    useEffect(() => {
        if (parkingChoose && memberCardAndVehicel.length !== 0) {
            const keys = memberCardAndVehicel.map((v: any) => v.CardNumber as string);

            historyInOutApi
                .checkByCardNumberAndParkingId({
                    ParkingId: parkingChoose.ID,
                    Data: keys,
                })
                .then((res) => setCheck(res.data));
        }
    }, [memberCardAndVehicel, parkingChoose]);

    const handleDelete = () => {
        if (listMemberParkingId.length === 0) {
            showSnackbarWithClose('Không có id member parking', { variant: 'error' });
            return;
        }

        if (!parkingChoose) {
            return;
        }

        memberApi
            .removeMoreMember({
                ListMemberParkingId: listMemberParkingId,
                ParkingId: parkingChoose.ID,
            })
            .then((res) => {
                if (res.data) {
                    showSnackbarWithClose('Xóa thành công', { variant: 'success' });
                    close();
                    reload();
                }
            })
            .catch((err) => {
                if (Array.isArray(err?.response?.data?.message)) {
                    err?.response?.data?.message.forEach((item: any) => {
                        showSnackbarWithClose(item, {
                            variant: 'error',
                        });
                    });
                } else {
                    showSnackbarWithClose(
                        err?.response ? err.response.data?.message : err.message,
                        {
                            variant: 'error',
                        }
                    );
                }
            });
    };

    return (
        <Stack
            sx={{
                position: 'fixed',
                width: '100vw',
                height: '100vh',
                top: 0,
                left: 0,
                zIndex: 40,
                cursor: 'default',
            }}
            alignItems="center"
            justifyContent="center"
        >
            <Stack
                sx={{
                    width: '100vw',
                    height: '100vh',
                    top: 0,
                    left: 0,
                    backgroundColor: '#55595D20',
                    position: 'absolute',
                    zIndex: 13,
                }}
                onClick={() => close()}
            />

            <Stack
                sx={{
                    width: 'fit-content',
                    height: 'fit-content',
                    borderRadius: '11px',
                    background: '#FFF',
                    zIndex: 14,
                    padding: '32px',
                }}
                alignItems="center"
            >
                <Stack sx={{ gap: '8px' }}>
                    <Image src="/icons/trash-red-comfirm.svg" width={115} height={89} alt="test" />
                    <Typography
                        sx={{
                            color: '#323232',
                            fontSize: '18px',
                            fontStyle: 'normal',
                            fontWeight: 500,
                            lineHeight: '24px',
                        }}
                    >
                        Xóa cư dân
                    </Typography>
                </Stack>
                <Stack sx={{ gap: '5px', pt: '32px' }} alignItems="center">
                    <Stack direction="row" sx={{ gap: '4px' }}>
                        <Typography
                            sx={{
                                color: '#AFAFAF',
                                fontSize: '16px',
                                fontStyle: 'normal',
                                fontWeight: 400,
                                lineHeight: '20px',
                            }}
                        >
                            Số khách hàng :
                        </Typography>
                        <Typography
                            sx={{
                                color: '#323232',
                                fontSize: '16px',
                                fontStyle: 'normal',
                                fontWeight: 500,
                                lineHeight: 'normal',
                            }}
                        >
                            {membersChoose.length}
                        </Typography>
                    </Stack>
                    <Stack direction="row" sx={{ gap: '8px' }} alignItems="center">
                        <Stack direction="row" alignItems="center">
                            <Typography
                                sx={{
                                    color: '#AFAFAF',
                                    fontSize: '14px',
                                    fontStyle: 'normal',
                                    fontWeight: 400,
                                    lineHeight: '140%',
                                }}
                            >
                                Số thẻ:
                            </Typography>
                            <Typography
                                sx={{
                                    color: '#007DC0',
                                    textAlign: 'center',
                                    fontSize: '14px',
                                    fontStyle: 'normal',
                                    fontWeight: 500,
                                    lineHeight: 'normal',
                                }}
                            >
                                {totalCard}
                            </Typography>
                        </Stack>

                        <Stack sx={{ width: '2px', height: '15px', background: '#D9D9D9' }} />

                        <Stack direction="row" alignItems="center">
                            <Typography
                                sx={{
                                    color: '#AFAFAF',
                                    fontSize: '14px',
                                    fontStyle: 'normal',
                                    fontWeight: 400,
                                    lineHeight: '140%',
                                }}
                            >
                                Số phương tiện:
                            </Typography>
                            <Typography
                                sx={{
                                    color: '#007DC0',
                                    textAlign: 'center',
                                    fontSize: '14px',
                                    fontStyle: 'normal',
                                    fontWeight: 500,
                                    lineHeight: 'normal',
                                }}
                            >
                                {totalVehicel}
                            </Typography>
                        </Stack>
                    </Stack>
                </Stack>
                <TableCheckCard CardAndVehicle={memberCardAndVehicel} CardNumberInParking={check} />

                {check.length === 0 ? (
                    <Stack sx={{ gap: '4px' }} alignItems="center">
                        <Stack
                            direction="row"
                            sx={{ alignItems: 'center', gap: '4px', marginTop: '32px' }}
                        >
                            <Typography
                                sx={{
                                    color: '#323232',
                                    fontSize: '16px',
                                    fontStyle: 'normal',
                                    fontWeight: 500,
                                    lineHeight: 'normal',
                                }}
                            >
                                Bạn chắc chắn xóa không?
                            </Typography>
                        </Stack>

                        <Typography
                            sx={{
                                color: '#55595D',
                                fontSize: '14px',
                                fontStyle: 'normal',
                                fontWeight: 400,
                                lineHeight: '140%',
                            }}
                        >
                            Vui lòng đưa xe ra khỏi bãi để có thể xóa dữ liệu
                        </Typography>
                    </Stack>
                ) : (
                    <Stack sx={{ gap: '4px' }} alignItems="center">
                        <Stack
                            direction="row"
                            sx={{ alignItems: 'center', gap: '4px', marginTop: '32px' }}
                        >
                            <Typography
                                sx={{
                                    color: '#007DC0',
                                    fontSize: '16px',
                                    fontStyle: 'normal',
                                    fontWeight: 500,
                                    lineHeight: 'normal',
                                }}
                            >
                                {check.length}
                            </Typography>
                            <Typography
                                sx={{
                                    color: '#323232',
                                    fontSize: '16px',
                                    fontStyle: 'normal',
                                    fontWeight: 500,
                                    lineHeight: 'normal',
                                }}
                            >
                                phương tiện còn trong bãi.
                            </Typography>
                        </Stack>

                        <Typography
                            sx={{
                                color: '#55595D',
                                fontSize: '14px',
                                fontStyle: 'normal',
                                fontWeight: 400,
                                lineHeight: '140%',
                            }}
                        >
                            Vui lòng đưa xe ra khỏi bãi để có thể xóa dữ liệu
                        </Typography>
                    </Stack>
                )}

                {check.length === 0 ? (
                    <Stack direction="row" sx={{ gap: '16px', marginTop: '24px' }}>
                        <Stack
                            sx={{
                                cursor: 'pointer',
                                width: '140px',
                                height: '40px',
                                justifyContent: 'center',
                                alignItems: 'center',
                                borderRadius: '6px',
                                border: '1px solid  #E3E5E5',
                            }}
                            onClick={() => close()}
                        >
                            <Typography>Không</Typography>
                        </Stack>
                        <Stack
                            sx={{
                                cursor: 'pointer',
                                width: '140px',
                                height: '40px',
                                justifyContent: 'center',
                                alignItems: 'center',
                                borderRadius: '6px',
                                backgroundColor: '#E42727',
                            }}
                            onClick={() => handleDelete()}
                        >
                            <Typography
                                sx={{
                                    color: '#FFF',
                                    fontSize: '14px',
                                    fontStyle: 'normal',
                                    fontWeight: 500,
                                    lineHeight: 'normal',
                                }}
                            >
                                Có
                            </Typography>
                        </Stack>
                    </Stack>
                ) : (
                    <></>
                )}
            </Stack>
        </Stack>
    );
};
