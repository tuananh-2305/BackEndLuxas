import { Stack, Typography } from '@mui/material';
import Image from 'next/image';
import SearchIcon from '@mui/icons-material/Search';
import CancelRoundedIcon from '@mui/icons-material/CancelRounded';
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { MemberControlSearchOption } from './search-options';
import { useSearchParams, useRouter, usePathname } from 'next/navigation';
import { SEARCH_KEY, SEARCH_KEY_VALUE } from './data.mocks';
import { FilterMemberChipList } from './chip-list';
import { generateURLWithQueryParams } from '@/ultis/global-func';
import { LocalStoreControl } from '@/hooks/local-storage';
import { FilterComponents } from '@/components/common';

interface ISearchParamns {
    page: string | null;
    address: string | null;
    name: string | null;
    phone: string | null;
    cardNumberOutSide: string | null;
    plateno: string | null;
    cardNumberInSide: string | null;
}

const localStoreControl = new LocalStoreControl();
interface IControlMemberFilterBox {
    openSearchOption: boolean;
    setOpenSearchOption: (v: boolean) => void;
    setIsHistorySearch: (v: boolean) => void;
}
export const ControlMemberFilterBox = (props: IControlMemberFilterBox) => {
    const { openSearchOption, setOpenSearchOption, setIsHistorySearch } = props;

    const searchParamAction = useSearchParams();
    const router = useRouter();
    const pathname = usePathname();

    const searhParams: ISearchParamns = useMemo(() => {
        let result: any = {};
        if (searchParamAction.get('page')) {
            result['page'] = searchParamAction.get('page');
        }
        if (searchParamAction.get('address')) {
            result['address'] = searchParamAction.get('address');
        }
        if (searchParamAction.get('cardNumberInSide')) {
            result['cardNumberInSide'] = searchParamAction.get('cardNumberInSide');
        }
        if (searchParamAction.get('cardNumberOutSide')) {
            result['cardNumberOutSide'] = searchParamAction.get('cardNumberOutSide');
        }
        if (searchParamAction.get('name')) {
            result['name'] = searchParamAction.get('name');
        }
        if (searchParamAction.get('phone')) {
            result['phone'] = searchParamAction.get('phone');
        }
        if (searchParamAction.get('plateno')) {
            result['plateno'] = searchParamAction.get('plateno');
        }

        return result;
    }, [searchParamAction]);

    const isHaveSearchData = useCallback(() => {
        return Boolean(
            searhParams.address ||
                searhParams.name ||
                searhParams.phone ||
                searhParams.plateno ||
                searhParams.cardNumberInSide ||
                searhParams.cardNumberOutSide
        );
    }, [
        searhParams.address,
        searhParams.cardNumberInSide,
        searhParams.cardNumberOutSide,
        searhParams.name,
        searhParams.phone,
        searhParams.plateno,
    ]);

    const [searchCurrentcase, setSearchCurrentcase] = useState<
        | 'address'
        | 'plateno'
        | 'cardNumberInSide'
        | 'cardNumberOutSide'
        | 'name'
        | 'phone'
        | 'unset'
    >(!isHaveSearchData() ? 'address' : 'unset');

    const [searchCurrentValue, setSearchCurrentValue] = useState<string>('');
    const [historySearch, setHistorySearch] = useState<string[]>([]);

    const ref = useRef<HTMLDivElement | null>(null);
    const inputRef = useRef<HTMLInputElement | null>(null);
    const boxRef = useRef<HTMLDivElement | null>(null);

    useEffect(() => {
        if (!isHaveSearchData()) {
            setSearchCurrentcase('address');
        }
    }, [isHaveSearchData]);

    useEffect(() => {
        setIsHistorySearch(historySearch.length !== 0 && searchCurrentcase !== 'unset');
    }, [historySearch.length, searchCurrentcase, setIsHistorySearch]);
    return (
        <FilterComponents
            searchCurrentcase={searchCurrentcase}
            searhParams={searhParams}
            setSearchCurrentcase={setSearchCurrentcase}
            isHaveSearchData={isHaveSearchData}
            openSearchOption={openSearchOption}
            setOpenSearchOption={setOpenSearchOption}
            SEARCH_KEY_VALUE={SEARCH_KEY_VALUE}
            SEARCH_KEY={SEARCH_KEY}
        />
        // <Stack
        //     sx={{
        //         width: '526px',
        //         height: '46px',
        //         border: '1px solid #E3E5E5',
        //         boxSizing: 'border-box',
        //         backgroundColor: 'white',
        //         borderRadius: '8px',
        //         zIndex: -1,
        //     }}
        //     direction="row"
        //     alignItems="center"
        //     onKeyDown={(event) => {
        //         if (
        //             event.key === 'Enter' &&
        //             Boolean(searchCurrentValue) &&
        //             searchCurrentcase !== 'unset'
        //         ) {
        //             const url = generateURLWithQueryParams(pathname, {
        //                 ...searhParams,
        //                 page: 1,
        //                 [searchCurrentcase]: searchCurrentValue,
        //             } as any);

        //             router.replace(url);

        //             localStoreControl.saveMembersHistorySearch([
        //                 searchCurrentValue,
        //                 ...historySearch,
        //             ]);
        //             setSearchCurrentcase('unset');
        //             setSearchCurrentValue('');
        //             if (ref.current) {
        //                 ref.current.style.opacity = '0';
        //                 ref.current.style.visibility = 'hidden';
        //             }
        //         }
        //     }}
        //     onMouseLeave={() => {
        //         // if (ref.current) {
        //         //     ref.current.style.opacity = '0';
        //         //     ref.current.style.visibility = 'hidden';
        //         // }
        //         // if (inputRef.current) {
        //         //     inputRef.current.blur();
        //         // }
        //         // if (!isHaveSearchData()) {
        //         //     setSearchCurrentcase('address');
        //         //     setSearchCurrentValue('');
        //         // } else {
        //         //     setSearchCurrentcase('unset');
        //         //     setSearchCurrentValue('');
        //         // }
        //     }}
        // >
        //     <Stack
        //         sx={{
        //             aspectRatio: '1/1',
        //             border: '1px solid',
        //             borderRadius: '8px 0px 0px 8px',
        //             height: '46px',
        //             cursor: 'pointer',
        //             position: 'relative',
        //             transition: 'all ease .3s',
        //             borderColor: openSearchOption && !isHaveSearchData() ? '#007DC0' : '#E3E5E5',
        //             '& > div': {
        //                 transition: 'all ease .3s',
        //                 opacity: openSearchOption && !isHaveSearchData() ? 1 : 0,
        //                 visibility: openSearchOption && !isHaveSearchData() ? 'visible' : 'hidden',
        //                 zIndex: !openSearchOption ? 200 : 'unset',
        //             },
        //         }}
        //         onClick={() => {
        //             router.replace(pathname);
        //             setOpenSearchOption(!openSearchOption);
        //         }}
        //         justifyContent="center"
        //         alignItems="center"
        //     >
        //         <Image
        //             src={
        //                 openSearchOption && !isHaveSearchData()
        //                     ? '/icons/filter-blue.svg'
        //                     : '/icons/filter-gray.svg'
        //             }
        //             width={24}
        //             height={24}
        //             alt="filter"
        //         />

        //         <MemberControlSearchOption
        //             searchCurrentcase={searchCurrentcase}
        //             changeSearchCase={(key) => {
        //                 setSearchCurrentcase(key);
        //                 setSearchCurrentValue('');
        //             }}
        //             openSearchOption={openSearchOption}
        //             searchParams={searhParams}
        //             close={() => setOpenSearchOption(false)}
        //         />
        //     </Stack>

        //     <Stack
        //         direction="row"
        //         alignItems="center"
        //         sx={{
        //             position: 'relative',
        //             width: '100%',
        //             borderRadius: '0px 8px 8px 0px',
        //         }}
        //         ref={boxRef}
        //         onClick={() => inputRef.current?.focus()}
        //     >
        //         <SearchIcon style={{ margin: '10px 8px 10px 16px', color: '#E3E5E5' }} />
        //         <FilterMemberChipList searchParams={searhParams} />
        //         <Stack direction="row" sx={{ flex: 1 }}>
        //             <Typography
        //                 sx={{
        //                     marginLeft: '4px',
        //                     color: '#AFAFAF',
        //                     fontSize: '14px',
        //                     fontStyle: 'normal',
        //                     fontWeight: 400,
        //                     lineheight: '140%',
        //                     userSelect: 'none',
        //                     whiteSpace: 'nowrap',
        //                 }}
        //             >
        //                 {searchCurrentcase !== 'unset'
        //                     ? isHaveSearchData()
        //                         ? `${SEARCH_KEY_VALUE[searchCurrentcase]}`
        //                         : `Tìm kiếm trong "${SEARCH_KEY_VALUE[searchCurrentcase]}"`
        //                     : ''}
        //             </Typography>
        //             <Stack
        //                 sx={{
        //                     position: 'relative',
        //                     height: '100%',
        //                     width: '100%',
        //                     '& > div': {
        //                         transition: 'all ease .3s',
        //                         opacity: openSearchOption && isHaveSearchData() ? 1 : 0,
        //                         visibility:
        //                             openSearchOption && isHaveSearchData() ? 'visible' : 'hidden',
        //                     },
        //                 }}
        //                 alignItems="center"
        //             >
        //                 <Typography
        //                     component={'input'}
        //                     ref={inputRef}
        //                     type="text"
        //                     onClick={() => {
        //                         if (searchCurrentcase === 'unset' && isHaveSearchData()) {
        //                             setOpenSearchOption(true);
        //                         }
        //                     }}
        //                     onFocus={() => {
        //                         setHistorySearch(localStoreControl.takeMembersHistorySearh());
        //                         if (ref.current) {
        //                             ref.current.style.opacity = '1';
        //                             ref.current.style.visibility = 'visible';
        //                         }

        //                         if (boxRef.current) {
        //                             boxRef.current.style.border = '1px solid #007DC0';
        //                         }
        //                     }}
        //                     onBlur={() => {
        //                         if (boxRef.current) {
        //                             boxRef.current.style.border = '1px solid #007DC0';
        //                         }
        //                         if (boxRef.current) {
        //                             boxRef.current.style.border = '1px solid transparent';
        //                         }
        //                     }}
        //                     sx={{
        //                         flex: 1,
        //                         border: 'none',
        //                         outline: 'none',
        //                         color: '#323232',
        //                         fontSize: '16px',
        //                         fontStyle: 'normal',
        //                         padding: '0px 4px',
        //                         width: '100%',
        //                         fontWeight: 400,
        //                         lineHeight: '20px',
        //                         backgroundColor: 'transparent',
        //                     }}
        //                     value={searchCurrentValue}
        //                     onChange={(event) => {
        //                         const { value } = event.target;
        //                         if (searchCurrentcase !== 'unset') {
        //                             setSearchCurrentValue(value);
        //                         }
        //                     }}
        //                 />

        //                 <MemberControlSearchOption
        //                     searchCurrentcase={searchCurrentcase}
        //                     changeSearchCase={(key) => {
        //                         setSearchCurrentcase(key);
        //                         setSearchCurrentValue('');
        //                     }}
        //                     searchParams={searhParams}
        //                     close={() => setOpenSearchOption(false)}
        //                     openSearchOption={openSearchOption}
        //                 />
        //             </Stack>
        //         </Stack>
        //         {isHaveSearchData() ? (
        //             <CancelRoundedIcon
        //                 sx={{
        //                     transition: 'all ease .3s',
        //                     cursor: 'pointer',
        //                     fontSize: '20px',
        //                     color: '#E3E5E5',
        //                     margin: '13px 16px ',
        //                     '&:hover ': {
        //                         transition: 'all ease .3s',
        //                         color: '#323232',
        //                     },
        //                 }}
        //                 onClick={() => {
        //                     router.replace(pathname);
        //                     setSearchCurrentcase('address');
        //                     setSearchCurrentValue('');
        //                 }}
        //             />
        //         ) : (
        //             <></>
        //         )}
        //         <Stack
        //             sx={{
        //                 position: 'absolute',
        //                 height: '4px',
        //                 width: '100%',
        //                 backgroundColor: 'transparent',
        //                 top: '100% ',
        //             }}
        //         />

        //         {/* {historySearch.length !== 0 && searchCurrentcase !== 'unset' ? (
        //             <Stack
        //                 sx={{
        //                     position: 'absolute',
        //                     left: 0,
        //                     right: 0,
        //                     opacity: 0,
        //                     visibility: 'hidden',
        //                     top: 'calc(100% + 4px)',
        //                     backgroundColor: '#fff',
        //                     borderRadius: '8px',
        //                     padding: '16px',
        //                     gap: '16px',
        //                     boxShadow: '0px 4px 16px 0px rgba(0, 0, 0, 0.10)',
        //                 }}
        //                 ref={ref}
        //             >
        //                 <Typography
        //                     sx={{
        //                         color: '#AFAFAF',
        //                         fontSize: '12px',
        //                         fontStyle: 'normal',
        //                         fontWeight: 400,
        //                         lineHeight: 'normal',
        //                     }}
        //                 >
        //                     Tìm kiếm gần đây
        //                 </Typography>

        //                 <Stack
        //                     sx={{
        //                         maxWidth: '100%',
        //                         overflowX: 'auto',
        //                         '::-webkit-scrollbar ': {
        //                             height: '2px',
        //                         },
        //                     }}
        //                 >
        //                     <Stack
        //                         direction="row"
        //                         sx={{
        //                             paddingBottom: '8px',
        //                             gap: '8px',
        //                             width: '100%',
        //                             flexWrap: 'wrap',
        //                         }}
        //                     >
        //                         {historySearch.map((v, k) => {
        //                             return (
        //                                 <Typography
        //                                     key={`history-${k}`}
        //                                     sx={{
        //                                         backgroundColor: '#F4FAFE',
        //                                         padding: '4px 8px',
        //                                         gap: '8px',
        //                                         borderRadius: '4px',
        //                                         color: '#55595D',
        //                                         fontSize: '12px',
        //                                         fontStyle: 'normal',
        //                                         fontWeight: 500,
        //                                         lineHeight: 'normal',
        //                                         cursor: 'pointer',
        //                                         whiteSpace: 'nowrap',
        //                                     }}
        //                                     onClick={() => {
        //                                         const url = generateURLWithQueryParams(pathname, {
        //                                             ...searhParams,
        //                                             page: 1,
        //                                             [searchCurrentcase]: v,
        //                                         } as any);

        //                                         router.replace(url);

        //                                         localStoreControl.saveMembersHistorySearch([
        //                                             v,
        //                                             ...historySearch,
        //                                         ]);

        //                                         setSearchCurrentcase('unset');
        //                                         setSearchCurrentValue('');

        //                                         if (ref.current) {
        //                                             ref.current.style.opacity = '0';
        //                                             ref.current.style.visibility = 'hidden';
        //                                         }
        //                                     }}
        //                                 >
        //                                     {v}
        //                                 </Typography>
        //                             );
        //                         })}
        //                     </Stack>
        //                 </Stack>
        //             </Stack>
        //         ) : (
        //             <></>
        //         )} */}
        //     </Stack>
        // </Stack>
    );
};
