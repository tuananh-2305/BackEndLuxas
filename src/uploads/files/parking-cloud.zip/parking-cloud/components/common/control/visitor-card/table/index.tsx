import { Stack, Table, TableBody, TableContainer } from '@mui/material';
import { Dispatch, SetStateAction, useRef } from 'react';

import { VehicleModel } from '@/models/vehicle.model';
import { TableControlHead } from './head';
import { TableControlRow } from './row';

interface IControlTable {
    data: VehicleModel[];
    reload: () => void;
    currentPage: number;
    idsChoose: string[];
    setIdsChoose: Dispatch<SetStateAction<string[]>>;
}

export const ControlTable = (props: IControlTable) => {
    const { data, currentPage, idsChoose, setIdsChoose, reload } = props;

    const isChooseAll = data.length !== 0 && idsChoose.length === data.length;

    const ref = useRef<HTMLDivElement | null>(null);

    return (
        <Stack ref={ref} sx={{ width: '100%', height: '100%', borderBottom: '1px solid #E3E5E5' }}>
            <TableContainer
                sx={{
                    maxHeight: `${ref.current?.clientHeight}px`,
                    '&::-webkit-scrollbar': {
                        width: '4px',
                    },
                }}
            >
                <Table
                    sx={{
                        borderCollapse: 'collapse',
                    }}
                >
                    <TableControlHead
                        isChooseAll={isChooseAll}
                        changeChooseAll={() => {
                            if (isChooseAll) {
                                setIdsChoose([]);
                            } else {
                                setIdsChoose(data.map((item) => item.ID));
                            }
                        }}
                    />

                    <TableBody
                        sx={{
                            maxHeight: `540px`,
                            overflow: 'auto',
                            position: 'relative',
                            '&::-webkit-scrollbar': {
                                width: '2px',
                            },
                        }}
                    >
                        {data.map((item: VehicleModel, index) => {
                            return (
                                <TableControlRow
                                    index={currentPage * 9 + index + 1}
                                    data={item}
                                    isChoose={idsChoose.includes(item.ID)}
                                    changeChoose={(id: string) => {
                                        if (idsChoose.includes(id)) {
                                            setIdsChoose(idsChoose.filter((v) => v !== id));
                                        } else {
                                            setIdsChoose([...idsChoose, id]);
                                        }
                                    }}
                                />
                            );
                        })}
                    </TableBody>
                </Table>
            </TableContainer>
        </Stack>
    );
};
