import { historyInOutApi } from '@/api/history-in-out-api';
import { useAppSelector } from '@/hooks';
import { Stack, Typography } from '@mui/material';
import { useEffect, useState } from 'react';
import Image from 'next/image';
import { TableCheckCardOrVehicel } from './table-check';
import { memberVehicleApi } from '@/api/member-vehicle-api';
import { showSnackbarWithClose } from '@/hooks/useSnackbarWithClose';
import { cardApi } from '@/api/card-api';

export interface IRow {
    member: {
        image: string | null;
        name: string;
        address: string;
        type: string;
    };
    card: {
        ID: string;
        numberInSide: string;
        numberOutSide: string;
        isCardElevator?: boolean;
    } | null;
    vehicel: {
        ID: string;
        plateNumber: string;
        type: string;
        brand: string;
        color: string;
        startDate: string;
        endDate: string;
    } | null;
}

interface IComfirmRemoveCard {
    memberVehicelCardData: IRow;
    caseRemove: 'card' | 'vehicel';
    close: () => void;
    reload: () => void;
}
export const ComfirmRemoveCardOrVehicel = (props: IComfirmRemoveCard) => {
    const { close, memberVehicelCardData, reload, caseRemove } = props;

    const [isOnParking, setIsOnParking] = useState<boolean | 'unset'>(false);
    const rolekey = useAppSelector((state) => state.common.roleKey);
    const parkingChoose = useAppSelector((state) => state.parking.chooseDashboard);

    useEffect(() => {
        if (!memberVehicelCardData?.card?.numberInSide) {
            return;
        }

        if (!parkingChoose) {
            return;
        }

        historyInOutApi
            .checkByCardNumberAndParkingId({
                ParkingId: parkingChoose.ID,
                Data: [memberVehicelCardData.card.numberInSide],
            })
            .then((res) => {
                const { data } = res;
                if (data.length === 0) {
                    setIsOnParking(false);
                } else {
                    setIsOnParking(true);
                }
            });
    }, [memberVehicelCardData?.card?.numberInSide, parkingChoose]);

    const handleDeleteVehicel = () => {
        if (!memberVehicelCardData.vehicel || !parkingChoose) {
            return;
        }

        memberVehicleApi
            .deleteMultiple({
                ParkingId: parkingChoose.ID,
                ListID: [memberVehicelCardData.vehicel.ID],
            })
            .then((res) => {
                const { data } = res;
                if (data.length === 0) {
                    showSnackbarWithClose('Xóa phương tiện thành công', {
                        variant: 'success',
                    });

                    reload();
                    close();
                } else {
                    data.forEach((element: any) => {
                        showSnackbarWithClose(element.Error, {
                            variant: 'error',
                        });
                    });
                }
            })
            .catch((err) => {
                if (Array.isArray(err?.response?.data?.message)) {
                    err?.response?.data?.message.forEach((item: any) => {
                        showSnackbarWithClose(item, {
                            variant: 'error',
                        });
                    });
                } else {
                    showSnackbarWithClose(
                        err?.response ? err.response.data?.message : err.message,
                        {
                            variant: 'error',
                        }
                    );
                }
            });
    };

    const handleDeleteCard = () => {
        if (!memberVehicelCardData.card) {
            return;
        }

        if (!parkingChoose) {
            return;
        }

        cardApi
            .removeMutipleCard(parkingChoose.ID, [memberVehicelCardData.card.ID])
            .then((res) => {
                const { data } = res;

                if (data.length === 0) {
                    showSnackbarWithClose('Xóa thẻ thành công', {
                        variant: 'success',
                    });

                    reload();
                    close();
                } else {
                    data.forEach((element: any) => {
                        showSnackbarWithClose(element.Error, {
                            variant: 'error',
                        });
                    });
                }

                // reload();
                // showSnackbarWithClose('Xóa thành công', { variant: 'success' });
            })
            .catch((err) => {
                if (Array.isArray(err?.response?.data?.message)) {
                    err?.response?.data?.message.forEach((item: any) => {
                        showSnackbarWithClose(item, {
                            variant: 'error',
                        });
                    });
                } else {
                    showSnackbarWithClose(
                        err?.response ? err.response.data?.message : err.message,
                        {
                            variant: 'error',
                        }
                    );
                }
            });
    };

    const keylist = rolekey.map((v): { value: string | boolean; key: string } => {
        if (v.KeySettingId.IsValue) {
            return {
                key: v.KeySettingId.KeyWord,
                value: v.Value,
            };
        } else {
            return {
                key: v.KeySettingId.KeyWord,
                value: v.IsUse,
            };
        }
    });

    return (
        <Stack
            sx={{
                position: 'fixed',
                width: '100vw',
                display: 'flex !important',
                height: '100vh',
                top: 0,
                left: 0,
                zIndex: 12,
                cursor: 'default',
            }}
            alignItems="center"
            justifyContent="center"
        >
            <Stack
                sx={{
                    width: '100%',
                    height: '100%',
                    backgroundColor: '#55595D20',
                    position: 'absolute',
                    display: 'flex !important',
                    zIndex: 13,
                }}
                onClick={() => close()}
            />

            <Stack
                sx={{
                    width: 'fit-content',
                    height: 'fit-content',
                    borderRadius: '11px',
                    background: '#FFF',
                    zIndex: 14,
                    display: 'flex !important',
                    padding: '32px',
                }}
                alignItems="center"
            >
                <Stack sx={{ gap: '8px', display: 'flex !important' }} alignItems="center">
                    <Image
                        src={
                            !isOnParking
                                ? '/icons/trash-red-rounded.svg'
                                : '/icons/warning-polygon.svg'
                        }
                        width={60}
                        height={60}
                        alt="test"
                    />

                    {isOnParking ? (
                        <Typography
                            sx={{
                                color: '#323232',
                                fontSize: '20px',
                                fontStyle: 'normal',
                                fontWeight: 600,
                                lineWeight: 'normal',
                            }}
                        >
                            Vui lòng đưa xe ra khỏi bãi để xóa dữ liệu
                        </Typography>
                    ) : (
                        <Typography
                            sx={{
                                color: '#323232',
                                fontSize: '20px',
                                fontStyle: 'normal',
                                fontWeight: 600,
                                lineWeight: 'normal',
                            }}
                        >
                            Bạn có chắc chắn xóa thẻ này?
                        </Typography>
                    )}

                    {isOnParking ? (
                        <Typography
                            sx={{
                                color: '#55595D',
                                fontSize: '16px',
                                fontStyle: 'normal',
                                fontWeight: 400,
                                lineHeight: 'normal',
                            }}
                        >
                            Có phương tiện còn trong bãi
                        </Typography>
                    ) : (
                        <Typography
                            sx={{
                                color: '#55595D',
                                fontSize: '16px',
                                fontStyle: 'normal',
                                fontWeight: 400,
                                lineHeight: 'normal',
                            }}
                        >
                            Sau khi xóa, dữ liệu sẽ được lưu trữ trong vòng 30 ngày.
                        </Typography>
                    )}
                </Stack>

                {caseRemove === 'vehicel' ? (
                    <Stack
                        alignItems="center"
                        sx={{ marginTop: '32px', gap: '8px', display: 'flex !important' }}
                        direction="row"
                    >
                        <Typography
                            component="span"
                            sx={{
                                color: '#AFAFAF',
                                fontSize: '16px',
                                fontStyle: 'normal',
                                fontWeight: 400,
                                lineHeight: '20px',
                            }}
                        >
                            Biển số:
                        </Typography>
                        <Typography
                            component="span"
                            sx={{
                                color: '#55595D',
                                fontSize: '16px',
                                fontStyle: 'normal',
                                fontWeight: 500,
                                lineHeight: 'normal',
                            }}
                        >
                            {memberVehicelCardData.vehicel?.plateNumber
                                ? memberVehicelCardData.vehicel?.plateNumber
                                : 'Không có'}
                        </Typography>
                    </Stack>
                ) : (
                    <></>
                )}

                {caseRemove === 'card' ? (
                    <Stack
                        direction="row"
                        sx={{ gap: '4px', marginTop: '32px', display: 'flex !important' }}
                        justifyContent="center"
                        alignItems="center"
                    >
                        <Typography
                            sx={{
                                color: '#AFAFAF',
                                fontSize: '16px',
                                fontStyle: 'normal',
                                fontWeight: 400,
                                lineHeight: '20px',
                            }}
                        >
                            Số thẻ ngoài:
                        </Typography>
                        <Typography
                            sx={{
                                color: '#323232',
                                fontSize: '16px',
                                fontStyle: 'normal',
                                fontWeight: 500,
                                lineHeight: 'normal',
                            }}
                        >
                            {memberVehicelCardData.card?.numberInSide}
                        </Typography>
                        <Stack sx={{ width: '1px', height: '15px', background: '#D9D9D9' }} />

                        {memberVehicelCardData.vehicel?.ID ? (
                            <Typography
                                sx={{
                                    color: '#007DC0',
                                    fontSize: '14px',
                                    fontStyle: 'normal',
                                    fontWeight: 400,
                                    lineHeight: '140%',
                                }}
                            >
                                Có phương tiện liên kết
                            </Typography>
                        ) : (
                            <Stack
                                direction="row"
                                sx={{ gap: '4px', display: 'flex !important' }}
                                alignItems="center"
                            >
                                <Typography
                                    sx={{
                                        color: '#AFAFAF',
                                        fontSize: '16px',
                                        fontStyle: 'normal',
                                        fontWeight: 400,
                                        lineHeight: '20px',
                                    }}
                                >
                                    Loại thẻ:
                                </Typography>
                                <Typography>
                                    {memberVehicelCardData?.card?.isCardElevator
                                        ? 'Thẻ thang máy'
                                        : 'Thẻ tháng'}
                                </Typography>
                            </Stack>
                        )}
                    </Stack>
                ) : (
                    <></>
                )}

                {!memberVehicelCardData.vehicel?.ID && caseRemove == 'vehicel' ? (
                    <Typography
                        sx={{
                            marginTop: '8px',
                            color: '#007DC0',
                            fontSize: '14px',
                            fontStyle: 'normal',
                            fontWeight: 400,
                            lineHeight: '140%',
                        }}
                    >
                        Không có phương tiện liên kết
                    </Typography>
                ) : (
                    <></>
                )}

                {isOnParking !== 'unset' && memberVehicelCardData.vehicel?.ID ? (
                    <TableCheckCardOrVehicel
                        item={memberVehicelCardData}
                        caseRemove={caseRemove}
                        isOnParking={isOnParking}
                    />
                ) : (
                    <Typography
                        sx={{
                            color: '#007DC0',
                            fontSize: '14px',
                            fontStyle: 'normal',
                            fontWeight: 400,
                            lineHeight: '140%',
                        }}
                    >
                        Không có phương tiện liên kết
                    </Typography>
                )}
                {/* 
                {!isOnParking ? (
                    <Stack sx={{ gap: '4px' }} alignItems="center">
                        <Stack
                            direction="row"
                            sx={{ alignItems: 'center', gap: '4px', marginTop: '32px' }}
                        >
                            <Typography
                                sx={{
                                    color: '#323232',
                                    fontSize: '16px',
                                    fontStyle: 'normal',
                                    fontWeight: 500,
                                    lineHeight: 'normal',
                                }}
                            >
                                Bạn chắc chắn xóa không?
                            </Typography>
                        </Stack>

                        <Typography
                            sx={{
                                color: '#55595D',
                                fontSize: '14px',
                                fontStyle: 'normal',
                                fontWeight: 400,
                                lineHeight: '140%',
                            }}
                        >
                            Sau khi xóa, dữ liệu sẽ được lưu trữ trên hệ thống trong vòng 30 ngày.
                        </Typography>
                    </Stack>
                ) : (
                    <Stack sx={{ gap: '4px' }} alignItems="center">
                        <Stack
                            direction="row"
                            sx={{ alignItems: 'center', gap: '4px', marginTop: '32px' }}
                        >
                            <Typography
                                sx={{
                                    color: '#007DC0',
                                    fontSize: '16px',
                                    fontStyle: 'normal',
                                    fontWeight: 500,
                                    lineHeight: 'normal',
                                }}
                            >
                                {isOnParking}
                            </Typography>
                            <Typography
                                sx={{
                                    color: '#323232',
                                    fontSize: '16px',
                                    fontStyle: 'normal',
                                    fontWeight: 500,
                                    lineHeight: 'normal',
                                }}
                            >
                                phương tiện còn trong bãi.
                            </Typography>
                        </Stack>

                        <Typography
                            sx={{
                                color: '#55595D',
                                fontSize: '14px',
                                fontStyle: 'normal',
                                fontWeight: 400,
                                lineHeight: '140%',
                            }}
                        >
                            Vui lòng đưa xe ra khỏi bãi để có thể xóa dữ liệu
                        </Typography>
                    </Stack>
                )} */}

                {!isOnParking ||
                keylist.find((v) => v.key === 'DELETE_CARD_AND_VEHICLE' && v.value) ? (
                    <Stack
                        direction="row"
                        sx={{ gap: '16px', marginTop: '24px', display: 'flex !important' }}
                    >
                        <Stack
                            sx={{
                                cursor: 'pointer',
                                width: '140px',
                                height: '40px',
                                justifyContent: 'center',
                                display: 'flex !important',
                                alignItems: 'center',
                                borderRadius: '6px',
                                border: '1px solid  #E3E5E5',
                            }}
                            onClick={() => close()}
                        >
                            <Typography>Không</Typography>
                        </Stack>
                        <Stack
                            sx={{
                                cursor: 'pointer',
                                width: '140px',
                                height: '40px',
                                justifyContent: 'center',
                                display: 'flex !important',
                                alignItems: 'center',
                                borderRadius: '6px',
                                backgroundColor: '#E42727',
                            }}
                            onClick={() => {
                                if (caseRemove === 'vehicel') {
                                    handleDeleteVehicel();
                                }

                                if (caseRemove === 'card') {
                                    handleDeleteCard();
                                }

                                close();
                            }}
                        >
                            <Typography
                                sx={{
                                    color: '#FFF',
                                    fontSize: '14px',
                                    fontStyle: 'normal',
                                    fontWeight: 500,
                                    lineHeight: 'normal',
                                }}
                            >
                                Có
                            </Typography>
                        </Stack>
                    </Stack>
                ) : (
                    <></>
                )}
            </Stack>
        </Stack>
    );
};
