import { Stack, TableCell, TableRow, Typography } from '@mui/material';
import { MemberDetailCardRow } from './row';
import { GlobalHistoryLogModel } from '@/models/global-history-log.model';

export interface IRow {
    member: {
        image: string | null;
        name: string;
        address: string;
        type: string;
    };
    card: {
        ID: string;
        numberInSide: string;
        numberOutSide: string;
    } | null;
    vehicel: {
        ID: string;
        plateNumber: string;
        type: string;
        brand: string;
        color: string;
        startDate: string;
        endDate: string;
    } | null;
}

interface IGlobalLogDetail {
    isExpland: boolean;
    data: GlobalHistoryLogModel;
    reload: () => void;
}

export const GlobalLogDetail = (props: IGlobalLogDetail) => {
    const { isExpland, data, reload } = props;

    return (
        <Stack
            sx={{
                height: isExpland ? '60px' : '0px !important',
                transition: 'all ease .3s',
                opacity: isExpland ? 1 : 0,
                visibility: isExpland ? 'visible' : 'collapse',
                '&  * ': {
                    transition: 'all ease .5s',
                    visibility: isExpland ? 'visible' : 'collapse',
                    opacity: isExpland ? 1 : 0,
                    display: isExpland ? 'table-cell' : 'none',
                },
                backgroundColor: '#DAF2FF',
                width: '100%',
            }}
        >
            <Stack
                sx={{
                    gap: '10px',
                }}
                dangerouslySetInnerHTML={{
                    __html: data?.Description,
                }}
            />
        </Stack>
    );
};
