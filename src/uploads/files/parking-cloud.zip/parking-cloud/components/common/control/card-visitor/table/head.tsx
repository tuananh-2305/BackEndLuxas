import { useAppSelector } from '@/hooks';
import { Stack, TableCell, TableHead, TableRow, Typography } from '@mui/material';
import Image from 'next/image';
interface ITableControlHead {
    isChooseAll: boolean;

    changeChooseAll: () => void;
}

export const TableControlHead = (props: ITableControlHead) => {
    const { changeChooseAll, isChooseAll } = props;

    const parkingChoose = useAppSelector((state) => state.parking.chooseDashboard);
    const profile = useAppSelector((state) => state.common.profile);

    return (
        <TableHead
            sx={{
                backgroundColor: '#E3E5E5',
                height: '40px',
                position: 'sticky',
                top: 0,
                zIndex: 2,
            }}
        >
            <TableRow>
                <TableCell align="center" sx={{ width: '48px', padding: 'unset' }}>
                    {parkingChoose?.SystemRoleSetting?.Delete ||
                    profile?.IsAdmin ||
                    profile?.IsSupperAdmin ? (
                        <Stack
                            sx={{ display: 'flex !important' }}
                            justifyContent="center"
                            alignItems="center"
                        >
                            <Stack
                                sx={{
                                    width: '16px',
                                    height: '16px',
                                    borderRadius: '4px',
                                    backgroundColor: isChooseAll ? '#007DC0' : '#fff',
                                    boxShadow:
                                        '0px 0px 0px 1px rgba(70, 79, 96, 0.16), 0px 1px 1px 0px rgba(0, 0, 0, 0.10)',
                                    cursor: 'pointer',
                                }}
                                justifyContent="center"
                                alignItems="center"
                                onClick={() => {
                                    changeChooseAll();
                                }}
                            >
                                <Image
                                    src="/icons/checked-white.svg"
                                    width={9}
                                    height={6}
                                    alt="checked"
                                />
                            </Stack>
                        </Stack>
                    ) : (
                        <></>
                    )}
                </TableCell>

                <TableCell align="center" sx={{ width: '40px', padding: 'unset' }}>
                    <Typography
                        sx={{
                            color: '#55595D',
                            fontSize: '14px',
                            fontStyle: 'normal',
                            fontWeight: 500,
                            lineHeight: 'normal',
                        }}
                    >
                        #
                    </Typography>
                </TableCell>
                <TableCell
                    align="left"
                    sx={{
                        // width: { xs: 'calc(100% - 1048px)', lg: 'unset' },
                        paddingLeft: '0px 0px 0px 16px',
                    }}
                >
                    <Typography
                        sx={{
                            color: '#55595D',
                            fontSize: '14px',
                            fontStyle: 'normal',
                            fontWeight: '500',
                            lineHeight: 'normal',
                        }}
                    >
                        SỐ THẺ NGOÀI
                    </Typography>
                </TableCell>
                <TableCell
                    align="left"
                    sx={{
                        // width: { xs: '200px', lg: 'unset' },
                        paddingLeft: '0px 0px 0px 16px',
                    }}
                >
                    <Typography
                        sx={{
                            color: '#55595D',
                            fontSize: '14px',
                            fontStyle: 'normal',
                            fontWeight: '500',
                            lineHeight: 'normal',
                        }}
                    >
                        MÃ THẺ
                    </Typography>
                </TableCell>

                <TableCell sx={{ width: '40px', paddingLeft: '0px 0px 0px 16px' }}></TableCell>
                <TableCell sx={{ width: '60px', paddingLeft: '0px 0px 0px 16px' }}></TableCell>
            </TableRow>
        </TableHead>
    );
};
