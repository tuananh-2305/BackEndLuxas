import { historyInOutApi } from '@/api/history-in-out-api';
import { useAppSelector } from '@/hooks';
import { Stack, Typography } from '@mui/material';
import { useEffect, useState } from 'react';

export interface ICardAndVehicle {
    AuthenticationId: string | null;
    Brand: string;
    CardNumber: string;
    Color: string;
    CreatedAt: string;
    ExpirationDate: string;
    IdCard: string;
    MemberVehicleId: string;
    PlateNumber: string;
    Type: string;
}

export interface ITableCheckCard {
    CardAndVehicle: ICardAndVehicle[];
    CardNumberInParking: string[];
}

export const TableCheckCard = (props: ITableCheckCard) => {
    const { CardAndVehicle, CardNumberInParking } = props;

    return (
        <Stack sx={{ width: '100%', gap: '2px', marginTop: '24px' }}>
            <Stack
                direction="row"
                sx={{ borderRadius: '4px', backgroundColor: '#F4FAFE', padding: '8px' }}
            >
                <Stack sx={{ width: '24px' }}>
                    <Typography
                        sx={{
                            color: '#323232',
                            fontSize: '14px',
                            fontStyle: 'normal',
                            fontWeight: 500,
                            lineHeight: 'normal',
                        }}
                    >
                        #
                    </Typography>
                </Stack>
                <Stack sx={{ width: '200px' }}>
                    <Typography
                        sx={{
                            color: '#323232',
                            fontSize: '14px',
                            fontStyle: 'normal',
                            fontWeight: 500,
                            lineHeight: 'normal',
                        }}
                    >
                        Số thẻ ngoài
                    </Typography>
                </Stack>
                <Stack sx={{ width: '120px' }}>
                    <Typography
                        sx={{
                            color: '#323232',
                            fontSize: '14px',
                            fontStyle: 'normal',
                            fontWeight: 500,
                            lineHeight: 'normal',
                        }}
                    >
                        Biển số
                    </Typography>
                </Stack>
                <Stack sx={{ width: '120px' }}>
                    <Typography
                        sx={{
                            color: '#323232',
                            fontSize: '14px',
                            fontStyle: 'normal',
                            fontWeight: 500,
                            lineHeight: 'normal',
                        }}
                    >
                        Loại xe
                    </Typography>
                </Stack>
                <Stack sx={{ width: '120px' }}>
                    <Typography
                        sx={{
                            color: '#323232',
                            fontSize: '14px',
                            fontStyle: 'normal',
                            fontWeight: 500,
                            lineHeight: 'normal',
                        }}
                    >
                        Tình trạng
                    </Typography>
                </Stack>
            </Stack>

            <Stack
                sx={{
                    gap: '2px',
                    maxHeight: '128px',
                    overflow: 'auto',
                    '&::-webkit-scrollbar': {
                        width: '2px',
                    },
                    '&::-webkit-scrollbar-thumb': {
                        backgroundColor: '#78C6E7',
                        borderRadius: '4px',
                    },
                }}
            >
                {CardAndVehicle.map((v, key: number) => {
                    return (
                        <Stack
                            key={v.IdCard}
                            direction="row"
                            sx={{
                                borderRadius: '4px',
                                backgroundColor: '#F8F8F8',
                                padding: '8px',
                            }}
                            alignItems="center"
                        >
                            <Stack sx={{ width: '24px' }}>
                                <Typography
                                    sx={{
                                        color: '#55595D',
                                        fontSize: '14px',
                                        fontStyle: 'normal',
                                        fontWeight: 400,
                                        lineHeight: '140%',
                                    }}
                                >
                                    {key + 1}
                                </Typography>
                            </Stack>
                            <Stack
                                sx={{
                                    width: '200px',
                                    gap: '4px',
                                    whiteSpace: 'nowrap',
                                }}
                                direction="row"
                            >
                                {v.IdCard ? (
                                    <Typography
                                        sx={{
                                            color: '#55595D',
                                            fontSize: '12px',
                                            fontStyle: 'normal',
                                            fontWeight: 400,
                                            lineHeight: '140%',
                                            whiteSpace: 'nowrap',
                                            overflow: 'hidden',
                                            textOverflow: 'ellipsis',
                                            maxWidth: '100px',
                                        }}
                                    >
                                        {v.IdCard}
                                    </Typography>
                                ) : (
                                    ''
                                )}

                                {v.IdCard ? (
                                    <Stack
                                        sx={{
                                            background: '#AFAFAF',
                                            width: '1px',
                                            height: '15px',
                                        }}
                                    />
                                ) : (
                                    <></>
                                )}

                                <Typography
                                    sx={{
                                        color: '#55595D',
                                        fontSize: '12px',
                                        fontStyle: 'normal',
                                        fontWeight: 400,
                                        lineHeight: '140%',
                                    }}
                                >
                                    {v.Type ? 'Thẻ tháng' : 'Thẻ Thang máy'}
                                </Typography>
                            </Stack>
                            <Stack sx={{ width: '120px' }}>
                                <Typography
                                    sx={{
                                        color: '#55595D',
                                        fontSize: '12px',
                                        fontStyle: 'normal',
                                        fontWeight: 400,
                                        lineHeight: '140%',
                                    }}
                                >
                                    {v.PlateNumber ? v.PlateNumber : '--'}
                                </Typography>
                            </Stack>

                            <Stack sx={{ width: '120px' }}>
                                <Typography
                                    sx={{
                                        color: '#55595D',
                                        fontSize: '14px',
                                        fontStyle: 'normal',
                                        fontWeight: 400,
                                        lineHeight: '140%',
                                    }}
                                >
                                    {v.Type ? v.Type : '--'}
                                </Typography>
                            </Stack>
                            <Stack
                                sx={{ width: '120px' }}
                                // justifyContent="center"
                                // alignItems="center"
                            >
                                <Stack
                                    sx={{
                                        padding: '4px 8px',
                                        borderRadius: '4px',
                                        background: CardNumberInParking.includes(v.CardNumber)
                                            ? '#FFE3E3'
                                            : '#BBF6D9',
                                    }}
                                >
                                    <Typography
                                        sx={{
                                            color: CardNumberInParking.includes(v.CardNumber)
                                                ? '#F95959'
                                                : '#008E47',
                                            fontSize: '14px',
                                            fontStyle: 'normal',
                                            fontWeight: 500,
                                            lineHeight: 'normal',
                                            textAlign: 'center',
                                        }}
                                    >
                                        {CardNumberInParking.includes(v.CardNumber)
                                            ? 'Còn trong bãi'
                                            : 'Đã ra khỏi bãi'}
                                    </Typography>
                                </Stack>
                            </Stack>
                        </Stack>
                    );
                })}
            </Stack>
        </Stack>
    );
};
