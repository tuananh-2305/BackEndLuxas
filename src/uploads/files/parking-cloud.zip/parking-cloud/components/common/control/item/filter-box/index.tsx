import { generateURLWithQueryParams } from '@/ultis/global-func';
import CancelRoundedIcon from '@mui/icons-material/CancelRounded';
import SearchIcon from '@mui/icons-material/Search';
import { Stack, Typography } from '@mui/material';
import Image from 'next/image';
import { usePathname, useRouter, useSearchParams } from 'next/navigation';
import { useRef, useState } from 'react';
import { FilterChipList } from './chip-list';
import { SearchOption } from './search-options';

interface IFilterComponents {
    searchCurrentcase: any;
    searhParams: any;
    setSearchCurrentcase: any;
    isHaveSearchData: any;
    openSearchOption: any;
    setOpenSearchOption: any;
    SEARCH_KEY_VALUE: any;
    SEARCH_KEY: any;
}
export const FilterComponents = (props: IFilterComponents) => {
    const {
        searchCurrentcase,
        searhParams,
        setSearchCurrentcase,
        isHaveSearchData,
        openSearchOption,
        setOpenSearchOption,
        SEARCH_KEY_VALUE,
        SEARCH_KEY,
    } = props;

    const searchParamAction = useSearchParams();
    const router = useRouter();
    const pathname = usePathname();

    const [searchCurrentValue, setSearchCurrentValue] = useState<string>('');

    const ref = useRef<HTMLDivElement | null>(null);
    const inputRef = useRef<HTMLInputElement | null>(null);
    const boxRef = useRef<HTMLDivElement | null>(null);

    return (
        <Stack
            sx={{
                width: '526px',
                height: '46px',
                border: '1px solid #E3E5E5',
                boxSizing: 'border-box',
                backgroundColor: 'white',
                borderRadius: '8px',
                zIndex: -1,
            }}
            direction="row"
            alignItems="center"
            onKeyDown={(event) => {
                if (
                    event.key === 'Enter' &&
                    Boolean(searchCurrentValue) &&
                    searchCurrentcase !== 'unset'
                ) {
                    const url = generateURLWithQueryParams(pathname, {
                        ...searhParams,
                        page: 1,
                        [searchCurrentcase]: searchCurrentValue,
                    } as any);

                    router.replace(url);

                    // localStoreControl.saveMembersHistorySearch([
                    //     searchCurrentValue,
                    //     ...historySearch,
                    // ]);
                    setSearchCurrentcase('unset');
                    setSearchCurrentValue('');
                    if (ref.current) {
                        ref.current.style.opacity = '0';
                        ref.current.style.visibility = 'hidden';
                    }
                }
            }}
            onMouseLeave={() => {
                // if (ref.current) {
                //     ref.current.style.opacity = '0';
                //     ref.current.style.visibility = 'hidden';
                // }
                // if (inputRef.current) {
                //     inputRef.current.blur();
                // }
                // if (!isHaveSearchData()) {
                //     setSearchCurrentcase('address');
                //     setSearchCurrentValue('');
                // } else {
                //     setSearchCurrentcase('unset');
                //     setSearchCurrentValue('');
                // }
            }}
        >
            <Stack
                sx={{
                    aspectRatio: '1/1',
                    border: '1px solid',
                    borderRadius: '8px 0px 0px 8px',
                    height: '46px',
                    cursor: 'pointer',
                    position: 'relative',
                    transition: 'all ease .3s',
                    borderColor: openSearchOption && !isHaveSearchData() ? '#007DC0' : '#E3E5E5',
                    '& > div': {
                        transition: 'all ease .3s',
                        opacity: openSearchOption && !isHaveSearchData() ? 1 : 0,
                        visibility: openSearchOption && !isHaveSearchData() ? 'visible' : 'hidden',
                        zIndex: !openSearchOption ? 200 : 'unset',
                    },
                }}
                onClick={() => {
                    router.replace(pathname);
                    setOpenSearchOption(!openSearchOption);
                }}
                justifyContent="center"
                alignItems="center"
            >
                <Image
                    src={
                        openSearchOption && !isHaveSearchData()
                            ? '/icons/filter-blue.svg'
                            : '/icons/filter-gray.svg'
                    }
                    width={24}
                    height={24}
                    alt="filter"
                />

                <SearchOption
                    searchCurrentcase={searchCurrentcase}
                    changeSearchCase={(key) => {
                        setSearchCurrentcase(key);
                        setSearchCurrentValue('');
                    }}
                    openSearchOption={openSearchOption}
                    searchParams={searhParams}
                    close={() => setOpenSearchOption(false)}
                    SEARCH_KEY={SEARCH_KEY}
                    SEARCH_KEY_VALUE={SEARCH_KEY_VALUE}
                />
            </Stack>

            <Stack
                direction="row"
                alignItems="center"
                sx={{
                    position: 'relative',
                    width: '100%',
                    borderRadius: '0px 8px 8px 0px',
                }}
                ref={boxRef}
                onClick={() => inputRef.current?.focus()}
            >
                <SearchIcon style={{ margin: '10px 8px 10px 16px', color: '#E3E5E5' }} />
                <FilterChipList
                    searchParams={searhParams}
                    SEARCH_KEY_VALUE={SEARCH_KEY_VALUE}
                    SEARCH_KEY={SEARCH_KEY}
                />
                <Stack direction="row" sx={{ flex: 1 }}>
                    <Typography
                        sx={{
                            marginLeft: '4px',
                            color: '#AFAFAF',
                            fontSize: '14px',
                            fontStyle: 'normal',
                            fontWeight: 400,
                            lineheight: '140%',
                            userSelect: 'none',
                            whiteSpace: 'nowrap',
                        }}
                    >
                        {searchCurrentcase !== 'unset'
                            ? isHaveSearchData()
                                ? `${SEARCH_KEY_VALUE[searchCurrentcase]}`
                                : `Tìm kiếm trong "${SEARCH_KEY_VALUE[searchCurrentcase]}"`
                            : ''}
                    </Typography>
                    <Stack
                        sx={{
                            position: 'relative',
                            height: '100%',
                            width: '100%',
                            '& > div': {
                                transition: 'all ease .3s',
                                opacity: openSearchOption && isHaveSearchData() ? 1 : 0,
                                visibility:
                                    openSearchOption && isHaveSearchData() ? 'visible' : 'hidden',
                            },
                        }}
                        alignItems="center"
                    >
                        <Typography
                            component={'input'}
                            ref={inputRef}
                            type="text"
                            onClick={() => {
                                if (searchCurrentcase === 'unset' && isHaveSearchData()) {
                                    setOpenSearchOption(true);
                                }
                            }}
                            onFocus={() => {
                                // setHistorySearch(localStoreControl.takeMembersHistorySearh());
                                if (ref.current) {
                                    ref.current.style.opacity = '1';
                                    ref.current.style.visibility = 'visible';
                                }

                                if (boxRef.current) {
                                    boxRef.current.style.border = '1px solid #007DC0';
                                }
                            }}
                            onBlur={() => {
                                if (boxRef.current) {
                                    boxRef.current.style.border = '1px solid #007DC0';
                                }
                                if (boxRef.current) {
                                    boxRef.current.style.border = '1px solid transparent';
                                }
                            }}
                            sx={{
                                flex: 1,
                                border: 'none',
                                outline: 'none',
                                color: '#323232',
                                fontSize: '16px',
                                fontStyle: 'normal',
                                padding: '0px 4px',
                                width: '100%',
                                fontWeight: 400,
                                lineHeight: '20px',
                                backgroundColor: 'transparent',
                            }}
                            value={searchCurrentValue}
                            onChange={(event) => {
                                const { value } = event.target;
                                if (searchCurrentcase !== 'unset') {
                                    setSearchCurrentValue(value);
                                }
                            }}
                        />

                        <SearchOption
                            searchCurrentcase={searchCurrentcase}
                            changeSearchCase={(key) => {
                                setSearchCurrentcase(key);
                                setSearchCurrentValue('');
                            }}
                            searchParams={searhParams}
                            close={() => setOpenSearchOption(false)}
                            openSearchOption={openSearchOption}
                            SEARCH_KEY={SEARCH_KEY}
                            SEARCH_KEY_VALUE={SEARCH_KEY_VALUE}
                        />
                    </Stack>
                </Stack>
                {isHaveSearchData() ? (
                    <CancelRoundedIcon
                        sx={{
                            transition: 'all ease .3s',
                            cursor: 'pointer',
                            fontSize: '20px',
                            color: '#E3E5E5',
                            margin: '13px 16px ',
                            '&:hover ': {
                                transition: 'all ease .3s',
                                color: '#323232',
                            },
                        }}
                        onClick={() => {
                            router.replace(pathname);
                            setSearchCurrentcase('address');
                            setSearchCurrentValue('');
                        }}
                    />
                ) : (
                    <></>
                )}
                <Stack
                    sx={{
                        position: 'absolute',
                        height: '4px',
                        width: '100%',
                        backgroundColor: 'transparent',
                        top: '100% ',
                    }}
                />

                {/* {historySearch.length !== 0 && searchCurrentcase !== 'unset' ? (
                    <Stack
                        sx={{
                            position: 'absolute',
                            left: 0,
                            right: 0,
                            opacity: 0,
                            visibility: 'hidden',
                            top: 'calc(100% + 4px)',
                            backgroundColor: '#fff',
                            borderRadius: '8px',
                            padding: '16px',
                            gap: '16px',
                            boxShadow: '0px 4px 16px 0px rgba(0, 0, 0, 0.10)',
                        }}
                        ref={ref}
                    >
                        <Typography
                            sx={{
                                color: '#AFAFAF',
                                fontSize: '12px',
                                fontStyle: 'normal',
                                fontWeight: 400,
                                lineHeight: 'normal',
                            }}
                        >
                            Tìm kiếm gần đây
                        </Typography>

                        <Stack
                            sx={{
                                maxWidth: '100%',
                                overflowX: 'auto',
                                '::-webkit-scrollbar ': {
                                    height: '2px',
                                },
                            }}
                        >
                            <Stack
                                direction="row"
                                sx={{
                                    paddingBottom: '8px',
                                    gap: '8px',
                                    width: '100%',
                                    flexWrap: 'wrap',
                                }}
                            >
                                {historySearch.map((v, k) => {
                                    return (
                                        <Typography
                                            key={`history-${k}`}
                                            sx={{
                                                backgroundColor: '#F4FAFE',
                                                padding: '4px 8px',
                                                gap: '8px',
                                                borderRadius: '4px',
                                                color: '#55595D',
                                                fontSize: '12px',
                                                fontStyle: 'normal',
                                                fontWeight: 500,
                                                lineHeight: 'normal',
                                                cursor: 'pointer',
                                                whiteSpace: 'nowrap',
                                            }}
                                            onClick={() => {
                                                const url = generateURLWithQueryParams(pathname, {
                                                    ...searhParams,
                                                    page: 1,
                                                    [searchCurrentcase]: v,
                                                } as any);

                                                router.replace(url);

                                                localStoreControl.saveMembersHistorySearch([
                                                    v,
                                                    ...historySearch,
                                                ]);

                                                setSearchCurrentcase('unset');
                                                setSearchCurrentValue('');

                                                if (ref.current) {
                                                    ref.current.style.opacity = '0';
                                                    ref.current.style.visibility = 'hidden';
                                                }
                                            }}
                                        >
                                            {v}
                                        </Typography>
                                    );
                                })}
                            </Stack>
                        </Stack>
                    </Stack>
                ) : (
                    <></>
                )} */}
            </Stack>
        </Stack>
    );
};
