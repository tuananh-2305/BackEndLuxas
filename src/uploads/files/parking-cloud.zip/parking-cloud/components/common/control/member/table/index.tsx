import { Stack, Table, TableBody, TableContainer } from '@mui/material';
import { Dispatch, MutableRefObject, SetStateAction, useMemo, useRef, useState } from 'react';
import { TableControlMemberHead } from './head';
import { TableControlMemberRowComponent } from './row';

interface IMemberControlTable {
    data: any[];
    reload: () => void;
    currentPage: number;
    idsChoose: string[];
    setIdsChoose: Dispatch<SetStateAction<string[]>>;
    idsExpland: string[];
    setIdsExpland: Dispatch<SetStateAction<string[]>>;
    // w: number | undefined;
    openSearchOption: boolean;
}

export const MemberControlTable = (props: IMemberControlTable) => {
    const {
        data,
        currentPage,
        idsChoose,
        setIdsChoose,
        idsExpland,
        setIdsExpland,
        reload,
        // w,
        openSearchOption,
    } = props;

    const [quickEditItemId, setQuickEditItemId] = useState<any>(null);
    const isChooseAll = data.length !== 0 && idsChoose.length === data.length;
    const isExplandAll = data.length !== 0 && idsExpland.length === data.length;

    // const ref = useRef<HTMLDivElement | null>(null);

    // const maxHeight = useMemo(() =>{return `${ref.current?.clientHeight}px`;}, [ref.current?.clientHeight]);

    return (
        <Stack
            sx={{
                width: '100%',
                zIndex: openSearchOption ? 0 : 2,
                overflow: 'auto',
                borderBottom: '1px solid #E3E5E5',
            }}
        >
            <TableContainer
                sx={{
                    width: '100%',
                    '&::-webkit-scrollbar': {
                        width: '4px',
                    },
                }}
            >
                <Table
                    sx={{
                        borderCollapse: 'collapse',
                    }}
                >
                    <TableControlMemberHead
                        isChooseAll={isChooseAll}
                        isExplandAll={isExplandAll}
                        changeChooseAll={() => {
                            if (isChooseAll) {
                                setIdsChoose([]);
                            } else {
                                setIdsChoose(data.map((item) => item.ID));
                            }
                        }}
                        changeExpladAll={() => {
                            if (isExplandAll) {
                                setIdsExpland([]);
                            } else {
                                setIdsExpland(data.map((item) => item.ID));
                            }
                        }}
                    />

                    <TableBody
                        sx={{
                            overflowY: 'auto',
                            maxHeight: `100px`,
                            zIndex: 0,
                            '&::-webkit-scrollbar': {
                                width: '2px',
                            },
                        }}
                    >
                        {data.map((item, index) => {
                            return (
                                <TableControlMemberRowComponent
                                    reload={() => reload()}
                                    key={item.ID}
                                    item={item}
                                    isEdit={quickEditItemId === item.ID}
                                    index={currentPage * 9 + index + 1}
                                    isExpland={idsExpland.includes(item.ID)}
                                    isChoose={idsChoose.includes(item.ID)}
                                    changeQuickEditId={() => {
                                        if (quickEditItemId === item.ID) {
                                            setQuickEditItemId(null);
                                        } else {
                                            setQuickEditItemId(item.ID);
                                        }
                                    }}
                                    changeExpland={(id: string) => {
                                        if (idsExpland.includes(id)) {
                                            setIdsExpland(idsExpland.filter((v) => v !== id));
                                        } else {
                                            setIdsExpland([...idsExpland, id]);
                                        }
                                    }}
                                    changeChoose={(id: string) => {
                                        if (idsChoose.includes(id)) {
                                            setIdsChoose(idsChoose.filter((v) => v !== id));
                                        } else {
                                            setIdsChoose([...idsChoose, id]);
                                        }
                                    }}
                                />
                            );
                        })}
                    </TableBody>
                </Table>
            </TableContainer>
        </Stack>
    );
};
