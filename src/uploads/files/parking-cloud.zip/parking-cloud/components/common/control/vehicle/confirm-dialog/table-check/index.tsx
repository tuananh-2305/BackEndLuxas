import { vehicleColor } from '@/constants/vehicle-color';
import { VehicleModel } from '@/models/vehicle.model';
import { renderVehicleColor } from '@/ultis/global-func';
import { Stack, Typography } from '@mui/material';

export interface ITableCheckVehicle {
    vehicleList: VehicleModel[];
    CardNumberInParking: string[];
}

export const TableCheckVehicle = (props: ITableCheckVehicle) => {
    const { vehicleList, CardNumberInParking } = props;

    return (
        <Stack sx={{ width: '100%', gap: '2px', marginTop: '24px' }}>
            <Stack
                direction="row"
                sx={{ borderRadius: '4px', backgroundColor: '#F4FAFE', padding: '8px' }}
            >
                <Stack sx={{ width: '24px' }}>
                    <Typography
                        sx={{
                            color: '#323232',
                            fontSize: '14px',
                            fontStyle: 'normal',
                            fontWeight: 500,
                            lineHeight: 'normal',
                        }}
                    >
                        #
                    </Typography>
                </Stack>
                <Stack sx={{ width: '100px' }}>
                    <Typography
                        sx={{
                            color: '#323232',
                            fontSize: '14px',
                            fontStyle: 'normal',
                            fontWeight: 500,
                            lineHeight: 'normal',
                        }}
                    >
                        Biển số
                    </Typography>
                </Stack>
                <Stack sx={{ width: '150px' }}>
                    <Typography
                        sx={{
                            color: '#323232',
                            fontSize: '14px',
                            fontStyle: 'normal',
                            fontWeight: 500,
                            lineHeight: 'normal',
                        }}
                    >
                        Loại xe
                    </Typography>
                </Stack>
                <Stack sx={{ width: '100px' }}>
                    <Typography
                        sx={{
                            color: '#323232',
                            fontSize: '14px',
                            fontStyle: 'normal',
                            fontWeight: 500,
                            lineHeight: 'normal',
                        }}
                    >
                        Màu sắc
                    </Typography>
                </Stack>
                <Stack sx={{ width: '120px' }}>
                    <Typography
                        sx={{
                            color: '#323232',
                            fontSize: '14px',
                            fontStyle: 'normal',
                            fontWeight: 500,
                            lineHeight: 'normal',
                        }}
                    >
                        Tình trạng
                    </Typography>
                </Stack>
            </Stack>

            <Stack
                sx={{
                    gap: '2px',
                    maxHeight: '128px',
                    overflow: 'auto',
                    '&::-webkit-scrollbar': {
                        width: '2px',
                    },
                    '&::-webkit-scrollbar-thumb': {
                        backgroundColor: '#78C6E7',
                        borderRadius: '4px',
                    },
                }}
            >
                {vehicleList.map((v, key: number) => {
                    return (
                        <Stack
                            key={v.ID}
                            direction="row"
                            sx={{
                                borderRadius: '4px',
                                backgroundColor: '#F8F8F8',
                                padding: '8px',
                            }}
                            alignItems="center"
                        >
                            <Stack sx={{ width: '24px' }}>
                                <Typography
                                    sx={{
                                        color: '#55595D',
                                        fontSize: '14px',
                                        fontStyle: 'normal',
                                        fontWeight: 400,
                                        lineHeight: '140%',
                                    }}
                                >
                                    {key + 1}
                                </Typography>
                            </Stack>
                            <Stack sx={{ width: '100px' }}>
                                <Typography
                                    sx={{
                                        color: '#55595D',
                                        fontSize: '12px',
                                        fontStyle: 'normal',
                                        fontWeight: 400,
                                        lineHeight: '140%',
                                    }}
                                >
                                    {v.PlateNumber ? v.PlateNumber : '--'}
                                </Typography>
                            </Stack>
                            <Stack sx={{ width: '150px' }}>
                                <Typography
                                    sx={{
                                        color: '#55595D',
                                        fontSize: '12px',
                                        fontStyle: 'normal',
                                        fontWeight: 400,
                                        lineHeight: '140%',
                                    }}
                                >
                                    {v.VehicleBrand ? v.VehicleBrand : '--'}
                                </Typography>
                            </Stack>

                            <Stack sx={{ width: '100px', alignItems: 'flex-start' }}>
                                <Typography
                                    sx={{
                                        color: '#55595D',
                                        fontSize: '14px',
                                        fontStyle: 'normal',
                                        fontWeight: 400,
                                        lineHeight: '140%',
                                    }}
                                >
                                    <Stack
                                        direction="row"
                                        sx={{
                                            gap: '4px',
                                            width: '100%',
                                            display: 'flex !important',
                                        }}
                                        justifyContent="center"
                                    >
                                        {renderVehicleColor(v?.VehicleColor ?? '--')
                                            .filter((v) => {
                                                const color = vehicleColor.find(
                                                    (c) => c.name === v.name
                                                );
                                                return Boolean(color);
                                            })
                                            .map((v: any) => {
                                                const color: any = vehicleColor.find(
                                                    (c) => c.name === v.name
                                                );

                                                return (
                                                    <Stack
                                                        key={color.value}
                                                        sx={{
                                                            width: '16px',
                                                            height: '16px',
                                                            borderRadius: '4px',
                                                            border: '1px solid #D0D0D0',
                                                            background: color.value,
                                                        }}
                                                    />
                                                );
                                            })}
                                    </Stack>
                                </Typography>
                            </Stack>
                            <Stack
                                sx={{ width: '120px' }}
                                // justifyContent="center"
                                // alignItems="center"
                            >
                                <Stack
                                    sx={{
                                        padding: '4px 8px',
                                        borderRadius: '4px',
                                        background: CardNumberInParking.includes(v.ID)
                                            ? '#FFE3E3'
                                            : '#BBF6D9',
                                    }}
                                >
                                    <Typography
                                        sx={{
                                            color: CardNumberInParking.includes(v.ID)
                                                ? '#F95959'
                                                : '#008E47',
                                            fontSize: '14px',
                                            fontStyle: 'normal',
                                            fontWeight: 500,
                                            lineHeight: 'normal',
                                            textAlign: 'center',
                                        }}
                                    >
                                        {CardNumberInParking.includes(v.ID)
                                            ? 'Còn trong bãi'
                                            : 'Đã ra khỏi bãi'}
                                    </Typography>
                                </Stack>
                            </Stack>
                        </Stack>
                    );
                })}
            </Stack>
        </Stack>
    );
};
