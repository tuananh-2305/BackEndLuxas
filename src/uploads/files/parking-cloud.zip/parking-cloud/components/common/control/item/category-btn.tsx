import { Stack, Typography } from '@mui/material';
import { profile } from 'console';
import * as React from 'react';

export interface ICategoryBtnProps {
    onClick?: React.MouseEventHandler<HTMLDivElement> | undefined;
    isActive?: boolean;
    text: string;
    value?: number;
}

export function CategoryBtn(props: ICategoryBtnProps) {
    const { isActive, value, text } = props;

    const displaycount = (v: number) => {
        if (v >= 1000) {
            return '1k+';
        } else {
            return v;
        }
    };
    return (
        <Stack
            sx={{
                gap: '11px',
                cursor: 'pointer',
            }}
            direction="row"
            alignItems="center"
            onClick={props.onClick}
        >
            <Typography
                component="span"
                sx={{
                    position: 'relative',
                    cursor: 'pointer',
                    color: '#55595D',
                    fontSize: '14px',
                    fontStyle: 'normal',
                    fontWeight: 500,
                    lineHeight: 'normal',
                    '&:hover ': {
                        transition: 'all ease .3s',
                        color: '#007DC0',
                    },
                    '&:after ': {
                        content: '""',
                        width: '100%',
                        height: '2px',
                        left: 0,
                        flexShrink: 0,
                        borderRadius: '1px',
                        backgroundColor: isActive ? '#007DC0' : 'transparent',
                        position: 'absolute',
                        bottom: '-10px',
                    },
                    userSelect: 'none',
                }}
            >
                {text}
            </Typography>

            <Stack
                sx={{
                    padding: '0px 6px',
                    gap: '10px',
                    borderRadius: '13px',
                    background: '#007DC0',
                    display: value ? 'flex' : 'none',
                }}
            >
                <Typography
                    sx={{
                        color: '#FFF',
                        fontSize: '10px',
                        fontStyle: 'normal',
                        fontWeight: 500,
                        lineHeight: '16px',
                        letterSpacing: '0.3px',
                        userSelect: 'none',
                    }}
                >
                    {displaycount(value ?? 0)}
                </Typography>
            </Stack>
        </Stack>
    );
}
