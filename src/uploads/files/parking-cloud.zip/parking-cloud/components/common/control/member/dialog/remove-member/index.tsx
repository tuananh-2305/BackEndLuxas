import { Stack, Typography } from '@mui/material';
import Image from 'next/image';
import { TableCheckCard } from './table-check';
import { useEffect, useState } from 'react';
import { useAppSelector } from '@/hooks';
import { historyInOutApi } from '@/api/history-in-out-api';
import { showSnackbarWithClose } from '@/hooks/useSnackbarWithClose';
import { memberApi } from '@/api/member-api';

interface IRemoveMemberComfirmDialogProps {
    item: any;
    close: () => void;
    reload: () => void;
}
export const RemoveMemberComfirmDialog = (props: IRemoveMemberComfirmDialogProps) => {
    const { close, item, reload } = props;

    const [check, setCheck] = useState<string[] | 'unset'>('unset');
    const parkingChoose = useAppSelector((state) => state.parking.chooseDashboard);
    const rolekey = useAppSelector((state) => state.common.roleKey);
    const keylist = rolekey.map((v): { value: string | boolean; key: string } => {
        if (v.KeySettingId.IsValue) {
            return {
                key: v.KeySettingId.KeyWord,
                value: v.Value,
            };
        } else {
            return {
                key: v.KeySettingId.KeyWord,
                value: v.IsUse,
            };
        }
    });

    useEffect(() => {
        if (parkingChoose && item.CardAndVehicle) {
            const keys = item.CardAndVehicle.map((v: any) => v.CardNumber as string);

            historyInOutApi
                .checkByCardNumberAndParkingId({
                    ParkingId: parkingChoose.ID,
                    Data: keys,
                })
                .then((res) => setCheck(res.data));
        }
    }, [item.CardAndVehicle, parkingChoose]);

    const handleDelete = () => {
        if (!item.MemberParkingId) {
            showSnackbarWithClose('Không có id member parking', { variant: 'error' });
            return;
        }

        if (!parkingChoose) {
            return;
        }

        memberApi
            .deleteMember(item.MemberParkingId, parkingChoose.ID)
            .then((res) => {
                if (res.data) {
                    showSnackbarWithClose('Xóa thành công', { variant: 'success' });
                    reload();
                }
            })
            .catch((err) => {
                if (Array.isArray(err?.response?.data?.message)) {
                    err?.response?.data?.message.forEach((item: any) => {
                        showSnackbarWithClose(item, {
                            variant: 'error',
                        });
                    });
                } else {
                    showSnackbarWithClose(
                        err?.response ? err.response.data?.message : err.message,
                        {
                            variant: 'error',
                        }
                    );
                }
            });
    };

    if (check === 'unset') {
        return <div>loading</div>;
    }

    return (
        <Stack
            sx={{
                position: 'fixed',
                width: '100vw',
                height: '100vh',
                display: 'flex',
                top: 0,
                left: 0,
                zIndex: 6,
                cursor: 'default',
            }}
            alignItems="center"
            justifyContent="center"
        >
            <Stack
                sx={{
                    width: '100%',
                    height: '100%',
                    backgroundColor: '#55595D20',
                    position: 'absolute',
                    zIndex: 3,
                }}
                onClick={() => close()}
            />

            <Stack
                sx={{
                    width: 'fit-content',
                    height: 'fit-content',
                    borderRadius: '11px',
                    background: '#FFF',
                    zIndex: 4,
                    padding: '32px',
                }}
                alignItems="center"
            >
                <Stack alignItems="center">
                    <Image
                        src={
                            check.length === 0
                                ? '/icons/trash-red-rounded.svg'
                                : '/icons/warning-polygon.svg'
                        }
                        width={60}
                        height={60}
                        alt="test"
                    />

                    <Typography
                        sx={{
                            color: '#323232',
                            fontSize: '18px',
                            fontStyle: 'normal',
                            fontWeight: 500,
                            lineHeight: '24px',
                            marginTop: '16px',
                            marginBottom: '6px',
                        }}
                    >
                        {check.length === 0
                            ? 'Bạn có chắc chắn xóa những khách hàng này?'
                            : 'Vui lòng đưa xe ra khỏi bãi để xóa dữ liệu'}
                    </Typography>

                    {check.length === 0 ? (
                        <Typography>
                            Sau khi xóa, dữ liệu sẽ được lưu trữ trong vòng 30 ngày.
                        </Typography>
                    ) : (
                        <Stack direction="row" sx={{ gap: '4px' }} alignItems="center">
                            <Typography
                                sx={{
                                    color: '#55595D',
                                    fontSize: '14px',
                                    fontStyle: 'normal',
                                    fontWeight: 500,
                                    lineHeight: '24px',
                                }}
                            >
                                {check.length}
                            </Typography>
                            <Typography
                                sx={{
                                    color: '#55595D',
                                    fontsize: '14px',
                                    fontStyle: 'normal',
                                    fontWeight: 400,
                                    lineHeight: '24px',
                                }}
                            >
                                phương tiện còn trong bãi
                            </Typography>
                        </Stack>
                    )}
                </Stack>

                <Stack sx={{ gap: '5px', pt: '32px' }} alignItems="center">
                    <Stack direction="row" sx={{ gap: '4px' }}>
                        <Typography
                            sx={{
                                color: '#AFAFAF',
                                fontSize: '16px',
                                fontStyle: 'normal',
                                fontWeight: 400,
                                lineHeight: '20px',
                            }}
                        >
                            Khách hàng :
                        </Typography>
                        <Typography
                            sx={{
                                color: '#55595D',
                                fontSize: '16px',
                                fontStyle: 'normal',
                                fontWeight: 500,
                                lineHeight: 'normal',
                            }}
                        >
                            {item.Name}
                        </Typography>
                    </Stack>
                    <Stack direction="row" sx={{ gap: '8px' }} alignItems="center">
                        <Stack direction="row" alignItems="center" sx={{ gap: '4px' }}>
                            <Typography
                                sx={{
                                    color: '#AFAFAF',
                                    fontSize: '14px',
                                    fontStyle: 'normal',
                                    fontWeight: 400,
                                    lineHeight: '140%',
                                }}
                            >
                                Số thẻ:
                            </Typography>
                            <Typography
                                sx={{
                                    color: '#55595D',
                                    fontSize: '14px',
                                    fontStyle: 'normal',
                                    fontWeight: 500,
                                    lineHeight: 'normal',
                                }}
                            >
                                {item.CountAuthentication}
                            </Typography>
                        </Stack>

                        <Stack sx={{ width: '2px', height: '15px', background: '#D9D9D9' }} />

                        <Stack direction="row" alignItems="center" sx={{ gap: '4px' }}>
                            <Typography
                                sx={{
                                    color: '#AFAFAF',
                                    fontSize: '14px',
                                    fontStyle: 'normal',
                                    fontWeight: 400,
                                    lineHeight: '140%',
                                }}
                            >
                                Số phương tiện:
                            </Typography>
                            <Typography
                                sx={{
                                    color: '#55595D',
                                    fontSize: '14px',
                                    fontStyle: 'normal',
                                    fontWeight: 500,
                                    lineHeight: 'normal',
                                }}
                            >
                                {item.CountVehicle.Total}
                            </Typography>
                        </Stack>
                    </Stack>
                </Stack>
                <TableCheckCard CardAndVehicle={item.CardAndVehicle} CardNumberInParking={check} />

                {check.length === 0 ? (
                    <Stack sx={{ gap: '4px' }} alignItems="center">
                        <Stack
                            direction="row"
                            sx={{ alignItems: 'center', gap: '4px', marginTop: '32px' }}
                        >
                            <Typography
                                sx={{
                                    color: '#323232',
                                    fontSize: '16px',
                                    fontStyle: 'normal',
                                    fontWeight: 500,
                                    lineHeight: 'normal',
                                }}
                            >
                                Bạn chắc chắn xóa không?
                            </Typography>
                        </Stack>

                        <Typography
                            sx={{
                                color: '#55595D',
                                fontSize: '14px',
                                fontStyle: 'normal',
                                fontWeight: 400,
                                lineHeight: '140%',
                            }}
                        >
                            Vui lòng đưa xe ra khỏi bãi để có thể xóa dữ liệu
                        </Typography>
                    </Stack>
                ) : (
                    <Stack sx={{ gap: '4px', height: '30px' }} alignItems="center"></Stack>
                )}

                {check.length === 0 ||
                keylist.find((v) => v.key === 'DELETE_CARD_AND_VEHICLE' && v.value) ? (
                    <Stack direction="row" sx={{ gap: '16px', marginTop: '24px' }}>
                        <Stack
                            sx={{
                                cursor: 'pointer',
                                width: '140px',
                                height: '40px',
                                justifyContent: 'center',
                                alignItems: 'center',
                                borderRadius: '6px',
                                border: '1px solid  #E3E5E5',
                            }}
                            onClick={() => close()}
                        >
                            <Typography>Không</Typography>
                        </Stack>
                        <Stack
                            sx={{
                                cursor: 'pointer',
                                width: '140px',
                                height: '40px',
                                justifyContent: 'center',
                                alignItems: 'center',
                                borderRadius: '6px',
                                backgroundColor: '#E42727',
                            }}
                            onClick={() => handleDelete()}
                        >
                            <Typography
                                sx={{
                                    color: '#FFF',
                                    fontSize: '14px',
                                    fontStyle: 'normal',
                                    fontWeight: 500,
                                    lineHeight: 'normal',
                                }}
                            >
                                Có
                            </Typography>
                        </Stack>
                    </Stack>
                ) : (
                    <></>
                )}
            </Stack>
        </Stack>
    );
};
