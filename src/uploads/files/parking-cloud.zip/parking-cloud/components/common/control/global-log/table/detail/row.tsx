import { vehicleColor } from '@/constants/vehicle-color';
import { formatNumber, renderVehicleColor } from '@/ultis/global-func';
import MoreVertRoundedIcon from '@mui/icons-material/MoreVertRounded';
import { Stack, TableCell, TableRow, Typography } from '@mui/material';
import Image from 'next/image';
import { useRef, useState } from 'react';

export interface IRow {
    member: {
        image: string | null;
        name: string;
        address: string;
        type: string;
    };
    card: {
        ID: string;
        numberInSide: string;
        numberOutSide: string;
    } | null;
    vehicel: {
        ID: string;
        plateNumber: string;
        type: string;
        brand: string;
        color: string;
        startDate: string;
        endDate: string;
    } | null;
}

interface IMemberDetailCardRowProps {
    isExpland: boolean;
    index: number;
    item: IRow;
    reload: () => void;
}

export const MemberDetailCardRow = (props: IMemberDetailCardRowProps) => {
    const { isExpland, index, item, reload } = props;

    const [active, setActive] = useState(false);
    const ref = useRef<HTMLDivElement | null>(null);
    const boxRef = ref?.current?.getBoundingClientRect();

    const [openLostCard, setOpenLostCard] = useState(false);
    const [openLostVehicel, setOpenLostVehicel] = useState(false);

    const [openComfirmRemoveCardOrVehicel, setOpenComfirmRemoveCardOrVehicel] = useState<
        'card' | 'vehicel' | 'unset'
    >('unset');

    const formatTime = (v: string) => {
        if (!v) {
            return 'unknow';
        } else {
            const d = new Date(v);

            return `${formatNumber(d.getDate())}/${formatNumber(d.getMonth() + 1)}/${formatNumber(
                d.getFullYear()
            )}`;
        }
    };

    return (
        <TableRow
            sx={{
                height: isExpland ? '60px' : '0px',
                transition: 'all ease .3s',
                opacity: isExpland ? 1 : 0,
                visibility: isExpland ? 'visible' : 'collapse',
                '&  * ': {
                    transition: 'all ease .5s',
                    visibility: isExpland ? 'visible' : 'collapse',
                    opacity: isExpland ? 1 : 0,
                    display: isExpland ? 'table-cell' : 'none',
                },
                backgroundColor: '#FAFDFF',
                '&:hover ': {
                    backgroundColor: '#DAF2FF',
                },
            }}
        >
            <TableCell
                align="center"
                sx={{
                    width: '48px',
                    padding: 'unset',
                    borderBottom: 'none',
                }}
            ></TableCell>
            <TableCell
                align="center"
                sx={{
                    width: '40px',
                    padding: 'unset',
                    borderBottom: 'none',
                }}
            ></TableCell>
            <TableCell
                sx={{
                    width: '40px',
                    padding: 'unset',
                    borderBottom: isExpland ? '1px solid #78C6E7' : 'none',
                }}
            >
                <Stack sx={{ width: '100%', display: 'flex !important' }} justifyContent="center">
                    <Typography
                        sx={{
                            textAlign: 'center',
                            color: '#55595D',
                            fontSize: { xs: '12px', lg: '14px' },
                            fontStyle: 'normal',
                            fontWeight: 400,
                            lineHeight: '140%',
                        }}
                    >
                        {index + 1}
                    </Typography>
                </Stack>
            </TableCell>
            <TableCell
                align="left"
                sx={{
                    // width: { xs: 'calc(100% - 1048px)', lg: 'unset' },
                    padding: '0px 0px 0px 16px',
                    borderBottom: isExpland ? '1px solid #78C6E7' : 'none',
                }}
            >
                <Stack
                    direction="row"
                    alignItems="center"
                    sx={{ width: '100%', display: 'flex !important' }}
                >
                    <Typography
                        sx={{
                            color: '#55595D',
                            fontSize: { xs: '12px', lg: '14px' },
                            fontStyle: 'normal',
                            fontWeight: 400,
                            lineHeight: '140%',
                        }}
                    >
                        {item.card?.numberOutSide ? item.card?.numberOutSide : ''}
                    </Typography>

                    {item.card?.numberOutSide ? (
                        <Stack
                            sx={{
                                width: '1px',
                                height: '15px',
                                backgroundColor: '#AFAFAF',
                                margin: '0px 4px',
                            }}
                        />
                    ) : (
                        <></>
                    )}

                    <Typography
                        sx={{
                            color: '#55595D',
                            fontSize: { xs: '12px', lg: '14px' },
                            fontStyle: 'normal',
                            fontWeight: 400,
                            lineHeight: '140%',
                        }}
                    >
                        {item.card?.numberInSide
                            ? `${item.vehicel?.type ? 'Thẻ tháng' : 'Thẻ thang máy'}`
                            : '--'}
                    </Typography>
                </Stack>
            </TableCell>
            <TableCell
                align="left"
                sx={{
                    // width: { xs: '200px', lg: 'unset' },
                    padding: '0px 0px 0px 16px',
                    borderBottom: isExpland ? '1px solid #78C6E7' : 'none',
                }}
            >
                <Typography
                    sx={{
                        color: '#55595D',
                        fontSize: { xs: '12px', lg: '14px' },
                        fontStyle: 'normal',
                        fontWeight: 400,
                        lineHeight: '140%',
                    }}
                >
                    {item.vehicel?.plateNumber ? item.vehicel?.plateNumber : '--'}
                </Typography>
            </TableCell>
            <TableCell
                align="left"
                sx={{
                    // width: { xs: '160px', lg: 'unset' },
                    padding: '0px 0px 0px 16px',
                    borderBottom: isExpland ? '1px solid #78C6E7' : 'none',
                }}
            >
                <Typography
                    sx={{
                        color: '#55595D',
                        fontSize: { xs: '12px', lg: '14px' },
                        fontStyle: 'normal',
                        fontWeight: 400,
                        lineHeight: '140%',
                    }}
                >
                    {item.vehicel?.type ? item.vehicel?.type : '--'}
                </Typography>
            </TableCell>
            <TableCell
                align="left"
                sx={{
                    // width: { xs: '150px', lg: 'unset' },
                    display: { xs: 'none', lg: 'table-cell' },
                    padding: '0px 0px 0px 16px',
                    borderBottom: isExpland ? '1px solid #78C6E7' : 'none',
                }}
            >
                <Typography
                    sx={{
                        color: '#55595D',
                        fontSize: { xs: '12px', lg: '14px' },
                        fontStyle: 'normal',
                        fontWeight: 400,
                        lineHeight: '140%',
                    }}
                >
                    {item.vehicel?.brand ? item.vehicel?.brand : '--'}
                </Typography>
            </TableCell>
            <TableCell
                align="center"
                sx={{
                    // width: { xs: '130px', lg: 'unset' },
                    padding: '0px 0px 0px 16px',
                    borderBottom: isExpland ? '1px solid #78C6E7' : 'none',
                }}
            >
                <Stack
                    direction="row"
                    sx={{ gap: '4px', width: '100%', display: 'flex !important' }}
                    justifyContent="center"
                >
                    {renderVehicleColor(item.vehicel?.color ?? '--')
                        .filter((v) => {
                            const color = vehicleColor.find((c) => c.name === v.name);
                            return Boolean(color);
                        })
                        .map((v: any) => {
                            const color: any = vehicleColor.find((c) => c.name === v.name);

                            return (
                                <Stack
                                    key={color.value}
                                    sx={{
                                        width: '16px',
                                        height: '16px',
                                        borderRadius: '4px',
                                        border: '1px solid #D0D0D0',
                                        background: color.value,
                                    }}
                                />
                            );
                        })}
                </Stack>
            </TableCell>
            <TableCell
                sx={{
                    // width: { xs: '160px', lg: 'unset' },
                    padding: '0px 0px 0px 16px',
                    borderBottom: isExpland ? '1px solid #78C6E7' : 'none',
                }}
            >
                <Stack sx={{ display: 'flex !important', width: '100%' }} justifyContent="center">
                    <Typography
                        sx={{
                            color: '#55595D',
                            fontSize: { xs: '12px', lg: '14px' },
                            fontStyle: 'normal',
                            fontWeight: 400,
                            lineHeight: '140%',
                            textAlign: 'center',
                        }}
                    >
                        {item.vehicel?.startDate ? formatTime(item.vehicel?.startDate) : '--'}
                    </Typography>
                </Stack>
            </TableCell>
            <TableCell
                sx={{
                    width: '40px',
                    padding: '0px 0px 0px 16px',
                    borderBottom: isExpland ? '1px solid #78C6E7' : 'none',
                }}
            >
                <Stack
                    sx={{ width: '100%', display: 'flex !important' }}
                    justifyContent="center"
                    alignItems="center"
                >
                    <Typography
                        sx={{
                            color: '#55595D',
                            fontSize: { xs: '12px', lg: '14px' },
                            textAlign: 'center',
                            fontStyle: 'normal',
                            fontWeight: 400,
                            lineHeight: '140%',
                        }}
                    >
                        {item.vehicel?.endDate ? formatTime(item.vehicel?.endDate) : '--'}
                    </Typography>
                </Stack>
            </TableCell>
            <TableCell
                sx={{
                    width: '60px',
                    padding: '0px 0px 0px 16px',
                    borderBottom: isExpland ? '1px solid #78C6E7' : 'none',
                }}
            >
                <Stack
                    ref={ref}
                    sx={{ display: 'flex !important', width: '32px', height: '32px' }}
                    justifyContent="center"
                    alignItems="center"
                    // justifyContent="center"
                    // alignItems="center"
                >
                    <MoreVertRoundedIcon
                        sx={{ color: '#808080', cursor: 'pointer' }}
                        onClick={() => setActive(!active)}
                    />
                </Stack>
                {active ? (
                    <Stack
                        sx={{
                            position: 'fixed',
                            width: '100vw',
                            height: '100vh',
                            top: 0,
                            left: 0,
                            zIndex: 4,
                        }}
                        onClick={() => setActive(false)}
                    />
                ) : (
                    <></>
                )}
                {active && boxRef ? (
                    <>
                        <Stack
                            sx={{
                                zIndex: 5,
                                position: 'fixed',
                                width: 'fit-content',
                                height: 'fit-content',
                                padding: '8px',
                                gap: '8px',
                                flexShrink: 0,
                                borderRadius: '6px',
                                background: '#fff',
                                boxShadow: '0px 1px 10px 0px rgba(34, 34, 34, 0.10)',
                                right: `calc(100vw - ${boxRef.x + boxRef.width}px)`,
                                top: `${boxRef.y}px`,
                            }}
                        >
                            {/* <Stack
                                sx={{
                                    flex: 1,
                                    borderRadius: '4px',
                                    paddingLeft: '8px',
                                    cursor: 'pointer',
                                    width: '100%',
                                    gap: '4px',
                                    flexWrap: 'nowrap',
                                    '&:hover ': {
                                        backgroundColor: '#F4FAFE',
                                    },
                                }}
                                direction="row"
                                alignItems="center"
                            >
                                <Image
                                    src="/icons/edit-blue.svg"
                                    width={24}
                                    height={24}
                                    alt="photo"
                                />
                                <Typography
                                    sx={{
                                        color: '#55595D',
                                        fontSize: { xs: '12px', lg: '14px' },
                                        fontStyle: 'normal',
                                        fontWeight: '500',
                                        width: '100%',
                                        lineHeight: 'normal',
                                        whiteSpace: 'nowrap',
                                        padding: '4px',
                                    }}
                                >
                                    Sửa nhanh
                                </Typography>
                            </Stack> */}
                        </Stack>
                    </>
                ) : (
                    <></>
                )}
            </TableCell>
        </TableRow>
    );
};
