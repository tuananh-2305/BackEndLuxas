import Image from 'next/image';
import { Stack, Typography } from '@mui/material';
import { useMemo } from 'react';
import { id } from 'date-fns/locale';

interface ISearchParamns {
    page: string | null;
    address: string | null;
    name: string | null;
    phone: string | null;
    cardNumberOutSide: string | null;
    plateno: string | null;
    cardNumberInSide: string | null;
}

interface ISearchOption {
    changeSearchCase: (
        key: any
        // | 'address'
        // | 'name'
        // | 'unset'
        // | 'plateno'
        // | 'cardNumberInSide'
        // | 'cardNumberOutSide'
        // | 'phone'
    ) => void;
    searchCurrentcase: any;
    // | 'address'
    // | 'plateno'
    // | 'cardNumberInSide'
    // | 'cardNumberOutSide'
    // | 'name'
    // | 'phone'
    // | 'unset';
    searchParams: ISearchParamns;
    close: () => void;
    openSearchOption: boolean;
    SEARCH_KEY: any;
    SEARCH_KEY_VALUE: any;
}

export const SearchOption = (props: ISearchOption) => {
    const {
        changeSearchCase,
        close,
        searchParams,
        searchCurrentcase,
        openSearchOption,
        SEARCH_KEY,
        SEARCH_KEY_VALUE,
    } = props;

    const keyCurrentSearch = useMemo(() => {
        const checks = Object.keys(searchParams);

        if (checks.length === 0) {
            if (searchCurrentcase === 'unset') {
                return [SEARCH_KEY[0]];
            } else {
                return [searchCurrentcase];
            }
        } else {
            if (searchCurrentcase === 'unset') {
                return checks;
            } else {
                if (checks.includes(searchCurrentcase)) {
                    return checks;
                } else {
                    return [...checks, searchCurrentcase];
                }
            }
        }
    }, [searchCurrentcase, searchParams]);

    return (
        <>
            <Stack
                sx={{
                    position: 'fixed',
                    width: '100vw',
                    height: '100vh',
                    backgroundColor: 'transparent',
                    top: 0,
                    left: 0,
                    right: 0,
                    bottom: 0,
                    zIndex: !openSearchOption ? 20000 : 2,
                }}
                onClick={() => close()}
            />
            <Stack
                sx={{
                    padding: '8px',
                    borderRadius: '8px',
                    background: '#FFF',
                    boxShadow: '0px 4px 16px 0px rgba(0, 0, 0, 0.10)',
                    position: 'absolute',
                    top: 'calc(100% + 4px)',
                    left: 0,
                    gap: '4px',
                    zIndex: 3,
                }}
            >
                {SEARCH_KEY &&
                    SEARCH_KEY.map((item: any) => {
                        return (
                            <Stack
                                key={item}
                                direction={'row'}
                                sx={{
                                    display: 'flex',
                                    width: '172px',
                                    height: '28px',
                                    padding: '2px 8px 2px 0px',
                                    gap: '25px',
                                    cursor: keyCurrentSearch.includes(item) ? 'default' : 'pointer',
                                    userSelect: keyCurrentSearch.includes(item) ? 'none' : 'auto',
                                    borderRadius: '4px',
                                    backgroundColor: keyCurrentSearch.includes(item)
                                        ? '#007DC0'
                                        : '#fff',
                                    transition: 'all ease .3s',

                                    '&:hover': keyCurrentSearch.includes(item)
                                        ? {}
                                        : {
                                              backgroundColor: '#F4FAFE',
                                          },
                                }}
                                onClick={() => {
                                    if (!keyCurrentSearch.includes(item)) {
                                        changeSearchCase(item);
                                        close();
                                    }
                                }}
                                alignItems="center"
                            >
                                <Typography
                                    sx={{
                                        color: keyCurrentSearch.includes(item) ? '#fff' : '#55595D',
                                        flex: 1,
                                        fontSize: '14px',
                                        fontStyle: 'normal',
                                        fontWeight: 400,
                                        lineHeight: '140%',
                                        padding: '4px 10px 4px 8px',
                                        flexShrink: 0,
                                    }}
                                >
                                    {SEARCH_KEY_VALUE[item]}
                                </Typography>
                                <Image
                                    src="/icons/checked-white.svg"
                                    width={14}
                                    height={14}
                                    alt="photo"
                                />
                            </Stack>
                        );
                    })}
            </Stack>
        </>
    );
};
