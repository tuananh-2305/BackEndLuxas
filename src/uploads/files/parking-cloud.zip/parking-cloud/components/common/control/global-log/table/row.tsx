import { UserInfo } from '@/components';
import { GlobalHistoryLogModel } from '@/models/global-history-log.model';
import { formatNumber } from '@/ultis/global-func';
import {
    Box,
    Collapse,
    Stack,
    Table,
    TableBody,
    TableCell,
    TableHead,
    TableRow,
    Typography,
} from '@mui/material';
import moment from 'moment';
import Image from 'next/image';
import { renderAction } from '../select-box/color';
import { useState } from 'react';
import { GlobalLogDetail } from './detail';

const BACKEND_DOMAIN = process.env.NEXT_PUBLIC_SERVER_PARKING_DOMAIN;
interface ITableRowGlobalLog {
    item: GlobalHistoryLogModel;
    index: number;
    changeQuickEditId: () => void;
    isEdit: boolean;
    reload: () => void;
}

export const TableRowGlobalLog = (props: ITableRowGlobalLog) => {
    const { item, index, changeQuickEditId, reload } = props;
    const [open, setOpen] = useState(false);

    return (
        <>
            <TableRow
                onClick={() => setOpen(!open)}
                sx={{
                    backgroundColor: () => {
                        if (open) {
                            return '#78C6E7';
                        } else {
                            return '#fff';
                        }
                    },
                    border: '1px solid #E3E5E5 !important',
                    transition: 'all ease .3s',
                    '&:hover ': open
                        ? {}
                        : {
                              backgroundColor: '#DAF2FF',
                          },
                    cursor: 'pointer',
                }}
            >
                <TableCell align="center" sx={{ width: '40px', padding: 'unset' }}>
                    <Typography
                        sx={{
                            color: open ? '#fff' : '#55595D',
                            fontSize: '14px',
                            fontStyle: 'normal',
                            fontWeight: 500,
                            lineHeight: 'normal',
                        }}
                    >
                        {index}
                    </Typography>
                </TableCell>
                <TableCell
                    align="left"
                    sx={{
                        paddingLeft: '0px 0px 0px 16px',
                        width: '150px',
                    }}
                >
                    <Stack
                        sx={{
                            display: 'flex',
                            flexDirection: 'row',
                            gap: '8px',
                            alignItems: 'center',
                        }}
                    >
                        <Image
                            src={
                                open
                                    ? renderAction(item.Action).iconPathActive
                                    : renderAction(item.Action).iconPath
                            }
                            width={24}
                            height={24}
                            style={{
                                background: open ? '#fff' : renderAction(item.Action).color,
                                padding: '5px',
                                borderRadius: '50%',
                                transition: 'all .3s',
                            }}
                            alt=""
                        />

                        <Typography
                            sx={{
                                color: open ? '#fff' : renderAction(item.Action).color,
                                fontSize: '14px',
                                fontStyle: 'normal',
                                fontWeight: '400',
                                lineHeight: 'normal',
                            }}
                        >
                            {renderAction(item.Action).text}
                        </Typography>
                    </Stack>
                </TableCell>
                <TableCell
                    align="left"
                    sx={{
                        width: { xs: '200px', lg: 'unset' },
                        paddingLeft: '16px',
                        minWidth: '200px',
                        maxWidth: '400px',
                    }}
                >
                    <Stack
                        sx={{
                            fontSize: '14px',
                            fontWeight: 400,
                            overflow: 'hidden',
                            display: '-webkit-box',
                            WebkitLineClamp: 1,
                            lineClamp: 1,
                            WebkitBoxOrient: 'vertical',
                            wordBreak: 'break-word',
                            whiteSpace: 'pre-line',
                            color: open ? '#fff' : '#55595d',
                        }}
                        dangerouslySetInnerHTML={{
                            __html: item?.Description,
                        }}
                    />
                </TableCell>
                <TableCell
                    align="left"
                    sx={{ width: { xs: '160px', lg: 'unset' }, paddingLeft: '0px 0px 0px 16px' }}
                >
                    <UserInfo
                        fullName={item?.MemberId?.Name}
                        avatar={BACKEND_DOMAIN + item?.MemberId?.Avatar}
                        textColor={open ? '#fff' : undefined}
                    />
                </TableCell>
                <TableCell
                    align="left"
                    sx={{
                        paddingLeft: '0px 0px 0px 16px',
                    }}
                >
                    <Typography
                        sx={{
                            color: open ? '#fff' : '#55595D',
                            fontSize: '14px',
                            fontStyle: 'normal',
                            fontWeight: '500',
                            lineHeight: 'normal',
                        }}
                    >
                        {moment(item.CreatedAt).format('HH:mm DD/MM/yyyy')}
                    </Typography>
                </TableCell>
                <TableCell
                    align="left"
                    sx={{
                        // width: { xs: '130px', lg: 'unset' },
                        paddingLeft: '0px 0px 0px 16px',
                    }}
                >
                    <Typography
                        sx={{
                            color: open ? '#fff' : '#55595D',
                            fontSize: '14px',
                            fontWeight: '600',
                            fontStyle: 'normal',
                            lineHeight: 'normal',
                        }}
                    >
                        {item?.UserId?.Name ?? ''}
                    </Typography>
                </TableCell>
            </TableRow>
            <TableRow>
                <TableCell
                    style={{ paddingBottom: 0, paddingTop: 0, background: '#F4FAFE' }}
                    colSpan={6}
                >
                    <Collapse in={open} timeout="auto" unmountOnExit>
                        <Box sx={{ margin: '24px 62px' }}>
                            <Stack
                                sx={{
                                    gap: '10px',
                                }}
                                dangerouslySetInnerHTML={{
                                    __html: item?.Description,
                                }}
                            />
                        </Box>
                    </Collapse>
                </TableCell>
            </TableRow>
        </>
    );
};
