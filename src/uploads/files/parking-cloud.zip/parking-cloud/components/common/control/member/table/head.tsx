import { Checkbox, Stack, TableCell, TableHead, TableRow, Typography } from '@mui/material';
import KeyboardArrowRightRoundedIcon from '@mui/icons-material/KeyboardArrowRightRounded';
import { Dispatch, SetStateAction } from 'react';
import Image from 'next/image';
import { useAppSelector } from '@/hooks';
interface ITableControlMemberHead {
    isExplandAll: boolean;
    isChooseAll: boolean;

    changeExpladAll: () => void;
    changeChooseAll: () => void;
}

export const TableControlMemberHead = (props: ITableControlMemberHead) => {
    const { changeChooseAll, changeExpladAll, isChooseAll, isExplandAll } = props;
    const parkingChoose = useAppSelector((state) => state.parking.chooseDashboard);
    const profile = useAppSelector((state) => state.common.profile);
    return (
        <TableHead
            sx={{
                backgroundColor: '#E3E5E5',
                height: '40px',
                position: 'sticky',
                top: 0,
                zIndex: 1,
            }}
        >
            <TableRow>
                <TableCell align="center" sx={{ width: '48px', padding: 'unset' }}>
                    {parkingChoose?.SystemRoleSetting?.Insert ||
                    parkingChoose?.SystemRoleSetting?.Update ||
                    parkingChoose?.SystemRoleSetting?.Delete ||
                    profile?.IsAdmin ||
                    profile?.IsSupperAdmin ? (
                        <Stack
                            sx={{ display: 'flex !important' }}
                            justifyContent="center"
                            alignItems="center"
                        >
                            <Stack
                                sx={{
                                    width: '16px',
                                    height: '16px',
                                    borderRadius: '4px',
                                    backgroundColor: isChooseAll ? '#007DC0' : '#fff',
                                    boxShadow:
                                        '0px 0px 0px 1px rgba(70, 79, 96, 0.16), 0px 1px 1px 0px rgba(0, 0, 0, 0.10)',
                                    cursor: 'pointer',
                                }}
                                justifyContent="center"
                                alignItems="center"
                                onClick={() => {
                                    changeChooseAll();
                                }}
                            >
                                <Image
                                    src="/icons/checked-white.svg"
                                    width={9}
                                    height={6}
                                    alt="checked"
                                />
                            </Stack>
                        </Stack>
                    ) : (
                        <></>
                    )}
                </TableCell>
                <TableCell align="center" sx={{ width: '40px', padding: 'unset' }}>
                    <Stack
                        sx={{
                            border: '1px solid #55595D',
                            borderRadius: '50%',
                            width: '20px',
                            height: '20px',
                            cursor: 'pointer',
                            rotate: isExplandAll ? '90deg' : '0deg',
                            transition: 'all ease .3s',
                        }}
                        justifyContent="center"
                        alignItems="center"
                        onClick={() => changeExpladAll()}
                    >
                        <KeyboardArrowRightRoundedIcon
                            sx={{ fontSize: '16px', color: '#55595D' }}
                        />
                    </Stack>
                </TableCell>
                <TableCell align="center" sx={{ width: '40px', padding: 'unset' }}>
                    <Typography
                        sx={{
                            color: '#55595D',
                            fontSize: '14px',
                            fontStyle: 'normal',
                            fontWeight: 500,
                            lineHeight: 'normal',
                        }}
                    >
                        #
                    </Typography>
                </TableCell>
                <TableCell
                    align="left"
                    sx={{
                        // width: { xs: 'calc(100% - 1048px)', lg: 'unset' },
                        paddingLeft: '0px 0px 0px 16px',
                    }}
                >
                    <Typography
                        sx={{
                            color: '#55595D',
                            fontSize: '14px',
                            fontStyle: 'normal',
                            fontWeight: '500',
                            lineHeight: 'normal',
                        }}
                    >
                        KHÁCH HÀNG
                    </Typography>
                </TableCell>
                <TableCell
                    align="left"
                    sx={{
                        // width: { xs: '200px', lg: 'unset' },
                        paddingLeft: '0px 0px 0px 16px',
                    }}
                >
                    <Typography
                        sx={{
                            color: '#55595D',
                            fontSize: '14px',
                            fontStyle: 'normal',
                            fontWeight: '500',
                            lineHeight: 'normal',
                        }}
                    >
                        LOẠI KHÁCH HÀNG
                    </Typography>
                </TableCell>
                <TableCell
                    align="left"
                    sx={{ width: { xs: '160px', lg: 'unset' }, paddingLeft: '0px 0px 0px 16px' }}
                >
                    <Typography
                        sx={{
                            color: '#55595D',
                            fontSize: '14px',
                            fontStyle: 'normal',
                            fontWeight: '500',
                            lineHeight: 'normal',
                        }}
                    >
                        ĐỊA CHỈ
                    </Typography>
                </TableCell>
                <TableCell
                    align="left"
                    sx={{
                        // width: { xs: '150px', lg: 'unset' },
                        display: { xs: 'none', lg: 'table-cell' },
                        paddingLeft: '0px 0px 0px 16px',
                    }}
                >
                    <Typography
                        sx={{
                            color: '#55595D',
                            fontSize: '14px',
                            fontStyle: 'normal',
                            fontWeight: '500',
                            lineHeight: 'normal',
                        }}
                    >
                        NGÀY ĐĂNG KÝ
                    </Typography>
                </TableCell>
                <TableCell
                    align="center"
                    sx={{
                        // width: { xs: '130px', lg: 'unset' },
                        paddingLeft: '0px 0px 0px 16px',
                    }}
                >
                    <Typography
                        sx={{
                            color: '#55595D',
                            fontSize: '14px',
                            fontStyle: 'normal',
                            fontWeight: '500',
                            lineHeight: 'normal',
                        }}
                    >
                        SỐ THẺ
                    </Typography>
                </TableCell>
                <TableCell
                    align="center"
                    sx={{
                        // width: { xs: '160px', lg: 'unset' },
                        paddingLeft: '0px 0px 0px 16px',
                    }}
                >
                    <Stack sx={{ display: 'flex !important' }} justifyContent="center">
                        <Typography
                            sx={{
                                color: '#55595D',
                                fontSize: '14px',
                                fontStyle: 'normal',
                                fontWeight: '500',
                                lineHeight: 'normal',
                            }}
                        >
                            SỐ PHƯƠNG TIỆN
                        </Typography>
                    </Stack>
                </TableCell>
                <TableCell sx={{ width: '40px', paddingLeft: '0px 0px 0px 16px' }}></TableCell>
                <TableCell sx={{ width: '60px', paddingLeft: '0px 0px 0px 16px' }}></TableCell>
            </TableRow>
        </TableHead>
    );
};
