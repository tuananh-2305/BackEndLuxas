import { Stack, Typography } from '@mui/material';
import { LAYOUT_CONTROL_NAVIGATION_DATA } from './mocks';
import Image from 'next/image';
import { useMemo, useState } from 'react';
import { useRouter } from 'next/router';
import { usePathname } from 'next/navigation';
import { useAppSelector } from '@/hooks';
import { ListParkingComponent } from './list-parking';
import Link from 'next/link';

export const LayoutControlNavigationComponent = () => {
    const [open, setOpen] = useState<boolean>(false);
    const router = useRouter();

    const pathname = usePathname();

    const choose = useMemo(
        () =>
            LAYOUT_CONTROL_NAVIGATION_DATA.find((item) => {
                return item.url === router.pathname || router.asPath === item.url;
            }),
        [pathname]
    );
    const parkingChoose = useAppSelector((state) => state.parking.chooseDashboard);

    return (
        <>
            {open ? (
                <Stack
                    sx={{
                        position: 'fixed',
                        top: 0,
                        left: 0,
                        width: '100vw',
                        height: '100vh',
                        backgroundColor: 'transparent',
                        zIndex: 4,
                        // backgroundColor: 'red',
                    }}
                    onClick={() => setOpen(false)}
                />
            ) : (
                <></>
            )}

            <Stack
                onClick={() => setOpen(!open)}
                sx={{
                    position: 'absolute',
                    top: 0,
                    left: 0,
                    backgroundColor: '#fff',
                    transition: 'all ease .5s',
                    borderRadius: '0px 0px 11px 11px',
                    zIndex: open ? 5 : 0,
                    boxShadow: open ? '0px 4px 16px 0px rgba(0, 0, 0, 0.10)' : 'unset',
                    cursor: 'pointer',
                }}
            >
                <Stack sx={{ padding: '15px 14px' }}>
                    <Stack direction="row" sx={{ gap: '8px' }}>
                        <Stack
                            sx={{
                                borderRadius: '50%',
                                width: '34px',
                                height: '34px',
                                boxShadow: '0px 1px 10px 0px rgba(34, 34, 34, 0.10)',
                            }}
                            justifyContent="center"
                            alignItems="center"
                        >
                            <Image
                                src="/icons/member-blue.svg"
                                width={18}
                                height={18}
                                alt="oryza-member"
                            />
                        </Stack>

                        <Stack direction="column">
                            <Stack
                                direction="row"
                                sx={{ gap: '14px' }}
                                alignItems="center"
                                justifyContent="space-between"
                            >
                                <Typography
                                    sx={{
                                        color: '#007DC0',
                                        fontSize: '16px',
                                        fontStyle: 'normal',
                                        fontWeight: '500',
                                        lineHeight: '24px',
                                    }}
                                >
                                    {choose ? choose.display : ''}
                                </Typography>

                                <Image
                                    src="/icons/arrow-fill-blue.svg"
                                    style={{
                                        userSelect: 'none',
                                        cursor: 'pointer',
                                        transform: open ? 'scaleY(-1)' : 'scaleY(1)',
                                        transition: 'all ease .3s',
                                    }}
                                    width={10}
                                    height={10}
                                    alt="arow-blue"
                                />
                            </Stack>
                            <Stack direction="row" alignItems="center" sx={{ gap: '8px' }}>
                                <Stack
                                    sx={{
                                        width: '8px',
                                        height: '8px',
                                        backgroundColor: '#22AE68',
                                        borderRadius: '50%',
                                    }}
                                />
                                <Typography
                                    sx={{
                                        color: '#55595D',
                                        fontSize: '14px',
                                        fontStyle: 'normal',
                                        fontWeight: 400,
                                        lineHeight: '16px',
                                    }}
                                >
                                    {parkingChoose?.Name}
                                </Typography>
                            </Stack>
                        </Stack>
                    </Stack>

                    <Stack
                        sx={{
                            paddingTop: open ? '16px' : '0',
                            gap: '8px',
                            visibility: open ? 'visible' : 'hidden',
                            opacity: open ? 1 : 0,
                            height: open ? 'unset' : '0px',
                            transition: 'all ease .3s',
                        }}
                    >
                        {LAYOUT_CONTROL_NAVIGATION_DATA.filter((item) => !item.hidden).map(
                            (item) => {
                                return (
                                    <Stack
                                        component={Link}
                                        href={item.url}
                                        key={item.url}
                                        direction="row"
                                        sx={{
                                            gap: '8px',
                                            cursor: 'pointer',
                                            backgroundColor:
                                                router.asPath === item.url ||
                                                router.pathname === item.url
                                                    ? '#007DC0'
                                                    : 'unset',
                                            borderRadius: '4px',
                                            '&:hover ':
                                                router.asPath !== item.url ||
                                                router.pathname !== item.url
                                                    ? { backgroundColor: '#F4FAFE' }
                                                    : {},
                                            transition: 'all ease .3s',
                                        }}
                                        alignItems="center"
                                    >
                                        <Stack
                                            sx={{ width: '32px', height: '32px', flexShrink: 0 }}
                                            justifyContent="center"
                                            alignItems="center"
                                        >
                                            <Image
                                                src={`/icons/${
                                                    router.asPath === item.url ||
                                                    router.pathname === item.url
                                                        ? item.icon.active
                                                        : item.icon.default
                                                }`}
                                                width={20}
                                                height={20}
                                                alt="member"
                                            />
                                        </Stack>

                                        <Typography
                                            sx={{
                                                color:
                                                    router.asPath === item.url ||
                                                    router.pathname === item.url
                                                        ? '#fff'
                                                        : '#55595D',
                                                fontSize: '16px',
                                                fontStyle: 'normal',
                                                fontWeight: 500,
                                                lineHeight: 'normal',
                                            }}
                                        >
                                            {item.display}
                                        </Typography>
                                    </Stack>
                                );
                            }
                        )}
                    </Stack>
                </Stack>
                <ListParkingComponent open={open} />
            </Stack>
        </>
    );
};
