import { historyInOutApi } from '@/api/history-in-out-api';
import ImageNextjs from '@/components/common/image';
import { useAppSelector } from '@/hooks';
import CloseRoundedIcon from '@mui/icons-material/CloseRounded';
import { Button, Dialog, DialogActions, Stack, Typography } from '@mui/material';
import { useEffect, useState } from 'react';
import styles from './stylem.module.css';
import { ICardAndVehicle, TableCheckCard } from './table-check';
import { CardModel } from '@/models/card.model';
import { systemRoleApi } from '@/api/key-system-role';
import { SystemRole } from '@/models/syste-role.model';
import { cardApi } from '@/api/card-api';
import { showSnackbarWithClose } from '@/hooks/useSnackbarWithClose';
export interface ConfirmCardDialogProps {
    open: boolean;
    cardChoose: CardModel[];
    onClose: () => void;
    reload: () => void;
}

export function ConfirmCardDialog(props: ConfirmCardDialogProps) {
    const { onClose, open, cardChoose, reload } = props;

    const packingChoose = useAppSelector((state) => state.parking.chooseDashboard);
    const [CardNumberInParking, setCardNumberInParking] = useState<string[]>([]);
    const [hasRoleDelete, setHasRoleDelete] = useState(false);

    const handleCheckCard = async () => {
        if (!packingChoose) return;

        let cardNumbers = cardChoose.map((v) => v.CardNumber);

        let payload = { ParkingId: packingChoose.ID, Data: cardNumbers };
        try {
            let { data } = await historyInOutApi.checkByCardNumberAndParkingId(payload);
            setCardNumberInParking(data);
        } catch (error) {
            //
        }
    };

    const handleChangeRole = async () => {
        if (!packingChoose) return;
        try {
            let { data } = await systemRoleApi.groupRoleByParkingId(packingChoose.ID);
            let systemRoles: SystemRole[] = data;
            let systemRole = systemRoles.filter(
                (item) => item?.KeySettingId?.KeyWord == 'DELETE_CARD_AND_VEHICLE'
            );

            let hasRole = false;
            if (systemRole.length > 0) {
                let role = systemRole[0];
                if (role.KeySettingId.IsValue) {
                    hasRole = false;
                } else {
                    hasRole = role.IsUse;
                }
            } else {
                hasRole = false;
            }
            setHasRoleDelete(hasRole);
        } catch (error) {}
    };

    const cardAndVehicle = cardChoose.map((card: CardModel) => {
        let data: ICardAndVehicle = {
            AuthenticationId: card.ID,
            Brand: card?.MemberVehicleId?.VehicleBrand,
            CardNumber: card.CardNumber,
            Color: card.MemberVehicleId?.VehicleColor,
            CreatedAt: card.CreatedAt,
            ExpirationDate: card.ExpirationDate,
            IdCard: card.IdCard ?? '',
            MemberVehicleId: card?.MemberVehicleId?.VehicleTypeId?.ID ?? '',
            PlateNumber: card?.MemberVehicleId?.PlateNumber ?? '',
            Type: card.TypeAuthen,
        };
        return data;
    });

    const isVehicleInParking = CardNumberInParking.length > 0 ? hasRoleDelete : false;

    useEffect(() => {
        handleCheckCard();
        handleChangeRole();
    }, []);

    const handleDelete = async () => {
        if (!packingChoose) return;
        try {
            const { data } = await cardApi.removeMutipleCard(
                packingChoose.ID,
                cardChoose.map((i) => i.ID)
            );

            if (data.length === 0) {
                showSnackbarWithClose('Xóa thẻ thành công', {
                    variant: 'success',
                });

                reload();
                onClose();
            } else {
                data.forEach((element: any) => {
                    showSnackbarWithClose(element.Error, {
                        variant: 'error',
                    });
                });
            }
        } catch (error: any) {
            if (Array.isArray(error?.response?.data?.message)) {
                error?.response?.data?.message.forEach((item: any) => {
                    showSnackbarWithClose(item, {
                        variant: 'error',
                    });
                });
            } else {
                showSnackbarWithClose(
                    error?.response ? error.response.data?.message : error.message,
                    {
                        variant: 'error',
                    }
                );
            }
        }
    };

    return (
        <Dialog onClose={onClose} open={open}>
            <Stack className={styles.container}>
                <Stack className={styles.closeBtn} onClick={onClose}>
                    <CloseRoundedIcon className={styles.closeIcon} />
                </Stack>

                <ImageNextjs
                    path={isVehicleInParking ? '/icons/warning_2.svg' : '/icons/bin_icon.svg'}
                    sx={{ width: '60px', height: '60px' }}
                />
                <Typography className={styles.textTitle}>
                    {isVehicleInParking
                        ? 'Vui lòng đưa xe ra khỏi bãi để xóa dữ liệu'
                        : 'Bạn có chắc chắn xóa thẻ này?'}
                </Typography>
                <Typography className={styles.textSubTitle}>
                    {isVehicleInParking
                        ? `${CardNumberInParking.length} phương tiện còn trong bãi`
                        : 'Sau khi xóa, dữ liệu sẽ được lưu trữ trong vòng 30 ngày.'}
                </Typography>
                <Typography className={styles.textSecond}>
                    Số thẻ:
                    <Typography className={styles.textBold} component="span">
                        {cardChoose.length}
                    </Typography>
                    |&nbsp;
                    <Typography className={styles.textHighlight} component="span">
                        Có phương tiện liên kết
                    </Typography>
                </Typography>
                <TableCheckCard
                    CardAndVehicle={cardAndVehicle}
                    CardNumberInParking={CardNumberInParking}
                />
            </Stack>

            {}
            <DialogActions className={styles.dialogAction}>
                <Button className={styles.cancelBtn} variant="contained" onClick={onClose}>
                    Không
                </Button>
                <Button
                    className={styles.submitBtn}
                    variant="contained"
                    onClick={handleDelete}
                    autoFocus
                >
                    Có
                </Button>
            </DialogActions>
        </Dialog>
    );
}
