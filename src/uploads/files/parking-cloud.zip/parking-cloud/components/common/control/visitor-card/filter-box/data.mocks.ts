export type SearchKeyCard = 'cardNumber' | 'idCard' | 'unset';

export const SEARCH_KEY: SearchKeyCard[] = ['cardNumber', 'idCard', 'unset'];

export const SEARCH_KEY_VALUE = {
    cardNumber: 'Mã thẻ trong',
    idCard: 'Mã thẻ ngoài',
};
