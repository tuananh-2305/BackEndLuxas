import { Stack, TableCell, TableRow, Typography } from '@mui/material';
import { MemberDetailCardRow } from './row';

export interface IRow {
    member: {
        image: string | null;
        name: string;
        address: string;
        type: string;
    };
    card: {
        ID: string;
        numberInSide: string;
        numberOutSide: string;
    } | null;
    vehicel: {
        ID: string;
        plateNumber: string;
        type: string;
        brand: string;
        color: string;
        startDate: string;
        endDate: string;
    } | null;
}

interface IMemberDetailComponent {
    isExpland: boolean;
    data: IRow[];
    reload: () => void;
}

export const MemberDetailComponent = (props: IMemberDetailComponent) => {
    const { isExpland, data, reload } = props;

    return (
        <>
            <TableRow
                sx={{
                    height: isExpland ? '60px' : '0px !important',
                    transition: 'all ease .3s',
                    opacity: isExpland ? 1 : 0,
                    visibility: isExpland ? 'visible' : 'collapse',
                    '&  * ': {
                        transition: 'all ease .5s',
                        visibility: isExpland ? 'visible' : 'collapse',
                        opacity: isExpland ? 1 : 0,
                        display: isExpland ? 'table-cell' : 'none',
                    },
                    backgroundColor: '#DAF2FF',
                }}
            >
                <TableCell
                    align="center"
                    sx={{
                        width: '48px',
                        padding: 'unset',
                        borderBottom: isExpland ? '1px solid #78C6E7' : 'unset',
                    }}
                ></TableCell>
                <TableCell
                    align="center"
                    sx={{
                        width: '40px',
                        padding: 'unset',
                        borderBottom: isExpland ? '1px solid #78C6E7' : 'unset',
                    }}
                ></TableCell>
                <TableCell
                    align="center"
                    sx={{
                        width: '40px',
                        padding: 'unset',
                        borderBottom: isExpland ? '1px solid #78C6E7' : 'unset',
                    }}
                >
                    <Stack
                        sx={{ width: '100%', display: 'flex !important' }}
                        justifyContent="center"
                    >
                        <Typography
                            sx={{
                                textAlign: 'center',
                                color: '#007DC0',
                                fontSize: { xs: '12px', lg: '14px' },
                                fontStyle: 'normal',
                                fontWeight: 400,
                                lineHeight: '140%',
                            }}
                        >
                            #
                        </Typography>
                    </Stack>
                </TableCell>
                <TableCell
                    align="left"
                    sx={{
                        // width: { xs: 'calc(100% - 1048px)', lg: 'unset' },
                        paddingLeft: '0px 0px 0px 16px',
                        borderBottom: isExpland ? '1px solid #78C6E7' : 'unset',
                    }}
                >
                    <Typography
                        sx={{
                            color: '#007DC0',
                            fontSize: { xs: '12px', lg: '14px' },
                            fontStyle: 'normal',
                            fontWeight: 600,
                            lineHeight: 'normal',
                        }}
                    >
                        Số thẻ ngoài
                    </Typography>
                </TableCell>
                <TableCell
                    align="left"
                    sx={{
                        // width: { xs: '200px', lg: 'unset' },
                        paddingLeft: '0px 0px 0px 16px',
                        borderBottom: isExpland ? '1px solid #78C6E7' : 'unset',
                    }}
                >
                    <Typography
                        sx={{
                            color: '#007DC0',
                            fontSize: { xs: '12px', lg: '14px' },
                            fontStyle: 'normal',
                            fontWeight: 600,
                            lineHeight: 'normal',
                        }}
                    >
                        Biển số
                    </Typography>
                </TableCell>
                <TableCell
                    align="left"
                    sx={{
                        // width: { xs: '160px', lg: 'unset' },
                        paddingLeft: '0px 0px 0px 16px',
                        borderBottom: isExpland ? '1px solid #78C6E7' : 'unset',
                    }}
                >
                    <Typography
                        sx={{
                            color: '#007DC0',
                            fontSize: { xs: '12px', lg: '14px' },
                            fontStyle: 'normal',
                            fontWeight: 600,
                            lineHeight: 'normal',
                        }}
                    >
                        Loại xe
                    </Typography>
                </TableCell>
                <TableCell
                    align="left"
                    sx={{
                        // width: { xs: '150px', lg: 'unset' },
                        display: { xs: 'none', lg: 'table-cell' },
                        paddingLeft: '0px 0px 0px 16px',
                        borderBottom: isExpland ? '1px solid #78C6E7' : 'unset',
                    }}
                >
                    <Typography
                        sx={{
                            color: '#007DC0',
                            fontSize: { xs: '12px', lg: '14px' },
                            fontStyle: 'normal',
                            fontWeight: 600,
                            lineHeight: 'normal',
                        }}
                    >
                        Hãng xe
                    </Typography>
                </TableCell>
                <TableCell
                    align="center"
                    sx={{
                        // width: { xs: '130px', lg: 'unset' },
                        paddingLeft: '0px 0px 0px 16px',
                        borderBottom: isExpland ? '1px solid #78C6E7' : 'unset',
                    }}
                >
                    <Stack
                        sx={{ width: '100%', display: 'flex !important' }}
                        justifyContent="center"
                    >
                        <Typography
                            sx={{
                                color: '#007DC0',
                                fontSize: { xs: '12px', lg: '14px' },
                                fontStyle: 'normal',
                                fontWeight: 600,
                                lineHeight: 'normal',
                            }}
                        >
                            Màu xe
                        </Typography>
                    </Stack>
                </TableCell>
                <TableCell
                    align="center"
                    sx={{
                        // width: { xs: '160px', lg: 'unset' },
                        paddingLeft: '0px 0px 0px 16px',
                        borderBottom: isExpland ? '1px solid #78C6E7' : 'unset',
                    }}
                >
                    <Stack
                        sx={{ width: '100%', display: 'flex !important' }}
                        justifyContent="center"
                    >
                        <Typography
                            sx={{
                                color: '#007DC0',
                                fontSize: { xs: '12px', lg: '14px' },
                                fontStyle: 'normal',
                                fontWeight: 600,
                                lineHeight: 'normal',
                            }}
                        >
                            Ngày đăng ký
                        </Typography>
                    </Stack>
                </TableCell>
                <TableCell
                    sx={{
                        width: '40px',
                        paddingLeft: '0px 0px 0px 16px',
                        borderBottom: isExpland ? '1px solid #78C6E7' : 'unset',
                    }}
                >
                    <Typography
                        sx={{
                            color: '#007DC0',
                            fontSize: { xs: '12px', lg: '14px' },
                            fontStyle: 'normal',
                            fontWeight: 600,
                            lineHeight: 'normal',
                            whiteSpace: 'nowrap',
                        }}
                    >
                        Ngày hết hạn
                    </Typography>
                </TableCell>
                <TableCell
                    sx={{
                        width: '60px',
                        paddingLeft: '0px 0px 0px 16px',
                        borderBottom: isExpland ? '1px solid #78C6E7' : 'unset',
                    }}
                ></TableCell>
            </TableRow>

            {data.map((item, key) => {
                return (
                    <MemberDetailCardRow
                        reload={reload}
                        key={`${key}-asd`}
                        index={key}
                        item={item}
                        isExpland={isExpland}
                    />
                );
            })}
        </>
    );
};
