export const SEARCH_KEY: ('address' | 'plateNumber' | 'name' | 'phone')[] = [
    'address',
    'plateNumber',
    'name',
    'phone',
];

export const SEARCH_KEY_VALUE = {
    address: 'Địa chỉ',
    plateNumber: 'Biển số',
    name: 'Tên cư dân',
    phone: 'Số điện thoại',
};
