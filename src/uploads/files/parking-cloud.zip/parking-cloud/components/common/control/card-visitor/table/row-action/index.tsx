import { Stack, TableCell, Typography } from '@mui/material';
import MoreVertRoundedIcon from '@mui/icons-material/MoreVertRounded';
import { useRef, useState } from 'react';
import Image from 'next/image';
import DialogUpdateVisitorCard from '@/components/dialog/dialog-visitor-card/update';
import { cardApi } from '@/api/card-api';
import { showSnackbarWithClose } from '@/hooks/useSnackbarWithClose';
import DeleteDialog from '@/components/common/dialog/delete-dialog';
import { memberVehicleApi } from '@/api/member-vehicle-api';
import { useAppSelector } from '@/hooks';

interface IRowActionComponent {
    isExpland: boolean;
    item: any;
    reload: () => void;
}

export const RowActionComponent = (props: IRowActionComponent) => {
    const { isExpland, item, reload } = props;

    const [deleteMemberComfirmActive, setDeleteMemberComfirmActive] = useState(false);
    const [openEditDialog, setOpenEditDialog] = useState(false);

    const [active, setActive] = useState(false);
    const ref = useRef<HTMLDivElement | null>(null);
    const parkingChoose = useAppSelector((state) => state.parking.chooseDashboard);
    const profile = useAppSelector((state) => state.common.profile);

    const boxRef = ref?.current?.getBoundingClientRect();
    const handleDelete = () => {
        if (!parkingChoose) {
            return;
        }

        cardApi
            .removeMutipleCardGuest(parkingChoose.ID, [item.ID])
            .then((res) => {
                const { data } = res;
                if (data.length === 0) {
                    showSnackbarWithClose('Xóa thẻ vãng lai thành công', {
                        variant: 'success',
                    });

                    reload();
                } else {
                    data.forEach((element: any) => {
                        showSnackbarWithClose(element.Error, {
                            variant: 'error',
                        });
                    });
                }
                // reload();
                // showSnackbarWithClose('Xóa thẻ vãng lai thành công', { variant: 'success' });
            })
            .catch((err) => {
                if (Array.isArray(err?.response?.data?.message)) {
                    err?.response?.data?.message.forEach((item: any) => {
                        showSnackbarWithClose(item, {
                            variant: 'error',
                        });
                    });
                } else {
                    showSnackbarWithClose(
                        err?.response ? err.response.data?.message : err.message,
                        {
                            variant: 'error',
                        }
                    );
                }
            });
    };
    return (
        <TableCell
            sx={{
                width: '60px',
                padding: '0px 0px 0px 16px',
                borderBottom: '1px solid #E3E5E5',
                position: 'relative',
            }}
        >
            {parkingChoose?.SystemRoleSetting?.Delete ||
            parkingChoose?.SystemRoleSetting?.Update ||
            profile?.IsAdmin ||
            profile?.IsSupperAdmin ? (
                <Stack
                    ref={ref}
                    sx={{
                        transition: 'all ease .3s',
                        display: 'flex !important',
                        width: '32px',
                        height: '32px',
                        '&:hover ': {
                            backgroundColor: '#fff',
                            borderRadius: '4px',
                        },
                    }}
                    justifyContent="center"
                    alignItems="center"
                >
                    <MoreVertRoundedIcon
                        sx={{ color: isExpland ? '#fff' : '#808080', cursor: 'pointer' }}
                        onClick={() => setActive(!active)}
                    />
                </Stack>
            ) : (
                <></>
            )}

            {active &&
            (parkingChoose?.SystemRoleSetting?.Delete ||
                parkingChoose?.SystemRoleSetting?.Update ||
                profile?.IsAdmin ||
                profile?.IsSupperAdmin) ? (
                <Stack
                    sx={{
                        position: 'fixed',
                        width: '100vw',
                        height: '100vh',
                        top: 0,
                        left: 0,
                        zIndex: 4,
                    }}
                    onClick={() => setActive(false)}
                />
            ) : (
                <></>
            )}

            {active &&
            boxRef &&
            (parkingChoose?.SystemRoleSetting?.Delete ||
                parkingChoose?.SystemRoleSetting?.Update ||
                profile?.IsAdmin ||
                profile?.IsSupperAdmin) ? (
                <Stack
                    sx={{
                        zIndex: 5,
                        position: 'fixed',
                        width: 'fit-content',
                        // height: '116px',
                        padding: '8px',
                        gap: '8px',
                        flexShrink: 0,
                        borderRadius: '6px',
                        background: '#fff',
                        boxShadow: '0px 1px 10px 0px rgba(34, 34, 34, 0.10)',
                        right: `${boxRef.width - 10}px`,
                        top: `${boxRef.y}px`,
                    }}
                >
                    {parkingChoose?.SystemRoleSetting?.Update ||
                    profile?.IsAdmin ||
                    profile?.IsSupperAdmin ? (
                        <Stack
                            sx={{
                                flex: 1,
                                borderRadius: '4px',
                                paddingLeft: '8px',
                                cursor: 'pointer',
                                width: '100%',
                                gap: '4px',
                                '&:hover ': {
                                    backgroundColor: '#F4FAFE',
                                },
                            }}
                            onClick={() => setOpenEditDialog(true)}
                            direction="row"
                            alignItems="center"
                        >
                            <Image src="/icons/edit-blue.svg" width={24} height={24} alt="photo" />
                            <Typography
                                sx={{
                                    color: '#55595D',
                                    fontSize: '14px',
                                    fontStyle: 'normal',
                                    fontWeight: '500',
                                    width: '100%',
                                    lineHeight: 'normal',
                                    whiteSpace: 'nowrap',
                                    padding: '4px',
                                }}
                            >
                                Chỉnh sửa
                            </Typography>
                        </Stack>
                    ) : (
                        <></>
                    )}

                    {parkingChoose?.SystemRoleSetting?.Update ||
                    profile?.IsAdmin ||
                    profile?.IsSupperAdmin ? (
                        <Stack
                            sx={{
                                flex: 1,
                                borderRadius: '4px',
                                paddingLeft: '8px',
                                cursor: 'pointer',
                                width: '100%',
                                gap: '4px',
                                '&:hover ': {
                                    backgroundColor: '#F4FAFE',
                                },
                            }}
                            direction="row"
                            alignItems="center"
                            onClick={() => setDeleteMemberComfirmActive(true)}
                        >
                            <Image src="/icons/trash-red.svg" width={24} height={24} alt="photo" />
                            <Typography
                                sx={{
                                    color: '#55595D',
                                    fontSize: '14px',
                                    fontStyle: 'normal',
                                    fontWeight: '500',
                                    width: '100%',
                                    lineHeight: 'normal',
                                    padding: '4px',
                                }}
                            >
                                Xóa
                            </Typography>
                        </Stack>
                    ) : (
                        <></>
                    )}

                    {/* <Stack
                        sx={{
                            flex: 1,
                            borderRadius: '4px',
                            paddingLeft: '8px',
                            cursor: 'pointer',
                            gap: '4px',
                            width: '100%',
                            '&:hover ': {
                                backgroundColor: '#F4FAFE',
                            },
                        }}
                        direction="row"
                        alignItems="center"
                    >
                        <Image src="/icons/file-search-green.svg" width={24} height={24} alt="photo" />
                        <Typography
                            sx={{
                                color: '#55595D',
                                fontSize: '14px',
                                fontStyle: 'normal',
                                fontWeight: '500',
                                lineHeight: 'normal',
                                width: '100%',
                                whiteSpace: 'nowrap',
                                padding: '4px',
                            }}
                        >
                            Xem chi tiết
                        </Typography>
                    </Stack> */}
                </Stack>
            ) : (
                <></>
            )}
            {deleteMemberComfirmActive && (
                <DeleteDialog
                    open={deleteMemberComfirmActive}
                    handleClose={() => {
                        setDeleteMemberComfirmActive(false);
                    }}
                    handleConfirm={() => {
                        handleDelete();
                        setDeleteMemberComfirmActive(false);
                    }}
                ></DeleteDialog>
            )}
            {openEditDialog && item && (
                <DialogUpdateVisitorCard
                    open={openEditDialog}
                    handleClose={() => {
                        setOpenEditDialog(false);
                    }}
                    handleReload={reload}
                    item={item}
                />
            )}
        </TableCell>
    );
};
