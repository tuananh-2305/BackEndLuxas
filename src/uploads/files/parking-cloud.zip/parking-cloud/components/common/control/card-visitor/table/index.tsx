import { Stack, Table, TableBody, TableContainer } from '@mui/material';
import { Dispatch, SetStateAction, useRef } from 'react';

import { CardModel } from '@/models';
import { TableControlHead } from './head';
import { TableControlRow } from './row';

interface IControlTable {
    data: CardModel[];
    reload: () => void;
    currentPage: number;
    idsChoose: string[];
    setIdsChoose: Dispatch<SetStateAction<string[]>>;
    openSearchOption: boolean;
}

export const ControlTable = (props: IControlTable) => {
    const { data, currentPage, idsChoose, setIdsChoose, reload, openSearchOption } = props;

    const isChooseAll = data.length !== 0 && idsChoose.length === data.length;

    const ref = useRef<HTMLDivElement | null>(null);

    return (
        <Stack
            ref={ref}
            sx={{
                width: '100%',
                height: '100%',
                borderBottom: '1px solid #E3E5E5',
                zIndex: openSearchOption ? 0 : 2,
            }}
        >
            <TableContainer
                sx={{
                    maxHeight: `${ref.current?.clientHeight}px`,
                    '&::-webkit-scrollbar': {
                        width: '4px',
                    },
                }}
            >
                <Table
                    sx={{
                        borderCollapse: 'collapse',
                    }}
                >
                    <TableControlHead
                        isChooseAll={isChooseAll}
                        changeChooseAll={() => {
                            if (isChooseAll) {
                                setIdsChoose([]);
                            } else {
                                setIdsChoose(data.map((item) => item.ID));
                            }
                        }}
                    />

                    <TableBody
                        sx={{
                            maxHeight: `540px`,
                            overflow: 'auto',
                            position: 'relative',
                            '&::-webkit-scrollbar': {
                                width: '2px',
                            },
                        }}
                    >
                        {data.map((item: CardModel, index) => {
                            return (
                                <TableControlRow
                                    key={`${index}-visitor-car`}
                                    index={currentPage * 9 + index + 1}
                                    data={item}
                                    isChoose={idsChoose.includes(item.ID)}
                                    changeChoose={(id: string) => {
                                        if (idsChoose.includes(id)) {
                                            setIdsChoose(idsChoose.filter((v) => v !== id));
                                        } else {
                                            setIdsChoose([...idsChoose, id]);
                                        }
                                    }}
                                    reload={reload}
                                />
                            );
                        })}
                    </TableBody>
                </Table>
            </TableContainer>
        </Stack>
    );
};
