import CloseRoundedIcon from '@mui/icons-material/CloseRounded';
import { Stack, Typography } from '@mui/material';
import Image from 'next/image';
import { Dispatch, SetStateAction, useState } from 'react';
import { SelectActionOptions } from './options';
interface ISelectActionComponent {
    idsChoose: string[];
    membersChoose: any[];
    openComfirmRemoveAllMember: boolean;
    setOpenComfirmRemoveAllMember: Dispatch<SetStateAction<boolean>>;
    reload: () => void;
    resetIdsChoose: () => void;
}

export const SelectActionComponent = (props: ISelectActionComponent) => {
    const {
        idsChoose,
        resetIdsChoose,
        membersChoose,
        reload,
        setOpenComfirmRemoveAllMember,
        openComfirmRemoveAllMember,
    } = props;
    const [active, setActive] = useState(false);

    // const [openComfirmRemoveAllMember, setOpenComfirmRemoveAllMember] = useState(false);

    return (
        <Stack
            alignItems="center"
            direction={'row'}
            sx={{
                zIndex: !openComfirmRemoveAllMember ? 800 : 'unset',
                visibility: idsChoose.length !== 0 ? 'visible' : 'hidden',
                opacity: idsChoose.length !== 0 ? 1 : 0,
                transition: 'all ease .3s',
            }}
        >
            <Stack direction="row" sx={{ gap: '16px' }} alignItems={'center'}>
                <Typography
                    sx={{
                        color: '#55595D',
                        fontSize: '14px',
                        fontStyle: 'normal',
                        fontWeight: 500,
                        lineHeight: 'normal',
                    }}
                >
                    Đã chọn :
                </Typography>
                <Typography sx={{ color: '#007DC0' }}>{idsChoose.length}</Typography>
            </Stack>

            {active ? (
                <Stack
                    sx={{
                        position: 'fixed',
                        width: '100vw',
                        height: '100vh',
                        zIndex: 2,
                        top: 0,
                        left: 0,
                        transform: 'translate(-100px,-100px)',
                    }}
                    onClick={() => setActive(false)}
                />
            ) : (
                <></>
            )}

            <Stack
                direction="row"
                sx={{
                    height: '46px',
                    marginLeft: '16px',
                    marginRight: '8px',
                    padding: '13px 16px',
                    gap: '8px',
                    borderRadius: '6px',
                    border: `1px solid #007DC0 `,
                    background: '#FFF',
                    cursor: 'pointer',
                    position: 'relative',
                }}
                alignItems="center"
                onClick={() => setActive(true)}
            >
                <Typography
                    sx={{
                        color: '#808080',
                        fontSize: '14px',
                        fontStyle: 'normal',
                        fontWeight: 400,
                        lineHeight: '140%',
                        flex: 1,
                    }}
                >
                    Hành động
                </Typography>
                <Stack
                    sx={{ width: '24px', height: '24px' }}
                    alignItems="center"
                    justifyContent={'center'}
                >
                    <Image src="/icons/chevron-gray.svg" width={24} height={24} alt="photo" />
                    {/* <ArrowForwardIosRoundedIcon
                        sx={{ fontSize: '16px', color: '#808080', rotate: '90deg' }}
                    /> */}
                </Stack>

                <Stack
                    sx={{
                        position: 'absolute',
                        width: 'fit-content',
                        padding: '8px',
                        top: 'calc(100% + 4px)',
                        backgroundColor: '#fff',
                        zIndex: 3,
                        left: 0,
                        borderRadius: '4px',
                        transition: 'all ease .3s',
                        visibility: active ? 'visible' : 'hidden',
                        opacity: active ? 1 : 0,
                        gap: '4px',
                    }}
                >
                    <SelectActionOptions activex={active} idsChoose={idsChoose} />

                    <Stack
                        sx={{
                            width: '153px',
                            padding: '6px 8px',
                            gap: '10px',
                            transition: 'all ease .3s',
                            '&:hover': {
                                backgroundColor: '#F4FAFE',
                            },
                        }}
                        onClick={() => setOpenComfirmRemoveAllMember(true)}
                    >
                        <Typography
                            sx={{
                                color: '#55595D',
                                fontSize: '14px',
                                fontStyle: 'normal',
                                fontWeight: 500,
                                lineHeight: 'normal',
                            }}
                        >
                            Xóa tất cả
                        </Typography>
                    </Stack>

                    {/* {openComfirmRemoveAllMember ? (
                        <RemoveAllMemberComfirmDialog
                            membersChoose={membersChoose}
                            listMemberParkingId={membersChoose.map((v) => v.MemberParkingId)}
                            totalCard={membersChoose.reduce((oldValue, currentValue) => {
                                return oldValue + currentValue.CountAuthentication;
                            }, 0)}
                            totalVehicel={membersChoose.reduce((oldValue, currentValue) => {
                                return oldValue + currentValue.CountVehicle.Total;
                            }, 0)}
                            close={() => {
                                setOpenComfirmRemoveAllMember(false);
                                resetIdsChoose();
                            }}
                            reload={() => reload()}
                        />
                    ) : (
                        <></>
                    )} */}
                </Stack>
            </Stack>

            <Stack
                sx={{ width: '16px', height: '16px', cursor: 'pointer' }}
                justifyContent="center"
                alignItems="center"
                onClick={() => resetIdsChoose()}
            >
                <CloseRoundedIcon sx={{ color: '#E42727', fontSize: '16px' }} />
            </Stack>
        </Stack>
    );
};
