import { vehicleColor } from '@/constants/vehicle-color';
import { CardModel } from '@/models';
import { renderVehicleColor } from '@/ultis/global-func';
import SyncIcon from '@mui/icons-material/Sync';
import { Stack, TableCell, TableRow, Typography } from '@mui/material';
import moment from 'moment';
import Image from 'next/image';
import { useState } from 'react';
import { RowActionComponent } from './row-action';
import { DialogUpdateCard } from '@/components/dialog/dialog-update/dialog-update-card-v2';
import { UserInfo } from '@/components';
import { useAppSelector } from '@/hooks';

const BACKEND_DOMAIN = process.env.NEXT_PUBLIC_SERVER_PARKING_DOMAIN;
interface ITableControlCardRowComponent {
    index: number;
    isChoose: boolean;
    data: CardModel;
    changeChoose: (id: string) => void;
    fetchData: () => void;
}

export const TableControlCardRowComponent = (props: ITableControlCardRowComponent) => {
    const { index, data, changeChoose, isChoose, fetchData } = props;

    const [openDialogUpdate, setOpenDialogUpdate] = useState(false);
    const parkingChoose = useAppSelector((state) => state.parking.chooseDashboard);
    const profile = useAppSelector((state) => state.common.profile);

    return (
        <>
            <TableRow
                sx={{
                    height: '60px',
                    maxHeight: '60px',
                    backgroundColor: () => {
                        if (isChoose) {
                            return '#DAF2FF';
                        } else {
                            return '#fff';
                        }
                    },
                    border: '1px solid #E3E5E5 !important',
                    transition: 'all ease .3s',
                    boxSizing: 'border-box',
                    '&:hover ': isChoose
                        ? {}
                        : {
                              backgroundColor: '#DAF2FF',
                          },
                }}
            >
                <TableCell
                    align="center"
                    sx={{
                        width: '48px',
                        padding: 'unset',
                        position: 'relative',
                        userSelect: 'none',
                    }}
                >
                    {parkingChoose?.SystemRoleSetting?.Delete ||
                    profile?.IsAdmin ||
                    profile?.IsSupperAdmin ? (
                        <Stack
                            sx={{ display: 'flex !important' }}
                            justifyContent="center"
                            alignItems="center"
                        >
                            <Stack
                                sx={{
                                    width: '16px',
                                    height: '16px',
                                    borderRadius: '4px',
                                    backgroundColor: isChoose ? '#007DC0' : '#fff',
                                    boxShadow:
                                        '0px 0px 0px 1px rgba(70, 79, 96, 0.16), 0px 1px 1px 0px rgba(0, 0, 0, 0.10)',
                                    cursor: 'pointer',
                                }}
                                justifyContent="center"
                                alignItems="center"
                                onClick={() => {
                                    changeChoose(data.ID);
                                }}
                            >
                                <Image
                                    src="/icons/checked-white.svg"
                                    width={9}
                                    height={6}
                                    alt="checked"
                                />
                            </Stack>
                        </Stack>
                    ) : (
                        <></>
                    )}
                </TableCell>

                <TableCell align="center" sx={{ width: '40px', padding: 'unset' }}>
                    <Typography
                        sx={{
                            // color: isExpland ? '#fff' : '#323232',
                            fontSize: { xs: '14px', md: '16px' },
                            fontStyle: 'normal',
                            fontWeight: 400,
                            lineHeight: '20px',
                            width: '100%',
                            wordBreak: 'break-word',
                        }}
                    >
                        {index}
                    </Typography>
                </TableCell>
                <TableCell
                    align="left"
                    sx={{
                        // width: { xs: '200px', lg: 'unset' },
                        paddingLeft: '0px 0px 0px 16px',
                    }}
                >
                    <Typography
                        sx={{
                            // color: isExpland ? '#fff' : '#323232',
                            fontSize: { xs: '13px', lg: '14px' },
                            fontStyle: 'normal',
                            fontWeight: '400',
                            lineHeight: 'normal',
                            width: '100%',
                            wordBreak: 'break-word',
                        }}
                    >
                        {data?.IdCard ?? ''}
                    </Typography>
                </TableCell>
                <TableCell
                    align="left"
                    sx={{
                        // width: { xs: '200px', lg: 'unset' },
                        paddingLeft: '0px 0px 0px 16px',
                    }}
                >
                    <Typography
                        sx={{
                            // color: isExpland ? '#fff' : '#323232',
                            fontSize: { xs: '13px', lg: '14px' },
                            fontStyle: 'normal',
                            fontWeight: '400',
                            lineHeight: 'normal',
                            width: '100%',
                            wordBreak: 'break-word',
                        }}
                    >
                        {data?.CardNumber ?? ''}
                    </Typography>
                </TableCell>
                <TableCell
                    align="left"
                    sx={{
                        // width: { xs: '160px', lg: 'unset' },
                        paddingLeft: '0px 0px 0px 16px',
                    }}
                >
                    <UserInfo
                        fullName={data?.MemberId?.Name ?? ''}
                        avatar={`${BACKEND_DOMAIN}${data?.MemberId?.Avatar}`}
                    />
                </TableCell>
                <TableCell
                    align="left"
                    sx={{
                        // width: { xs: '150px', lg: 'unset' },
                        display: { xs: 'none', lg: 'table-cell' },
                        paddingLeft: '0px 0px 0px 16px',
                    }}
                >
                    <Typography
                        sx={{
                            // color: isExpland ? '#fff' : '#323232',
                            fontSize: { xs: '13px', lg: '14px' },
                            fontStyle: 'normal',
                            fontWeight: '400',
                            lineHeight: 'normal',
                            width: '100%',
                            wordBreak: 'break-word',
                        }}
                    >
                        {data?.MemberId?.Address ?? ''}
                    </Typography>
                </TableCell>
                <TableCell
                    align="center"
                    sx={{
                        // width: { xs: '130px', lg: 'unset' },
                        paddingLeft: '0px 0px 0px 16px',
                    }}
                >
                    <Typography
                        sx={{
                            // color: isExpland ? '#fff' : '#323232',
                            fontSize: { xs: '13px', lg: '14px' },
                            fontStyle: 'normal',
                            fontWeight: '400',
                            lineHeight: 'normal',
                            width: '100%',
                            wordBreak: 'break-word',
                        }}
                    >
                        {data?.TypeAuthen ?? ''}
                    </Typography>
                </TableCell>
                <TableCell
                    align="center"
                    sx={{
                        // width: { xs: '130px', lg: 'unset' },
                        paddingLeft: '0px 0px 0px 16px',
                    }}
                >
                    <Typography
                        sx={{
                            // color: isExpland ? '#fff' : '#323232',
                            fontSize: { xs: '13px', lg: '14px' },
                            fontStyle: 'normal',
                            fontWeight: '400',
                            lineHeight: 'normal',
                            width: '100%',
                            wordBreak: 'break-word',
                        }}
                    >
                        {data?.CreatedAt ? moment(data.CreatedAt).format('DD/MM/yyyy') : ''}
                    </Typography>
                </TableCell>

                <TableCell sx={{ width: '40px', paddingLeft: '0px 0px 0px 16px' }}>
                    <Stack
                        sx={{ display: 'flex !important', width: '100%' }}
                        justifyContent="center"
                        alignItems="center"
                    >
                        <SyncIcon
                            sx={{
                                transform: 'scaleY(-1) rotate(-45deg)',
                                color: '#CDD2D1',
                                transition: 'all ease .5s',
                            }}
                        />
                    </Stack>
                </TableCell>
                <RowActionComponent
                    isExpland={false}
                    item={data}
                    changeQuickEditId={function (): void {
                        setOpenDialogUpdate(true);
                    }}
                    reload={fetchData}
                />
            </TableRow>

            {openDialogUpdate && data && (
                <DialogUpdateCard
                    open={openDialogUpdate}
                    handleClose={() => {
                        setOpenDialogUpdate(false);
                    }}
                    item={data}
                    handleReload={fetchData}
                    isElevator
                />
            )}

            {/* <MemberDetailComponent isExpland={isExpland} data={dataTransform} reload={reload} /> */}
        </>
    );
};
