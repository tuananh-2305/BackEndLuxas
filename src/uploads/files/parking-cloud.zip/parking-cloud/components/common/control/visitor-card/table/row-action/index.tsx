import { Stack, TableCell, Typography } from '@mui/material';
import MoreVertRoundedIcon from '@mui/icons-material/MoreVertRounded';
import { useRef, useState } from 'react';
import Image from 'next/image';

interface IRowActionComponent {
    isExpland: boolean;
    item: any;
    changeQuickEditId: () => void;
    reload: () => void;
}

export const RowActionComponent = (props: IRowActionComponent) => {
    const { isExpland, item, changeQuickEditId, reload } = props;

    const [deleteMemberComfirmActive, setDeleteMemberComfirmActive] = useState(false);
    const [active, setActive] = useState(false);
    const ref = useRef<HTMLDivElement | null>(null);
    const boxRef = ref?.current?.getBoundingClientRect();

    return (
        <TableCell
            sx={{
                width: '60px',
                padding: '0px 0px 0px 16px',
                borderBottom: '1px solid #E3E5E5',
                position: 'relative',
            }}
        >
            <Stack
                ref={ref}
                sx={{
                    transition: 'all ease .3s',
                    display: 'flex !important',
                    width: '32px',
                    height: '32px',
                    '&:hover ': {
                        backgroundColor: '#fff',
                        borderRadius: '4px',
                    },
                }}
                justifyContent="center"
                alignItems="center"
            >
                <MoreVertRoundedIcon
                    sx={{ color: isExpland ? '#fff' : '#808080', cursor: 'pointer' }}
                    onClick={() => setActive(!active)}
                />
            </Stack>

            {active ? (
                <Stack
                    sx={{
                        position: 'fixed',
                        width: '100vw',
                        height: '100vh',
                        top: 0,
                        left: 0,
                        zIndex: 4,
                    }}
                    onClick={() => setActive(false)}
                />
            ) : (
                <></>
            )}

            {active && boxRef ? (
                <Stack
                    sx={{
                        zIndex: 5,
                        position: 'fixed',
                        width: 'fit-content',
                        // height: '116px',
                        padding: '8px',
                        gap: '8px',
                        flexShrink: 0,
                        borderRadius: '6px',
                        background: '#fff',
                        boxShadow: '0px 1px 10px 0px rgba(34, 34, 34, 0.10)',
                        right: `${boxRef.width - 10}px`,
                        top: `${boxRef.y}px`,
                    }}
                >
                    <Stack
                        sx={{
                            flex: 1,
                            borderRadius: '4px',
                            paddingLeft: '8px',
                            cursor: 'pointer',
                            width: '100%',
                            gap: '4px',
                            '&:hover ': {
                                backgroundColor: '#F4FAFE',
                            },
                        }}
                        onClick={() => changeQuickEditId()}
                        direction="row"
                        alignItems="center"
                    >
                        <Image src="/icons/edit-blue.svg" width={24} height={24} alt="photo" />
                        <Typography
                            sx={{
                                color: '#55595D',
                                fontSize: '14px',
                                fontStyle: 'normal',
                                fontWeight: '500',
                                width: '100%',
                                lineHeight: 'normal',
                                whiteSpace: 'nowrap',
                                padding: '4px',
                            }}
                        >
                            Chỉnh sửa
                        </Typography>
                    </Stack>
                    <Stack
                        sx={{
                            flex: 1,
                            borderRadius: '4px',
                            paddingLeft: '8px',
                            cursor: 'pointer',
                            width: '100%',
                            gap: '4px',
                            '&:hover ': {
                                backgroundColor: '#F4FAFE',
                            },
                        }}
                        direction="row"
                        alignItems="center"
                        onClick={() => setDeleteMemberComfirmActive(true)}
                    >
                        <Image src="/icons/trash-red.svg" width={24} height={24} alt="photo" />
                        <Typography
                            sx={{
                                color: '#55595D',
                                fontSize: '14px',
                                fontStyle: 'normal',
                                fontWeight: '500',
                                width: '100%',
                                lineHeight: 'normal',
                                padding: '4px',
                            }}
                        >
                            Xóa
                        </Typography>
                    </Stack>
                    {/* <Stack
                        sx={{
                            flex: 1,
                            borderRadius: '4px',
                            paddingLeft: '8px',
                            cursor: 'pointer',
                            gap: '4px',
                            width: '100%',
                            '&:hover ': {
                                backgroundColor: '#F4FAFE',
                            },
                        }}
                        direction="row"
                        alignItems="center"
                    >
                        <Image src="/icons/file-search-green.svg" width={24} height={24} alt="photo" />
                        <Typography
                            sx={{
                                color: '#55595D',
                                fontSize: '14px',
                                fontStyle: 'normal',
                                fontWeight: '500',
                                lineHeight: 'normal',
                                width: '100%',
                                whiteSpace: 'nowrap',
                                padding: '4px',
                            }}
                        >
                            Xem chi tiết
                        </Typography>
                    </Stack> */}
                </Stack>
            ) : (
                <></>
            )}
            {/* {deleteMemberComfirmActive ? (
                <RemoveMemberComfirmDialog
                    close={() => setDeleteMemberComfirmActive(false)}
                    item={item}
                    reload={reload}
                />
            ) : (
                <></>
            )} */}
        </TableCell>
    );
};
