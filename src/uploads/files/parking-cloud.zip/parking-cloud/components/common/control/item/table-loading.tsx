import {
    Skeleton,
    Stack,
    Table,
    TableBody,
    TableCell,
    TableContainer,
    TableHead,
    TableRow,
} from '@mui/material';

export interface ITableLoadingProps {
    limit?: number;
    countHeader?: number;
}

export function TableLoading(props: ITableLoadingProps) {
    const limit = props.limit ?? 7;
    const countHeader = props.countHeader ?? 5;
    return (
        <Stack
            sx={{
                flex: 1,
                background: '#fff',
            }}
        >
            <TableContainer
                sx={{
                    width: '100%',
                    overflowY: 'auto',
                    '&::-webkit-scrollbar': {
                        width: '4px',
                    },
                }}
            >
                <Table>
                    <TableHead
                        sx={{
                            backgroundColor: '#E3E5E5',
                            height: '40px',
                        }}
                    >
                        <TableRow>
                            {Array.from(Array(countHeader).keys()).map((index) => {
                                return (
                                    <TableCell key={index} align="center">
                                        <Skeleton variant="text" />
                                    </TableCell>
                                );
                            })}
                        </TableRow>
                    </TableHead>

                    <TableBody
                        sx={{
                            zIndex: 0,
                            height: '100px',
                            maxHeight: '100px',
                            overflow: 'auto',
                            position: 'relative',
                            '&::-webkit-scrollbar': {
                                width: '2px',
                            },
                        }}
                    >
                        {Array.from(Array(limit).keys()).map((index) => {
                            function randomPercentage() {
                                const randomPercentage = Math.random() * (100 - 30) + 30;
                                return randomPercentage + '%';
                            }
                            return (
                                <TableRow key={index} sx={{ height: '60px' }}>
                                    {Array.from(Array(countHeader).keys()).map((index) => {
                                        return (
                                            <TableCell key={index} align="center">
                                                <Skeleton
                                                    variant="text"
                                                    width={randomPercentage()}
                                                    sx={{ my: '8px' }}
                                                />
                                            </TableCell>
                                        );
                                    })}
                                </TableRow>
                            );
                        })}
                    </TableBody>
                </Table>
            </TableContainer>
        </Stack>
    );
}
