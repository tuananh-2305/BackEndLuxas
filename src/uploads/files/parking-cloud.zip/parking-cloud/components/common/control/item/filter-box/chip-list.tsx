import { Stack, Typography } from '@mui/material';
import { SEARCH_KEY_VALUE, SEARCH_KEY } from './data.mocks';
import CloseRoundedIcon from '@mui/icons-material/CloseRounded';
import { usePathname, useRouter } from 'next/navigation';
import { generateURLWithQueryParams } from '@/ultis/global-func';
import { useEffect, useRef } from 'react';

// interface ISearchParamns {
//     page: string | null;
//     address: string | null;
//     name: string | null;
//     phone: string | null;
//     cardNumberOutSide: string | null;
//     plateno: string | null;
//     cardNumberInSide: string | null;
// }

interface IFilterChipList {
    searchParams: any;
    SEARCH_KEY_VALUE: any;
    SEARCH_KEY: any;
}
export const FilterChipList = (props: IFilterChipList) => {
    const { searchParams, SEARCH_KEY_VALUE, SEARCH_KEY } = props;

    const pathname = usePathname();
    const router = useRouter();

    const ref = useRef<HTMLDivElement | null>(null);

    useEffect(() => {
        if (ref.current) {
            ref.current.scrollLeft = ref.current.scrollWidth;
        }
    }, [searchParams]);

    return (
        <Stack
            ref={ref}
            direction="row"
            sx={{
                maxWidth: '200px',
                overflow: 'auto',
                gap: '4px',
                '&::-webkit-scrollbar': {
                    // height: '2px',
                    display: 'none',
                },
            }}
        >
            {Object.keys(searchParams)
                .filter((k: any) => SEARCH_KEY.includes(k))
                .map((v, k) => {
                    return (
                        <Stack
                            direction="row"
                            key={`key-search-${v}-${k}`}
                            sx={{
                                whiteSpace: 'nowrap',
                                padding: '2px 12px',
                                alignItems: 'center',
                                width: 'fit-content',
                                borderRadius: '12px',
                                background: '#F8F8F8',
                            }}
                        >
                            <Typography
                                component="span"
                                sx={{
                                    color: '#55595D',
                                    fontSize: '14px',
                                    fontStyle: 'normal',
                                    fontWeight: 400,
                                    lineHeight: '20px',
                                    marginRight: '4px',
                                }}
                            >
                                {(SEARCH_KEY_VALUE as any)[v]}
                            </Typography>
                            <Typography
                                component="span"
                                sx={{
                                    color: '#55595D',
                                    fontSize: '14px',
                                    fontStyle: 'normal',
                                    fontWeight: 400,
                                    lineHeight: '20px',
                                }}
                            >
                                &ldquo;
                            </Typography>
                            <Typography
                                component="span"
                                sx={{
                                    color: '#007DC0',
                                    fontSize: '14px',
                                    fontStyle: 'normal',
                                    fontWeight: 400,
                                    lineHeight: '20px',
                                }}
                            >
                                {(searchParams as any)[v]}
                            </Typography>
                            <Typography
                                component="span"
                                sx={{
                                    color: '#55595D',
                                    fontSize: '14px',
                                    fontStyle: 'normal',
                                    fontWeight: 400,
                                    lineHeight: '20px',
                                }}
                            >
                                &rdquo;
                            </Typography>

                            <CloseRoundedIcon
                                onClick={() => {
                                    let newSearchParams: any = { ...searchParams };
                                    if (Object.keys(newSearchParams).includes(v)) {
                                        delete newSearchParams[v];
                                    }

                                    const url = generateURLWithQueryParams(
                                        pathname,
                                        newSearchParams
                                    );
                                    router.replace(url);
                                }}
                                sx={{ fontSize: '14px', cursor: 'pointer', margin: '2px' }}
                            />
                        </Stack>
                    );
                })}
        </Stack>
    );
};
