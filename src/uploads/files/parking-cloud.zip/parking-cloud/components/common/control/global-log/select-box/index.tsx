import { OptionSelect } from '@/components/common/input/text-field-form/text-field-form-select';
import { Stack, Typography } from '@mui/material';
import SelectTypeDataOption from './type-data-option';
import SelectTypeActionOption from './type-action-option';

export interface ISelectOptionGlobalLogProps {
    setCaseHistory: (v: any) => void;
    setCaseDataHistory: (v: any) => void;
}

export default function SelectOptionGlobalLog(props: ISelectOptionGlobalLogProps) {
    const { setCaseHistory, setCaseDataHistory } = props;

    return (
        <Stack direction="row" sx={{ gap: '16px' }}>
            <Stack
                direction={{ xs: 'column', lg: 'row' }}
                alignItems={{ xs: 'flex-start', lg: 'center' }}
                sx={{ gap: { xs: '0px', lg: '16px' } }}
            >
                <Typography sx={{ fontSize: '14px', fontWeight: 500, color: '#55595D' }}>
                    Loại thao tác
                </Typography>
                <SelectTypeActionOption onChange={setCaseHistory} />
            </Stack>

            <Stack
                direction={{ xs: 'column', lg: 'row' }}
                alignItems={{ xs: 'flex-start', lg: 'center' }}
                sx={{ gap: { xs: '0px', lg: '16px' } }}
            >
                <Typography sx={{ fontSize: '14px', fontWeight: 500, color: '#55595D' }}>
                    Loại dữ liệu
                </Typography>
                <SelectTypeDataOption onChange={setCaseDataHistory} />
            </Stack>
        </Stack>
    );
}
