import { vehicleColor } from '@/constants/vehicle-color';
import { VehicleModel } from '@/models/vehicle.model';
import { renderVehicleColor } from '@/ultis/global-func';
import SyncIcon from '@mui/icons-material/Sync';
import { Stack, TableCell, TableRow, Typography } from '@mui/material';
import moment from 'moment';
import Image from 'next/image';
import { RowActionComponent } from './row-action';

const BACKEND_DOMAIN = process.env.NEXT_PUBLIC_SERVER_PARKING_DOMAIN;
interface ITableControlRow {
    index: number;
    isChoose: boolean;
    data: VehicleModel;
    changeChoose: (id: string) => void;
}

export const TableControlRow = (props: ITableControlRow) => {
    const { index, data, changeChoose, isChoose } = props;

    return (
        <>
            <TableRow
                sx={{
                    height: '60px',
                    maxHeight: '60px',
                    backgroundColor: () => {
                        if (isChoose) {
                            return '#DAF2FF';
                        } else {
                            return '#fff';
                        }
                    },
                    border: '1px solid #E3E5E5 !important',
                    transition: 'all ease .3s',
                    boxSizing: 'border-box',
                    '&:hover ': isChoose
                        ? {}
                        : {
                              backgroundColor: '#DAF2FF',
                          },
                }}
            >
                <TableCell
                    align="center"
                    sx={{
                        width: '48px',
                        padding: 'unset',
                        position: 'relative',
                        userSelect: 'none',
                    }}
                >
                    <Stack
                        sx={{ display: 'flex !important' }}
                        justifyContent="center"
                        alignItems="center"
                    >
                        <Stack
                            sx={{
                                width: '16px',
                                height: '16px',
                                borderRadius: '4px',
                                backgroundColor: isChoose ? '#007DC0' : '#fff',
                                boxShadow:
                                    '0px 0px 0px 1px rgba(70, 79, 96, 0.16), 0px 1px 1px 0px rgba(0, 0, 0, 0.10)',
                                cursor: 'pointer',
                            }}
                            justifyContent="center"
                            alignItems="center"
                            onClick={() => {
                                changeChoose(data.ID);
                            }}
                        >
                            <Image
                                src="/icons/checked-white.svg"
                                width={9}
                                height={6}
                                alt="checked"
                            />
                        </Stack>
                    </Stack>
                </TableCell>

                <TableCell align="center" sx={{ width: '40px', padding: 'unset' }}>
                    <Typography
                        sx={{
                            // color: isExpland ? '#fff' : '#323232',
                            fontSize: { xs: '14px', md: '16px' },
                            fontStyle: 'normal',
                            fontWeight: 400,
                            lineHeight: '20px',
                            width: '100%',
                            wordBreak: 'break-word',
                        }}
                    >
                        {index}
                    </Typography>
                </TableCell>
                <TableCell
                    align="left"
                    sx={{
                        // width: { xs: '200px', lg: 'unset' },
                        paddingLeft: '0px 0px 0px 16px',
                    }}
                >
                    <Typography
                        sx={{
                            // color: isExpland ? '#fff' : '#323232',
                            fontSize: { xs: '13px', lg: '14px' },
                            fontStyle: 'normal',
                            fontWeight: '400',
                            lineHeight: 'normal',
                            width: '100%',
                            wordBreak: 'break-word',
                        }}
                    >
                        {data?.PlateNumber ?? ''}
                    </Typography>
                </TableCell>
                <TableCell
                    align="left"
                    sx={{
                        // width: { xs: '200px', lg: 'unset' },
                        paddingLeft: '0px 0px 0px 16px',
                    }}
                >
                    <Typography
                        sx={{
                            // color: isExpland ? '#fff' : '#323232',
                            fontSize: { xs: '13px', lg: '14px' },
                            fontStyle: 'normal',
                            fontWeight: '400',
                            lineHeight: 'normal',
                            width: '100%',
                            wordBreak: 'break-word',
                        }}
                    >
                        {data?.VehicleTypeId?.Name ?? ''}
                    </Typography>
                </TableCell>
                <TableCell
                    align="left"
                    sx={{
                        // width: { xs: '160px', lg: 'unset' },
                        paddingLeft: '0px 0px 0px 16px',
                    }}
                >
                    <Typography
                        sx={{
                            // color: isExpland ? '#fff' : '#323232',
                            fontSize: { xs: '13px', lg: '14px' },
                            fontStyle: 'normal',
                            fontWeight: '500',
                            lineHeight: 'normal',
                            width: '100%',
                            wordBreak: 'break-word',
                        }}
                    >
                        {data?.VehicleBrand ?? ''}
                    </Typography>
                </TableCell>
                <TableCell
                    align="center"
                    sx={{
                        // width: { xs: '130px', lg: 'unset' },
                        padding: '0px 0px 0px 16px',
                    }}
                >
                    <Stack
                        direction="row"
                        sx={{ gap: '4px', width: '100%', display: 'flex !important' }}
                        justifyContent="center"
                    >
                        {renderVehicleColor(data?.VehicleColor ?? '--')
                            .filter((v) => {
                                const color = vehicleColor.find((c) => c.name === v.name);
                                return Boolean(color);
                            })
                            .map((v: any) => {
                                const color: any = vehicleColor.find((c) => c.name === v.name);

                                return (
                                    <Stack
                                        key={color.value}
                                        sx={{
                                            width: '16px',
                                            height: '16px',
                                            borderRadius: '4px',
                                            border: '1px solid #D0D0D0',
                                            background: color.value,
                                        }}
                                    />
                                );
                            })}
                    </Stack>
                </TableCell>
                <TableCell
                    align="center"
                    sx={{
                        // width: { xs: '130px', lg: 'unset' },
                        paddingLeft: '0px 0px 0px 16px',
                    }}
                >
                    <Typography
                        sx={{
                            // color: isExpland ? '#fff' : '#323232',
                            fontSize: { xs: '13px', lg: '14px' },
                            fontStyle: 'normal',
                            fontWeight: '400',
                            lineHeight: 'normal',
                            width: '100%',
                            wordBreak: 'break-word',
                        }}
                    >
                        {data?.MemberId?.Name ?? ''}
                    </Typography>
                </TableCell>
                <TableCell
                    align="center"
                    sx={{
                        // width: { xs: '130px', lg: 'unset' },
                        paddingLeft: '0px 0px 0px 16px',
                    }}
                >
                    <Typography
                        sx={{
                            // color: isExpland ? '#fff' : '#323232',
                            fontSize: { xs: '13px', lg: '14px' },
                            fontStyle: 'normal',
                            fontWeight: '400',
                            lineHeight: 'normal',
                            width: '100%',
                            wordBreak: 'break-word',
                        }}
                    >
                        {data?.MemberId?.Address ?? ''}
                    </Typography>
                </TableCell>
                <TableCell
                    align="center"
                    sx={{
                        // width: { xs: '130px', lg: 'unset' },
                        paddingLeft: '0px 0px 0px 16px',
                    }}
                >
                    <Typography
                        sx={{
                            // color: isExpland ? '#fff' : '#323232',
                            fontSize: { xs: '13px', lg: '14px' },
                            fontStyle: 'normal',
                            fontWeight: '400',
                            lineHeight: 'normal',
                            width: '100%',
                            wordBreak: 'break-word',
                        }}
                    >
                        {data?.ActivationDate
                            ? moment(data.ActivationDate).format('DD/MM/yyyy')
                            : ''}
                    </Typography>
                </TableCell>
                <TableCell
                    align="center"
                    sx={{
                        // width: { xs: '130px', lg: 'unset' },
                        paddingLeft: '0px 0px 0px 16px',
                    }}
                >
                    <Typography
                        sx={{
                            // color: isExpland ? '#fff' : '#323232',
                            fontSize: { xs: '13px', lg: '14px' },
                            fontStyle: 'normal',
                            fontWeight: '400',
                            lineHeight: 'normal',
                            width: '100%',
                            wordBreak: 'break-word',
                        }}
                    >
                        {data?.ExpirationDate
                            ? moment(data.ExpirationDate).format('DD/MM/yyyy')
                            : ''}
                    </Typography>
                </TableCell>

                <TableCell sx={{ width: '40px', paddingLeft: '0px 0px 0px 16px' }}>
                    <Stack
                        sx={{ display: 'flex !important', width: '100%' }}
                        justifyContent="center"
                        alignItems="center"
                    >
                        <SyncIcon
                            sx={{
                                transform: 'scaleY(-1) rotate(-45deg)',
                                color: '#CDD2D1',
                                transition: 'all ease .5s',
                            }}
                        />
                    </Stack>
                </TableCell>
                <RowActionComponent
                    isExpland={false}
                    item={''}
                    changeQuickEditId={function (): void {
                        throw new Error('Function not implemented.');
                    }}
                    reload={function (): void {
                        throw new Error('Function not implemented.');
                    }}
                />
            </TableRow>

            {/* <MemberDetailComponent isExpland={isExpland} data={dataTransform} reload={reload} /> */}
        </>
    );
};
