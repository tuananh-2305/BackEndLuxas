import { Stack, Typography } from '@mui/material';
import DialogCreateMemberVehicle from '@/components/dialog/dialog-create-member-vehicle';
import dynamic from 'next/dynamic';
// import { LayoutControlNavigationComponent } from './navigation';

const LayoutControlNavigationComponent = dynamic(
    () => import('./navigation').then((mod) => mod.LayoutControlNavigationComponent),
    {
        ssr: false,
    }
);

import ActionBtn from '@/components/dashboard/topbar/components/action-btn';
import { DialogCreateCard } from '@/components/dialog/dialog-create-card-v2';
import { useAppSelector } from '@/hooks';
import AddRoundedIcon from '@mui/icons-material/AddRounded';
import { useRouter } from 'next/router';
import { useState } from 'react';
import DialogCraeteVisitorCard from '@/components/dialog/dialog-visitor-card/create';

interface IControlComponentHead {
    caseExtra: 'direct-to-create' | 'sub-navigation' | 'hidden';
    fecthData?: () => void;
}

export const ControlComponentHead = (props: IControlComponentHead) => {
    const { caseExtra, fecthData } = props;
    const router = useRouter();
    const pathName = router.route.split('/').at(-1);

    const parkingChoose = useAppSelector((state) => state.parking.chooseDashboard);
    const profile = useAppSelector((state) => state.common.profile);

    const [openDialogCreate, setOpenDialogCreate] = useState(false);

    const handleClickCreateBtn = () => {
        switch (pathName) {
            case 'member':
            case 'card':
            case 'elevator-card':
            case 'vehicel':
                router.push('/settings/member/create');
                break;
            case 'visitor-card':
                setOpenDialogCreate(true);
                break;
            default:
                break;
        }
    };

    return (
        <Stack
            direction="row"
            sx={{
                backgroundColor: '#fff',
                height: '70px',
                minHeight: '70px',
                width: '100%',
                position: 'relative',
                borderRadius: '11px',
            }}
            alignItems="center"
        >
            <LayoutControlNavigationComponent />

            {caseExtra === 'direct-to-create' &&
            (profile?.IsAdmin ||
                profile?.IsSupperAdmin ||
                parkingChoose?.SystemRoleSetting?.Insert) ? (
                <Stack
                    onClick={handleClickCreateBtn}
                    sx={{
                        backgroundColor: '#007DC0',
                        position: 'absolute',
                        right: '32px',
                        width: '130px',
                        height: '40px',
                        borderRadius: '6px',
                        padding: '0px 16px',
                        cursor: 'pointer',
                    }}
                    alignItems="center"
                    justifyContent="space-between"
                    direction="row"
                >
                    <Stack
                        sx={{
                            width: { xs: '20px', lg: '24px' },
                            height: { xs: '20px', lg: '24px' },
                            backgroundColor: '#fff',
                            borderRadius: { xs: '2px', lg: '5px' },
                        }}
                        justifyContent="center"
                        alignItems="center"
                    >
                        <AddRoundedIcon sx={{ color: '#007DC0' }} />
                    </Stack>
                    <Typography
                        sx={{
                            color: '#fff',
                            fontSize: { xs: '14px', lg: '16px' },
                            fontStyle: 'normal',
                            fontWeight: '700',
                            lineHeight: 'normal',
                        }}
                    >
                        TẠO MỚI
                    </Typography>
                </Stack>
            ) : (
                <></>
            )}
            {caseExtra === 'sub-navigation' ? (
                <Stack sx={{ position: 'absolute', right: '32px' }}>
                    <ActionBtn />
                </Stack>
            ) : (
                <></>
            )}
            {/* create card dialog */}
            {/* {parkingChoose?.ID &&
                openDialogCreate &&
                (pathName == 'elevator-card' || pathName == 'card') && (
                    <DialogCreateCard
                        close={() => setOpenDialogCreate(false)}
                        onlyElevator={pathName == 'elevator-card'}
                        reload={function (): void {
                            if (fecthData) fecthData();
                        }}
                    />
                )} */}
            {/* create visitor card */}
            {parkingChoose?.ID && openDialogCreate && pathName == 'visitor-card' && (
                <DialogCraeteVisitorCard
                    handleClose={() => setOpenDialogCreate(false)}
                    open={openDialogCreate}
                    handleReload={function (): void {
                        if (fecthData) fecthData();
                    }}
                />
            )}
            {/* vehicle */}
            {parkingChoose?.ID && openDialogCreate && pathName == 'vehicel' && (
                <DialogCreateMemberVehicle
                    open={openDialogCreate}
                    handleReload={function (): void {
                        if (fecthData) fecthData();
                    }}
                    handleClose={() => setOpenDialogCreate(false)}
                />
            )}
        </Stack>
    );
};
