import { LocalStoreControl } from '@/hooks/local-storage';
import { generateURLWithQueryParams } from '@/ultis/global-func';
import CancelRoundedIcon from '@mui/icons-material/CancelRounded';
import SearchIcon from '@mui/icons-material/Search';
import { Stack, Typography } from '@mui/material';
import Image from 'next/image';
import { usePathname, useRouter, useSearchParams } from 'next/navigation';
import { useCallback, useMemo, useRef, useState } from 'react';

interface ISearchParamns {
    page: string | null;
    search: string | null;
}

const localStoreControl = new LocalStoreControl();
interface IGlobalLogFilterBox {}
export const GlobalLogFilterBox = (props: IGlobalLogFilterBox) => {
    const searchParamAction = useSearchParams();
    const router = useRouter();
    const pathname = usePathname();

    const searhParams: ISearchParamns = useMemo(() => {
        let result: any = {};
        if (searchParamAction.get('page')) {
            result['page'] = searchParamAction.get('page');
        }
        if (searchParamAction.get('search')) {
            result['search'] = searchParamAction.get('search');
        }
        return result;
    }, [searchParamAction]);

    const isHaveSearchData = useCallback(() => {
        return Boolean(searhParams.search);
    }, [searhParams.search]);

    const searchCurrentcase = 'search';

    const [searchCurrentValue, setSearchCurrentValue] = useState<string>('');
    const [historySearch, setHistorySearch] = useState<string[]>([]);

    const ref = useRef<HTMLDivElement | null>(null);
    const inputRef = useRef<HTMLInputElement | null>(null);
    const boxRef = useRef<HTMLDivElement | null>(null);

    return (
        <Stack
            sx={{
                width: { xs: '300px', lg: '400px', xl: '526px' },
                height: '46px',
                border: '1px solid #E3E5E5',
                boxSizing: 'border-box',
                backgroundColor: 'white',
                borderRadius: '8px',
                zIndex: -1,
            }}
            direction="row"
            alignItems="center"
            onKeyDown={(event) => {
                if (event.key === 'Enter' && Boolean(searchCurrentValue)) {
                    const url = generateURLWithQueryParams(pathname, {
                        ...searhParams,
                        page: 1,
                        [searchCurrentcase]: searchCurrentValue,
                    } as any);

                    router.replace(url);

                    localStoreControl.saveMembersHistorySearch([
                        searchCurrentValue,
                        ...historySearch,
                    ]);
                    // setSearchCurrentValue('');
                    if (ref.current) {
                        ref.current.style.opacity = '0';
                        ref.current.style.visibility = 'hidden';
                    }
                }
            }}
        >
            <Stack
                sx={{
                    aspectRatio: '1/1',
                    border: '1px solid',
                    borderRadius: '8px 0px 0px 8px',
                    height: '46px',
                    cursor: 'pointer',
                    position: 'relative',
                    transition: 'all ease .3s',
                    borderColor: '#E3E5E5',
                }}
                onClick={() => {
                    router.replace(pathname);
                }}
                justifyContent="center"
                alignItems="center"
            >
                <Image src={'/icons/filter-gray.svg'} width={24} height={24} alt="filter" />
            </Stack>

            <Stack
                direction="row"
                alignItems="center"
                sx={{ position: 'relative', width: '100%', borderRadius: '0px 8px 8px 0px' }}
                ref={boxRef}
                onClick={() => {
                    if (inputRef?.current) {
                        inputRef?.current?.focus();
                    }
                }}
            >
                <SearchIcon style={{ margin: '10px 8px 10px 16px', color: '#E3E5E5' }} />

                <Stack direction="row" sx={{ flex: 1 }}>
                    <Stack
                        sx={{
                            position: 'relative',
                            height: '100%',
                            width: '100%',
                        }}
                        alignItems="center"
                    >
                        <Typography
                            component={'input'}
                            ref={inputRef}
                            type="text"
                            sx={{
                                flex: 1,
                                border: 'none',
                                outline: 'none',
                                color: '#323232',
                                fontSize: '16px',
                                fontStyle: 'normal',
                                padding: '0px 4px',
                                width: '100%',
                                fontWeight: 400,
                                lineHeight: '20px',
                                backgroundColor: 'transparent',
                            }}
                            value={searchCurrentValue}
                            onChange={(event) => {
                                const { value } = event.target;
                                setSearchCurrentValue(value);
                            }}
                        />
                    </Stack>
                </Stack>
                {isHaveSearchData() ? (
                    <CancelRoundedIcon
                        sx={{
                            transition: 'all ease .3s',
                            cursor: 'pointer',
                            fontSize: '20px',
                            color: '#E3E5E5',
                            margin: '13px 16px ',
                            '&:hover ': {
                                transition: 'all ease .3s',
                                color: '#323232',
                            },
                        }}
                        onClick={() => {
                            router.replace(pathname);
                            setSearchCurrentValue('');
                        }}
                    />
                ) : (
                    <></>
                )}
            </Stack>
        </Stack>
    );
};
