import { historyInOutApi } from '@/api/history-in-out-api';
import { systemRoleApi } from '@/api/key-system-role';
import ImageNextjs from '@/components/common/image';
import { useAppSelector } from '@/hooks';
import { SystemRole } from '@/models/syste-role.model';
import { VehicleModel } from '@/models/vehicle.model';
import CloseRoundedIcon from '@mui/icons-material/CloseRounded';
import { Button, Dialog, DialogActions, Stack, Typography } from '@mui/material';
import { useEffect, useState } from 'react';
import styles from './stylem.module.css';
import { TableCheckVehicle } from './table-check';
import { memberVehicleApi } from '@/api/member-vehicle-api';
import { showSnackbarWithClose } from '@/hooks/useSnackbarWithClose';
export interface ConfirmVehicleDialogProps {
    open: boolean;
    vehicleChoose: VehicleModel[];
    onClose: () => void;
    reload: () => void;
}

export function ConfirmVehicleDialog(props: ConfirmVehicleDialogProps) {
    const { onClose, open, vehicleChoose, reload } = props;

    const packingChoose = useAppSelector((state) => state.parking.chooseDashboard);
    const [CardNumberInParking, setCardNumberInParking] = useState<string[]>([]);
    const [hasRoleDelete, setHasRoleDelete] = useState(false);

    const handleCheckCard = async () => {
        if (!packingChoose) return;

        let vehicleIds = vehicleChoose.map((v) => v.ID ?? '');

        let payload = { ParkingId: packingChoose.ID, Data: vehicleIds };
        try {
            let { data } = await historyInOutApi.checkByPlateNumberAndParking(payload);
            setCardNumberInParking(data);
        } catch (error) {
            //
        }
    };

    const handleChangeRole = async () => {
        if (!packingChoose) return;
        try {
            let { data } = await systemRoleApi.groupRoleByParkingId(packingChoose.ID);
            let systemRoles: SystemRole[] = data;
            let systemRole = systemRoles.filter(
                (item) => item?.KeySettingId?.KeyWord == 'DELETE_CARD_AND_VEHICLE'
            );

            let hasRole = false;
            if (systemRole.length > 0) {
                let role = systemRole[0];
                if (role.KeySettingId.IsValue) {
                    hasRole = false;
                } else {
                    hasRole = role.IsUse;
                }
            } else {
                hasRole = false;
            }
            setHasRoleDelete(hasRole);
        } catch (error) {}
    };

    const isVehicleInParking = CardNumberInParking.length > 0 ? hasRoleDelete : false;

    useEffect(() => {
        handleCheckCard();
        handleChangeRole();
    }, []);

    const handleDelete = async () => {
        if (!packingChoose) return;
        let data = {
            ListID: vehicleChoose.map((i) => i.ID),
            ParkingId: packingChoose.ID,
        };
        try {
            const { data: dataRes } = await memberVehicleApi.deleteMultiple(data);
            if (dataRes.length === 0) {
                showSnackbarWithClose('Xóa phương tiện thành công', {
                    variant: 'success',
                });

                reload();
                onClose();
            } else {
                dataRes.forEach((element: any) => {
                    showSnackbarWithClose(element.Error, {
                        variant: 'error',
                    });
                });
            }
        } catch (error: any) {
            if (Array.isArray(error?.response?.data?.message)) {
                error?.response?.data?.message.forEach((item: any) => {
                    showSnackbarWithClose(item, {
                        variant: 'error',
                    });
                });
            } else {
                showSnackbarWithClose(
                    error?.response ? error.response.data?.message : error.message,
                    {
                        variant: 'error',
                    }
                );
            }
        }
    };

    return (
        <Dialog onClose={onClose} open={open}>
            <Stack className={styles.container}>
                <Stack className={styles.closeBtn} onClick={onClose}>
                    <CloseRoundedIcon className={styles.closeIcon} />
                </Stack>

                <ImageNextjs
                    path={isVehicleInParking ? '/icons/warning_2.svg' : '/icons/bin_icon.svg'}
                    sx={{ width: '60px', height: '60px' }}
                />
                <Typography className={styles.textTitle}>
                    {isVehicleInParking
                        ? 'Vui lòng đưa xe ra khỏi bãi để xóa dữ liệu'
                        : 'Bạn có chắc chắn xóa phương tiện này?'}
                </Typography>
                <Typography className={styles.textSubTitle}>
                    {isVehicleInParking
                        ? `${CardNumberInParking.length} phương tiện còn trong bãi`
                        : 'Sau khi xóa, dữ liệu sẽ được lưu trữ trong vòng 30 ngày.'}
                </Typography>
                {/* <Typography className={styles.textSecond}>
                    Số thẻ:
                    <Typography className={styles.textBold} component="span">
                        {cardChoose.length}
                    </Typography>
                    |&nbsp;
                    <Typography className={styles.textHighlight} component="span">
                        Có phương tiện liên kết
                    </Typography>
                </Typography> */}
                <TableCheckVehicle
                    vehicleList={vehicleChoose}
                    CardNumberInParking={CardNumberInParking}
                />
            </Stack>
            <DialogActions className={styles.dialogAction}>
                <Button className={styles.cancelBtn} variant="contained" onClick={onClose}>
                    Không
                </Button>
                <Button
                    className={styles.submitBtn}
                    variant="contained"
                    onClick={handleDelete}
                    autoFocus
                >
                    Có
                </Button>
            </DialogActions>
        </Dialog>
    );
}
