import { Stack, Typography } from '@mui/material';
import * as React from 'react';
import Image from 'next/image';

export interface ITableEmptyProps {}

export function TableEmpty(props: ITableEmptyProps) {
    return (
        <Stack
            sx={{
                position: 'fixed',
                bottom: '140px',
                width: '100%',
            }}
            justifyContent="center"
            alignItems="center"
        >
            <Stack sx={{ gap: '48px' }}>
                <Image src="/icons/empty-page.svg" width={336} height={248} alt="empty-page" />
                <Stack sx={{ gap: '6px' }}>
                    <Typography
                        sx={{
                            userSelect: 'none',
                            color: '#323232',
                            textAlign: 'center',
                            fontSize: '24px',
                            fontStyle: 'normal',
                            fontWeight: 700,
                            lineHeight: 'normal',
                        }}
                    >
                        Không có dữ liệu để hiển thị
                    </Typography>
                    <Typography
                        sx={{
                            userSelect: 'none',
                            color: '#55595D',
                            textAlign: 'center',
                            fontSize: '16px',
                            fontStyle: 'normal',
                            fontWeight: 400,
                            lineHeight: '20px',
                        }}
                    >
                        Nhấn “
                        <span
                            style={{
                                color: '#007DC0',
                                fontSize: '16px',
                                fontStyle: 'normal',
                                fontWeight: 400,
                                lineHeight: '20px',
                            }}
                        >
                            TẠO MỚI
                        </span>
                        ” để thêm dữ liệu
                    </Typography>
                </Stack>
            </Stack>
        </Stack>
    );
}
