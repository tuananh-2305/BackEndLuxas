export function renderAction(action: string) {
    let data = {
        iconPath: '',
        iconPathActive: '',
        color: '',
        text: '',
    };
    switch (action) {
        case 'CREATE':
            data = {
                iconPath: '/icons/add.svg',
                iconPathActive: '/icons/add_active.svg',
                color: '#22AE68',
                text: 'Tạo mới',
            };
            break;
        case 'UPDATE':
            data = {
                iconPath: '/icons/update_icon.svg',
                iconPathActive: '/icons/update_icon_active.svg',
                color: '#007DC0',
                text: 'Cập nhật',
            };
            break;
        case 'DELETE':
            data = {
                iconPath: '/icons/remove_icon.svg',
                iconPathActive: '/icons/remove_icon_active.svg',
                color: '#E42727',
                text: 'Xóa',
            };
            break;
        default:
            data = {
                iconPath: '',
                iconPathActive: '',
                color: '',
                text: '',
            };
            break;
    }
    return data;
}
