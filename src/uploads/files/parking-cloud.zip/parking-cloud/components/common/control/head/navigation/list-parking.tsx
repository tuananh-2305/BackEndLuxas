import { useAppDispatch, useAppSelector } from '@/hooks';
import { Stack, Typography } from '@mui/material';
import Image from 'next/image';

import { changeParkingChooseDashboard } from '@/redux/index';

interface IListParkingComponent {
    open: boolean;
}

export const ListParkingComponent = (props: IListParkingComponent) => {
    const { open } = props;

    const parkings = useAppSelector((state) => state.parking.parkings);
    const parkingChoose = useAppSelector((state) => state.parking.chooseDashboard);
    const dispatch = useAppDispatch();

    const changeParking = (parking: any) => {
        if (parking.ID !== parkingChoose?.ID) {
            const action = changeParkingChooseDashboard({ parking });
            dispatch(action);
        }
    };

    return (
        <Stack
            sx={{
                overflow: 'auto',
                '&::-webkit-scrollbar ': {
                    display: 'none',
                },
                maxHeight: '220px',
                paddingTop: open ? '10px' : '0',
                gap: '8px',
                visibility: open ? 'visible' : 'hidden',
                opacity: open ? 1 : 0,
                height: open ? 'unset' : '0px',
                transition: 'all ease .3s',
                paddingBottom: !open ? 'unset' : '8px',
                marginBottom: !open ? 'unset' : '8px',
                px: '10px',
            }}
            alignItems="center"
        >
            {parkings.map((p) => {
                return (
                    <Stack
                        key={p.ID}
                        direction="row"
                        sx={{
                            width: '263px',
                            height: '70px',
                            borderRadius: '8px',
                            padding: '8px',
                            background: p.ID === parkingChoose?.ID ? '#55595D' : '#FFF',
                            cursor: 'pointer',
                            boxShadow: '0px 1px 10px 0px rgba(34, 34, 34, 0.10)',
                            transition: 'all ease .3s',
                            '&:hover':
                                p.ID === parkingChoose?.ID
                                    ? {}
                                    : {
                                          background: '#DAF2FF',
                                      },
                        }}
                        alignItems={'center'}
                        onClick={() => {
                            changeParking(p);
                        }}
                    >
                        <Image
                            src={
                                p.ID === parkingChoose?.ID
                                    ? '/icons/parking-white.svg'
                                    : '/icons/parking-round-gray.svg'
                            }
                            width={24}
                            height={24}
                            alt="photo"
                        />

                        <Stack
                            sx={{
                                backgroundColor: '#CDD2D1',
                                width: '1px',
                                height: '44px',
                                margin: '0px 8px',
                            }}
                        />

                        <Stack>
                            <Typography
                                sx={{
                                    color: p.ID === parkingChoose?.ID ? '#FFF' : '#55595D',
                                    fontSize: '16px',
                                    fontStyle: 'normal',
                                    fontWeight: 500,
                                    lineHeight: '24px',
                                }}
                            >
                                {p.Name}
                            </Typography>
                            <Typography
                                sx={{
                                    color: p.ID === parkingChoose?.ID ? '#FFF' : '#55595D',
                                    fontSize: '14px',
                                    fontStyle: 'normal',
                                    fontWeight: 400,
                                    lineHeight: '20px',
                                }}
                            >
                                {p.Address}
                            </Typography>
                        </Stack>
                    </Stack>
                );
            })}
        </Stack>
    );
};
