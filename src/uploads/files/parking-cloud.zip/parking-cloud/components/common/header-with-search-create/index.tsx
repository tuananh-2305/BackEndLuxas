import AddBoxIcon from '@mui/icons-material/AddBox';
import { IconButton, Stack, Tooltip, Typography } from '@mui/material';
import {
    changeIsCreateDialog,
    changeSearchText,
    clearControl,
    updateLeftbarOpen,
} from '@/redux/index';
import { ChangeEvent, useEffect, useState } from 'react';
import { useAppDispatch, useAppSelector } from '@/hooks/useReudx';
import Image from 'next/image';
import { useDebouncedValue } from '@mantine/hooks';
import MenuOpenIcon from '@mui/icons-material/MenuOpen';

export const HeaderWithSearchAndCreate = () => {
    const dispatch = useAppDispatch();

    const openAdminBar = useAppSelector((state) => state.common.leftBarStateOpen.admin);

    const [searchText, setSearchText] = useState('');
    const [debounced] = useDebouncedValue(searchText, 500);

    useEffect(() => {
        return () => {
            const action = clearControl();
            dispatch(action);
        };
    }, [dispatch]);

    useEffect(() => {
        const action = changeSearchText({ searchText: debounced });
        dispatch(action);
    }, [debounced, dispatch]);

    const handleOpenCreate = () => {
        const action = changeIsCreateDialog({ isOpen: true });
        dispatch(action);
    };

    return (
        <Stack
            sx={{
                padding: '10px',
                height: 'fit-content',
                justifyContent: 'space-between',
                width: '100%',
            }}
            alignItems="center"
            direction="row"
        >
            <Stack sx={{ direction: 'row' }} spacing={'20px'} direction="row">
                <Tooltip title="Mở thanh công cụ trái.">
                    <IconButton
                        sx={{
                            transform: 'rotate(180deg)',
                            display: openAdminBar ? 'none' : 'flex',
                        }}
                        onClick={() => {
                            const action = updateLeftbarOpen({ view: 'admin', open: true });
                            dispatch(action);
                        }}
                    >
                        <MenuOpenIcon />
                    </IconButton>
                </Tooltip>

                <Stack
                    onClick={() => handleOpenCreate()}
                    direction="row"
                    sx={{
                        padding: '5px 20px',
                        backgroundColor: '#78C6E7',
                        borderRadius: '10px',
                        cursor: 'pointer',
                    }}
                    spacing={'10px'}
                    alignItems="center"
                >
                    <Stack>
                        <AddBoxIcon sx={{ color: '#595959' }} />
                    </Stack>
                    <Stack>
                        <Typography sx={{ userSelect: 'none', fontWeight: 700, color: '#fff' }}>
                            Tạo mới
                        </Typography>
                    </Stack>
                </Stack>
            </Stack>

            <Stack direction="row" sx={{ borderBottom: '1px solid #000000', padding: '5px' }}>
                <input
                    style={{ border: 'none', outline: 'none' }}
                    placeholder="Tìm kiếm..."
                    value={searchText}
                    onChange={(e) => {
                        const { value } = e.target;
                        setSearchText(value);
                    }}
                />
                <Image src="/icons/search.svg" width={24} height={24} alt="search" />
            </Stack>
        </Stack>
    );
};
