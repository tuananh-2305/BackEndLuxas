import {
    Button,
    Card,
    CardActions,
    CardContent,
    CardHeader,
    CardMedia,
    IconButton,
    MenuItem,
    Stack,
    Typography,
} from '@mui/material';
import DeleteIcon from '@mui/icons-material/Delete';
import ActionTable from '../action-table/action-table';
import EditIcon from '@mui/icons-material/Edit';

export interface IMediaCardProps {
    urlBackground: string;
    avatar: React.ReactNode;
    children?: React.ReactNode;
    title: string;
    CompanyName: string;
    handleCard?: () => void;
}

export default function MediaCard(props: IMediaCardProps) {
    const { urlBackground, title, avatar, children, CompanyName, handleCard } = props;
    return (
        <Card
            sx={{
                background: 'rgba(255, 255, 255, 0.5)',
                position: 'relative',
                borderRadius: '1rem',
                height: { xs: '250px', md: '300px' },
            }}
            onClick={handleCard}
        >
            <Stack
                sx={{
                    position: 'absolute',
                    top: '30%',
                    left: 5,
                    flexDirection: 'row',
                    // width: '100%',
                }}
            >
                {avatar}
                <Stack sx={{ ml: -2, zIndex: 0 }}>
                    <Stack
                        direction={'row'}
                        alignItems={'flex-start'}
                        spacing={1}
                        sx={{
                            pl: 3,
                            pr: 2,
                            mt: 0.8,
                            bgcolor: '#fff',
                            height: '30px',
                            borderRadius: '0px 37px 0px 0px',
                        }}
                    >
                        <Typography
                            sx={{
                                fontSize: '16px',
                                fontWeight: 600,
                                overflow: 'hidden',
                                display: '-webkit-box',
                                WebkitLineClamp: 1,
                                lineClamp: 1,
                                WebkitBoxOrient: 'vertical',
                            }}
                        >
                            {title}
                        </Typography>
                    </Stack>
                </Stack>
            </Stack>
            <CardMedia sx={{ height: '40%' }} image={urlBackground} title="green iguana" />
            <CardContent
                sx={{
                    height: '60%',
                    borderTop: '1px solid #D9D9D9',
                    zIndex: 2,
                    position: 'absolute',
                    width: `100%`,
                }}
            >
                <Stack sx={{ height: '100%', pt: 1 }}>
                    <Stack
                        sx={{
                            height: '60%',
                            justifyContent: 'center',
                            alignItems: 'center',
                            textAlign: 'center',
                        }}
                    >
                        <Typography
                            sx={{
                                fontSize: '16px',
                                fontWeight: 600,
                                color: '#000',
                                lineHeight: '20px',
                                textAlign: 'center',
                                overflow: 'hidden',
                                display: '-webkit-box',
                                WebkitLineClamp: 2,
                                lineClamp: 2,
                                WebkitBoxOrient: 'vertical',
                            }}
                        >
                            {CompanyName}
                        </Typography>
                    </Stack>
                    {children}
                </Stack>
            </CardContent>
            {/* <CardActions sx={{ height: '20%', justifyContent: 'flex-end' }}>{action}</CardActions> */}
        </Card>
    );
}
