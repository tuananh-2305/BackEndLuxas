import { CameraModel } from '@/models/parking.model';
import CardParking from './card-parking';
import { Stack, Typography } from '@mui/material';
import { StyledDot } from '../style-component';
import Image from 'next/image';
import { useEffect, useState } from 'react';

export interface ICardCameraProps {
    item: CameraModel;
}

export default function CardCamera(props: ICardCameraProps) {
    const { item } = props;
    const [isOnline, setIsOnline] = useState(true);
    return (
        <CardParking
            sx={{
                backgroundColor: 'rgba(217, 217, 217, 0.2)',
                color: '#55595D',
                '.card-title': {
                    fontSize: '14px',
                },
                '.card-content': {
                    fontSize: '12px',
                },
                p: 2,
                minHeight: '300px',
            }}
            title={item.Name}
            content={'Phân loại: Camera'}
            avatar={
                <Stack
                    sx={{
                        width: '40px',
                        height: '40px',

                        cursor: 'pointer',
                    }}
                    justifyContent="center"
                    alignItems="center"
                >
                    <Image
                        src="/icons/surveillance-cameras-two.svg"
                        width={24}
                        height={24}
                        alt="file-arrow"
                    />
                </Stack>
            }
        >
            {/* <Typography
                variant="caption"
                color={'inherit'}
                sx={{
                    whiteSpace: 'normal',
                    overflowWrap: 'break-word',
                }}
                component={'p'}
            >
                Luồng RTSP: {item.RTSP}
            </Typography> */}
            <Typography variant="caption" color={'inherit'} sx={{ overflow: 'hidden' }}>
                Mã box: {item?.Imei}
            </Typography>
            <Stack direction="row" sx={{}} spacing={'10px'} alignItems={'center'} mt={'auto'}>
                <StyledDot color={!isOnline ? '#E94F4F' : '#5EB14A'} />
                <Typography variant="caption" color={'inherit'}>
                    {isOnline ? 'Đang hoạt động' : 'Đang ngắt kết nối'}
                </Typography>
            </Stack>
        </CardParking>
    );
}
