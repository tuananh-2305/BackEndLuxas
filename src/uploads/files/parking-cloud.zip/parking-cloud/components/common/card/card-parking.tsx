import { Stack, Tooltip } from '@mui/material';
import IconButton, { IconButtonProps } from '@mui/material/IconButton';
import Typography from '@mui/material/Typography';
import { SxProps, Theme } from '@mui/material/styles';
interface ExpandMoreProps extends IconButtonProps {
    expand: boolean;
}

export interface ICardParkingProps {
    title: string;
    description?: string;
    content: string;
    count?: number;
    avatar?: React.ReactNode;
    itemActions?: React.ReactNode;
    sx?: SxProps<Theme>;
    children?: React.ReactNode;
}
export default function CardParking(props: ICardParkingProps) {
    const { title, description, content, count, itemActions, sx, avatar, children } = props;

    return (
        <Stack
            sx={{
                boxShadow: '0px 0px 10px 0px rgba(0,0,0,0.2)',
                borderRadius: '10px',
                backgroundColor: '#067DC0',
                color: '#fff',
                minWidth: 100,
                p: 1.2,
                ...sx,
            }}
        >
            <Stack>
                <Stack direction={'row'} alignItems={'center'} spacing={1}>
                    {avatar}
                    <Tooltip title={title}>
                        <Typography
                            variant="h5"
                            fontWeight={'600'}
                            component="h2"
                            flex={1}
                            color={'inherit'}
                            className="card-title"
                            sx={{
                                overflow: 'hidden',
                                display: '-webkit-box',
                                WebkitLineClamp: 2,
                                lineClamp: 2,
                                WebkitBoxOrient: 'vertical',
                                textOverflow: 'ellipsis',
                                wordWrap: 'break-word',
                            }}
                        >
                            {title}
                        </Typography>
                    </Tooltip>
                    {itemActions && itemActions}
                </Stack>
                <Typography
                    variant="body2"
                    sx={{
                        color: 'inherit',
                        overflow: 'hidden',
                        display: '-webkit-box',
                        WebkitLineClamp: 1,
                        lineClamp: 1,
                        WebkitBoxOrient: 'vertical',
                        textOverflow: 'ellipsis',
                        wordWrap: 'break-word',
                    }}
                >
                    {description}
                </Typography>
                <Typography variant="body2" color={'inherit'} className="card-content">
                    {content}
                </Typography>
            </Stack>
            {children}
            {count && (
                <Typography variant="h3" component={'p'} color={'inherit'} ml="auto">
                    {count}
                </Typography>
            )}
        </Stack>
    );
}
