import { Stack, Tooltip, Typography } from '@mui/material';
import { CompanyInterface } from '@/redux/index';
import Grid2 from '@mui/material/Unstable_Grid2';
import MediaCard from './card-media';
import { AvatarCustom } from '../avatar-next';
import DialogUpdateCompany from '@/components/dialog/dialog-update/dialog-update-company';
import { useState } from 'react';
import DialogDetailCompany from '@/components/dialog/dialog-detail/dialog-detail-company';
import DialogWarning from '@/components/dialog/dialog-warning';
import { companyApi } from '@/api/company-api';
import { showSnackbarWithClose } from '@/hooks/useSnackbarWithClose';
import { useRouter } from 'next/router';
const BACKEND_DOMAIN = process.env.NEXT_PUBLIC_SERVER_PARKING_DOMAIN;

interface CompanyCardItemProps {
    item: CompanyInterface;
    handleReload: () => void;
    handleDetail?: () => void;
}
export const CompanyCardItem = (props: CompanyCardItemProps) => {
    const { item, handleReload, handleDetail } = props;

    const router = useRouter();

    return (
        <Grid2 xs={12} sm={4} md={4} lg={3} xl={2}>
            <MediaCard
                urlBackground={
                    item.Background
                        ? BACKEND_DOMAIN + item.Background
                        : '/images/default_background_company.png'
                }
                avatar={
                    <AvatarCustom
                        src={item.Logo ? BACKEND_DOMAIN + item.Logo : ''}
                        alt="B"
                        sx={{ zIndex: 3 }}
                    />
                }
                title={item.SortName}
                CompanyName={item.Name}
                handleCard={handleDetail}
            >
                <Stack direction="row" justifyContent="center" sx={{ width: '100%', gap: '10px' }}>
                    <Typography
                        sx={{
                            fontSize: '13px',
                            fontWeight: 300,
                            fontStyle: 'italic',
                            pl: 0.5,
                            display: '-webkit-box',
                            WebkitLineClamp: 1,
                            lineClamp: 1,
                            WebkitBoxOrient: 'vertical',
                            overflow: 'hidden',
                            textOverflow: 'ellipsis',
                            maxWidth: '180px',
                            whiteSpace: 'pre-wrap',
                            wordBreak: 'break-word',
                            lineHeight: '20px',
                            color: '#55595D',
                        }}
                    >
                        {item.Email ? item.Email : 'Chưa đặt'}
                    </Typography>
                    -
                    <Typography
                        sx={{
                            fontSize: '13px',
                            fontWeight: 300,
                            fontStyle: 'italic',
                            pl: 0.5,
                            display: '-webkit-box',
                            WebkitLineClamp: 1,
                            lineClamp: 1,
                            WebkitBoxOrient: 'vertical',
                            overflow: 'hidden',
                            textOverflow: 'ellipsis',
                            maxWidth: '180px',
                            whiteSpace: 'pre-wrap',
                            wordBreak: 'break-word',
                            lineHeight: '20px',
                            color: '#55595D',
                        }}
                    >
                        {item.Phone ? item.Phone : 'Chưa đặt'}
                    </Typography>
                </Stack>
            </MediaCard>
        </Grid2>
    );
};
