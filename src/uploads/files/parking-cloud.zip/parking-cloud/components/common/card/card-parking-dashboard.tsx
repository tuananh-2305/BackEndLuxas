import { useAppDispatch, useAppSelector } from '@/hooks/useReudx';
import { changeParkingChoose, changeParkingChooseDashboard } from '@/redux/index';
import AddIcon from '@mui/icons-material/Add';
import ParkingIcon from '@mui/icons-material/LocalParking';
import MenuOpenIcon from '@mui/icons-material/MenuOpen';
import SettingsIcon from '@mui/icons-material/Settings';
import { Button, IconButton, Stack, Tooltip, Typography } from '@mui/material';
import { useRouter } from 'next/router';
import { useContext, useEffect, useState } from 'react';
import CardParking from '../../common/card/card-parking';
import LeftNav from '../../common/nav/left-nav';
import { StyledDot } from '../../common/style-component';
import DialogCreateParking from '../../dialog/dialog-create-parking';
import { ParkingModel } from '@/models/index';
import {
    PARKING_CHOSE_DASHBOARD,
    PARKING_CHOSE_SETTING,
    checkRoleRead,
    countOnline,
    getNameAddress,
    getRoleReport,
    showAddress,
} from '@/ultis/index';
import Image from 'next/image';
import { ContextLostHistory } from '@/components/lost-history';

export interface ICardParkingDashboardProps {
    parking: ParkingModel;
    isActived: boolean;
}

export default function CardParkingDashboard(props: ICardParkingDashboardProps) {
    const { parking, isActived } = props;
    const dispatch = useAppDispatch();
    const { device } = useContext(ContextLostHistory);
    const countOnlineNumber = countOnline(device);
    const deviceErr = device?.length - countOnlineNumber;

    const color = {
        red: '#E42727',
        white: '#ffffff',
        green: '#3CD856',
        grey1: '#CDD2D1',
        primary: '#007DC0',
        textBlack: '#323232',
        textBlack2: '#55595D',
    };

    return (
        // <Stack
        //     sx={{
        //         backgroundColor: isActived ? '#067DC0' : '#fff',
        //         padding: { xs: '10px', lg: '20px' },
        //         // boxShadow: '0px 4px 4px rgba(0, 0, 0, 0.25)',
        //         borderRadius: '15px',
        //         minHeight: 'fit-content',
        //         position: 'relative',
        //         cursor: 'pointer',
        //         '@keyframes glowing': {
        //             '0%': {
        //                 backgroundPosition: '0 0',
        //             },
        //             '50%': {
        //                 backgroundPosition: '400% 0;',
        //             },
        //             '100%': {
        //                 backgroundPosition: '0 0',
        //             },
        //         },

        //         color: isActived ? '#fff' : '#55595D',
        //         transition: 'all 0.5s ease',
        //     }}
        //     onClick={() => {
        //         if (isActived) return;

        //         const action = changeParkingChooseDashboard({
        //             parking: parking,
        //         });
        //         localStorage.setItem(PARKING_CHOSE_DASHBOARD, parking.ID);
        //         dispatch(action);
        //     }}
        // >
        //     <Stack
        //         direction="row"
        //         spacing={{ xs: '5px', lg: '10px' }}
        //         sx={{ position: 'relative' }}
        //         alignItems="stretch"
        //     >
        //         <Stack sx={{ transform: 'translateY(10px)' }}>
        //             <StyledDot
        //                 color={
        //                     !parking?.Device || parking?.Device?.length === 0
        //                         ? 'rgba(205, 210, 209, 1)'
        //                         : parking.Device.some((device) => !device.IsOnline)
        //                         ? '#E94F4F'
        //                         : '#00ff00'
        //                 }
        //             />
        //         </Stack>
        //         <Stack
        //             sx={{
        //                 flex: 1,
        //                 margin: '10px',
        //                 gap: { xs: '0px', lg: '10px' },
        //                 height: '100%',
        //             }}
        //         >
        //             <Typography
        //                 sx={{
        //                     fontSize: { xs: '18px', lg: '24px' },
        //                     fontWeight: 700,
        //                     color: 'inherit',
        //                 }}
        //             >
        //                 {parking.Name}
        //             </Typography>
        //             <Typography
        //                 sx={{
        //                     fontSize: '12px',
        //                     fontWeight: 300,
        //                     color: 'inherit',
        //                     overflow: 'hidden',
        //                     display: '-webkit-box',
        //                     WebkitLineClamp: 3,
        //                     lineClamp: 3,
        //                     WebkitBoxOrient: 'vertical',
        //                     textOverflow: 'ellipsis',
        //                     wordWrap: 'break-word',
        //                 }}
        //             >
        //                 {showAddress(
        //                     parking?.Address || '',
        //                     getNameAddress(parking?.Ward),
        //                     getNameAddress(parking?.District),
        //                     getNameAddress(parking?.Province)
        //                 )}
        //             </Typography>
        //         </Stack>
        //     </Stack>
        // </Stack>
        <Stack
            direction="row"
            sx={{
                width: '263px',
                height: '70px',
                borderRadius: '8px',
                padding: '8px',
                background: isActived ? '#55595D' : '#FFF',
                cursor: 'pointer',
                boxShadow: '0px 1px 10px 0px rgba(34, 34, 34, 0.10)',
                transition: 'all ease .3s',
                '&:hover': isActived
                    ? {}
                    : {
                          background: '#DAF2FF',
                      },
            }}
            alignItems={'center'}
            onClick={() => {
                if (isActived) return;

                const action = changeParkingChooseDashboard({
                    parking: parking,
                });
                localStorage.setItem(PARKING_CHOSE_DASHBOARD, parking.ID);
                dispatch(action);
            }}
        >
            <Image
                src={isActived ? '/icons/parking-white.svg' : '/icons/parking-round-gray.svg'}
                width={24}
                height={24}
                alt="photo"
            />

            <Stack
                sx={{
                    backgroundColor: '#CDD2D1',
                    width: '1px',
                    height: '44px',
                    margin: '0px 8px',
                }}
            />

            <Stack>
                <Stack direction={'row'} gap={1} alignItems={'center'}>
                    <Stack
                        sx={{
                            // background: deviceErr > 0 ? color.red : color.green,
                            background:
                                !parking?.Device || parking?.Device?.length === 0
                                    ? 'rgba(205, 210, 209, 1)'
                                    : parking.Device.some((device) => !device.IsOnline)
                                    ? '#E94F4F'
                                    : '#00ff00',
                            width: 8,
                            height: 8,
                            borderRadius: '50%',
                        }}
                    />
                    <Typography
                        sx={{
                            color: isActived ? '#FFF' : '#55595D',
                            fontSize: '16px',
                            fontStyle: 'normal',
                            fontWeight: 500,
                            lineHeight: '24px',
                            maxWidth: '200px',
                            overflow: 'hidden',
                            whiteSpace: 'nowrap',
                            textOverflow: 'ellipsis',
                        }}
                    >
                        {parking.Name}
                    </Typography>
                </Stack>
                <Typography
                    sx={{
                        color: isActived ? '#FFF' : '#55595D',
                        fontSize: '14px',
                        fontStyle: 'normal',
                        fontWeight: 400,
                        lineHeight: '20px',
                        overflow: 'hidden',
                        whiteSpace: 'nowrap',
                        textOverflow: 'ellipsis',
                        maxWidth: '200px',
                    }}
                >
                    {showAddress(
                        parking?.Address || '',
                        getNameAddress(parking?.Ward),
                        getNameAddress(parking?.District),
                        getNameAddress(parking?.Province)
                    )}
                </Typography>
            </Stack>
        </Stack>
    );
}
