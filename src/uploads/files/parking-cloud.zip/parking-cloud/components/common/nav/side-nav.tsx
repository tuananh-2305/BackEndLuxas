import { authApi } from '@/api/index';
import { CookieStoreControl } from '@/hooks/index';
import { useAppDispatch, useAppSelector } from '@/hooks/useReudx';
import { itemsMenu, subItemsAdmin } from '@/mocks/index';
import { resetAll, updaProfile } from '@/redux/index';
import { checkRole, getRoleReport } from '@/ultis/index';
import Image from 'next/image';
import InfoIcon from '@mui/icons-material/Info';
import {
    Avatar,
    Box,
    Button,
    Divider,
    IconButton,
    Stack,
    Tooltip,
    Typography,
} from '@mui/material';
import { useRouter } from 'next/router';
import { AvatarCustom } from '../avatar-next/avatar-custom';
import AvartarPopover from '../avatar-next/avatar-popover';
import ImageNextjs from '../image';
export interface ISideNavProps {}
const BACKEND_DOMAIN = process.env.NEXT_PUBLIC_SERVER_PARKING_DOMAIN;

export default function SideNav(props: ISideNavProps) {
    const router = useRouter();
    const { pathname } = router;
    const profile = useAppSelector((state) => state.common.profile);
    const dispatch = useAppDispatch();
    const parkingChoose = useAppSelector((state) => state.parking.choose);
    const handleLogout = () => {
        const instance = CookieStoreControl.getInstance();
        const rfToken = instance.token.get_refesh_token();
        if (rfToken) {
            authApi.logout(rfToken).then(() => {
                instance.token.remove_refesh_token();
                instance.token.remove_access_token();

                const action = updaProfile({
                    profile: null,
                });
                dispatch(action);
                const actionResetAllParking = resetAll();
                dispatch(actionResetAllParking);
                localStorage.clear();
                router.replace('/login');
            });
        }
    };
    const parkings = useAppSelector((state) => state.parking.parkings);

    return (
        <Stack
            sx={{
                width: '80px',
                height: '100%',
                pb: 2,
                flexDirection: 'row',
            }}
        >
            <Stack flex={1} alignItems={'center'} spacing={1}>
                <Stack
                    onClick={() => {
                        router.push('/');
                    }}
                    sx={{
                        cursor: 'pointer',
                        marginBottom: '5px',
                        height: '70px',
                        width: '100%',
                        position: 'relative',

                        '&:after ': {
                            bottom: 0,
                            position: 'absolute',
                            content: '""',
                            height: '1px',
                            width: '48px',
                            backgroundColor: '#fff',
                        },
                    }}
                    justifyContent="center"
                    alignItems="center"
                >
                    <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="35"
                        height="35"
                        viewBox="0 0 48 48"
                        fill="none"
                    >
                        <g clipPath="url(#clip0_673_33120)">
                            <path
                                d="M24.0006 36.0804H24.0012C27.2038 36.077 30.2743 34.8034 32.539 32.5389C34.8038 30.2745 36.0778 27.2041 36.0816 24.0015V24.0009C36.0816 21.6119 35.3731 19.2765 34.0459 17.2901C32.7186 15.3036 30.8322 13.7554 28.625 12.8411C26.4179 11.9268 23.9891 11.6875 21.646 12.1534C19.3028 12.6194 17.1505 13.7697 15.4611 15.4589C13.7717 17.1481 12.6211 19.3004 12.1548 21.6435C11.6886 23.9866 11.9276 26.4153 12.8416 28.6226C13.7557 30.8298 15.3037 32.7165 17.29 34.044C19.2763 35.3715 21.6116 36.0802 24.0006 36.0804ZM24.0007 0.508789C25.767 0.508789 27.4611 1.20968 28.7112 2.4576L45.544 19.2905C46.7919 20.5405 47.4928 22.2346 47.4928 24.0009C47.4928 25.7673 46.7919 27.4614 45.544 28.7114L28.7112 45.5443C27.4611 46.7922 25.767 47.4931 24.0007 47.4931C22.2344 47.4931 20.5402 46.7922 19.2902 45.5443L2.45735 28.7114C1.20943 27.4614 0.508533 25.7673 0.508533 24.0009C0.508533 22.2346 1.20943 20.5405 2.45735 19.2905L19.2902 2.4576C20.5402 1.20968 22.2344 0.508789 24.0007 0.508789Z"
                                fill="white"
                                stroke="white"
                            />
                            <path
                                d="M20.5467 18.8319C21.569 18.1488 22.7709 17.7842 24.0004 17.7842C25.6488 17.7859 27.2292 18.4415 28.3947 19.6071C29.5603 20.7726 30.2158 22.3529 30.2176 24.0011C30.2176 25.2307 29.853 26.4327 29.1699 27.4551C28.4868 28.4775 27.5158 29.2743 26.3798 29.7449C25.2438 30.2154 23.9938 30.3385 22.7878 30.0986C21.5818 29.8588 20.4741 29.2666 19.6046 28.3972C18.7352 27.5277 18.1431 26.42 17.9032 25.214C17.6633 24.008 17.7864 22.758 18.257 21.622C18.7275 20.486 19.5243 19.5151 20.5467 18.8319Z"
                                fill="white"
                                stroke="white"
                            />
                        </g>
                        <defs>
                            <clipPath id="clip0_673_33120">
                                <rect width="48" height="48" fill="white" />
                            </clipPath>
                        </defs>
                    </svg>
                </Stack>

                <Stack flex={1} spacing={1} component={'nav'}>
                    {itemsMenu
                        .filter((item) => {
                            if (!parkingChoose && item.path === '/settings/member') {
                                return false;
                            }

                            if (
                                parkingChoose &&
                                item.path === '/dashboard' &&
                                getRoleReport(profile, parkings).length === 0
                            ) {
                                return false;
                            }
                            return true;
                        })
                        .map((item, index) => {
                            const isActive =
                                pathname.startsWith(item.path) ||
                                (pathname.startsWith('/settings') &&
                                    item.path.startsWith('/settings'));
                            const isShow = checkRole(profile, item.roles);
                            if (!isShow) return null;
                            return (
                                <Tooltip key={index} title={item.title} placement="right">
                                    <Stack
                                        sx={{
                                            py: 1,
                                            width: 48,
                                            height: 48,
                                            borderRadius: '8px',
                                            alignItems: 'center',
                                            cursor: 'pointer',
                                            justifyContent: 'center',
                                            background: isActive ? '#007dc0' : 'transparent',
                                            ':active': {
                                                background: '#007dc0',
                                            },
                                        }}
                                        onClick={() => {
                                            if (router.pathname === item.path) return;
                                            if (item.path === '/admin') {
                                                const subItem = subItemsAdmin.find((item) => {
                                                    return item.path == '/admin';
                                                });
                                                if (subItem && checkRole(profile, subItem?.roles)) {
                                                    router.push(subItem.path);
                                                } else {
                                                    const pathRedirect = subItemsAdmin.find(
                                                        (item) => {
                                                            return checkRole(profile, item.roles);
                                                        }
                                                    );
                                                    router.push(pathRedirect?.path || '/');
                                                }
                                            } else {
                                                router.push(item.path);
                                            }
                                        }}
                                    >
                                        <Image
                                            src={isActive ? item.iconActive : item.icon}
                                            width={24}
                                            height={24}
                                            alt={''}
                                        />
                                    </Stack>
                                </Tooltip>
                            );
                        })}
                </Stack>

                <Avatar
                    src={'/gif/help.gif'}
                    alt=""
                    sizes="small"
                    style={{ borderRadius: 0, width: 24, height: 24 }}
                />

                <AvartarPopover
                    btn={
                        <AvatarCustom
                            src={profile?.Avatar ? BACKEND_DOMAIN + profile?.Avatar : ''}
                            type="square"
                        />
                    }
                >
                    <Stack sx={{ padding: '15px' }} spacing={'10px'}>
                        <Stack>
                            <Stack direction="row" alignItems={'center'}>
                                <Typography sx={{ fontWeight: 700 }}>{profile?.Name}</Typography>
                                <Box>
                                    <IconButton
                                        onClick={() => {
                                            router.push('/profile');
                                        }}
                                    >
                                        <InfoIcon />
                                    </IconButton>
                                </Box>
                            </Stack>
                            <Typography sx={{ fontWeight: 300, fontSize: '10px' }}>
                                {`${profile?.Phone ? profile.Phone : 'chưa có phone.'} - ${
                                    profile?.Email ? profile.Email : 'chưa có mail.'
                                }`}
                            </Typography>
                        </Stack>
                        <Stack
                            onClick={handleLogout}
                            sx={{
                                padding: '10px 80px',
                                backgroundColor: '#55595D',
                                boxShadow: '0px 2px 2px rgba(0, 0, 0, 0.25)',
                                borderRadius: '10px',
                                cursor: 'pointer',
                            }}
                        >
                            <Typography
                                sx={{ fontWeight: 700, color: '#fff', textTransform: 'uppercase' }}
                            >
                                Đăng Xuất
                            </Typography>
                        </Stack>
                    </Stack>
                </AvartarPopover>
            </Stack>
        </Stack>
    );
}
