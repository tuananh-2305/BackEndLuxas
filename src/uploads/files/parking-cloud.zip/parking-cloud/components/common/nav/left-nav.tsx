import { SIZE_lEFT_MENU } from '@/constants/global';
import { useAppSelector } from '@/hooks/useReudx';
import { Stack, SxProps, Theme, useMediaQuery } from '@mui/material';
import * as React from 'react';

export interface ILeftNavProps {
    children?: React.ReactNode;
    sx?: SxProps<Theme>;
}

export default function LeftNav(props: ILeftNavProps) {
    const vh = useAppSelector((state) => state.common.vh);
    const matches = useMediaQuery('(min-width:1300px)');
    return (
        <Stack
            px={2}
            sx={{
                zIndex: 10,
                backgroundColor: '#fff',
                borderRight: '1px solid rgba(0,0,0,0.1)',
                width: SIZE_lEFT_MENU,
                minWidth: SIZE_lEFT_MENU,
                ...props.sx,
                position: matches ? 'unset' : 'absolute',
                left: 0,
                height: `${vh}px`,
            }}
        >
            {props.children}
        </Stack>
    );
}
