import { vehicleTypeApi } from '@/api/vehicle-type-api';
import { Vehicel } from '@/components/formular/interface';
import { useAppSelector } from '@/hooks/index';
import { AuthenData, PaginationIDPayload, VehicleData } from '@/models/index';
import ArrowForwardIosIcon from '@mui/icons-material/ArrowForwardIos';
import CloseIcon from '@mui/icons-material/Close';
import DeleteIcon from '@mui/icons-material/Delete';
import EditIcon from '@mui/icons-material/Edit';
import SearchIcon from '@mui/icons-material/Search';
import {
    IconButton,
    InputBase,
    InputLabel,
    ListItem,
    ListItemText,
    Paper,
    Popover,
    Stack,
    Typography,
} from '@mui/material';
import List from '@mui/material/List';
import { useCallback, useEffect, useRef, useState } from 'react';
import { OptionSelect } from '../../input/text-field-form/text-field-form-select';
import { MemberVehicleModel } from '@/models/member.vehicle.model';
import { memberVehicleApi } from '@/api/member-vehicle-api';
import { useDebouncedValue } from '@mantine/hooks';

interface SelectVehicleProps {
    setValue: (value: MemberVehicleModel | null) => void;
    parkingId: string;
    value: MemberVehicleModel | null;
    isNotRequired?: boolean;
    memberId: string | undefined;
    textError?: string;
    isParking?: boolean;
}

export const SelectVehicle = (props: SelectVehicleProps) => {
    const { parkingId, setValue, value, isNotRequired, memberId, textError } = props;

    const ref = useRef<any | null>(null);

    const [listVehicle, setListVehicle] = useState<OptionSelect[]>([]);
    const parkingChoose = useAppSelector((state) => state.parking.choose);
    const [anchorEl, setAnchorEl] = useState<HTMLButtonElement | null>(null);

    // use effect
    useEffect(() => {
        if (!parkingChoose) return;
        vehicleTypeApi.getVehicleTypes().then((res) => {
            if (res.data && res.data.length > 0) {
                var list = res.data.map((item: Vehicel) => {
                    var option: OptionSelect = {
                        id: item.ID,
                        label: item.Name,
                    };
                    return option;
                });
                setListVehicle(list);
            }
        });
    }, [parkingChoose]);

    const [data, setData] = useState<MemberVehicleModel[]>([]);
    const [loading, setLoading] = useState(false);
    const [total, setTotal] = useState(0);
    const [search, setSearch] = useState('');
    const [debounced] = useDebouncedValue(search, 400);

    const loadVehicles = useCallback(
        (memberId: string | null, parkingId: string | undefined, search: string) => {
            if (!memberId || !parkingId) return;
            const payload: PaginationIDPayload = {
                Current: 0,
                Limit: 6,
                TextSearch: search,
                ID: memberId,
            };
            setLoading(true);
            memberVehicleApi
                .getMemberVehicleByIdMemberAndParking(parkingId, payload)
                .then((res) => {
                    const { Data, Total, Limit } = res.data;
                    setData(Data);
                    setTotal(Total);
                })
                .finally(() => {
                    setLoading(false);
                });
        },
        []
    );

    useEffect(() => {
        if (memberId) {
            loadVehicles(memberId, parkingId, debounced);
        }
    }, [debounced, loadVehicles, parkingId, memberId]);
    return (
        <>
            <InputLabel sx={{ fontSize: 14, fontWeight: 400, color: '#55595D', mb: '6px' }}>
                {props.isParking ? '3' : '2'}. Chọn phương tiện{' '}
                <Typography
                    component={'span'}
                    sx={{
                        color: '#E42727',
                        fontSize: 13,
                    }}
                >
                    (✶)
                </Typography>
            </InputLabel>
            <Stack
                onClick={() => setAnchorEl(ref.current)}
                direction="row"
                alignItems="center"
                justifyContent="space-between"
                ref={ref}
                sx={{
                    border: '1px solid #E3E5E5',
                    padding: '13px 16px',
                    borderRadius: '6px',
                    position: 'relative',
                    height: '46px',
                }}
            >
                {value == null ? (
                    <Typography sx={{ fontSize: '16px', color: '#323232', opacity: 0.5 }}>
                        Chọn phương tiện
                    </Typography>
                ) : (
                    <Stack direction="row" sx={{ gap: '12px', flex: 1 }}>
                        <Typography
                            sx={{
                                fontSize: '14px',
                                fontWeight: 400,
                                lineHeight: '140%',
                            }}
                        >
                            {value.VehicleTypeId?.Name}
                        </Typography>

                        <Typography
                            sx={{
                                fontSize: '14px',
                                fontWeight: 500,
                                lineHeight: '140%',
                                whiteSpace: 'nowrap',
                                color: '#007DC0',
                            }}
                        >
                            {value.PlateNumber}
                        </Typography>
                        <Stack
                            sx={{
                                width: '1px',
                                height: '14px',
                                backgroundColor: '#E3E5E5',
                            }}
                        />
                        <Typography
                            sx={{
                                fontSize: '14px',
                                fontWeight: 400,
                                lineHeight: '140%',
                                whiteSpace: 'nowrap',
                                color: '#808080',
                            }}
                        >
                            {value?.VehicleBrand}
                        </Typography>
                    </Stack>
                )}

                <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="24"
                    height="24"
                    viewBox="0 0 24 24"
                    fill="none"
                    style={{
                        fontSize: '20px',
                        cursor: 'pointer',
                        transition: 'all .3s ease',
                        color: '#55595D',
                        rotate: !Boolean(anchorEl) ? '0deg' : '180deg',
                        marginRight: '-10px',
                    }}
                >
                    <path
                        d="M6 9L12 15L18 9"
                        stroke="#55595D"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                    />
                </svg>
            </Stack>
            {textError && (
                <Stack direction={'row'} spacing={'5px'} sx={{ alignItems: 'center', mt: '4px' }}>
                    <Stack
                        sx={{
                            width: '13px',
                            height: '13px',
                            alignItems: 'center',
                            justifyContent: 'center',
                            background: '#E42727',
                            borderRadius: '50%',
                        }}
                    >
                        <CloseIcon sx={{ color: '#fff', fontSize: 10, fontWeight: 600 }} />
                    </Stack>
                    <Typography
                        sx={{
                            fontSize: 12,
                            fontWeight: 400,
                            color: '#E42727',
                        }}
                    >
                        {textError}
                    </Typography>
                </Stack>
            )}
            <Popover
                id={Boolean(anchorEl) ? 'simple-popover' : undefined}
                open={Boolean(anchorEl)}
                anchorEl={anchorEl}
                onClose={() => setAnchorEl(null)}
                anchorOrigin={{
                    vertical: 'bottom',
                    horizontal: 'left',
                }}
            >
                <Stack
                    sx={{
                        width: `${ref.current?.clientWidth}px`,
                        backgroundColor: '#fff',
                        transition: 'all ease .3s',
                        left: 0,
                        boxShadow: '0px 4px 16px 0px rgba(0, 0, 0, 0.10)',
                        padding: '8px',
                        gap: '4px',
                    }}
                >
                    <Paper
                        component="form"
                        sx={{
                            display: 'flex',
                            alignItems: 'center',
                            border: '1px solid #F2F2F2',
                            borderRadius: '6px',
                        }}
                        elevation={0}
                    >
                        <IconButton sx={{ p: '5px' }} aria-label="menu">
                            <SearchIcon style={{ color: '#AFAFAF' }} />
                        </IconButton>
                        <InputBase
                            sx={{ flex: 1, fontSize: 12 }}
                            placeholder="Chọn loại xe"
                            inputProps={{ 'aria-label': 'Chọn loại xe' }}
                        />
                    </Paper>

                    <Stack
                        sx={{
                            border: '1px solid #F2F2F2;',
                            padding: '4px',
                            borderRadius: '6px',
                        }}
                    >
                        <Stack
                            sx={{
                                maxHeight: '300px',
                                padding: '4px',
                                overflow: 'auto',
                                scrollSnapType: 'y mandatory',
                                '&::-webkit-scrollbar': {
                                    width: '2px',
                                },
                                '&::-webkit-scrollbar-thumb': {
                                    background: '#78C6E7',
                                },
                                '&::-webkit-scrollbar-track': {
                                    background: '#F2F2F2',
                                },
                            }}
                        >
                            <List disablePadding>
                                {data && data.length > 0 ? (
                                    data.map((v, k) => {
                                        return (
                                            <ListItem
                                                key={`${k}-vehicel-brand-item`}
                                                disablePadding
                                            >
                                                <Stack
                                                    sx={{
                                                        scrollSnapAlign: 'start',
                                                        gap: '8px',
                                                        borderRadius: '4px',
                                                        cursor: 'pointer',
                                                        transition: 'all ease .3s',
                                                        '.icon-button': {
                                                            opacity: 0,
                                                            visibility: 'hidden',
                                                            width: 0,
                                                        },
                                                        '&:hover ': {
                                                            backgroundColor: '#F4FAFE',
                                                            '.icon-button': {
                                                                opacity: 1,
                                                                visibility: 'visible',
                                                                width: '40px',
                                                            },
                                                        },
                                                        width: '100%',
                                                        p: '10px',
                                                    }}
                                                    direction="row"
                                                    alignItems="center"
                                                >
                                                    <Stack
                                                        onClick={() => {
                                                            setValue(v);
                                                        }}
                                                        direction="row"
                                                        sx={{ gap: '12px', flex: 1 }}
                                                    >
                                                        <Typography
                                                            sx={{
                                                                fontSize: '14px',
                                                                fontWeight: 400,
                                                                lineHeight: '140%',
                                                            }}
                                                        >
                                                            {listVehicle.filter(
                                                                (i) => i.id == v.VehicleTypeId?.ID
                                                            )[0]?.label ?? ''}
                                                        </Typography>
                                                        <Stack
                                                            sx={{
                                                                width: '1px',
                                                                height: '14px',
                                                                backgroundColor: '#E3E5E5',
                                                            }}
                                                        />
                                                        <Typography
                                                            sx={{
                                                                fontSize: '14px',
                                                                fontWeight: 500,
                                                                lineHeight: '140%',
                                                                whiteSpace: 'nowrap',
                                                                color: '#007DC0',
                                                            }}
                                                        >
                                                            {v.PlateNumber}
                                                        </Typography>
                                                        <Stack
                                                            sx={{
                                                                width: '1px',
                                                                height: '14px',
                                                                backgroundColor: '#E3E5E5',
                                                            }}
                                                        />
                                                        <Typography
                                                            sx={{
                                                                fontSize: '14px',
                                                                fontWeight: 400,
                                                                lineHeight: '140%',
                                                                whiteSpace: 'nowrap',
                                                                color: '#808080',
                                                            }}
                                                        >
                                                            {v.VehicleBrand}
                                                        </Typography>
                                                    </Stack>
                                                </Stack>
                                            </ListItem>
                                        );
                                    })
                                ) : (
                                    <List>
                                        <ListItem disablePadding dense>
                                            <ListItemText
                                                primary={
                                                    data.length > 0
                                                        ? 'Thêm phương tiện'
                                                        : 'Chưa có phương tiện'
                                                }
                                            />
                                        </ListItem>
                                    </List>
                                )}
                            </List>
                        </Stack>
                    </Stack>
                </Stack>
            </Popover>
        </>
    );
};
