import ArrowForwardIosIcon from '@mui/icons-material/ArrowForwardIos';
import CheckIcon from '@mui/icons-material/Check';
import { Grid, InputLabel, Popover, Stack, Typography } from '@mui/material';
import { useEffect, useRef, useState } from 'react';
import CloseIcon from '@mui/icons-material/Close';
import AddIcon from '@mui/icons-material/Add';
import { vehicleColor } from '@/constants/vehicle-color';
interface CaseVehicelColorSelectProps {
    value: any[];
    onChange: (v: any) => void;
    textError?: string;
    color?: string;
    tabIndex?: number | undefined;
}
export const CaseVehicelColorSelect = (props: CaseVehicelColorSelectProps) => {
    const { value, onChange, textError } = props;

    const ref = useRef<HTMLDivElement | null>(null);
    const color = props.color ? props.color : textError ? '#E42727' : '#E3E5E5';
    const [tooltip, setTooltip] = useState<string | null>(null);

    const [anchorEl, setAnchorEl] = useState<any>(null);
    const open = Boolean(anchorEl);
    const id = open ? 'simple-popover' : undefined;
    return (
        <Stack sx={{ position: 'relative' }}>
            <InputLabel sx={{ fontSize: 14, fontWeight: 400, color: '#55595D', mb: '6px' }}>
                5. Màu xe{' '}
                {/* <Typography
                    component={'span'}
                    sx={{
                        color: '#E42727',
                        fontSize: 13,
                    }}
                >
                    (✶)
                </Typography> */}
            </InputLabel>
            <Stack
                direction="row"
                onClick={(e) => setAnchorEl(ref.current)}
                alignItems="center"
                justifyContent="space-between"
                ref={ref}
                tabIndex={props.tabIndex}
                sx={{
                    border: `1px solid ${color}`,
                    padding: '13px 16px',
                    borderRadius: '6px',
                    height: '46px',
                    cursor: 'pointer',
                    ':focus': {
                        outlineColor: '#E3E5E5',
                    },
                }}
            >
                {value && value.length > 0 ? (
                    <Stack direction={'row'} sx={{ flex: 1, gap: '5px' }}>
                        {value.map((item, index) => {
                            return (
                                <Stack
                                    key={`${index}-vehicel-color-item`}
                                    direction={'row'}
                                    spacing={'9px'}
                                    sx={{ alignItems: 'center', justifyContent: 'center' }}
                                >
                                    <Stack
                                        sx={{
                                            backgroundColor: item.value,
                                            width: '15px',
                                            height: '15px',
                                            boxShadow:
                                                'rgba(67, 71, 85, 0.27) 0px 0px 0.25em, rgba(90, 125, 188, 0.05) 0px 0.25em 1em',
                                            borderRadius: '4px',
                                        }}
                                    ></Stack>
                                </Stack>
                            );
                        })}
                        {value.map((item, index) => {
                            return (
                                <Stack
                                    key={`${index}-vehicel-color-item`}
                                    direction={'row'}
                                    spacing={'9px'}
                                    sx={{ alignItems: 'center', justifyContent: 'center' }}
                                >
                                    <Typography
                                        sx={{
                                            color: '#323232',
                                            fontSize: 11,
                                            fontWeight: 400,
                                        }}
                                    >
                                        {item.name}
                                    </Typography>
                                </Stack>
                            );
                        })}
                    </Stack>
                ) : (
                    <Typography sx={{ fontSize: '16px', color: '#323232', opacity: 0.5 }}>
                        Chọn màu xe
                    </Typography>
                )}

                {/* <ArrowForwardIosIcon
                    sx={{
                        fontSize: '15px',
                        rotate: open ? '-90deg' : '90deg',
                        cursor: 'pointer',
                        transition: 'all ease .3s',
                        color: '#55595D',
                    }}
                /> */}

                <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="24"
                    height="24"
                    viewBox="0 0 24 24"
                    fill="none"
                    style={{
                        fontSize: '20px',
                        cursor: 'pointer',
                        transition: 'all .3s ease',
                        color: '#55595D',
                        rotate: !open ? '0deg' : '180deg',
                        marginRight: '-10px',
                    }}
                >
                    <path
                        d="M6 9L12 15L18 9"
                        stroke="#55595D"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                    />
                </svg>
            </Stack>

            {textError && (
                <Stack direction={'row'} spacing={'5px'} sx={{ alignItems: 'center', mt: '4px' }}>
                    <Stack
                        sx={{
                            width: '13px',
                            height: '13px',
                            alignItems: 'center',
                            justifyContent: 'center',
                            background: '#E42727',
                            borderRadius: '50%',
                        }}
                    >
                        <CloseIcon sx={{ color: '#fff', fontSize: 10, fontWeight: 600 }} />
                    </Stack>
                    <Typography
                        sx={{
                            fontSize: 12,
                            fontWeight: 400,
                            color: '#E42727',
                        }}
                    >
                        {textError}
                    </Typography>
                </Stack>
            )}

            <Popover
                id={id}
                open={open}
                anchorEl={anchorEl}
                onClose={() => setAnchorEl(null)}
                anchorOrigin={{
                    vertical: 'bottom',
                    horizontal: 'left',
                }}
            >
                <Stack
                    sx={{
                        width: `${ref.current?.clientWidth}px`,
                        backgroundColor: '#fff',
                        transition: 'all ease .3s',
                        boxShadow: '0px 4px 16px 0px rgba(0, 0, 0, 0.10)',
                        padding: '10px',
                        gap: '4px',
                    }}
                >
                    <Grid container spacing={1}>
                        {vehicleColor.map((v, k) => {
                            const isItemInValue = value.some((i) => i.name === v.name);
                            return (
                                <Grid item xs={1.5} key={`${k}-vehicel-color-item`}>
                                    <Stack
                                        onMouseEnter={() => setTooltip(v.name)}
                                        onMouseLeave={() => setTooltip(null)}
                                        onClick={() => {
                                            var newValue = [...value];
                                            const isItemInValue = value.some(
                                                (i) => i.name === v.name
                                            );
                                            if (isItemInValue) {
                                                var removeItem = newValue.filter(
                                                    (i) => i.name !== v.name
                                                );
                                                newValue = removeItem;
                                            } else {
                                                if (value.length < 2) {
                                                    newValue.push(v);
                                                } else {
                                                    newValue.shift();
                                                    newValue.push(v);
                                                }
                                            }

                                            onChange(newValue);
                                        }}
                                        sx={{
                                            backgroundColor: v.value,
                                            width: '20px',
                                            height: '20px',
                                            // border: '2px solid #D0D0D0',
                                            borderRadius: '4px',
                                            alignItems: 'center',
                                            justifyContent: 'center',
                                            cursor: 'pointer',
                                            boxShadow:
                                                'rgba(67, 71, 85, 0.27) 0px 0px 0.25em, rgba(90, 125, 188, 0.05) 0px 0.25em 1em',
                                            ':hover': {
                                                '.add-icon-hover': {
                                                    opacity: 1,
                                                    transition: 'all .3s',
                                                },
                                            },
                                            position: 'relative',
                                        }}
                                    >
                                        {isItemInValue && (
                                            <CheckIcon sx={{ fontSize: 10, color: v.deValue }} />
                                        )}
                                        <AddIcon
                                            className="add-icon-hover"
                                            sx={{
                                                opacity: 0,
                                                color: v.deValue,
                                                fontSize: 15,
                                                display: isItemInValue ? 'none' : 'flex',
                                            }}
                                        />
                                    </Stack>
                                </Grid>
                            );
                        })}
                    </Grid>
                    <Typography
                        sx={{
                            pt: '5px',
                            fontSize: 14,
                            fontWeight: 400,
                            color: '#808080',
                        }}
                    >
                        Thêm {tooltip ? tooltip : '...'}
                    </Typography>
                </Stack>
            </Popover>
        </Stack>
    );
};
