import { Popover, Stack, Typography } from '@mui/material';
import { useRef, useState } from 'react';

interface CaseHistorySelectProps {
    type: 'ALL' | 'IN' | 'OUT';
    change: (v: 'ALL' | 'IN' | 'OUT') => void;
}

export const CaseHistorySelect = (props: CaseHistorySelectProps) => {
    const { change, type } = props;
    const ref = useRef<HTMLDivElement | null>(null);
    const [open, setOpen] = useState(false);

    const generatorTitle = () => {
        switch (type) {
            case 'ALL':
                return 'Tất cả xe';
            case 'IN':
                return 'Trong bãi';
            case 'OUT':
                return 'Đã ra';
            default:
                return 'Chưa thiết lập';
        }
    };

    return (
        <Stack>
            <Stack
                ref={ref}
                sx={{
                    width: '200px',
                    border: '1px solid #55595D',
                    padding: '5px 10px',
                    borderRadius: '5px',
                    cursor: 'pointer',
                }}
                onClick={() => setOpen(true)}
            >
                <Typography sx={{ fontSize: '12px', fontWeight: 700 }}>
                    {generatorTitle()}
                </Typography>
            </Stack>
            <Popover
                open={open}
                anchorEl={ref.current}
                onClose={() => setOpen(false)}
                anchorOrigin={{
                    vertical: 'bottom',
                    horizontal: 'left',
                }}
            >
                <Stack sx={{ width: `${ref.current?.clientWidth}px` }}>
                    <Stack
                        sx={{
                            padding: '5px 10px',
                            cursor: 'pointer',
                            '&:hover': {
                                backgroundColor: '#d9d9d9',
                            },
                        }}
                        onClick={() => {
                            change('ALL');
                            setOpen(false);
                        }}
                    >
                        <Typography
                            sx={{
                                fontSize: '12px',
                                fontWeight: 700,
                            }}
                        >
                            Tất cả
                        </Typography>
                    </Stack>
                    <Stack
                        sx={{
                            padding: '5px 10px',
                            cursor: 'pointer',
                            '&:hover': {
                                backgroundColor: '#d9d9d9',
                            },
                        }}
                        onClick={() => {
                            change('IN');
                            setOpen(false);
                        }}
                    >
                        <Typography sx={{ fontSize: '12px', fontWeight: 700 }}>
                            Trong bãi
                        </Typography>
                    </Stack>
                    <Stack
                        sx={{
                            padding: '5px 10px',
                            cursor: 'pointer',
                            '&:hover': {
                                backgroundColor: '#d9d9d9',
                            },
                        }}
                        onClick={() => {
                            change('OUT');
                            setOpen(false);
                        }}
                    >
                        <Typography sx={{ fontSize: '12px', fontWeight: 700 }}>Xe đã ra</Typography>
                    </Stack>
                </Stack>
            </Popover>
        </Stack>
    );
};
