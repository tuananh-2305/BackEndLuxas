import { vehicelBranchApi } from '@/api/vehicel-brand';
import { useDebouncedValue } from '@mantine/hooks';
import AddBoxIcon from '@mui/icons-material/AddBox';
import AddBoxOutlinedIcon from '@mui/icons-material/AddBoxOutlined';
import ArrowForwardIosIcon from '@mui/icons-material/ArrowForwardIos';
import CloseIcon from '@mui/icons-material/Close';
import SearchIcon from '@mui/icons-material/Search';
import {
    IconButton,
    InputAdornment,
    InputBase,
    InputLabel,
    Paper,
    Popover,
    Stack,
    TextField,
    Typography,
} from '@mui/material';
import { useCallback, useEffect, useRef, useState } from 'react';
import { VehicelSelectBranchItem } from './item-case';
import { ArrowIcon } from '../../icons/arrow-icon';

interface CaseVehicelBranchSelectProps {
    value: string;
    onChange: (v: any) => void;
    textError?: string;
    color?: string;
    tabIndex?: number | undefined;
}

export const CaseVehicelBranchSelect = (props: CaseVehicelBranchSelectProps) => {
    const { value, onChange, textError } = props;
    const color = props.color ? props.color : textError ? '#E42727' : '#E3E5E5';

    const [search, setSearch] = useState('');
    const [debouncedSearch] = useDebouncedValue(search, 200);
    const [idEdit, setIdEdit] = useState('');
    const ref = useRef<HTMLInputElement | null>(null);
    const [data, setData] = useState<any[]>([]);
    // const [loading, setLoading] = useState(false);

    const [anchorEl, setAnchorEl] = useState<any>(null);

    const callData = useCallback((s: string) => {
        vehicelBranchApi.pagination({ TextSearch: s, Current: 0, Limit: 1000 }).then((res) => {
            const { Data, Total } = res.data;
            setData(Data);
        });
    }, []);

    useEffect(() => {
        callData(debouncedSearch);
    }, [callData, debouncedSearch]);

    useEffect(() => {
        if (!Boolean(anchorEl)) {
            setIdEdit('');
        }
    }, [anchorEl]);

    return (
        <Stack component={'form'} onSubmit={(e) => e.preventDefault()}>
            <InputLabel sx={{ fontSize: 14, fontWeight: 400, color: '#55595D', mb: '6px' }}>
                4. Hãng xe{' '}
                {/* <Typography
                    component={'span'}
                    sx={{
                        color: '#E42727',
                        fontSize: 13,
                    }}
                >
                    (✶)
                </Typography> */}
            </InputLabel>
            <TextField
                ref={ref}
                aria-describedby={Boolean(anchorEl) ? 'simple-popover' : undefined}
                onClick={(event: any) => setAnchorEl(event.currentTarget)}
                type="text"
                size="small"
                value={value}
                autoComplete="off"
                sx={{
                    '& .MuiOutlinedInput-root:hover': {
                        '& > fieldset': {
                            borderColor: color,
                        },
                    },
                    '& .MuiOutlinedInput-root': {
                        '& > fieldset': {
                            borderColor: color,
                            borderRadius: '6px',
                        },
                        '&.Mui-focused fieldset': {
                            borderColor: color,
                        },
                    },
                    '& label.Mui-focused': {
                        color: color,
                    },
                    marginTop: '0px',
                    flex: 1,
                }}
                inputProps={{
                    tabIndex: props.tabIndex,
                    style: {
                        fontSize: 16,
                        fontWeight: 400,
                        color: '#323232',
                        padding: '13px 16px',
                        lineHeight: '20px',
                        height: '20px',
                    },
                }}
                placeholder="Chọn hoặc nhập hãng"
                InputProps={{
                    endAdornment: (
                        <InputAdornment
                            position="end"
                            onClick={() => setAnchorEl(null)}
                            sx={{
                                height: '100%',
                                mr: '-7px',
                            }}
                        >
                            <svg
                                xmlns="http://www.w3.org/2000/svg"
                                width="24"
                                height="24"
                                viewBox="0 0 24 24"
                                fill="none"
                                style={{
                                    fontSize: '20px',
                                    cursor: 'pointer',
                                    transition: 'all .3s ease',
                                    color: '#55595D',
                                    rotate: !Boolean(anchorEl) ? '0deg' : '180deg',
                                }}
                            >
                                <path
                                    d="M6 9L12 15L18 9"
                                    stroke="#55595D"
                                    strokeWidth="2"
                                    strokeLinecap="round"
                                    strokeLinejoin="round"
                                />
                            </svg>
                        </InputAdornment>
                    ),
                }}
            />
            {textError && (
                <Stack direction={'row'} spacing={'5px'} sx={{ alignItems: 'center', mt: '4px' }}>
                    <Stack
                        sx={{
                            width: '13px',
                            height: '13px',
                            alignItems: 'center',
                            justifyContent: 'center',
                            background: '#E42727',
                            borderRadius: '50%',
                        }}
                    >
                        <CloseIcon sx={{ color: '#fff', fontSize: 10, fontWeight: 600 }} />
                    </Stack>
                    <Typography
                        sx={{
                            fontSize: 12,
                            fontWeight: 400,
                            color: '#E42727',
                        }}
                    >
                        {textError}
                    </Typography>
                </Stack>
            )}
            <Popover
                id={Boolean(anchorEl) ? 'simple-popover' : undefined}
                open={Boolean(anchorEl)}
                anchorEl={anchorEl}
                onClose={() => setAnchorEl(null)}
                anchorOrigin={{
                    vertical: 'bottom',
                    horizontal: 'left',
                }}
            >
                <Stack
                    sx={{
                        backgroundColor: '#fff',
                        boxShadow: '0px 4px 16px 0px rgba(0, 0, 0, 0.10)',
                        padding: '8px',
                        gap: '4px',
                        width: `${ref.current?.clientWidth}px`,
                    }}
                >
                    <Paper
                        component="form"
                        sx={{
                            display: 'flex',
                            alignItems: 'center',
                            border: '1px solid #F2F2F2',
                            borderRadius: '6px',
                        }}
                        elevation={0}
                    >
                        <IconButton sx={{ p: '5px' }} aria-label="menu">
                            <SearchIcon style={{ color: '#AFAFAF' }} />
                        </IconButton>
                        <InputBase
                            sx={{ flex: 1, fontSize: 12 }}
                            placeholder="Chọn loại xe"
                            inputProps={{ 'aria-label': 'Chọn loại xe' }}
                            value={search}
                            onChange={(e) => {
                                const { value } = e.target;
                                setSearch(value);
                            }}
                        />
                        {search && !data.map((v) => v.Name).includes(search) ? (
                            <IconButton
                                sx={{
                                    '.icon-none-active': {
                                        display: 'inline-block',
                                    },
                                    '.icon-active': {
                                        display: 'none',
                                    },
                                    ':hover ': {
                                        '.icon-none-active': { display: 'none' },
                                        '.icon-active': {
                                            display: 'inline-block',
                                        },
                                    },
                                    p: '5px',
                                }}
                                onClick={() => {
                                    vehicelBranchApi.create(search).then((res) => {
                                        setSearch('');
                                        callData(debouncedSearch);
                                    });
                                }}
                            >
                                <AddBoxOutlinedIcon
                                    className="icon-none-active"
                                    sx={{ fontSize: '20px', cursor: 'pointer', color: '#55595D' }}
                                />
                                <AddBoxIcon
                                    className="icon-active"
                                    sx={{ fontSize: '20px', cursor: 'pointer', color: '#007DC0' }}
                                />
                            </IconButton>
                        ) : (
                            <></>
                        )}
                    </Paper>

                    <Stack
                        sx={{
                            border: '1px solid #F2F2F2;',
                            padding: '4px',
                            borderRadius: '6px',
                        }}
                    >
                        <Stack
                            sx={{
                                maxHeight: '200px',
                                padding: '4px',
                                overflow: 'auto',
                                scrollSnapType: 'y mandatory',
                                '&::-webkit-scrollbar': {
                                    width: '2px',
                                },
                                '&::-webkit-scrollbar-thumb': {
                                    background: '#78C6E7',
                                },
                                '&::-webkit-scrollbar-track': {
                                    background: '#F2F2F2',
                                },
                            }}
                        >
                            {data.map((v, k) => {
                                return (
                                    <Stack
                                        key={`${k}-vehicel-brand-item`}
                                        onClick={() => {
                                            onChange(v?.Name ?? '');
                                        }}
                                    >
                                        <VehicelSelectBranchItem
                                            callData={() => callData(search)}
                                            makeEdit={() => {
                                                if (idEdit === v.ID) {
                                                    setIdEdit('');
                                                } else {
                                                    setIdEdit(v.ID);
                                                }
                                            }}
                                            isEdit={idEdit === v.ID}
                                            v={v}
                                            onClose={() => setAnchorEl(null)}
                                        />
                                    </Stack>
                                );
                            })}
                        </Stack>
                    </Stack>
                </Stack>
            </Popover>
        </Stack>
    );
};
