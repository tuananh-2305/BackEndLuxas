import { vehicelBranchApi } from '@/api/vehicel-brand';
import DeleteIcon from '@mui/icons-material/Delete';
import EditIcon from '@mui/icons-material/Edit';
import { Stack, Typography } from '@mui/material';
import SaveIcon from '@mui/icons-material/Save';
import HighlightOffIcon from '@mui/icons-material/HighlightOff';
import { useEffect, useState } from 'react';

interface VehicelSelectBranchItemProps {
    callData: () => void;
    makeEdit: () => void;
    isEdit: boolean;
    v: any;
    onClose: () => void;
}

export const VehicelSelectBranchItem = (props: VehicelSelectBranchItemProps) => {
    const { callData, v, makeEdit, isEdit } = props;

    const [text, setText] = useState('');

    useEffect(() => {
        setText(v.Name);
    }, [isEdit, v.Name]);

    return (
        <Stack
            sx={{
                padding: '4px 8px',
                scrollSnapAlign: 'start',
                gap: '8px',
                borderRadius: '4px',
                cursor: 'pointer',
                transition: 'all ease .3s',
                '& > svg': {
                    opacity: 0,
                    visibility: 'hidden',
                    width: 0,
                },
                '&:hover ': {
                    backgroundColor: '#F4FAFE',
                    '& > svg': {
                        opacity: 1,
                        visibility: 'visible',
                        width: '1em',
                    },
                },
            }}
            direction="row"
            alignItems="center"
        >
            {isEdit ? (
                <HighlightOffIcon
                    sx={{
                        fontSize: '20px',
                        color: '#55595D',
                        transition: 'all ease .3s',
                    }}
                    onClick={() => makeEdit()}
                />
            ) : (
                <EditIcon
                    sx={{
                        fontSize: '20px',
                        color: '#55595D',
                        transition: 'all ease .3s',
                    }}
                    onClick={() => makeEdit()}
                />
            )}

            {isEdit ? (
                <input
                    style={{ flex: 1 }}
                    value={text}
                    onChange={(e) => {
                        const { value } = e.target;
                        setText(value);
                    }}
                />
            ) : (
                <Typography
                    onClick={() => {
                        if (props.onClose) {
                            props.onClose();
                        }
                    }}
                    sx={{
                        flex: 1,
                        fontSize: '14px',
                        fontWeight: 400,
                        lineHeight: '140%',
                    }}
                >
                    {v.Name}
                </Typography>
            )}

            {isEdit ? (
                <SaveIcon
                    sx={{
                        fontSize: '20px',
                        color: '#007DC0',
                        transition: 'all ease .3s',
                    }}
                    onClick={() => {
                        vehicelBranchApi.update({ ID: v.ID, Name: text }).then((res) => {
                            makeEdit();
                            callData();
                        });
                    }}
                />
            ) : (
                <DeleteIcon
                    sx={{
                        fontSize: '20px',
                        color: '#E42727',
                        transition: 'all ease .3s',
                    }}
                    onClick={() => {
                        vehicelBranchApi.remove(v.ID).then((res) => {
                            callData();
                        });
                    }}
                />
            )}
        </Stack>
    );
};
