import { vehicleTypeApi } from '@/api/vehicle-type-api';
import { Vehicel } from '@/components/formular/interface';
import { useAppSelector } from '@/hooks/index';
import { AuthenData, VehicleData } from '@/models/index';
import ArrowForwardIosIcon from '@mui/icons-material/ArrowForwardIos';
import CloseIcon from '@mui/icons-material/Close';
import DeleteIcon from '@mui/icons-material/Delete';
import EditIcon from '@mui/icons-material/Edit';
import SearchIcon from '@mui/icons-material/Search';
import {
    IconButton,
    InputBase,
    InputLabel,
    ListItem,
    ListItemText,
    Paper,
    Popover,
    Stack,
    Typography,
} from '@mui/material';
import List from '@mui/material/List';
import { useEffect, useRef, useState } from 'react';
import { OptionSelect } from '../../input/text-field-form/text-field-form-select';

interface CaseVehicesListSelectProps {
    formVehicleList: VehicleData[];
    value: VehicleData | null;
    setValue: (value: any) => void;
    textError?: string;
    setFormVehicleList: (v: any) => void;
    formCardList: AuthenData[];
    activeId: string;
    tabIndex?: number | undefined;
}
export const CaseVehicesListSelect = ({
    value,
    setValue,
    tabIndex,
    activeId,
    textError,
    formCardList,
    formVehicleList,
    setFormVehicleList,
}: CaseVehicesListSelectProps) => {
    const ref = useRef<any | null>(null);

    const [listVehicle, setListVehicle] = useState<OptionSelect[]>([]);
    const parkingChoose = useAppSelector((state) => state.parking.chooseDashboard);
    const [anchorEl, setAnchorEl] = useState<HTMLButtonElement | null>(null);

    // use effect
    useEffect(() => {
        if (!parkingChoose) return;
        vehicleTypeApi.getVehicleTypes().then((res) => {
            if (res.data && res.data.length > 0) {
                var list = res.data.map((item: Vehicel) => {
                    var option: OptionSelect = {
                        id: item.ID,
                        label: item.Name,
                    };
                    return option;
                });
                setListVehicle(list);
            }
        });
    }, [parkingChoose]);

    const vehicleList = () => {
        // Check if the formCardList is empty, return the original formVehicleList
        if (formCardList.length === 0) {
            return formVehicleList;
        }

        // Create a Set containing the IDs of elements in formCardList
        const formCardListIds = new Set(formCardList.map((i) => i.vehicleType?.id));

        // If activeId is available, add it to formCardListIds
        if (activeId) {
            formCardListIds.add(activeId);
        }

        // Use filter to filter the formVehicleList based on the condition
        const filteredList = formVehicleList.filter((element) => {
            // Check if the element exists in the formCardListIds
            const check = formCardListIds.has(element?.id);
            // Return true if it doesn't exist or if activeId is in formCardListIds
            return !check;
        });
        // Return the filtered list
        return filteredList;
    };

    return (
        <>
            <InputLabel sx={{ fontSize: 14, fontWeight: 400, color: '#55595D', mb: '6px' }}>
                2. Chọn phương tiện{' '}
                <Typography
                    component={'span'}
                    sx={{
                        color: '#E42727',
                        fontSize: 13,
                    }}
                >
                    (✶)
                </Typography>
            </InputLabel>
            <Stack
                onClick={() => setAnchorEl(ref.current)}
                direction="row"
                alignItems="center"
                justifyContent="space-between"
                ref={ref}
                tabIndex={tabIndex}
                sx={{
                    border: '1px solid #E3E5E5',
                    padding: '13px 16px',
                    borderRadius: '6px',
                    position: 'relative',
                    height: '46px',
                    ':focus': {
                        outlineColor: '#E3E5E5',
                    },
                }}
            >
                {value == null ? (
                    <Typography sx={{ fontSize: '16px', color: '#323232', opacity: 0.5 }}>
                        Chọn phương tiện
                    </Typography>
                ) : (
                    <Stack direction="row" sx={{ gap: '12px', flex: 1 }}>
                        <Typography
                            sx={{
                                fontSize: '14px',
                                fontWeight: 400,
                                lineHeight: '140%',
                            }}
                        >
                            {listVehicle.filter((i) => i.id == value.vehicleTypeId).length > 0
                                ? listVehicle.filter((i) => i.id == value.vehicleTypeId)[0].label
                                : ''}
                        </Typography>

                        <Typography
                            sx={{
                                fontSize: '14px',
                                fontWeight: 500,
                                lineHeight: '140%',
                                whiteSpace: 'nowrap',
                                color: '#007DC0',
                            }}
                        >
                            {formVehicleList.filter((i) => i.vehicleTypeId == value.vehicleTypeId)
                                .length > 0
                                ? formVehicleList.filter(
                                      (i) => i.vehicleTypeId == value.vehicleTypeId
                                  )[0].placeNo
                                : ''}
                        </Typography>
                        <Stack
                            sx={{
                                width: '1px',
                                height: '14px',
                                backgroundColor: '#E3E5E5',
                            }}
                        />
                        <Typography
                            sx={{
                                fontSize: '14px',
                                fontWeight: 400,
                                lineHeight: '140%',
                                whiteSpace: 'nowrap',
                                color: '#808080',
                            }}
                        >
                            {value?.vehicleBrand}
                        </Typography>
                    </Stack>
                )}

                {/* <ArrowForwardIosIcon
                    sx={{
                        fontSize: '15px',
                        rotate: Boolean(anchorEl) ? '-90deg' : '90deg',
                        cursor: 'pointer',
                        transition: 'all ease .3s',
                        color: '#55595D',
                    }}
                /> */}
                <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="24"
                    height="24"
                    viewBox="0 0 24 24"
                    fill="none"
                    style={{
                        fontSize: '20px',
                        cursor: 'pointer',
                        transition: 'all .3s ease',
                        color: '#55595D',
                        rotate: !Boolean(anchorEl) ? '0deg' : '180deg',
                        marginRight: '-10px',
                    }}
                >
                    <path
                        d="M6 9L12 15L18 9"
                        stroke="#55595D"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                    />
                </svg>
            </Stack>
            {textError && (
                <Stack direction={'row'} spacing={'5px'} sx={{ alignItems: 'center', mt: '4px' }}>
                    <Stack
                        sx={{
                            width: '13px',
                            height: '13px',
                            alignItems: 'center',
                            justifyContent: 'center',
                            background: '#E42727',
                            borderRadius: '50%',
                        }}
                    >
                        <CloseIcon sx={{ color: '#fff', fontSize: 10, fontWeight: 600 }} />
                    </Stack>
                    <Typography
                        sx={{
                            fontSize: 12,
                            fontWeight: 400,
                            color: '#E42727',
                        }}
                    >
                        {textError}
                    </Typography>
                </Stack>
            )}
            <Popover
                id={Boolean(anchorEl) ? 'simple-popover' : undefined}
                open={Boolean(anchorEl)}
                anchorEl={anchorEl}
                onClose={() => setAnchorEl(null)}
                anchorOrigin={{
                    vertical: 'bottom',
                    horizontal: 'left',
                }}
            >
                <Stack
                    sx={{
                        width: `${ref.current?.clientWidth}px`,
                        backgroundColor: '#fff',
                        transition: 'all ease .3s',
                        left: 0,
                        boxShadow: '0px 4px 16px 0px rgba(0, 0, 0, 0.10)',
                        padding: '8px',
                        gap: '4px',
                    }}
                >
                    <Paper
                        component="form"
                        sx={{
                            display: 'flex',
                            alignItems: 'center',
                            border: '1px solid #F2F2F2',
                            borderRadius: '6px',
                        }}
                        elevation={0}
                    >
                        <IconButton sx={{ p: '5px' }} aria-label="menu">
                            <SearchIcon style={{ color: '#AFAFAF' }} />
                        </IconButton>
                        <InputBase
                            sx={{ flex: 1, fontSize: 12 }}
                            placeholder="Chọn loại xe"
                            inputProps={{ 'aria-label': 'Chọn loại xe' }}
                        />
                    </Paper>

                    <Stack
                        sx={{
                            border: '1px solid #F2F2F2;',
                            padding: '4px',
                            borderRadius: '6px',
                        }}
                    >
                        <Stack
                            sx={{
                                maxHeight: '300px',
                                padding: '4px',
                                overflow: 'auto',
                                scrollSnapType: 'y mandatory',
                                '&::-webkit-scrollbar': {
                                    width: '2px',
                                },
                                '&::-webkit-scrollbar-thumb': {
                                    background: '#78C6E7',
                                },
                                '&::-webkit-scrollbar-track': {
                                    background: '#F2F2F2',
                                },
                            }}
                        >
                            <List disablePadding>
                                {formVehicleList && vehicleList().length > 0 ? (
                                    vehicleList().map((v, k) => {
                                        return (
                                            <ListItem
                                                key={`${k}-vehicel-brand-item`}
                                                disablePadding
                                            >
                                                <Stack
                                                    sx={{
                                                        scrollSnapAlign: 'start',
                                                        gap: '8px',
                                                        borderRadius: '4px',
                                                        cursor: 'pointer',
                                                        transition: 'all ease .3s',
                                                        '.icon-button': {
                                                            opacity: 0,
                                                            visibility: 'hidden',
                                                            width: 0,
                                                        },
                                                        '&:hover ': {
                                                            backgroundColor: '#F4FAFE',
                                                            '.icon-button': {
                                                                opacity: 1,
                                                                visibility: 'visible',
                                                                width: '40px',
                                                            },
                                                        },
                                                        width: '100%',
                                                        p: '0 10px',
                                                    }}
                                                    direction="row"
                                                    alignItems="center"
                                                >
                                                    <IconButton
                                                        className="icon-button"
                                                        edge="start"
                                                        aria-label="delete"
                                                        sx={{
                                                            color: '#55595D',
                                                            transition: 'all ease .3s',
                                                            width: '40px',
                                                            height: '40px',
                                                        }}
                                                    >
                                                        <EditIcon sx={{ fontSize: '20px' }} />
                                                    </IconButton>
                                                    <Stack
                                                        onClick={() => {
                                                            setValue(v);
                                                            setAnchorEl(null);
                                                        }}
                                                        direction="row"
                                                        sx={{ gap: '12px', flex: 1 }}
                                                    >
                                                        <Typography
                                                            sx={{
                                                                fontSize: '14px',
                                                                fontWeight: 400,
                                                                lineHeight: '140%',
                                                            }}
                                                        >
                                                            {listVehicle.filter(
                                                                (i) => i.id == v.vehicleTypeId
                                                            )[0]?.label ?? ''}
                                                        </Typography>
                                                        <Stack
                                                            sx={{
                                                                width: '1px',
                                                                height: '14px',
                                                                backgroundColor: '#E3E5E5',
                                                            }}
                                                        />
                                                        <Typography
                                                            sx={{
                                                                fontSize: '14px',
                                                                fontWeight: 500,
                                                                lineHeight: '140%',
                                                                whiteSpace: 'nowrap',
                                                                color: '#007DC0',
                                                            }}
                                                        >
                                                            {v.placeNo}
                                                        </Typography>
                                                        <Stack
                                                            sx={{
                                                                width: '1px',
                                                                height: '14px',
                                                                backgroundColor: '#E3E5E5',
                                                            }}
                                                        />
                                                        <Typography
                                                            sx={{
                                                                fontSize: '14px',
                                                                fontWeight: 400,
                                                                lineHeight: '140%',
                                                                whiteSpace: 'nowrap',
                                                                color: '#808080',
                                                            }}
                                                        >
                                                            {v.vehicleBrand}
                                                        </Typography>
                                                    </Stack>

                                                    <IconButton
                                                        className="icon-button"
                                                        edge="end"
                                                        aria-label="delete"
                                                        sx={{
                                                            color: '#55595D',
                                                            transition: 'all ease .3s',
                                                            width: '40px',
                                                            height: '40px',
                                                        }}
                                                    >
                                                        <DeleteIcon
                                                            onClick={() => {
                                                                var arr = formVehicleList.filter(
                                                                    (element) => element.id != v.id
                                                                );
                                                                setValue(null);
                                                                setFormVehicleList(arr);
                                                            }}
                                                            sx={{
                                                                fontSize: '20px',
                                                                color: '#E42727',
                                                            }}
                                                        />
                                                    </IconButton>
                                                </Stack>
                                            </ListItem>
                                        );
                                    })
                                ) : (
                                    <List>
                                        <ListItem
                                            disablePadding
                                            dense
                                            // secondaryAction={
                                            //     <IconButton edge="end" aria-label="delete">
                                            //         <DeleteIcon />
                                            //     </IconButton>
                                            // }
                                        >
                                            <ListItemText
                                                primary={
                                                    formVehicleList.length > 0
                                                        ? 'Thêm phương tiện'
                                                        : 'Chưa có phương tiện'
                                                }
                                            />
                                        </ListItem>
                                    </List>
                                )}
                            </List>
                        </Stack>
                    </Stack>
                </Stack>
            </Popover>
        </>
    );
};
