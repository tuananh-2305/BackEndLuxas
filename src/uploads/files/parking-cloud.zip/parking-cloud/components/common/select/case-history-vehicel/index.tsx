import { vehicleTypeApi } from '@/api/vehicle-type-api';
import { Popover, Stack, Typography } from '@mui/material';
import { useEffect, useRef, useState } from 'react';

interface CaseHistorySelectProps {
    value: string;
    change: (v: string) => void;
}

export const CaseHistoryVehicleSelect = (props: CaseHistorySelectProps) => {
    const { change, value } = props;
    const ref = useRef<HTMLDivElement | null>(null);
    const [open, setOpen] = useState(false);
    const [vehicles, setVehicles] = useState<any[]>([]);

    useEffect(() => {
        vehicleTypeApi.getVehicleTypes().then((res) => {
            setVehicles(res.data);
        });
    }, []);
    const generatorTitle = () => {
        // console.log(value);
        if (value === 'ALL') {
            return 'Tất cả loại xe';
        } else {
            return vehicles.filter((v) => v.ID === value)[0].Name;
        }
    };
    return (
        <Stack>
            <Stack
                ref={ref}
                sx={{
                    width: '200px',
                    border: '1px solid #55595D',
                    padding: '5px 10px',
                    borderRadius: '5px',
                    cursor: 'pointer',
                }}
                onClick={() => setOpen(true)}
            >
                <Typography sx={{ fontSize: '12px', fontWeight: 700 }}>
                    {generatorTitle()}
                </Typography>
            </Stack>
            <Popover
                open={open}
                anchorEl={ref.current}
                onClose={() => setOpen(false)}
                anchorOrigin={{
                    vertical: 'bottom',
                    horizontal: 'left',
                }}
            >
                <Stack sx={{ width: `${ref.current?.clientWidth}px` }}>
                    <Stack
                        key={'all vehicle'}
                        sx={{
                            padding: '5px 10px',
                            cursor: 'pointer',
                            '&:hover': {
                                backgroundColor: '#d9d9d9',
                            },
                        }}
                        onClick={() => {
                            change('ALL');
                            setOpen(false);
                        }}
                    >
                        <Typography
                            sx={{
                                fontSize: '12px',
                                fontWeight: 700,
                            }}
                        >
                            Tất cả
                        </Typography>
                    </Stack>
                    {vehicles.map((v) => {
                        return (
                            <Stack
                                key={v.ID}
                                sx={{
                                    padding: '5px 10px',
                                    cursor: 'pointer',
                                    '&:hover': {
                                        backgroundColor: '#d9d9d9',
                                    },
                                }}
                                onClick={() => {
                                    setOpen(false);
                                    change(v.ID);
                                }}
                            >
                                <Typography
                                    sx={{
                                        fontSize: '12px',
                                        fontWeight: 700,
                                    }}
                                >
                                    {v.Name}
                                </Typography>
                            </Stack>
                        );
                    })}
                </Stack>
            </Popover>
        </Stack>
    );
};
