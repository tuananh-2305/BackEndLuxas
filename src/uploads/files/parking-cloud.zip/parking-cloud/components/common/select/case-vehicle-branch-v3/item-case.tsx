import { VehicleBrand } from '@/models/vehicle.model';
import DeleteOutlinedIcon from '@mui/icons-material/DeleteOutlined';
import ModeEditOutlineOutlinedIcon from '@mui/icons-material/ModeEditOutlineOutlined';
import {
    IconButton,
    InputBase,
    ListItem,
    ListItemButton,
    ListItemText,
    Stack,
} from '@mui/material';
import { useRef, useState } from 'react';
import SaveRoundedIcon from '@mui/icons-material/SaveRounded';
import { vehicelBranchApi } from '@/api/vehicel-brand';
export interface IVehicelBranchItemProps {
    item: VehicleBrand;
    onRemove: (v: any) => void;
    propsCheck: any;
}

export function VehicelBranchItem(props: IVehicelBranchItemProps) {
    const { item, propsCheck } = props;

    return (
        <ListItem
            disablePadding
            sx={{
                ':hover': {
                    '.delete-icon': {
                        opacity: 1,
                    },
                },
            }}
        >
            <ListItemText {...propsCheck} primary={item.Name} />
            <IconButton
                className="delete-icon"
                onClick={() => {
                    props.onRemove(item.ID);
                }}
                sx={{ opacity: 0 }}
            >
                <DeleteOutlinedIcon color="error" />
            </IconButton>
        </ListItem>
    );
}
