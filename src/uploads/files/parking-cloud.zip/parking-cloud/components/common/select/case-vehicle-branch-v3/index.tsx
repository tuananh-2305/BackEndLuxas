import { vehicelBranchApi } from '@/api/vehicel-brand';
import { VehicleBrand } from '@/models/vehicle.model';
import { Validator } from '@/ultis/validate';
import CloseIcon from '@mui/icons-material/Close';
import { Autocomplete, InputLabel, Stack, TextField, Typography } from '@mui/material';
import { useCallback, useEffect, useState } from 'react';
import { VehicelBranchItem } from './item-case';
interface VehicelBranchSelectProV3ps {
    value: string;
    onChange: (v: any) => void;
    textError?: string;
    color?: string;
    tabIndex?: number | undefined;
}

export const VehicelBranchSelectV3 = (props: VehicelBranchSelectProV3ps) => {
    const { value, onChange, textError } = props;
    const color = props.color ? props.color : textError ? '#E42727' : '#E3E5E5';

    const [data, setData] = useState<VehicleBrand[]>([]);
    const [optionValue, setOptionValue] = useState<VehicleBrand | null>(null);

    const [searchKey, setsearchKey] = useState('');

    const callData = useCallback(async () => {
        vehicelBranchApi.pagination({ TextSearch: '', Current: 0, Limit: 1000 }).then((res) => {
            const { Data, Total } = res.data;
            setData(Data);
        });
    }, []);

    useEffect(() => {
        callData();
    }, []);

    useEffect(() => {
        setsearchKey(value ?? '');
        let dataFilter = data.filter((i: any) => i.Name == value);
        let newValue = dataFilter.length > 0 ? dataFilter[0] : null;
        setOptionValue(newValue);
    }, [value]);

    const handleAddOption = async (option: string) => {
        let hasErr = Validator.checkNotEmpty(option) != null;
        if (hasErr) return;

        let filterItem = data.filter((i) => i.Name.toLowerCase() == option.toLowerCase());
        if (filterItem.length > 0) {
            onChange(filterItem[0].Name);
        } else {
            try {
                let { data } = await vehicelBranchApi.create(option);
                vehicelBranchApi
                    .pagination({ TextSearch: '', Current: 0, Limit: 1000 })
                    .then((res) => {
                        const { Data, Total } = res.data;
                        setData(Data);
                        setOptionValue(data);
                        onChange(data.Name);
                        setsearchKey(data.Name);
                    });
            } catch (error) {
                //
            }
        }
    };

    const [open, setOpen] = useState(false);
    const closePopper = () => setOpen(false);
    const openPopper = () => setOpen(true);

    return (
        <Stack
            component={'form'}
            sx={{
                p: 0,
            }}
            onSubmit={(e) => {
                e.preventDefault();
                handleAddOption(searchKey);
                closePopper();
            }}
        >
            <InputLabel sx={{ fontSize: 14, fontWeight: 400, color: '#55595D', mb: '6px' }}>
                4. Hãng xe
            </InputLabel>
            {data.length > 0 && (
                <Autocomplete
                    open={open}
                    onOpen={openPopper}
                    onClose={closePopper}
                    options={data}
                    value={optionValue}
                    inputValue={searchKey}
                    onInputChange={(event, newInputValue) => {
                        setsearchKey(newInputValue);
                    }}
                    isOptionEqualToValue={(option, value) => option.Name === value.Name}
                    onChange={(event: any, value: VehicleBrand | null) => {
                        setOptionValue(value);
                        onChange(value?.Name);
                    }}
                    getOptionLabel={(option: VehicleBrand) => option.Name}
                    openOnFocus
                    clearIcon={<></>}
                    renderInput={(params) => (
                        <TextField
                            {...params}
                            placeholder="Chọn hãng xe"
                            sx={{
                                '& .MuiOutlinedInput-root:hover': {
                                    '& > fieldset': {
                                        borderColor: color,
                                        transition: 'all 0.3s',
                                    },
                                },
                                '& .MuiOutlinedInput-root': {
                                    '& > fieldset': {
                                        borderColor: color,
                                        transition: 'all 0.3s',
                                        borderRadius: '6px',
                                        color: 'red',
                                    },
                                    '&.Mui-focused fieldset': {
                                        borderColor: color,
                                        transition: 'all 0.3s',
                                    },
                                },
                                '& label.Mui-focused': {
                                    color: color,
                                },
                                marginTop: '0px',
                                transition: 'all 0.3s',
                                '& input[type=number]': {
                                    '-moz-appearance': 'textfield',
                                },
                                '& input[type=number]::-webkit-outer-spin-button': {
                                    '-webkit-appearance': 'none',
                                    margin: 0,
                                },
                                '& input[type=number]::-webkit-inner-spin-button': {
                                    '-webkit-appearance': 'none',
                                    margin: 0,
                                },
                                margin: 0,
                                padding: 0,
                            }}
                            inputProps={{
                                ...params.inputProps,
                                tabIndex: props.tabIndex,
                                style: {
                                    fontSize: '16px',
                                    fontWeight: 400,
                                    color: '#323232',
                                    height: '13px',
                                },
                            }}
                        />
                    )}
                    noOptionsText={'Nhấn "Enter" để thêm ' + searchKey}
                    renderOption={(props1: object, item: VehicleBrand, state: object) => (
                        <VehicelBranchItem
                            key={item.ID}
                            item={item}
                            propsCheck={props1}
                            onRemove={function (ID: string): void {
                                vehicelBranchApi.remove(ID).then((res) => {
                                    callData();
                                });
                                if (ID == optionValue?.ID) {
                                    setOptionValue(null);
                                    onChange('');
                                    setsearchKey('');
                                }
                            }}
                        />
                    )}
                />
            )}
            {textError && (
                <Stack direction={'row'} spacing={'5px'} sx={{ alignItems: 'center', mt: '4px' }}>
                    <Stack
                        sx={{
                            width: '13px',
                            height: '13px',
                            alignItems: 'center',
                            justifyContent: 'center',
                            background: '#E42727',
                            borderRadius: '50%',
                        }}
                    >
                        <CloseIcon sx={{ color: '#fff', fontSize: 10, fontWeight: 600 }} />
                    </Stack>
                    <Typography
                        sx={{
                            fontSize: 12,
                            fontWeight: 400,
                            color: '#E42727',
                        }}
                    >
                        {textError}
                    </Typography>
                </Stack>
            )}
        </Stack>
    );
};
