import * as React from 'react';
import Image from 'next/image';
import { SxProps, Theme } from '@mui/material/styles';
import { Stack } from '@mui/material';

export interface IImageNextjsProps {
    path: string;
    sx?: SxProps<Theme>;
    alt?: string;
}

export default function ImageNextjs(props: IImageNextjsProps) {
    const { path, sx, alt = 'oryza-image' } = props;
    return (
        <Stack component={'div'} sx={sx}>
            <div className={'image-container'}>
                <Image src={path} className={'image'} fill alt={alt} />
            </div>
        </Stack>
    );
}
