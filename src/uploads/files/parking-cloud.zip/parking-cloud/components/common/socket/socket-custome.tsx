const BACKEND_DOMAIN = process.env.NEXT_PUBLIC_SERVER_PARKING_DOMAIN || '';
import { useAppDispatch, useAppSelector } from '@/hooks/useReudx';
import { LayoutProps } from '@/models/common';
import { updateDevice, updateDeviceOnlineOffline } from '@/redux/index';
import {
    updateHistoryNew,
    updateHistoryUpdate,
    updateOfflineDevice,
    updateOnlineDevice,
} from '@/redux/socket';

import { createContext, useEffect, useState } from 'react';
import { io } from 'socket.io-client';

export interface ISocketCustomProps {}
export const SocketContext: any = createContext({ socket: null });

export default function SocketCustom({ children }: LayoutProps) {
    // const useSocketCustom = UseSocketCustom();
    const dispatch = useAppDispatch();
    const [socketClient, setSocketClient] = useState<any>(null);
    const profile = useAppSelector((state) => state.common.profile);
    // const [socketServer, setSocketServer] = useState<Socket | null>(null);

    useEffect(() => {
        if (!profile?.ID) return;
        const socket = io(BACKEND_DOMAIN, {
            withCredentials: true,
        });
        socket.on('connect', () => {
            // console.log('connect');
            socket.emit('join-web', {
                UserId: profile.ID,
            });
        });
        setSocketClient(socket);
        return () => {
            socket.disconnect();
            setSocketClient(null);
        };
    }, [profile?.ID]);

    useEffect(() => {
        if (socketClient) {
            socketClient.on('device-online', (data: any) => {
                // console.log('device-online', data);
                const action = updateOnlineDevice({ data: data });
                dispatch(action);
                const action1 = updateDeviceOnlineOffline({ data: data, isOnline: true });
                dispatch(action1);
            });
            socketClient.on('device-offline', (data: any) => {
                // console.log('device-offline', data);
                const action = updateOfflineDevice({ data: data });
                dispatch(action);
                const action1 = updateDeviceOnlineOffline({ data: data, isOnline: false });
                dispatch(action1);
            });
            socketClient.on('create-history', (data: any) => {
                // console.log('create-history', data);
                const action = updateHistoryNew({ data: data });
                dispatch(action);
            });
            socketClient.on('update-history', (data: any) => {
                // console.log('update-history', data);
                const action = updateHistoryUpdate({ data: data });
                dispatch(action);
            });
            socketClient.on('create-camera', (data: any) => {
                // console.log('create-camera', data);
            });
            socketClient.on('update-camera', (data: any) => {
                // console.log('update-camera', data);
            });
            socketClient.on('delete-camera', (data: any) => {
                // console.log('delete-camera', data);
            });
            socketClient.on(
                'synchronized-data',
                (data: { Data: any; Table: string; Status: 'INSERT' | 'UPDATE' }) => {}
            );
        }
    }, [socketClient]);

    return (
        <SocketContext.Provider value={{ socket: socketClient }}>{children}</SocketContext.Provider>
    );
}
