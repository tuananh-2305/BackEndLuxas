import MoreVertIcon from '@mui/icons-material/MoreVert';
import { IconButton, IconButtonPropsColorOverrides } from '@mui/material';
import { OverridableStringUnion } from '@mui/types';
import { useEffect, useState } from 'react';
import { StyledMenu } from '../style-component';

export interface ICustomizedMenusProps {
    children?: React.ReactNode[] | React.ReactNode;
    sx?: any;
    size?: 'small' | 'medium' | undefined;
}

export default function CustomizedMenus(props: ICustomizedMenusProps) {
    const [anchorEl, setAnchorEl] = useState<null | HTMLElement>(null);
    const open = Boolean(anchorEl);
    const [isShow, setIsShow] = useState<boolean>(false);

    const handleClick = (event: React.MouseEvent<HTMLElement>) => {
        setAnchorEl(event.currentTarget);
    };
    const handleClose = () => {
        setAnchorEl(null);
    };
    useEffect(() => {
        // if (!props.children) return;
        setIsShow(false);
        if (!Array.isArray(props.children) && props.children) {
            setIsShow(true);
            return;
        }
        Array.isArray(props.children) &&
            props.children?.some((item: any) => {
                if (item) {
                    setIsShow(true);
                    return true;
                }
            });
        return () => {
            setIsShow(false);
        };
    }, [props.children]);

    return (
        <>
            <IconButton
                id="demo-customized-button"
                aria-controls={open ? 'demo-customized-menu' : undefined}
                aria-haspopup="true"
                aria-expanded={open ? 'true' : undefined}
                onClick={handleClick}
                sx={
                    (props.sx,
                    {
                        display: isShow ? 'flex' : 'none',
                    })
                }
                size={props.size}
            >
                <MoreVertIcon fontSize={props.size} />
            </IconButton>
            <StyledMenu
                MenuListProps={{
                    'aria-labelledby': 'demo-customized-button',
                }}
                anchorEl={anchorEl}
                open={open}
                onClose={handleClose}
                onClick={handleClose}
            >
                {props.children}
            </StyledMenu>
        </>
    );
}
