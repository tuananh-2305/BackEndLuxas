import { Stack } from '@mui/material';
import React from 'react';
import DateTimeCustomerComp from './data-time-customer';

export interface IShowDatetimeCustomerProps {}

export default function ShowDatetimeCustomer(props: IShowDatetimeCustomerProps) {
    return (
        <Stack>
            <DateTimeCustomerComp />
        </Stack>
    );
}
