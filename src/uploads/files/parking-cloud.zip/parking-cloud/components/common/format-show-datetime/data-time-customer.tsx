import { Stack, Typography } from '@mui/material';
import React from 'react';
import CalendarMonthOutlinedIcon from '@mui/icons-material/CalendarMonthOutlined';

export interface IDateTimeCustomerCompProps {}

export default function DateTimeCustomerComp(props: IDateTimeCustomerCompProps) {
    return (
        <Stack>
            <Stack>
                <CalendarMonthOutlinedIcon />
                <Typography>10/10/2023</Typography>
            </Stack>
        </Stack>
    );
}
