import { DialogContentText, IconButton, Stack, SxProps, Theme, Tooltip } from '@mui/material';
import DeleteOutlinedIcon from '@mui/icons-material/DeleteOutlined';
import CustomizedMenus from '../menu/menu';
import BorderColorIcon from '@mui/icons-material/BorderColor';
import SyncProblemIcon from '@mui/icons-material/SyncProblem';
import DialogAlert from '@/components/dialog/dialog-alert';
import { useState } from 'react';
import DialogWarning from '@/components/dialog/dialog-warning';
import DeleteDialog from '../dialog/delete-dialog';
import DeleteMemberDialog from '@/components/dialog/dialog-delete-member/delete-dialog';
export interface IActionTableProps {
    children?: React.ReactNode[] | React.ReactNode;
    onDelete?: () => void;
    onEdit?: () => void;
    onSync?: () => void;
    size?: 'small' | 'medium' | undefined;
    sx?: SxProps<Theme>;
    data?: any;
}

export default function ActionTable(props: IActionTableProps) {
    const { children, onDelete, onEdit, onSync, size, sx } = props;
    const [openDialogSuccess, setOpenDialogSuccess] = useState(false);

    return (
        <Stack
            direction={'row'}
            alignItems={'center'}
            spacing={1}
            sx={{ ...sx }}
            onClick={(e) => {
                e.stopPropagation();
            }}
            justifyContent={'flex-start'}
        >
            {props.data ? (
                <DeleteMemberDialog
                    open={openDialogSuccess}
                    handleClose={() => {
                        setOpenDialogSuccess(false);
                    }}
                    handleConfirm={() => {
                        if (onDelete) onDelete();
                        setOpenDialogSuccess(false);
                    }}
                    data={props.data}
                />
            ) : (
                <DialogWarning
                    open={openDialogSuccess}
                    handleClose={() => {
                        setOpenDialogSuccess(false);
                    }}
                    handleConfirm={() => {
                        if (onDelete) onDelete();
                        setOpenDialogSuccess(false);
                    }}
                    title="Bạn đang thực hiện hành động xóa dữ liệu khỏi hệ thống, Nhập "
                ></DialogWarning>
            )}

            {onSync && (
                <Tooltip title="Đồng bộ">
                    <IconButton color="error" onClick={onSync} size={size}>
                        <SyncProblemIcon fontSize={size} />
                    </IconButton>
                </Tooltip>
            )}
            {onDelete && (
                <Tooltip title="Xóa">
                    <IconButton
                        color="error"
                        sx={{
                            backgroundColor: 'rgba(233, 79, 79, 0.3)',
                            '&:hover': {
                                backgroundColor: 'rgba(233, 79, 79, 0.2)',
                            },
                            boxShadow: '0px 2px 2px rgba(0, 0, 0, 0.25)',
                        }}
                        onClick={() => {
                            setOpenDialogSuccess(true);
                        }}
                        size={size}
                    >
                        <DeleteOutlinedIcon fontSize={size} />
                    </IconButton>
                </Tooltip>
            )}
            {onEdit && (
                <Tooltip title="Sửa">
                    <IconButton
                        sx={{
                            backgroundColor: '#067DC0',
                            color: '#fff',
                            '&:hover': {
                                backgroundColor: 'rgba(6, 125, 192, 0.8)',
                            },
                            boxShadow: '0px 2px 2px rgba(0, 0, 0, 0.25)',
                        }}
                        onClick={onEdit}
                        size={size}
                    >
                        <BorderColorIcon fontSize={size} />
                    </IconButton>
                </Tooltip>
            )}
            <CustomizedMenus size={size}>{children}</CustomizedMenus>
        </Stack>
    );
}
