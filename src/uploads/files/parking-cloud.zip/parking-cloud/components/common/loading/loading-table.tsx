import { LinearProgress, Stack, Typography } from '@mui/material';
import * as React from 'react';

export interface ILoadingTableProps {}

export default function LoadingTable(props: ILoadingTableProps) {
    return (
        <Stack
            sx={{ flex: 1, width: '100%' }}
            direction="column"
            justifyContent="center"
            alignItems="center"
        >
            <Stack sx={{ width: '40%', gap: '20px' }} justifyContent="center" alignItems="center">
                <Typography sx={{ fontWeight: 700, color: '#333' }}>
                    Đang tìm nạp dữ liệu
                </Typography>
                <LinearProgress sx={{ width: '100%' }} />
            </Stack>
        </Stack>
    );
}
