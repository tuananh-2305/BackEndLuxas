import { Popover, Stack } from '@mui/material';
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs';
import { DateCalendar } from '@mui/x-date-pickers/DateCalendar';
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import dayjs, { Dayjs } from 'dayjs';
import 'dayjs/locale/vi';

import { styled } from '@mui/material/styles';
import { PickersDay, PickersDayProps } from '@mui/x-date-pickers/PickersDay';
import isBetweenPlugin from 'dayjs/plugin/isBetween';
import * as React from 'react';
import { useEffect } from 'react';
import { TimeControlComponent } from '../picker-popover/time-control-v2';

export interface IPickDateMuiPopupProps {
    anchorEl: HTMLDivElement | null;
    onclose: () => void;
    startTime: Date | null;
    endTime: Date | null;
    timeStartchange: (t: Date | null) => void;
    timeEndchange: (t: Date | null) => void;
    minTime?: any;
    maxTime?: any;
}

dayjs.extend(isBetweenPlugin);

interface CustomPickerDayProps extends PickersDayProps<Dayjs> {
    dayIsBetween: boolean;
    isFirstDay: boolean;
    isLastDay: boolean;
}

const CustomPickersDay = styled(PickersDay, {
    shouldForwardProp: (prop) =>
        prop !== 'dayIsBetween' && prop !== 'isFirstDay' && prop !== 'isLastDay',
})<CustomPickerDayProps>(({ theme, dayIsBetween, isFirstDay, isLastDay }) => ({
    ...(dayIsBetween && {
        background: '#F4FAFE',
        '&:hover, &:focus': {
            background: '#F4FAFE',
        },
        // borderRadius: '50%',
        clipPath: 'circle(42.5%)',
    }),
    ...(isFirstDay && {
        background: '#007DC0',
        color: '#fff',
        '&:hover, &:focus': {
            background: '#007DC0',
            color: '#fff',
        },
    }),
    ...(isLastDay && {
        color: '#fff',
        background: '#007DC0',
        '&:hover, &:focus': {
            color: '#fff',
            background: '#007DC0',
        },
    }),
})) as React.ComponentType<CustomPickerDayProps>;

function Day(
    props: PickersDayProps<Dayjs> & { selectedDay?: Dayjs | null; highlightedDays?: Date[] }
) {
    const { highlightedDays = [], day, selectedDay, ...other } = props;

    if (selectedDay == null) {
        return <PickersDay day={day} {...other} />;
    }
    var arr = [...highlightedDays];

    arr.sort(function (a, b) {
        return a.getTime() - b.getTime();
    });

    const start = arr[0];
    const end = arr[arr.length - 1];

    const dayIsBetween = day.isBetween(start, end, null, '[]');
    const isFirstDay = day.isSame(start, 'day');
    const isLastDay = day.isSame(end, 'day');

    return (
        <CustomPickersDay
            {...other}
            day={day}
            sx={dayIsBetween ? { px: 2.5, mx: 0 } : {}}
            dayIsBetween={dayIsBetween}
            isFirstDay={isFirstDay}
            isLastDay={isLastDay}
        />
    );
}
export default function PickDateMuiPopup(props: IPickDateMuiPopupProps) {
    const {
        anchorEl,
        onclose,
        timeEndchange,
        timeStartchange,
        startTime,
        endTime,
        minTime,
        maxTime,
    } = props;
    // const maxDate: any = dayjs(maxTime);
    // const minDate: any = dayjs(minTime);
    // const defaultValue: Dayjs = dayjs(time);
    const now = new Date();
    const today = new Date(now.getFullYear(), now.getMonth(), now.getDate(), 0, 0);

    const [value, setValue] = React.useState<Dayjs | null>(dayjs(today));
    const [highlightedDays, setHighlightedDays] = React.useState<Date[]>([]);

    useEffect(() => {
        var start = startTime ?? new Date();
        var end = endTime ?? new Date();
        setHighlightedDays([start, end]);
    }, []);

    useEffect(() => {
        if (highlightedDays.length == 2) {
            var arr = [...highlightedDays];
            arr.sort(function (a, b) {
                return a.getTime() - b.getTime();
            });
            const start = arr[0];
            const end = arr[arr.length - 1];
            timeEndchange(end);
            timeStartchange(start);
        }
    }, [highlightedDays]);

    return (
        <Popover
            open={Boolean(anchorEl)}
            anchorEl={anchorEl}
            onClose={onclose}
            anchorOrigin={{
                vertical: 'bottom',
                horizontal: 'left',
            }}
            sx={{ mt: '10px' }}
        >
            <LocalizationProvider dateAdapter={AdapterDayjs} adapterLocale="vi">
                <DateCalendar
                    value={value}
                    onChange={(value) => {
                        console.log('value: ' + dayjs(value).format('HH:mm DD/MM/YYYY'));

                        var arr = [...highlightedDays];
                        arr.push(value!.toDate());
                        if (arr.length > 2) {
                            arr.shift();
                        }
                        setHighlightedDays(arr);
                        setValue(value);
                    }}
                    slots={{ day: Day }}
                    slotProps={{
                        day: {
                            selectedDay: value,
                            highlightedDays: highlightedDays,
                        } as any,
                    }}
                    dayOfWeekFormatter={(d) => `${d}`}
                    sx={{
                        '& .MuiPickersDay-root': {
                            '&.Mui-selected': {
                                background: '#007DC0',
                                color: '#fff',
                                '&:hover, &:focus': {
                                    background: '#007DC0',
                                    color: '#fff',
                                },
                            },
                        },
                    }}
                    disableHighlightToday={true}
                />
                <Stack direction={'row'}>
                    {startTime ? (
                        <TimeControlComponent
                            timeChoose={new Date(startTime)}
                            minTime={null}
                            maxTime={endTime}
                            timeChooseChangeTime={(hour: number, minute: number) => {
                                const currentChoose = new Date(startTime)
                                    ? new Date(startTime)
                                    : new Date();

                                // change hour
                                const changeHour = new Date(currentChoose.setHours(hour));

                                // change minute
                                const changeMinute = new Date(changeHour.setMinutes(minute));

                                timeStartchange(changeMinute);
                            }}
                        />
                    ) : (
                        <></>
                    )}
                    {endTime ? (
                        <TimeControlComponent
                            timeChoose={new Date(endTime)}
                            minTime={startTime}
                            maxTime={null}
                            timeChooseChangeTime={(hour: number, minute: number) => {
                                const currentChoose = new Date(endTime)
                                    ? new Date(endTime)
                                    : new Date();

                                // change hour
                                const changeHour = new Date(currentChoose.setHours(hour));

                                // change minute
                                const changeMinute = new Date(changeHour.setMinutes(minute));

                                timeEndchange(changeMinute);
                            }}
                        />
                    ) : (
                        <></>
                    )}
                </Stack>
            </LocalizationProvider>
            {/* old version */}
            {/* <LocalizationProvider dateAdapter={AdapterDayjs} adapterLocale="vi">
                <DateCalendar
                    onChange={timechange}
                    maxDate={maxDate}
                    minDate={minDate}
                    defaultValue={defaultValue}
                    dayOfWeekFormatter={(d) => `${d}`}
                />

                {time ? (
                    <TimeControlComponent
                        timeChoose={new Date(time)}
                        minTime={minTime}
                        maxTime={maxTime}
                        timeChooseChangeTime={(hour: number, minute: number) => {
                            const currentChoose = new Date(time) ? new Date(time) : new Date();

                            // change hour
                            const changeHour = new Date(currentChoose.setHours(hour));

                            // change minute
                            const changeMinute = new Date(changeHour.setMinutes(minute));

                            timechange(changeMinute);
                        }}
                    />
                ) : (
                    <></>
                )}
            </LocalizationProvider> */}
        </Popover>
    );
}
