import { getDateTime } from '@/ultis/global-func';
import CancelIcon from '@mui/icons-material/Cancel';
import { Stack, Tooltip, Typography } from '@mui/material';
import Image from 'next/image';
import { MouseEvent, useState } from 'react';
import { PickerDateTimePopover } from './picker-popover';
import moment from 'moment';

interface StyleCustomDateTimePickerComponent {
    time: Date | null;
    setTime: (t: Date | null) => void;
    maxTime: () => Date | null | undefined;
    minTime: () => Date | null | undefined;
    disableResetTime?: boolean;
    size?: 'medium' | 'small';
    disShowCancel?: boolean;
    fullWith?: boolean;
    display?: string;
    startTitle?: string;
    endTitle?: string;
    tooltip?: string;
}

export const StyleCustomDateTimePickerComponent = (props: StyleCustomDateTimePickerComponent) => {
    const [anchorEl, setAnchorEl] = useState<HTMLDivElement | null>(null);

    const {
        time,
        setTime,
        maxTime,
        minTime,
        disableResetTime,
        size,
        disShowCancel,
        fullWith,
        display,
        startTitle,
        endTitle,
        tooltip,
    } = props;

    const max = maxTime();
    const min = minTime();

    const renderPickerSelect = () => {
        return (
            <Stack
                sx={{
                    backgroundColor: 'transparent',
                    padding: size === 'small' ? '2px 10px' : '2px 10px',
                    width: fullWith ? '100%' : 'unset',
                    cursor: 'pointer',
                }}
                direction="row"
                alignItems="center"
                justifyContent="space-between"
            >
                <Stack
                    sx={{ flex: 1 }}
                    onClick={(event: MouseEvent<HTMLDivElement>) =>
                        setAnchorEl(event.currentTarget)
                    }
                >
                    <Typography sx={{ fontSize: '14px' }}>
                        {startTitle}
                        {/* {display ? display : time ? moment(time).format('DD-MM-yyyy') : 'Chưa đặt'} */}
                        {display ? display : time ? getDateTime(time.toString()) : 'Chưa đặt'}
                        {endTitle}
                    </Typography>
                </Stack>

                {disableResetTime ? (
                    <></>
                ) : (
                    <Stack direction="row" alignItems="center" ml={1}>
                        {!disShowCancel && time ? (
                            <CancelIcon
                                onClick={() => setTime(null)}
                                sx={{ fontSize: '20px', color: '#D0474F', cursor: 'pointer' }}
                            />
                        ) : (
                            <></>
                        )}
                    </Stack>
                )}
            </Stack>
        );
    };

    return (
        <>
            {tooltip ? (
                <Tooltip title={props.tooltip}>{renderPickerSelect()}</Tooltip>
            ) : (
                renderPickerSelect()
            )}
            <PickerDateTimePopover
                anchorEl={anchorEl}
                time={time}
                minTime={min}
                maxTime={max}
                onclose={() => setAnchorEl(null)}
                timechange={(t: Date | null) => setTime(t)}
            />
        </>
    );
};
