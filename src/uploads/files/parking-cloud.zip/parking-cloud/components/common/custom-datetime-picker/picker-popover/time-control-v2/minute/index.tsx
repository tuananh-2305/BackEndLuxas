import { formatNumber } from '@/ultis/global-func';
import { Stack, Typography } from '@mui/material';
import { useEffect, useRef, useState } from 'react';
import KeyboardArrowDownIcon from '@mui/icons-material/KeyboardArrowDown';
import { off } from 'process';

interface PickerTimeControlMinuteProps {
    timeChoose: Date;
    onMinuteChange: (m: number) => void;
    isOverLimitTime: (h: number) => boolean;
}

export const PickerTimeControlMinute = (props: PickerTimeControlMinuteProps) => {
    const { onMinuteChange, timeChoose, isOverLimitTime } = props;
    const [timeIndex, setTimeIndex] = useState<number>(0);

    const crollTarget = useRef<HTMLDivElement | null>(null);
    const isChoose = (m: number) => {
        return timeChoose.getMinutes() === m;
    };

    useEffect(() => {
        if (crollTarget && crollTarget.current) {
            crollTarget.current.scrollTop = timeChoose.getMinutes() * 40;
        }
        setTimeIndex(timeChoose.getMinutes());
    }, [timeChoose]);

    const onPressUpBtn = () => {
        if (timeIndex > 0) {
            setTimeIndex(timeIndex - 1);
            if (crollTarget && crollTarget.current) {
                crollTarget.current.scrollTop = (timeIndex - 1) * 40;
            }
        }
    };
    const onPressDownBtn = () => {
        if (timeIndex < 59) {
            setTimeIndex(timeIndex + 1);
            if (crollTarget && crollTarget.current) {
                crollTarget.current.scrollTop = (timeIndex + 1) * 40;
            }
        }
    };
    return (
        <Stack
            sx={{
                flex: 1,
            }}
            justifyContent="center"
            alignItems="center"
        >
            <Stack
                onClick={onPressUpBtn}
                sx={{
                    transform: 'rotate(180deg)',
                    width: '40px',
                    height: '40px',
                    alignItems: 'center',
                    justifyContent: 'center',
                    borderRadius: '6px',
                    ':hover': {
                        background: '#f4fafe',
                    },
                    ':active': {
                        background: '#d1d1d1',
                        '.down-icon': {
                            color: '#ffffff',
                        },
                    },
                    transition: 'all 0.25s ease-in-out',
                    cursor: 'pointer',
                }}
            >
                <KeyboardArrowDownIcon
                    className="down-icon"
                    sx={{
                        color: '#d1d1d1',
                        transition: 'all 0.25s ease-in-out',
                    }}
                />
            </Stack>
            <Stack flex={1} alignItems="center" justifyContent="center">
                <Stack
                    sx={{
                        maxHeight: '40px',
                        overflow: 'auto',
                        cursor: 'pointer',
                        scrollBehavior: 'smooth',
                        whiteSpace: 'nowrap',
                        scrollSnapType: 'y mandatory',
                        '&::-webkit-scrollbar': {
                            display: 'none',
                        },
                        width: '40px',
                        height: '40px',
                    }}
                    ref={crollTarget}
                    onScroll={(v) => {
                        var newIndex = Math.floor(v.currentTarget.scrollTop / 40);
                        if (newIndex != timeIndex) {
                            setTimeIndex(newIndex);
                        }
                    }}
                >
                    {Array.from(
                        {
                            length: 60,
                        },
                        (_, i) => i
                    ).map((v) => (
                        <Stack
                            alignItems="center"
                            key={`${v}-hours-picsker`}
                            sx={{
                                transition: 'all ease .3s',
                                scrollSnapAlign: 'center',
                                tabIndex: isChoose(v) ? 0 : 'unset',
                                cursor: isOverLimitTime(v) ? 'default' : 'pointer',
                                color: isOverLimitTime(v)
                                    ? '#D0D0D0'
                                    : isChoose(v)
                                    ? '#323232'
                                    : '#4A4D51',
                            }}
                            onClick={() => {
                                if (isOverLimitTime(v)) {
                                } else {
                                    onMinuteChange(v);
                                }
                            }}
                        >
                            <Stack
                                sx={{
                                    width: '40px',
                                    height: '40px',
                                    alignItems: 'center',
                                    justifyContent: 'center',
                                }}
                            >
                                <Typography
                                    sx={{
                                        fontSize: isChoose(v) ? '14px' : '12px',
                                        fontWeight: isChoose(v) ? 700 : 400,
                                        userSelect: 'none',
                                    }}
                                >
                                    {formatNumber(v)}
                                </Typography>
                            </Stack>
                        </Stack>
                    ))}
                </Stack>
            </Stack>
            <Stack
                onClick={onPressDownBtn}
                sx={{
                    width: '40px',
                    height: '40px',
                    alignItems: 'center',
                    justifyContent: 'center',
                    borderRadius: '6px',
                    ':hover': {
                        background: '#f4fafe',
                    },
                    ':active': {
                        background: '#d1d1d1',
                        '.down-icon': {
                            color: '#ffffff',
                        },
                    },
                    transition: 'all 0.25s ease-in-out',
                    cursor: 'pointer',
                }}
            >
                <KeyboardArrowDownIcon
                    className="down-icon"
                    sx={{
                        color: '#d1d1d1',
                        transition: 'all 0.25s ease-in-out',
                    }}
                />
            </Stack>
            {/* <Stack>
                <Typography sx={{ fontSize: '14px', fontWeight: 700 }}>Phút</Typography>
            </Stack> */}
        </Stack>
    );
};
