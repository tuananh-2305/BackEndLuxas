import { getDateTime } from '@/ultis/global-func';
import CancelIcon from '@mui/icons-material/Cancel';
import { Stack, Typography } from '@mui/material';
import Image from 'next/image';
import { MouseEvent, useState } from 'react';
import { PickerDateTimePopover } from './picker-popover';

interface CustomDateTimePickerComponent {
    time: Date | null;
    setTime: (t: Date | null) => void;
    maxTime: () => Date | null | undefined;
    minTime: () => Date | null | undefined;
    disableResetTime?: boolean;
    size?: 'medium' | 'small';
    disShowCancel?: boolean;
    fullWith?: boolean;
    display?: string;
    disCalendarIcon?: boolean;
}

export const CustomDateTimePickerComponent = (props: CustomDateTimePickerComponent) => {
    const [anchorEl, setAnchorEl] = useState<HTMLDivElement | null>(null);

    const {
        time,
        setTime,
        maxTime,
        minTime,
        disableResetTime,
        size,
        disShowCancel,
        disCalendarIcon,
        fullWith,
        display,
    } = props;

    const max = maxTime();
    const min = minTime();

    return (
        <>
            <Stack
                sx={{
                    backgroundColor: 'transparent',
                    borderRadius: '5px',
                    border: '1px #A0ACBD solid',
                    padding: size === 'small' ? '5px 20px' : '10px 20px',
                    width: fullWith ? '100%' : 'unset',
                    cursor: 'pointer',
                }}
                direction="row"
                alignItems="center"
                justifyContent="space-between"
            >
                <Stack
                    sx={{ flex: 1 }}
                    onClick={(event: MouseEvent<HTMLDivElement>) =>
                        setAnchorEl(event.currentTarget)
                    }
                >
                    <Typography>
                        {display ? display : time ? getDateTime(time.toString()) : 'Chưa đặt'}
                    </Typography>
                </Stack>

                {disableResetTime ? (
                    <></>
                ) : (
                    <Stack direction="row" alignItems="center" ml={1}>
                        {!disShowCancel && time ? (
                            <CancelIcon
                                onClick={() => setTime(null)}
                                sx={{ fontSize: '20px', color: '#D0474F', cursor: 'pointer' }}
                            />
                        ) : (
                            <></>
                        )}

                        {!disCalendarIcon ? (
                            <Image
                                onClick={(event: MouseEvent<HTMLDivElement>) =>
                                    setAnchorEl(event.currentTarget)
                                }
                                src="/ico/date-time-svgrepo-com.svg"
                                width={24}
                                height={24}
                                alt="date-time-picker-icon"
                            />
                        ) : (
                            <></>
                        )}
                    </Stack>
                )}
            </Stack>
            <PickerDateTimePopover
                anchorEl={anchorEl}
                time={time}
                minTime={min}
                maxTime={max}
                onclose={() => setAnchorEl(null)}
                timechange={(t: Date | null) => setTime(t)}
            />
        </>
    );
};
