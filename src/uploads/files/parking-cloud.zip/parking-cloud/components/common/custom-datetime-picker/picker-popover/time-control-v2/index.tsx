import { Stack, Typography } from '@mui/material';
import { PickerTimeControlHour } from './hour';
import { PickerTimeControlMinute } from './minute';

interface TimeControlComponentProps {
    timeChoose: Date;
    minTime?: Date | null;
    maxTime?: Date | null;
    timeChooseChangeTime: (hour: number, minute: number) => void;
}

export const TimeControlComponent = (props: TimeControlComponentProps) => {
    const { timeChooseChangeTime } = props;
    const timeChoose = new Date(props.timeChoose);
    const minTime = props.minTime ? new Date(props.minTime) : null;
    const maxTime = props.maxTime ? new Date(props.maxTime) : null;

    const isOverLimitMinTime = (hour: number, minute: number, type: 'hour' | 'minute') => {
        if (minTime && timeChoose) {
            if (type === 'minute') {
            }

            const d =
                type === 'minute'
                    ? new Date(
                          timeChoose.getFullYear(),
                          timeChoose.getMonth(),
                          timeChoose.getDate(),
                          hour,
                          minute,
                          0,
                          0
                      )
                    : new Date(
                          timeChoose.getFullYear(),
                          timeChoose.getMonth(),
                          timeChoose.getDate(),
                          hour,
                          minute,
                          0,
                          0
                      );

            return minTime.getTime() > d.getTime();
        } else {
            return false;
        }
    };

    const isOverLimitMaxTime = (hour: number, minute: number) => {
        if (maxTime && timeChoose) {
            const d = new Date(
                timeChoose.getFullYear(),
                timeChoose.getMonth(),
                timeChoose.getDate(),
                hour,
                minute,
                0,
                0
            );

            return maxTime.getTime() < d.getTime();
        } else {
            return false;
        }
    };

    const isOverLimitTime = (hour: number, minute: number, type: 'hour' | 'minute') => {
        return isOverLimitMinTime(hour, minute, type) || isOverLimitMaxTime(hour, minute);
    };

    return (
        <Stack
            alignItems="center"
            justifyContent="center"
            direction="row"
            sx={{
                borderRadius: '12px',
                boxShadow: '0px 1px 10px 0px rgba(34, 34, 34, 0.10)',
                width: '130px',
                margin: '0 20px 20px 20px',
                alignItems: 'center',
                justifyContent: 'center',
            }}
        >
            <PickerTimeControlHour
                timeChoose={timeChoose}
                isOverLimitTime={(h: number) => isOverLimitTime(h, timeChoose.getMinutes(), 'hour')}
                onHourChange={(h: number) => {
                    timeChooseChangeTime(h, timeChoose.getMinutes());
                }}
            />
            <Typography
                sx={{
                    color: '#454545',
                    fontSize: '12px',
                    fontWeight: '400',
                }}
            >
                :
            </Typography>
            {/* ------------------------ */}
            <PickerTimeControlMinute
                timeChoose={timeChoose}
                isOverLimitTime={(m: number) => isOverLimitTime(timeChoose.getHours(), m, 'minute')}
                onMinuteChange={(m: number) => {
                    timeChooseChangeTime(timeChoose.getHours(), m);
                }}
            />
        </Stack>
    );
};
