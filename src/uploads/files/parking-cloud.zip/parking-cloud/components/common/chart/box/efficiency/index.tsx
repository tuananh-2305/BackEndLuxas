import * as React from 'react';
import styles from '../../dashboard.module.css';
import { Card, CardContent, CardHeader, IconButton, Stack, Typography } from '@mui/material';
import { calculatePercent } from '@/ultis/global-func';
import { useContext, useMemo } from 'react';
import { ContextDashboard } from '@/components/dashboard/dashboard-context';
import MoreVertIcon from '@mui/icons-material/MoreVert';
import { useAppSelector } from '@/hooks/index';
import { DonutChartComponent } from '@/components/dashboard/chart/item';
export interface IEfficiencyProps {
    title: string;
    titleDataFirst: string;
    titleDataSecond: string;
    dataFirst: number;
    dataSecond: number;
    isSetting: boolean;
}

export default function Efficiency(props: IEfficiencyProps) {
    return (
        <Card className={styles.card}>
            <CardHeader
                action={
                    props.isSetting ? (
                        <IconButton aria-label="settings">
                            <MoreVertIcon />
                        </IconButton>
                    ) : (
                        <></>
                    )
                }
                title={<Typography className={styles.card_title}>{props.title}</Typography>}
            />
            <CardContent
                className={styles.card_content}
                sx={{
                    '& .MuiCardContent-root:last-child': {
                        paddingBottom: 0,
                    },
                    padding: 0,
                }}
            >
                <Stack direction="row" sx={{ alignItems: 'center' }}>
                    <DonutChartComponent
                        chartWidth="200px"
                        colors={['#067DC0', '#CDD2D1']}
                        // data={[
                        //     dashboardToday.DataCarInParking +
                        //         (dashboardToday.DataCarIn - dashboardToday.DataCarOut),
                        //     capacity,
                        // ]}
                        data={[
                            calculatePercent(props.dataFirst, props.dataFirst + props.dataSecond),
                        ]}
                        text={`${calculatePercent(
                            props.dataFirst,
                            props.dataFirst + props.dataSecond
                        )}%`}
                    />
                    <Stack spacing={'10px'}>
                        <Stack direction="row" spacing={'10px'} sx={{ alignItems: 'center' }}>
                            <Stack
                                sx={{
                                    backgroundColor: '#067DC0',
                                    width: '10px',
                                    height: '10px',
                                    borderRadius: '5px',
                                }}
                            />
                            <Stack spacing={'5px'}>
                                <Typography
                                    sx={{
                                        fontSize: '14px',
                                        color: '#55595D',
                                        fontWeight: 400,
                                    }}
                                >
                                    {props.titleDataFirst}{' '}
                                    <span
                                        style={{
                                            fontWeight: 700,
                                            fontSize: '16px',
                                        }}
                                    >
                                        {props.dataFirst}
                                    </span>
                                </Typography>
                            </Stack>
                        </Stack>
                        <Stack direction="row" spacing={'10px'} sx={{ alignItems: 'center' }}>
                            <Stack
                                sx={{
                                    backgroundColor: '#78C6E7',
                                    width: '10px',
                                    height: '10px',
                                    borderRadius: '5px',
                                }}
                            />
                            <Stack sx={{}} spacing={'5px'}>
                                <Typography
                                    sx={{ fontSize: '14px', color: '#55595D', fontWeight: 400 }}
                                >
                                    {props.titleDataSecond}{' '}
                                    <span
                                        style={{
                                            fontWeight: 700,
                                            fontSize: '16px',
                                            color: '#55595D',
                                        }}
                                    >
                                        {props.dataSecond}
                                    </span>
                                </Typography>
                            </Stack>
                        </Stack>
                    </Stack>
                </Stack>
            </CardContent>
        </Card>
    );
}
