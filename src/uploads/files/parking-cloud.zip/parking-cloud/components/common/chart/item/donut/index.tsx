import { Stack, SxProps, Theme, Typography } from '@mui/material';
import dynamic from 'next/dynamic';
const ReactApexChart = dynamic(() => import('react-apexcharts'), { ssr: false });

interface DonutChartComponentProps {
    sx?: SxProps<Theme> | undefined;
    chartWidth: string;
    text?: string;
    data: number[];
    colors: string[];
}

export const DonutChartComponent = (props: DonutChartComponentProps) => {
    const { sx, chartWidth, text, data, colors } = props;
    return (
        <Stack sx={{ ...sx, position: 'relative' }} alignItems="center" justifyContent="center">
            {text ? (
                <Stack
                    sx={{
                        position: 'absolute',
                    }}
                >
                    <Typography>{text}</Typography>
                </Stack>
            ) : (
                <></>
            )}

            <ReactApexChart
                options={{
                    colors: colors,
                    chart: {
                        type: 'radialBar',
                        offsetY: 0,
                        sparkline: {
                            enabled: true,
                        },
                        parentHeightOffset: 0,
                    },
                    tooltip: {
                        enabled: false,
                        fillSeriesColor: false,
                        y: {
                            formatter: (seriesName: any) => seriesName,
                            title: {
                                formatter: (seriesName: any) => `${seriesName}`,
                            },
                        },
                    },
                    plotOptions: {
                        pie: {
                            donut: {
                                size: '80px',
                            },
                        },
                        radialBar: {
                            hollow: {
                                margin: 0,
                                size: '55%',
                                background: 'transparent',
                            },
                            dataLabels: {
                                show: true,
                                name: {
                                    show: false,
                                },
                                value: {
                                    color: '#323232',
                                    fontSize: '28px',
                                    fontWeight: 700,
                                    show: false,
                                    offsetY: 0,
                                },
                            },
                            startAngle: 0,
                            endAngle: 360,
                            track: {
                                background: '#78C6E7', // Đổi màu cho phần không biểu thị (màu phần nằm ngoài)
                            },
                        },
                    },
                    dataLabels: { enabled: false },
                    legend: { show: false },
                    fill: {
                        type: 'gradient',
                        gradient: {
                            shade: 'dark',
                            type: 'horizontal',
                            shadeIntensity: 0.5,
                            gradientToColors: ['#007DC050', '#007DC0'],
                            inverseColors: true,
                            opacityFrom: 1,
                            opacityTo: 1,
                            stops: [0, 50, 100],
                            colorStops: [],
                        },
                    },
                    stroke: {
                        lineCap: 'round',
                    },
                }}
                width={chartWidth}
                // series={data}
                series={data}
                type="radialBar"
            />
        </Stack>
    );
};
