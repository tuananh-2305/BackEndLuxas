import { HourModel } from '@/models/dashboard.model';
import dynamic from 'next/dynamic';

const ReactApexChart = dynamic(() => import('react-apexcharts'), { ssr: false });
interface LineChartProps {
    data1: number[];
    data2: number[];
}
export const LineChartComponent = (props: LineChartProps) => {
    const { data1, data2 } = props;
    return (
        <ReactApexChart
            options={{
                chart: { toolbar: { show: false } },
                xaxis: {
                    categories: Array.from({ length: data1.length }, (x, i) => `${i}h`),
                },
                stroke: {
                    // colors: ['#1B4DFF', ],
                    curve: 'smooth',
                    width: 2,
                    // fill: {
                    //     type: 'gradient',
                    //     gradient: {
                    //         shadeIntensity: 1,
                    //         opacityFrom: 0.7,
                    //         opacityTo: 0.9,
                    //         stops: [0, 90, 100],
                    //     },
                    // },
                },
                legend: { show: false },
                dataLabels: {
                    enabled: false,
                },
                grid: { show: true, borderColor: '#f2f2f2' },
                yaxis: {
                    show: true,
                    showAlways: true,
                    axisBorder: {
                        show: true,
                        color: '#D0D0D0',
                        offsetX: 0,
                        offsetY: 0,
                    },
                },
            }}
            series={[
                {
                    data: data1,
                    color: '#1B4DFF',
                    name: 'Xe vào',
                },
                {
                    data: data2,
                    color: '#0AC4FF',
                    name: 'Xe ra',
                },
            ]}
            type="area"
            height={'100%'}
        />
    );
};
