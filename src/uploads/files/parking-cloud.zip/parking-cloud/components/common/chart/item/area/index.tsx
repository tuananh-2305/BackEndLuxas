import dynamic from 'next/dynamic';

const ReactApexChart = dynamic(() => import('react-apexcharts'), { ssr: false });

interface AreaChartCompnentProps {
    color: string;
    width?: string;
    height: string;
}

export const AreaChartCompnent = (props: AreaChartCompnentProps) => {
    const { color, width, height } = props;

    return (
        <ReactApexChart
            options={{
                tooltip: {
                    enabled: false,
                    fillSeriesColor: false,
                    y: {
                        formatter: (seriesName: any) => seriesName,
                        title: {
                            formatter: (seriesName: any) => `${seriesName}`,
                        },
                    },
                },
                dataLabels: {
                    enabled: false,
                    textAnchor: 'middle',
                    distributed: true,
                    style: { colors: ['#000'] },
                },
                plotOptions: {
                    bar: {
                        dataLabels: {
                            position: '',
                        },
                        distributed: true,
                    },
                },
                xaxis: {
                    labels: {
                        show: false, // Hide x-axis labels
                    },
                },
                yaxis: {
                    show: false,
                    showAlways: true,
                    axisBorder: {
                        show: true,
                        color: '#D0D0D0',
                        offsetX: 0,
                        offsetY: 0,
                    },
                },
                grid: { show: false },
                chart: { toolbar: { show: false } },
                legend: { show: false },
            }}
            type="area"
            series={[
                {
                    data: [11, 25, 19, 30, 51, 25, 19, 42, 62, 52, 52, 66],
                    color: color,
                },
            ]}
            width={width}
            height={height}
        />
    );
};
