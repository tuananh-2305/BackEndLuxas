import { Stack } from '@mui/material';
import dynamic from 'next/dynamic';
const ReactApexChart = dynamic(() => import('react-apexcharts'), { ssr: false });

interface ColumnChartComponentProps {
    colors: string[];
    labels: string[];
    data: number[];
    title?: string;
    width?: string;
}

export const ColumnChartComponent = (props: ColumnChartComponentProps) => {
    const { colors, data, labels, title, width } = props;
    return (
        <ReactApexChart
            options={{
                colors: colors,
                tooltip: {
                    enabled: false,
                    fillSeriesColor: false,
                    y: {
                        formatter: (seriesName: any) => seriesName,
                        title: {
                            formatter: (seriesName: any) => `${seriesName}`,
                        },
                    },
                },
                dataLabels: {
                    enabled: true,
                    distributed: true,
                    textAnchor: 'middle',
                    style: {
                        colors: undefined,
                    },
                },
                plotOptions: {
                    bar: {
                        dataLabels: {
                            position: '',
                        },
                        distributed: true,
                        columnWidth: '30px',
                        borderRadius: 5,
                        borderRadiusApplication: 'end',
                    },
                },
                grid: {
                    show: true,
                    borderColor: '#f2f2f2',
                    yaxis: {
                        lines: { show: true },
                    },
                },
                chart: { toolbar: { show: false } },
                title: {
                    text: title,
                    style: { color: '#000', fontSize: '13px', fontWeight: '700' },
                },
                labels: labels,
                legend: {
                    show: true,
                    showForSingleSeries: true,
                    position: 'bottom',
                    horizontalAlign: 'center',
                    fontSize: '14px',
                    fontWeight: 500,
                    markers: {
                        width: 12,
                        height: 12,
                        radius: 12,
                    },
                },

                xaxis: {
                    labels: {
                        show: true, // Hide x-axis labels
                    },
                },
                yaxis: {
                    show: true,
                    showAlways: true,
                    axisBorder: {
                        show: true,
                        color: '#D0D0D0',
                        offsetX: 0,
                        offsetY: 0,
                    },
                },
            }}
            type="bar"
            series={[
                {
                    data: data,
                },
            ]}
            height={'100%'}
            width={width ? width : '100%'}
        />
    );
};
