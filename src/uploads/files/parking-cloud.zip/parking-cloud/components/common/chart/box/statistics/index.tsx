import ImageNextjs from '@/components/common/image';
import MoreVertIcon from '@mui/icons-material/MoreVert';
import { Card, CardContent, CardHeader, IconButton, Stack, Typography } from '@mui/material';
import Grid from '@mui/material/Grid';
import styles from '../../dashboard.module.css';

export interface IStatisticsProps {
    isSetting: boolean;
    title: string;
    titleDataFirst: string;
    titleDataSecond: string;
    titleDataThird: string;
    titleDataFourth: string;
    dataFirst: string;
    dataSecond: string;
    dataThird: string;
    dataFourth: string;
    iconFirst: string;
    iconSecond: string;
    iconThird: string;
    iconFourth: string;
}

export default function Statistics(props: IStatisticsProps) {
    return (
        <Card className={styles.card}>
            <CardHeader
                action={
                    props.isSetting ? (
                        <IconButton aria-label="settings">
                            <MoreVertIcon />
                        </IconButton>
                    ) : (
                        <></>
                    )
                }
                title={<Typography className={styles.card_title}>{props.title}</Typography>}
            />
            <CardContent>
                <Grid container rowSpacing={2} columnSpacing={{ xs: 2 }}>
                    {/* item 1 */}

                    <Grid item xs={3}>
                        <Stack
                            className={styles.card_box}
                            sx={{ boxShadow: '0px 4px 16px #C5F4FF', background: '#C5F4FF' }}
                        >
                            <Stack
                                className={styles.card_box_icon}
                                sx={{ background: '#35d4f6', p: '12px' }}
                            >
                                {/* <ImageNextjs path="icons/decive_icon.svg" /> */}
                                <ImageNextjs path={props.iconFirst} />
                            </Stack>
                            <Typography className={styles.card_box_text} sx={{ py: '7px' }}>
                                {props.titleDataFirst}
                            </Typography>
                            <Typography className={styles.card_box_number}>
                                {props.dataFirst || 0}
                            </Typography>
                        </Stack>
                    </Grid>

                    {/* item 2*/}
                    <Grid item xs={3}>
                        <Stack
                            className={styles.card_box}
                            sx={{ boxShadow: '0px 4px 16px #F3E8FF', background: '#F3E8FF' }}
                        >
                            <Stack className={styles.card_box_icon} sx={{ background: '#BF83FF' }}>
                                <ImageNextjs path={props.iconSecond} />
                            </Stack>
                            <Typography className={styles.card_box_text} sx={{ py: '7px' }}>
                                {props.titleDataSecond}
                            </Typography>
                            <Typography className={styles.card_box_number}>
                                {props.dataSecond || 0}
                            </Typography>
                        </Stack>
                    </Grid>
                    {/* item 3*/}
                    <Grid item xs={3}>
                        <Stack
                            className={styles.card_box}
                            sx={{ boxShadow: '0px 4px 16px #DCFCE7', background: '#DCFCE7' }}
                        >
                            <Stack
                                className={styles.card_box_icon}
                                sx={{ background: '#3CD856', p: '10px' }}
                            >
                                <ImageNextjs path={props.iconThird} />
                            </Stack>
                            <Typography className={styles.card_box_text} sx={{ py: '7px' }}>
                                {props.titleDataThird}
                            </Typography>
                            <Typography className={styles.card_box_number}>
                                {props.dataThird || 0}
                            </Typography>
                        </Stack>
                    </Grid>
                    {/* item 4*/}
                    <Grid item xs={3}>
                        <Stack
                            className={styles.card_box}
                            sx={{ boxShadow: '0px 4px 16px #FFF4DE', background: '#FFF4DE' }}
                        >
                            <Stack
                                className={styles.card_box_icon}
                                sx={{ background: '#FF947A', p: '10px' }}
                            >
                                <ImageNextjs path={props.iconFourth} />
                            </Stack>
                            <Typography className={styles.card_box_text} sx={{ py: '7px' }}>
                                {props.titleDataFourth}
                            </Typography>
                            <Typography className={styles.card_box_number}>
                                {props.dataFourth || 0}
                            </Typography>
                        </Stack>
                    </Grid>
                </Grid>
            </CardContent>
        </Card>
    );
}
