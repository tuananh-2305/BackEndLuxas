import { convertToDataChart } from '@/ultis/index';
import { Card, CardContent, CardHeader, Typography } from '@mui/material';
import { useMemo } from 'react';
import styles from '../../dashboard.module.css';
import { ColumnChartComponent } from '../../item';
export interface IVehicleOccupancyChartProps {
    title: string;
    data: any[] | null;
}

export default function VehicleOccupancyChart(props: IVehicleOccupancyChartProps) {
    const dataChartType = useMemo(() => {
        if (!props.data) return [];
        return convertToDataChart(props.data, 'Xe khác');
    }, [props.data]);

    return (
        <Card className={styles.card}>
            <CardHeader
                title={<Typography className={styles.card_title}>{props.title}</Typography>}
            />
            <CardContent
                sx={{
                    minHeight: '150px',
                    pt: '0px',
                    paddingBottom: '15px !important',
                }}
            >
                <ColumnChartComponent
                    colors={['#067DC0', '#FFB862', '#78C6E7', '#55595D']}
                    // data={[39, 25, 19, 30]}
                    data={dataChartType.map((item) => item.Total)}
                    labels={dataChartType.map((item) => item.Name)}
                    // title="Xe trong bãi"
                    width="100%"
                />
            </CardContent>
        </Card>
    );
}
