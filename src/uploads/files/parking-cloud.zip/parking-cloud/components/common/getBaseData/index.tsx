import { authApi } from '@/api/auth-api';
import { useRouter } from 'next/router';
import { useEffect } from 'react';
import {
    changeParkingChoose,
    changeParkingChooseDashboard,
    updaProfile,
    updateDataParkings,
    updateProvinces,
    updateVehicleTypes,
} from '@/redux/index';
import { useAppDispatch, useAppSelector } from '@/hooks/useReudx';
import { groupRoleApi, parkingApi } from '@/api/index';
import { addressApi } from '@/api/address';
import { ParkingModel } from '@/models/index';
import {
    PARKING_CHOSE_DASHBOARD,
    PARKING_CHOSE_SETTING,
    getRoleReport,
    getRoleSetting,
} from '@/ultis/index';
import { CookieStoreControl } from '@/hooks/cookie-storage';
import { vehicleTypeApi } from '@/api/vehicle-type-api';

interface GetBaseDateReduxProps {
    children: JSX.Element;
}
const cookieInstance = CookieStoreControl.getInstance();
export const GetBaseDateRedux = (props: GetBaseDateReduxProps) => {
    const { children } = props;
    const router = useRouter();

    const profile = useAppSelector((state) => state.common.profile);
    const provinces = useAppSelector((state) => state.common.provinces);
    const parkings = useAppSelector((state) => state.parking.parkings);
    const vehicleTypes = useAppSelector((state) => state.common.vehicleTypes);
    const dispatch = useAppDispatch();
    useEffect(() => {
        const refesh = cookieInstance.token.get_refesh_token();
        const access = cookieInstance.token.get_access_token();

        if (router.asPath !== '/login' && !profile) {
            if (refesh && access) {
                authApi.getProfile().then((res) => {
                    const action = updaProfile({ profile: res.data });
                    dispatch(action);
                });
            }
        }
    }, [dispatch, profile, router.asPath]);
    // call api
    // alert error

    useEffect(() => {
        if (!provinces || provinces.length == 0) {
            addressApi.getProvinces().then((res) => {
                const action = updateProvinces({ provinces: res.data });
                dispatch(action);
            });
        }
    }, [dispatch, provinces]);

    useEffect(() => {
        if (!profile) {
            return;
        }
        if (!vehicleTypes || vehicleTypes.length == 0) {
            vehicleTypeApi
                .getVehicleTypes()
                .then((res) => {
                    const action = updateVehicleTypes({ vehicleTypes: res?.data });
                    dispatch(action);
                })
                .catch((err) => {
                    console.log('err', err);
                });
        }
    }, [dispatch, vehicleTypes, profile]);

    useEffect(() => {
        if (profile) {
            parkingApi.getAllParking().then((res) => {
                // console.log('data', res.data);
                const action = updateDataParkings({ data: res.data });
                dispatch(action);
                const parkingReport = getRoleReport(profile, res.data);
                if (res?.data?.length > 0 && parkings?.length == 0) {
                    // const profileClone = structuredClone(profile);
                    const profileClone = JSON.parse(JSON.stringify(profile));
                    const parkingSetting = getRoleSetting(profile, res.data);
                    profileClone.IsDashboard = true;
                    const currentParkingChooseId =
                        localStorage.getItem(PARKING_CHOSE_DASHBOARD) || '';
                    let parkingChoose = parkingReport.find(
                        (item) => item.ID == currentParkingChooseId
                    );
                    if (!parkingChoose) {
                        parkingChoose = parkingReport[0];
                    }
                    const actionChoseReport = changeParkingChooseDashboard({
                        parking: parkingChoose,
                    });
                    dispatch(actionChoseReport);
                    localStorage.setItem(PARKING_CHOSE_DASHBOARD, parkingChoose?.ID || '');

                    if (parkingSetting.length > 0) {
                        const currentParkingSettingChooseId =
                            localStorage.getItem(PARKING_CHOSE_SETTING) || '';
                        let parkingChooseSetting = parkingSetting.find(
                            (item) => item.ID == currentParkingSettingChooseId
                        );
                        if (!parkingChooseSetting) {
                            parkingChooseSetting = parkingSetting[0];
                        }
                        const actionChoseDefault = changeParkingChoose({
                            parking: parkingChooseSetting,
                        });
                        dispatch(actionChoseDefault);
                        profileClone.IsSetting = true;
                        localStorage.setItem(PARKING_CHOSE_SETTING, parkingChooseSetting?.ID || '');
                    }
                    const action = updaProfile({ profile: profileClone });
                    dispatch(action);

                    return;
                }
            });
        }
    }, [dispatch, profile]);
    return children;
};
